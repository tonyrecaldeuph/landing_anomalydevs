/**
 * Dashboard UI Logic - WhatsAppProSend Campañas Masivas
 * Maneja eventos de la interfaz y comunicación con el background/content script.
 */

document.addEventListener('DOMContentLoaded', () => {
    console.log('UPHONE Dashboard: Inicializado con éxito.');
    Analytics.track('dashboard_open');

    // --- Selectores principales ---
    const sendBtn = document.getElementById('btn-enviar-ahora');
    const stopBtn = document.getElementById('btn-detener');
    const messageText = document.getElementById('message-text');
    const resetBtn = document.querySelector('.btn-danger-outline');
    const importBtn = document.querySelector('.btn-import');
    const fileInput = document.getElementById('contact-file-input');
    const contactCountBadge = document.getElementById('contact-count');
    const variablesContainer = document.getElementById('variables-container');
    const variableTags = document.getElementById('variable-tags');

    // Variantes de mensaje (pool) y tiempos
    const variantesList = document.getElementById('variantes-list');
    const btnAddVariante = document.getElementById('btn-add-variante');

    const connectionDot = document.getElementById('connection-dot');
    const connectionText = document.getElementById('connection-text');

    // Modals
    const navHistorial = document.getElementById('nav-historial');
    const navSoporte = document.getElementById('nav-soporte');
    const navLicencia = document.getElementById('nav-licencia');
    const modalHistorial = document.getElementById('modal-historial');
    const modalSoporte = document.getElementById('modal-soporte');
    const modalLicencia = document.getElementById('modal-licencia');
    const btnCerrarModals = document.querySelectorAll('.btn-close');

    // Licencia
    const licenseBadge = document.getElementById('license-badge');
    const licenseInfo = document.getElementById('license-info');
    const appVersion = document.getElementById('app-version');
    if (appVersion) {
        appVersion.textContent = Utils.formatVersionBadge(chrome.runtime.getManifest().version);
    }
    const inputLicenseKey = document.getElementById('input-license-key');
    const btnActivarLicencia = document.getElementById('btn-activar-licencia');

    // Promociones e Imágenes Selectores
    const selectPromocion = document.getElementById('select-promocion');
    const btnEliminarPromo = document.getElementById('btn-eliminar-promo');
    const btnGuardarPromo = document.getElementById('btn-guardar-promo');
    const inputImagen = document.getElementById('input-imagen');
    const btnCargarImagen = document.getElementById('btn-cargar-imagen');
    const btnQuitarImagen = document.getElementById('btn-quitar-imagen');
    const previewImagenContainer = document.getElementById('preview-imagen-container');
    const previewImagen = document.getElementById('preview-imagen');

    // Puente ADB (bridge/server.js): cuentas, estado y progreso en vivo
    const puenteEstadoBadge = document.getElementById('puente-estado');
    const puenteAviso = document.getElementById('puente-aviso');
    const listaCuentas = document.getElementById('lista-cuentas');
    const puenteProgreso = document.getElementById('puente-progreso');
    const btnVentanaProgreso = document.getElementById('btn-ventana-progreso');
    const btnRefrescarCuentas = document.getElementById('btn-refrescar-cuentas');
    const btnReiniciarPuente = document.getElementById('btn-reiniciar-puente');
    const inputTopeDiario = document.getElementById('input-tope-diario');

    // --- Estado de la aplicación ---
    let contacts = [];
    let availableVariables = [];
    let currentImageDataUrl = '';
    let promotions = [];
    
    // --- Configuración Opciones de Envío ---
    // (Sliders de tiempo removidos: ahora el tiempo está fijo a 2 segundos)

    // --- Gate combinado del botón Enviar: puente + cuentas + contactos + licencia ---
    // El canal de WhatsApp Web está fuera de alcance (spec 1): la campaña corre
    // en el puente ADB, así que lo que habilita el envío es el puente conectado
    // con al menos una cuenta tildada, no una pestaña de WhatsApp Web abierta.
    let isPuenteListo = false;
    let isLicenseAllowed = false;
    let hasPromptedForLicense = false;

    function updateSendButtonState() {
        sendBtn.disabled = !(isPuenteListo && cuentasHabilitadas.length > 0 && isLicenseAllowed && contacts.length > 0);
    }

    // --- Borrador (draft) previo a iniciar campaña ---
    // El popup de la extensión se destruye por completo al hacer clic fuera de él
    // (no es una pestaña, MV3 lo cierra) — sin guardar el trabajo en progreso
    // (Excel cargado + mensaje escrito) antes de darle "Enviar", salir del popup
    // borraba todo. currentCampaign solo se guarda AL enviar; esto cubre el resto.
    let draftSaveTimer = null;
    function scheduleDraftSave() {
        clearTimeout(draftSaveTimer);
        draftSaveTimer = setTimeout(saveDraft, 500);
    }
    function saveDraft() {
        if (contacts.length === 0 && !messageText.value) return; // nada que guardar
        chrome.storage.local.set({
            draftCampaign: {
                contacts,
                messageTemplate: messageText.value,
                messageVariants: collectMessageVariants(),
                imageDataUrl: currentImageDataUrl,
                promoId: selectPromocion ? selectPromocion.value : ''
            }
        });
    }
    function restoreDraft() {
        chrome.storage.local.get(['draftCampaign'], (data) => {
            const draft = data.draftCampaign;
            if (!draft || !Array.isArray(draft.contacts) || draft.contacts.length === 0) return;
            if (contacts.length > 0) return; // ya hay datos (ej. campaña activa restaurada), no pisar

            contacts = draft.contacts;
            updateSendButtonState();
            availableVariables = DataProcessor.getAvailableVariables(contacts);

            if (draft.messageTemplate) messageText.value = draft.messageTemplate;
            if (variantesList && Array.isArray(draft.messageVariants) && draft.messageVariants.length > 1) {
                variantesList.innerHTML = '';
                draft.messageVariants.slice(1).forEach(v => addVarianteRow(v));
            }
            if (draft.imageDataUrl) {
                currentImageDataUrl = draft.imageDataUrl;
                showImagePreview(draft.imageDataUrl);
            }
            if (draft.promoId && selectPromocion) selectPromocion.value = draft.promoId;

            updateUIWithContacts();
            console.log(`Borrador restaurado: ${contacts.length} contacto(s), mensaje incluido`);
        });
    }

    // --- Puente ADB: conexión, cuentas y progreso en vivo ---
    // El popup se destruye al cerrarse, así que el cliente no reconecta solo:
    // cada apertura conecta de nuevo y pide `status`, que es como el puente
    // recupera una campaña en curso (difunde el progreso a todos los clientes).
    const puente = PuenteClient.crearPuenteClient({});
    let cuentasDetectadas = [];
    let cuentasSinSesion = []; // instaladas sin número: se muestran bloqueadas
    let cuentasHabilitadas = [];
    let campaniaPuente = null; // definición de la campaña en vuelo, para el historial

    // Dos cosas distintas pueden necesitar el mismo renglón de aviso (puente
    // desactualizado y cuota agotada), así que se juntan en vez de pisarse.
    let avisoCuota = '';

    function pintarAviso() {
        if (!puenteAviso) return;
        const partes = [puente.aviso(), avisoCuota].filter((t) => !!t);
        puenteAviso.textContent = partes.join(' ');
        puenteAviso.style.display = partes.length > 0 ? '' : 'none';
    }

    function pintarEstadoPuente(texto, verde) {
        if (btnReiniciarPuente) btnReiniciarPuente.textContent = verde ? 'Reiniciar puente' : 'Iniciar puente';
        connectionDot.className = verde ? 'dot green' : 'dot red';
        connectionText.textContent = texto;
        if (puenteEstadoBadge) puenteEstadoBadge.textContent = 'Puente: ' + texto;
        pintarAviso();
        isPuenteListo = puente.puedeIniciar();
        updateSendButtonState();
    }

    function guardarCuentasHabilitadas() {
        chrome.storage.local.set({ enabledTargets: cuentasHabilitadas });
    }

    /**
     * La primera búsqueda abre cada WhatsApp del celular para ver si tiene
     * número (~5 s por cuenta). Sin este aviso la lista vacía parecía una falla.
     */
    function mostrarBuscandoCuentas() {
        if (!listaCuentas || cuentasDetectadas.length > 0) return;
        listaCuentas.innerHTML = '';
        const aviso = document.createElement('div');
        aviso.style.color = 'var(--text-muted)';
        aviso.style.fontSize = '0.85rem';
        aviso.textContent = 'Buscando cuentas… se abre cada WhatsApp del celular para ver si tiene número (puede tardar unos 30 s).';
        listaCuentas.appendChild(aviso);
    }

    function renderCuentas() {
        if (!listaCuentas) return;
        // El tope que manda es el del formulario (va en `config.tope`); del
        // puente solo se toman los enviados del dia.
        const filas = PuenteClient.filasDeCuentas(cuentasDetectadas, cuentasHabilitadas, {
            tope: PuenteClient.normalizarTope(inputTopeDiario ? inputTopeDiario.value : ''),
            porTarget: puente.estado().cuota.porTarget
        }, cuentasSinSesion);
        listaCuentas.innerHTML = '';
        if (filas.length === 0) {
            const vacio = document.createElement('div');
            vacio.style.color = 'var(--text-muted)';
            vacio.style.fontSize = '0.85rem';
            vacio.textContent = 'Sin cuentas detectadas. Conecta los celulares por USB y pulsa "Buscar cuentas".';
            listaCuentas.appendChild(vacio);
            avisoCuota = '';
            pintarAviso();
            updateSendButtonState();
            return;
        }
        filas.forEach((fila) => {
            const label = document.createElement('label');
            label.style.display = 'flex';
            label.style.alignItems = 'center';
            label.style.gap = '8px';
            label.style.fontSize = '0.85rem';
            // Interruptor como el de las demás opciones: el checkbox nativo casi
            // no se ve en el tema oscuro.
            const interruptor = document.createElement('span');
            interruptor.className = 'switch';
            const tilde = document.createElement('input');
            tilde.type = 'checkbox';
            tilde.checked = fila.habilitado;
            tilde.disabled = fila.sinSesion;
            tilde.dataset.target = fila.target;
            tilde.addEventListener('change', () => {
                cuentasHabilitadas = PuenteClient.alternarCuenta(cuentasHabilitadas, fila.target, tilde.checked);
                guardarCuentasHabilitadas();
                updateSendButtonState();
            });
            const deslizador = document.createElement('span');
            deslizador.className = 'slider round';
            interruptor.appendChild(tilde);
            interruptor.appendChild(deslizador);
            const texto = document.createElement('span');
            texto.textContent = fila.etiqueta;
            const cuotaTexto = document.createElement('span');
            cuotaTexto.style.marginLeft = 'auto';
            cuotaTexto.style.fontSize = '0.78rem';
            if (fila.sinSesion) {
                // Clon de app dual sin registrar: abre en la bienvenida de WhatsApp
                cuotaTexto.textContent = 'sin número registrado';
                cuotaTexto.style.color = 'var(--text-muted)';
                texto.style.opacity = '0.5';
                label.style.cursor = 'not-allowed';
                label.title = 'Esta app no tiene una cuenta de WhatsApp. Inicia sesión en el celular y pulsa "Buscar cuentas".';
            } else if (fila.agotada) {
                // Una cuenta en el tope del día no envía: el puente la saltea y
                // los contactos quedan Pendiente. Mejor decirlo antes de enviar.
                cuotaTexto.textContent = 'cuota agotada (' + fila.tope + '/' + fila.tope + ')';
                cuotaTexto.style.color = 'var(--color-danger, #d9534f)';
                texto.style.opacity = '0.6';
            } else {
                cuotaTexto.textContent = 'quedan ' + fila.restante + ' de ' + fila.tope;
                cuotaTexto.style.color = 'var(--text-muted)';
            }
            label.appendChild(interruptor);
            label.appendChild(texto);
            label.appendChild(cuotaTexto);
            listaCuentas.appendChild(label);
        });
        // Aviso cuando TODAS las tildadas están agotadas: la campaña arrancaría
        // y dejaría todo Pendiente sin mandar un solo mensaje.
        const tildadas = filas.filter((f) => f.habilitado);
        avisoCuota = tildadas.length > 0 && tildadas.every((f) => f.agotada)
            ? 'Todas las cuentas tildadas llegaron al tope diario (' + tildadas[0].tope +
              '). Vuelven a subir mañana, o subí el tope si tus cuentas lo aguantan.'
            : '';
        pintarAviso();
        updateSendButtonState();
    }

    function conectarPuente() {
        pintarEstadoPuente('conectando...', false);
        puente.conectar().then(() => {
            const est = puente.estado();
            pintarEstadoPuente(est.aislamiento === 'supported'
                ? 'conectado (v' + est.bridgeVersion + ')'
                : 'desactualizado', est.aislamiento === 'supported');
            mostrarBuscandoCuentas();
            puente.listarCuentas();
            puente.pedirEstado();
        }, () => {
            pintarEstadoPuente('apagado', false);
            // El usuario final no abre terminales: si el puente está apagado al
            // abrir el dashboard, se inicia solo (una vez por apertura).
            if (!arranqueAutomaticoIntentado) {
                arranqueAutomaticoIntentado = true;
                controlarPuenteDesdeUI('start', { silencioso: true });
            }
        });
    }

    let arranqueAutomaticoIntentado = false;

    /**
     * Inicia o reinicia el puente por el lanzador nativo (native-launcher) y
     * vuelve a conectar. Sin el lanzador registrado no hay forma de arrancarlo
     * desde la extensión: se explica qué hacer en vez de mostrar el error crudo.
     */
    function controlarPuenteDesdeUI(comando, opciones) {
        const silencioso = !!(opciones && opciones.silencioso);
        if (btnReiniciarPuente) btnReiniciarPuente.disabled = true;
        pintarEstadoPuente(comando === 'start' ? 'iniciando...' : 'reiniciando...', false);
        chrome.runtime.sendMessage({ action: 'BRIDGE_CONTROL', command: comando }, (res) => {
            if (btnReiniciarPuente) btnReiniciarPuente.disabled = false;
            if (chrome.runtime.lastError || !res || res.ok !== true) {
                const detalle = (res && res.message) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || '';
                pintarEstadoPuente('apagado', false);
                const texto = 'No se pudo iniciar el puente ADB. Si es la primera vez en este computador, ' +
                    'ejecuta una vez el instalador (native-launcher\\install.exe) y vuelve a abrir la extensión.';
                if (puenteAviso) {
                    puenteAviso.textContent = texto;
                    puenteAviso.style.display = '';
                }
                if (!silencioso) alert(texto + (detalle ? '\n\nDetalle: ' + detalle : ''));
                return;
            }
            puente.cerrar();
            setTimeout(conectarPuente, 2000);
        });
    }

    puente.escuchar('devices', (msg) => {
        cuentasDetectadas = Array.isArray(msg.devices) ? msg.devices : [];
        cuentasSinSesion = Array.isArray(msg.sinSesion) ? msg.sinSesion : [];
        // Una cuenta tildada que ya no está conectada no puede enviar: se
        // destilda para que el botón no prometa un envío que el puente
        // rechazaría con NO_ENABLED_TARGETS.
        cuentasHabilitadas = cuentasHabilitadas.filter((t) => cuentasDetectadas.includes(t));
        guardarCuentasHabilitadas();
        renderCuentas();
    });

    /**
     * Miniventana de progreso (ui/progreso.html) abajo a la derecha: el popup se
     * cierra al hacer clic fuera, una ventana chica de Chrome sigue a la vista.
     * Si ya está abierta, se trae al frente en vez de abrir otra.
     */
    const ANCHO_VENTANA = 340;
    const ALTO_VENTANA = 260;
    function abrirMiniventana() {
        const crear = () => {
            chrome.windows.create({
                url: chrome.runtime.getURL('ui/progreso.html'),
                type: 'popup',
                width: ANCHO_VENTANA,
                height: ALTO_VENTANA,
                left: Math.max(0, screen.availWidth - ANCHO_VENTANA - 16),
                top: Math.max(0, screen.availHeight - ALTO_VENTANA - 16),
                focused: false
            }, (ventana) => {
                if (ventana) chrome.storage.local.set({ ventanaProgresoId: ventana.id });
            });
        };
        chrome.storage.local.get(['ventanaProgresoId'], (data) => {
            if (!data.ventanaProgresoId) { crear(); return; }
            chrome.windows.update(data.ventanaProgresoId, { focused: true }, () => {
                if (chrome.runtime.lastError) crear(); // la cerraron: se abre otra
            });
        });
    }
    if (btnVentanaProgreso) btnVentanaProgreso.addEventListener('click', abrirMiniventana);

    puente.escuchar('started', (msg) => {
        abrirMiniventana();
        if (puenteProgreso) {
            puenteProgreso.style.display = '';
            puenteProgreso.textContent = 'Campaña en curso: 0/' + (msg.total || 0);
        }
        // El id une la campaña guardada aquí con su resultado en el puente: sin él,
        // un resultado recuperado tras cerrar el popup no sabría qué contactos eran.
        if (campaniaPuente && msg.campaignId) {
            campaniaPuente.campaignId = msg.campaignId;
            chrome.storage.local.set({ currentCampaign: campaniaPuente });
        }
    });

    /**
     * Resultados que el puente guardó y nadie confirmó (popup cerrado al
     * terminar, o el puente murió a mitad): entran al historial una sola vez
     * y se confirman. Con eso "Retomar envío" manda solo lo pendiente.
     */
    function recuperarSinConfirmar(pendientes) {
        if (!Array.isArray(pendientes) || pendientes.length === 0) return;
        chrome.storage.local.get(['history', 'currentCampaign'], (data) => {
            const history = Array.isArray(data.history) ? data.history : [];
            const yaEstan = new Set(history.map((h) => h && h.campaignId).filter((id) => !!id));
            pendientes.forEach((entrada) => {
                if (!entrada || !entrada.campaignId) return;
                if (!yaEstan.has(entrada.campaignId)) {
                    history.unshift(PuenteClient.historialDesdePendiente(entrada, data.currentCampaign));
                    yaEstan.add(entrada.campaignId);
                }
            });
            chrome.storage.local.set({ history }, () => {
                pendientes.forEach((entrada) => { if (entrada && entrada.campaignId) puente.confirmar(entrada.campaignId); });
            });
        });
    }

    puente.escuchar('progress', (msg) => {
        if (puenteProgreso) {
            puenteProgreso.style.display = '';
            let etiqueta = msg.target || '';
            try {
                etiqueta = WhatsAppTargets.etiquetaTarget(msg.target);
            } catch (_) { /* target que no parsea: se muestra crudo */ }
            puenteProgreso.textContent = (msg.index + 1) + '. ' + (msg.phone || '') + ' — ' + (msg.status || '') +
                (etiqueta ? ' (' + etiqueta + ')' : '');
        }
        pintarResultado(msg.index, msg.status);
    });

    /** Fila de un contacto con la misma etiqueta y color que el resumen. */
    function pintarResultado(index, status) {
        const statusEl = document.getElementById(`status-row-${index}`);
        if (!statusEl) return;
        statusEl.value = displayResultLabel(status || '');
        statusEl.style.color = resultColor(status || '');
        statusEl.style.fontWeight = 'bold';
    }

    puente.escuchar('error', (msg) => {
        if (puenteProgreso) {
            puenteProgreso.style.display = '';
            puenteProgreso.textContent = 'Error del puente (' + (msg.code || '') + '): ' + (msg.message || '');
        }
        alert('El puente ADB no pudo enviar: ' + (msg.message || msg.code || 'error desconocido'));
    });

    puente.escuchar('done', (msg) => {
        if (puenteProgreso) puenteProgreso.textContent = 'Campaña terminada.';
        const item = PuenteClient.historialDesdeDone(msg, campaniaPuente || {});
        campaniaPuente = null;
        chrome.storage.local.get(['history'], (data) => {
            const history = Array.isArray(data.history) ? data.history : [];
            history.unshift(item);
            // `campaignFinished` dispara el resumen y restaura los botones: el
            // mismo camino que usa el canal Web desde background.js.
            chrome.storage.local.set({ history, campaignFinished: true });
        });
        // El resultado durable del puente queda confirmado recién cuando el
        // historial lo tiene guardado.
        if (msg.campaignId) puente.confirmar(msg.campaignId);
    });

    puente.escuchar('quota', (msg) => {
        // El puente manda la cuota al cerrar cada campaña: el restante del día
        // se ve sin tener que reiniciar nada.
        if (inputTopeDiario && Number(msg.tope) > 0) inputTopeDiario.value = msg.tope;
        renderCuentas();
    });

    puente.escuchar('status', (msg) => {
        recuperarSinConfirmar(msg.sinConfirmar);
        if (msg.isRunning) {
            sendBtn.disabled = true;
            stopBtn.style.display = 'flex';
            if (puenteProgreso) {
                puenteProgreso.style.display = '';
                puenteProgreso.textContent = 'Campaña en curso: ' + (msg.progressIndex || 0) + '/' + (msg.total || 0);
            }
            // Popup reabierto: reponer los contactos de la campaña en curso y sus resultados
            chrome.storage.local.get(['currentCampaign'], (data) => {
                const r = PuenteClient.campaniaParaRestaurar(data.currentCampaign, msg);
                if (!r.restaurar) return;
                campaniaPuente = r.campania;
                contacts = r.campania.contacts;
                renderContactList();
                r.resultados.forEach((x) => pintarResultado(x.index, x.status));
            });
        }
    });

    puente.escuchar('cerrado', () => {
        pintarEstadoPuente('apagado', false);
    });

    if (btnRefrescarCuentas) {
        btnRefrescarCuentas.addEventListener('click', () => {
            // Verificar abre cada WhatsApp en el celular (unos segundos por cuenta)
            if (puente.estado().conectado) {
                mostrarBuscandoCuentas();
                puente.listarCuentas({ verificar: true });
            }
            else conectarPuente();
        });
    }

    if (btnReiniciarPuente) {
        btnReiniciarPuente.addEventListener('click', () => {
            controlarPuenteDesdeUI(puente.estado().conectado ? 'restart' : 'start');
        });
    }

    if (inputTopeDiario) {
        inputTopeDiario.addEventListener('change', () => {
            inputTopeDiario.value = PuenteClient.normalizarTope(inputTopeDiario.value);
            chrome.storage.local.set({ topeDiario: Number(inputTopeDiario.value) });
            renderCuentas();
        });
    }

    chrome.storage.local.get(['enabledTargets', 'topeDiario'], (data) => {
        cuentasHabilitadas = Array.isArray(data.enabledTargets) ? data.enabledTargets : [];
        if (inputTopeDiario) inputTopeDiario.value = PuenteClient.normalizarTope(data.topeDiario);
        renderCuentas();
        conectarPuente();
    });

    // --- Estado de licencia (badge + gate) ---
    const LICENSE_REASON_TEXT = {
        no_license: 'No hay una licencia activada en este dispositivo.',
        not_found: 'La clave de licencia ingresada no existe.',
        pending: 'La licencia aún no ha iniciado su vigencia.',
        expired: 'La licencia ha vencido.',
        suspended: 'La licencia está suspendida.',
        device_not_registered: 'Este dispositivo no está registrado en la licencia.',
        device_limit_reached: 'Se alcanzó el cupo máximo de dispositivos de esta licencia.',
        offline_grace_expired: 'No se pudo validar la licencia con el servidor y venció el margen de 48h sin conexión.',
        network_error: 'No se pudo contactar al servidor de licencias.',
        invalid_state: 'Estado de licencia inconsistente. Vuelve a activarla.'
    };

    function renderLicenseBadge(result) {
        if (result.allowed) {
            const soonToExpire = typeof result.daysRemaining === 'number' && result.daysRemaining <= 30;
            licenseBadge.textContent = soonToExpire
                ? `🟡 ${result.companyName} — vence en ${result.daysRemaining} día(s)`
                : `🟢 ${result.companyName} — ${result.daysRemaining} día(s) restantes`;
        } else {
            licenseBadge.textContent = `🔴 ${LICENSE_REASON_TEXT[result.reason] || 'Licencia no válida.'}`;
        }

        if (licenseInfo) {
            const lineas = Utils.licenseInfoLines(result, LICENSE_REASON_TEXT[result.reason] || '');
            licenseInfo.replaceChildren(...lineas.map((texto) => {
                const linea = document.createElement('div');
                linea.textContent = texto;
                return linea;
            }));
        }
    }

    function refreshLicenseStatus() {
        chrome.runtime.sendMessage({ action: 'LICENSE_STATUS' }, (result) => {
            if (chrome.runtime.lastError || !result) return;
            isLicenseAllowed = result.allowed === true;
            renderLicenseBadge(result);
            updateSendButtonState();

            if (!hasPromptedForLicense && result.reason === 'no_license') {
                hasPromptedForLicense = true;
                if (modalLicencia) modalLicencia.style.display = 'flex';
            }
        });
    }

    // Chequear cada 60 segundos (la revalidación real contra el backend la hace
    // el service worker cada 6h vía chrome.alarms; esto solo refresca la UI
    // con el último estado cacheado)
    setInterval(refreshLicenseStatus, 60000);
    refreshLicenseStatus();

    if (navLicencia && modalLicencia) {
        navLicencia.addEventListener('click', (e) => {
            e.preventDefault();
            modalLicencia.style.display = 'flex';
        });
    }
    if (licenseBadge && modalLicencia) {
        licenseBadge.addEventListener('click', () => {
            modalLicencia.style.display = 'flex';
        });
    }

    if (btnActivarLicencia) {
        btnActivarLicencia.addEventListener('click', () => {
            const key = (inputLicenseKey.value || '').trim();
            if (!key) {
                alert('Ingresa una clave de licencia.');
                return;
            }
            btnActivarLicencia.disabled = true;
            btnActivarLicencia.textContent = 'Activando...';
            chrome.runtime.sendMessage({ action: 'LICENSE_ACTIVATE', licenseKey: key }, (result) => {
                btnActivarLicencia.disabled = false;
                btnActivarLicencia.textContent = 'Activar';
                if (chrome.runtime.lastError || !result) {
                    alert('No se pudo contactar al servidor de licencias. Intenta de nuevo.');
                    return;
                }
                isLicenseAllowed = result.allowed === true;
                renderLicenseBadge(result);
                updateSendButtonState();
                if (result.allowed) {
                    alert(`Licencia activada: ${result.companyName}. Vigente hasta ${result.endDate}.`);
                    if (modalLicencia) modalLicencia.style.display = 'none';
                } else {
                    alert(LICENSE_REASON_TEXT[result.reason] || 'No se pudo activar la licencia.');
                }
            });
        });
    }

    restoreDraft();

    // --- Manejo de Modales ---
    function openModal(modal) {
        modal.style.display = 'flex';
    }

    function closeModal(modal) {
        modal.style.display = 'none';
    }

    navHistorial.addEventListener('click', (e) => {
        e.preventDefault();

        chrome.storage.local.get(['history'], (data) => {
            const historyList = document.getElementById('historial-lista');
            historyList.innerHTML = '';

            if (data.history && data.history.length > 0) {
                data.history.forEach((item, idx) => {
                    const li = document.createElement('li');
                    li.style.padding = '15px';
                    li.style.marginBottom = '10px';
                    li.style.backgroundColor = 'var(--bg-tertiary)';
                    li.style.borderRadius = 'var(--radius-md)';
                    li.style.border = '1px solid var(--border-color)';
                    li.style.display = 'flex';
                    li.style.flexDirection = 'column';
                    li.style.gap = '10px';

                    const headerDiv = document.createElement('div');
                    headerDiv.style.display = 'flex';
                    headerDiv.style.justifyContent = 'space-between';
                    headerDiv.style.alignItems = 'center';

                    let statusIcon = '✅';
                    let statusColor = '#22c55e';
                    if (item.status === 'Detenida') {
                        statusIcon = '⛔';
                        statusColor = '#eab308';
                    }

                    const resumen = summarizeResults(item.contactResults || []);
                    headerDiv.innerHTML = `
                        <div>
                            <div style="font-weight: 600; font-size: 1.05rem; color: var(--text-main); margin-bottom: 4px;">
                                ${new Date(item.date).toLocaleString()}
                            </div>
                            <div style="font-size: 0.85rem; color: var(--text-muted);">
                                👥 ${item.contactCount} contactos procesados
                            </div>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 2px;">
                                ✅ ${resumen.enviados} enviados · ⚪ ${resumen.sinWhatsApp} sin WhatsApp · ❌ ${resumen.errores} errores
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 6px; background: rgba(0,0,0,0.2); padding: 4px 10px; border-radius: 20px; font-size: 0.85rem; font-weight: bold; color: ${statusColor}; border: 1px solid ${statusColor}40;">
                            ${statusIcon} ${item.status}
                        </div>
                    `;
                    li.appendChild(headerDiv);

                    // Botones de descarga si hay resultados detallados
                    if (item.contactResults && item.contactResults.length > 0) {
                        const actionsDiv = document.createElement('div');
                        actionsDiv.style.display = 'flex';
                        actionsDiv.style.justifyContent = 'flex-end';
                        actionsDiv.style.gap = '8px';
                        actionsDiv.style.marginTop = '5px';
                        actionsDiv.style.paddingTop = '10px';
                        actionsDiv.style.borderTop = '1px dashed var(--border-color)';

                        const btnCSV = document.createElement('button');
                        btnCSV.className = 'btn btn-muted';
                        btnCSV.style.padding = '6px 12px';
                        btnCSV.style.fontSize = '0.8rem';
                        btnCSV.innerHTML = '📄 CSV';
                        btnCSV.addEventListener('click', () => exportHistoryAsCSV(item));

                        const btnXLS = document.createElement('button');
                        btnXLS.className = 'btn btn-muted';
                        btnXLS.style.padding = '6px 12px';
                        btnXLS.style.fontSize = '0.8rem';
                        btnXLS.innerHTML = '📊 XLS';
                        btnXLS.addEventListener('click', () => exportHistoryAsXLS(item));

                        actionsDiv.appendChild(btnCSV);
                        actionsDiv.appendChild(btnXLS);

                        // Se retoma lo que falte, sin importar cómo terminó: errores,
                        // pendientes por cuota o lo que una caída dejó sin procesar.
                        {
                            const pending = computePendingContacts(item.contacts || [], item.contactResults || []);
                            if (pending.length > 0) {
                                const btnRetomar = document.createElement('button');
                                btnRetomar.className = 'btn btn-accent';
                                btnRetomar.style.padding = '6px 12px';
                                btnRetomar.style.fontSize = '0.8rem';
                                btnRetomar.innerHTML = `▶️ Retomar (${pending.length})`;
                                btnRetomar.addEventListener('click', () => {
                                    closeModal(modalHistorial);
                                    resumeCampaignFromHistory(item);
                                });
                                actionsDiv.appendChild(btnRetomar);
                            }
                        }

                        li.appendChild(actionsDiv);
                    }

                    historyList.appendChild(li);
                });
            } else {
                historyList.innerHTML = '<li style="padding: 15px; text-align: center; color: var(--text-muted);">Aún no hay campañas guardadas en el historial.</li>';
            }
        });
        openModal(modalHistorial);
    });

    // Soporte modal
    if (navSoporte && modalSoporte) {
        navSoporte.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(modalSoporte);
        });
    }

    // Ayuda → abre el modal de Soporte
    const btnAyuda = document.getElementById('btn-ayuda');
    if (btnAyuda && modalSoporte) {
        btnAyuda.addEventListener('click', () => {
            openModal(modalSoporte);
        });
    }

    btnCerrarModals.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal-overlay');
            closeModal(modal);
        });
    });

    const btnBorrarHistorial = document.getElementById('btn-borrar-historial');
    if (btnBorrarHistorial) {
        btnBorrarHistorial.addEventListener('click', () => {
            if (confirm('¿Estás seguro de que deseas borrar TODO el historial? Esta acción no se puede deshacer.')) {
                chrome.storage.local.remove('history', () => {
                    const historyList = document.getElementById('historial-lista');
                    if (historyList) {
                        historyList.innerHTML = '<li style="padding: 15px; text-align: center; color: var(--text-muted);">El historial ha sido borrado.</li>';
                    }
                    alert('Historial borrado exitosamente.');
                });
            }
        });
    }

    const btnExportarRespaldo = document.getElementById('btn-exportar-respaldo');
    if (btnExportarRespaldo) {
        btnExportarRespaldo.addEventListener('click', () => {
            chrome.storage.local.get(Respaldo.CLAVES, (datos) => {
                const exportadoEn = new Date().toISOString();
                const respaldo = Respaldo.armar(datos, exportadoEn, chrome.runtime.getManifest().version);
                const blob = new Blob([JSON.stringify(respaldo, undefined, 2)], { type: 'application/json' });
                triggerDownload(blob, Respaldo.nombreArchivo(exportadoEn));
                Analytics.track('backup_export', { campaigns: respaldo.history.length });
            });
        });
    }

    // --- Lógica de IMPORTACIÓN ---
    importBtn.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            importBtn.disabled = true;
            importBtn.innerHTML = '<span>⏳</span> Procesando...';

            contacts = await DataProcessor.readContacts(file);
            updateSendButtonState();
            availableVariables = DataProcessor.getAvailableVariables(contacts);

            updateUIWithContacts();
            saveDraft();
        } catch (error) {
            alert(error);
        } finally {
            importBtn.disabled = false;
            importBtn.innerHTML = '<span class="icon">📞</span> Importar contactos';
        }
    });

    function updateUIWithContacts() {
        contactCountBadge.textContent = `${contacts.length} contactos cargados`;

        if (availableVariables.length > 0) {
            variablesContainer.style.display = 'block';
            variableTags.innerHTML = '';

            availableVariables.forEach(variable => {
                const tag = document.createElement('span');
                tag.className = 'variable-tag';
                tag.textContent = variable;
                tag.onclick = () => insertVariable(variable);
                variableTags.appendChild(tag);
            });
        }

        // Re-evaluar el gate (puente + cuentas) antes de habilitar
        updateSendButtonState();
        renderContactList();
        updatePreview();
    }

    function renderContactList() {
        const listContainer = document.getElementById('contacts-list');
        if (!listContainer) return;

        listContainer.innerHTML = '';

        if (contacts.length === 0) {
            listContainer.innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 20px;">No hay contactos cargados. Importa un archivo o añade manualmente.</div>';
            return;
        }

        const fragment = document.createDocumentFragment();

        // 🛡️ ANTI-FREEZE LIMIT: Renderizar máximo 500 filas en el DOM.
        // Evita que la interfaz se congele si el Excel tiene miles de filas vacías.
        const maxRender = Math.min(contacts.length, 500);

        // Campos del formato base (ver CAMPAIGN_COLUMNS en dataProcessor.js) agrupados
        // en 2 líneas legibles en vez de 9 cajitas de texto de ~78px cada una —
        // nombre/apellido/modelo se cortaban a 10-12 caracteres y parecían vacíos.
        for (let i = 0; i < maxRender; i++) {
            const contact = contacts[i];

            const row = document.createElement('div');
            row.className = 'contact-row-v2';

            const header = document.createElement('div');
            header.className = 'contact-row-header';

            const numLabel = document.createElement('span');
            numLabel.className = 'contact-row-num';
            numLabel.textContent = `${i + 1}.`;
            header.appendChild(numLabel);

            const nameSpan = document.createElement('span');
            nameSpan.className = 'contact-row-name';
            const nombreCompleto = [contact['NOMBRE CLIENTE'], contact['APELLIDO CLIENTE']].filter(Boolean).join(' ');
            nameSpan.textContent = nombreCompleto || '(sin nombre)';
            nameSpan.title = nombreCompleto;
            header.appendChild(nameSpan);

            const phoneSpan = document.createElement('span');
            phoneSpan.className = 'contact-row-phone';
            phoneSpan.textContent = `☎ ${contact['TELEFONO 1'] || '-'}`;
            header.appendChild(phoneSpan);

            row.appendChild(header);

            const details = document.createElement('div');
            details.className = 'contact-row-details';

            const DETAIL_FIELDS = [
                ['Contrato', contact['Nº CONTRATO']],
                ['Cédula', contact['CÉDULA']],
                ['Modelo', contact['MODELO']],
                ['Mora', contact['VALOR EN MORA'] ? `$${contact['VALOR EN MORA']}` : ''],
                ['Días', contact['DIAS IMPAGO']]
            ];
            DETAIL_FIELDS.forEach(([label, value]) => {
                if (!value) return;
                const field = document.createElement('span');
                field.className = 'contact-row-field';
                field.title = String(value);
                const b = document.createElement('b');
                b.textContent = `${label}: `;
                field.appendChild(b);
                field.appendChild(document.createTextNode(value));
                details.appendChild(field);
            });

            // Estado (input por compatibilidad con el resto del código, que hace
            // document.getElementById('status-row-N').value = ... en muchos lugares)
            const statusInput = document.createElement('input');
            statusInput.type = 'text';
            statusInput.className = 'contact-row-input contact-row-status';
            statusInput.id = `status-row-${i}`;
            statusInput.value = 'Estado: Pendiente ⏳';
            statusInput.readOnly = true;
            statusInput.style.color = '#a3a3a3'; // Mutered por default
            statusInput.style.fontWeight = 'bold';
            details.appendChild(statusInput);

            row.appendChild(details);
            fragment.appendChild(row);
        }

        listContainer.appendChild(fragment);

        // Mostrar indicador de si hay más escondidos
        if (contacts.length > 500) {
            const divInfo = document.createElement('div');
            divInfo.style.textAlign = 'center';
            divInfo.style.padding = '15px';
            divInfo.style.color = '#38bdf8';
            divInfo.style.fontWeight = 'bold';
            divInfo.innerHTML = `⚠️ Para mantener la rapidez de la ventana, solo se muestran las primeras 500 filas.<br>La campaña de todas formas enviará los ${contacts.length} contactos.`;
            listContainer.appendChild(divInfo);
        }
    }

    function insertVariable(variable) {
        const start = messageText.selectionStart;
        const end = messageText.selectionEnd;
        const text = messageText.value;
        const before = text.substring(0, start);
        const after = text.substring(end, text.length);

        messageText.value = before + `{{${variable}}}` + after;
        messageText.focus();
        messageText.selectionStart = messageText.selectionEnd = start + variable.length + 4;
        updatePreview();
    }

    // --- Vista Previa Dinámica ---
    function updatePreview() {
        if (contacts.length === 0 || !messageText.value) return;

        // Mostrar preview del primer contacto
        const firstContact = contacts[0];
        let previewText = Utils.personalizeMessage(messageText.value, firstContact);
        previewText = Utils.parseSpinSyntax(previewText);

        // Podríamos añadir un elemento de preview en el HTML si quisiéramos
        console.log('Vista previa (1er contacto):', previewText);
    }

    messageText.addEventListener('input', updatePreview);
    messageText.addEventListener('input', scheduleDraftSave);

    // --- Variantes de mensaje (pool) ---
    /**
     * Añade una fila de variante adicional (textarea + botón eliminar).
     * La Variante 1 es siempre el textarea principal #message-text.
     */
    function addVarianteRow(value = '') {
        if (!variantesList) return null;
        const row = document.createElement('div');
        row.className = 'variante-row';
        row.style.cssText = 'display: flex; gap: 8px; align-items: flex-start;';

        const ta = document.createElement('textarea');
        ta.className = 'variante-extra';
        ta.placeholder = 'Variante adicional del mensaje...';
        ta.style.cssText = 'flex: 1; min-height: 70px;';
        ta.value = value;

        const btnDel = document.createElement('button');
        btnDel.type = 'button';
        btnDel.className = 'btn btn-danger-outline';
        btnDel.textContent = '✕';
        btnDel.title = 'Eliminar variante';
        btnDel.style.cssText = 'padding: 4px 10px; min-height: 34px; flex-shrink: 0;';
        btnDel.addEventListener('click', () => row.remove());

        row.appendChild(ta);
        row.appendChild(btnDel);
        variantesList.appendChild(row);
        return ta;
    }

    /**
     * Recolecta todas las variantes no vacías: [Variante 1 (principal), ...extras].
     */
    function collectMessageVariants() {
        const all = [];
        const main = messageText.value.trim();
        if (main) all.push(main);
        document.querySelectorAll('.variante-extra').forEach(t => {
            const v = t.value.trim();
            if (v) all.push(v);
        });
        return all;
    }

    if (btnAddVariante) {
        btnAddVariante.addEventListener('click', () => {
            const ta = addVarianteRow('');
            if (ta) ta.focus();
        });
    }

    /**
     * Arranca una campaña por el puente ADB. Compartido entre "Enviar ahora"
     * (campaignData armado desde el formulario) y "Retomar envío"
     * (campaignData armado desde un item del historial, con los contactos
     * pendientes en vez de la lista completa).
     *
     * El canal de WhatsApp Web está fuera de alcance (spec 1/2.1): el envío
     * real vive en `bridge/sesion.js`, del otro lado del puente, así que esto
     * no cae al service worker. Sin puente no se envía nada: es mejor decirlo
     * que dejar la campaña a medias.
     */
    function launchCampaign(campaignData) {
        if (!isLicenseAllowed) {
            alert('No se pudo iniciar la campaña: licencia no válida.');
            if (modalLicencia) modalLicencia.style.display = 'flex';
            return;
        }
        if (campaignData.imageDataUrl) {
            alert('El puente ADB todavía no envía imágenes: quita la imagen para enviar solo el texto.');
            return;
        }

        console.log('Enviando datos de campaña por el puente ADB:', campaignData.contacts.length, 'contactos');

        const r = puente.iniciar({
            contacts: campaignData.contacts,
            template: campaignData.messageTemplate || '',
            messageVariants: campaignData.messageVariants || [],
            enabledDevices: cuentasHabilitadas,
            config: campaignData.config || {}
        });
        if (!r.ok) {
            alert('No se pudo iniciar la campaña: ' + r.message);
            if (r.code === PuenteClient.CodigoCliente.PUENTE_DESCONECTADO) conectarPuente();
            return;
        }

        campaniaPuente = campaignData;
        // currentCampaign se guarda igual: el resumen y "Retomar envío" lo leen,
        // y el popup puede cerrarse en medio de la campaña.
        chrome.storage.local.set({ currentCampaign: campaignData });
        Analytics.track('campaign_start', { contactCount: campaignData.contacts.length, channel: 'adb' });
        sendBtn.disabled = true;
        sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña en curso...';
        stopBtn.style.display = 'flex';
        // El puente no pausa: detener es lo único que se puede hacer a mitad de
        // camino (los contactos sin alcanzar quedan Pendiente y se retoman).
    }

    /**
     * Retoma una campaña "Detenida" del historial: recalcula los contactos
     * pendientes (nunca alcanzados + con error) contra la definición original
     * guardada, y la relanza por el puente ADB — sin volver a filtrar/subir el
     * Excel. Los items viejos guardados con el canal retirado también se
     * retoman por el puente, que es el único canal disponible.
     */
    function resumeCampaignFromHistory(historyItem) {
        const pending = computePendingContacts(historyItem.contacts || [], historyItem.contactResults || []);
        if (pending.length === 0) {
            alert('No hay contactos pendientes por reintentar en esta campaña.');
            return;
        }
        launchCampaign({
            contacts: pending,
            messageTemplate: historyItem.messageTemplate || '',
            messageVariants: historyItem.messageVariants || [],
            config: historyItem.config || {},
            imageDataUrl: historyItem.imageDataUrl || ''
        });
    }

    // --- Evento de ENVÍO ---
    sendBtn.addEventListener('click', () => {
        const text = messageText.value;
        if (!text) {
            alert('Por favor, escribe un mensaje.');
            return;
        }

        if (contacts.length === 0) {
            alert('Por favor, importa una lista de contactos primero.');
            return;
        }

        const campaignData = getCampaignConfig();
        campaignData.messageTemplate = text;
        campaignData.messageVariants = collectMessageVariants();
        campaignData.contacts = contacts;
        campaignData.promoId = selectPromocion ? selectPromocion.value : '';

        launchCampaign(campaignData);
    });

    /**
     * Devuelve los botones al estado "sin campaña". La usan el fin de campaña
     * (`campaignFinished`) y el fallback del stop, que no puede escribir
     * `campaignFinished` sin un `done` que le dé su item de historial.
     */
    function restaurarBotonesCampania() {
        stopBtn.style.display = 'none';
        stopBtn.disabled = false;
        stopBtn.style.opacity = '';
        stopBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/></svg> Detener Campaña';
        sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Enviar ahora';
        updateSendButtonState();
    }

    // --- Evento de DETENER CAMPAÑA ---
    stopBtn.addEventListener('click', () => {
        if (stopBtn.disabled) return; // evita doble-clic durante "Deteniendo..."
        stopBtn.disabled = true;
        stopBtn.style.opacity = '0.7';
        stopBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/></svg> Deteniendo...';

        const parado = puente.detener();
        if (!parado.ok) {
            console.warn('[STOP] el puente no recibió el stop:', parado.code);
        }
        // UI se restaura vía listener `campaignFinished` (storage) cuando llega
        // el `done` del puente.

        // Fallback: el puente fuerza su propio `done` a los 30 s
        // (STOP_FORZADO_MS en bridge/sesion.js), así que acá se espera más para
        // no pisarlo. Y no se escribe `campaignFinished`: sin un `done` no hay
        // item de historial nuevo, y el resumen mostraría los números de la
        // campaña anterior. Solo se destraba la UI y se dice qué pasó.
        setTimeout(() => {
            if (stopBtn.style.display !== 'none' && stopBtn.disabled) {
                console.warn('[STOP] el puente no confirmó el done en 45s — destrabando la UI');
                restaurarBotonesCampania();
                if (puenteProgreso) {
                    puenteProgreso.style.display = '';
                    puenteProgreso.textContent = 'El puente no confirmó el fin de la campaña. ' +
                        'Reabrí el dashboard para ver el resultado guardado por el puente.';
                }
            }
        }, 45000);
    });

    // Resetear formulario
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            if (confirm('¿Seguro que quieres borrar toda la configuración?')) {
                messageText.value = '';
                if (variantesList) variantesList.innerHTML = '';
                contacts = [];
                updateSendButtonState();
                availableVariables = [];
                contactCountBadge.textContent = '0 contactos cargados';
                variablesContainer.style.display = 'none';
                fileInput.value = '';

                const listContainer = document.getElementById('contacts-list');
                if (listContainer) {
                    listContainer.innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 20px;">No hay contactos cargados.</div>';
                }
            }
        });
    }

    function getCampaignConfig() {
        return {
            config: {
                duplicateRemoval: document.getElementById('chk-dedup') ? document.getElementById('chk-dedup').checked : true,
                randomizeMessages: document.getElementById('chk-random') ? document.getElementById('chk-random').checked : true,
                // Tope diario por cuenta: el puente lo rechaza si no es entero > 0.
                tope: PuenteClient.normalizarTope(inputTopeDiario ? inputTopeDiario.value : '')
            },
            imageDataUrl: currentImageDataUrl
        };
    }

    // --- Funciones de Exportación de Historial ---
    // classifyResultStatus y computePendingContacts viven en campaignEngine.js
    // (cargado antes que este script en dashboard.html) — son globales, compartidas
    // con background.js (que las trae vía importScripts) para no duplicar la
    // lógica de qué cuenta como éxito/error en el canal Web.

    /**
     * Construye filas planas a partir de los contactResults de una campaña.
     * Cada fila contiene: Teléfono, Estado, y todos los campos extra del contacto.
     */
    function buildExportRows(historyItem) {
        const results = historyItem.contactResults || [];
        if (results.length === 0) return { headers: [], rows: [] };

        // Extraer las columnas extra del primer contacto con datos
        const sampleData = results.find(r => r.contactData && Object.keys(r.contactData).length > 0);
        const extraKeysRaw = sampleData ? Object.keys(sampleData.contactData) : [];

        const hasNombre = extraKeysRaw.includes('Nombre');
        const hasApellido = extraKeysRaw.includes('Apellido');
        
        let extraKeys = [];
        if (hasNombre || hasApellido) {
            extraKeys.push('Nombre');
        }
        extraKeysRaw.forEach(k => {
            if (k !== 'Nombre' && k !== 'Apellido') {
                extraKeys.push(k);
            }
        });

        const headers = ['Teléfono', 'Estado', ...extraKeys];
        const rows = results.map(r => {
            const baseRow = [r.phone || '', exportStatusText(r.status || '')];
            const extraValues = extraKeys.map(key => {
                if (key === 'Nombre') {
                    const n = r.contactData ? (r.contactData['Nombre'] || '') : '';
                    const a = r.contactData ? (r.contactData['Apellido'] || '') : '';
                    return `${n} ${a}`.trim();
                } else {
                    return (r.contactData && r.contactData[key] != null) ? String(r.contactData[key]) : '';
                }
            });
            return [...baseRow, ...extraValues];
        });

        return { headers, rows };
    }

    function exportHistoryAsCSV(historyItem) {
        const { headers, rows } = buildExportRows(historyItem);
        if (headers.length === 0) {
            alert('No hay datos detallados para exportar.');
            return;
        }

        const escapeCsvField = (field) => {
            const str = String(field);
            if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return `"${str.replace(/"/g, '""')}"`;
            }
            return str;
        };

        const csvLines = [
            headers.map(escapeCsvField).join(','),
            ...rows.map(row => row.map(cell => escapeCsvField(String(cell))).join(','))
        ];
        const csvContent = csvLines.join('\n');
        const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' }); // BOM para Excel

        const dateStr = new Date(historyItem.date).toISOString().slice(0, 10);
        triggerDownload(blob, `campaña_${dateStr}.csv`);
    }

    function exportHistoryAsXLS(historyItem) {
        const { headers: baseHeaders, rows: baseRows } = buildExportRows(historyItem);
        if (baseHeaders.length === 0) {
            alert('No hay datos detallados para exportar.');
            return;
        }

        // Insertar columna 'Tipo' (Enviado / Sin WhatsApp / Error) en posición 2 (después de Estado)
        const headers = ['Teléfono', 'Tipo', 'Estado', ...baseHeaders.slice(2)];

        const rows = baseRows.map(row => {
            const rawStatus = String(row[1] || '');
            const clase = classifyResultStatus(rawStatus);
            const tipo = clase === 'NoEncontrado' ? 'Sin WhatsApp' : clase;

            // Limpiar emojis del campo Estado usando regex de rangos Unicode
            const cleanStatus = rawStatus
                .replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '') // Surrogate pairs (emojis)
                .replace(/[\u2600-\u27BF]/g, '')                 // Símbolos varios
                .replace(/[\u23E0-\u23FF]/g, '')                 // Flechas y relojes
                .trim();

            return [row[0], tipo, cleanStatus, ...row.slice(2)];
        });

        let tableHtml = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        tableHtml += '<head><meta charset="utf-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Resultados WhatsAppProSend</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>';
        tableHtml += '<body><table border="1" style="border-collapse:collapse; font-family:Calibri,Arial,sans-serif; font-size:12px;">';

        // Fila de título
        const dateStr = new Date(historyItem.date).toLocaleString('es-ES');
        tableHtml += `<tr><td colspan="${headers.length}" style="background-color:#1e293b; color:#ffffff; font-size:14px; font-weight:bold; padding:10px; text-align:center;">WhatsAppProSend &mdash; Reporte de Campa&ntilde;a &mdash; ${dateStr}</td></tr>`;

        // Cabeceras
        tableHtml += '<tr>';
        headers.forEach(h => {
            tableHtml += `<th style="background-color:#334155; color:#ffffff; font-weight:bold; padding:8px 12px; text-align:left; border:1px solid #475569;">${h}</th>`;
        });
        tableHtml += '</tr>';

        // Filas de datos
        rows.forEach((row, rowIdx) => {
            const evenRow = rowIdx % 2 === 0;
            tableHtml += '<tr>';
            row.forEach((cell, idx) => {
                let cellValue = String(cell);
                let bgColor = evenRow ? '#f8fafc' : '#ffffff';
                let color = '#1e293b';
                let fontWeight = 'normal';

                // Columna Tipo (index 1) recibe el color semántico
                if (idx === 1) {
                    switch(cellValue) {
                        case 'Enviado':
                            bgColor = '#dcfce7'; color = '#166534'; fontWeight = 'bold'; break;
                        case 'Sin WhatsApp':
                            bgColor = '#f1f5f9'; color = '#475569'; fontWeight = 'bold'; break;
                        case 'Duplicado':
                        case 'Omitido':
                            bgColor = '#fef9c3'; color = '#92400e'; break;
                        default:
                            bgColor = '#fee2e2'; color = '#991b1b'; fontWeight = 'bold'; break;
                    }
                }

                tableHtml += `<td style="background-color:${bgColor}; color:${color}; font-weight:${fontWeight}; padding:6px 10px; border:1px solid #e2e8f0;">${cellValue}</td>`;
            });
            tableHtml += '</tr>';
        });

        // Fila de resumen final
        const enviadosTotal = rows.filter(r => r[1] === 'Enviado').length;
        const sinWhatsAppTotal = rows.filter(r => r[1] === 'Sin WhatsApp').length;
        const errTotal = rows.filter(r => r[1] !== 'Enviado' && r[1] !== 'Sin WhatsApp' && r[1] !== 'Duplicado' && r[1] !== 'Omitido').length;
        tableHtml += `<tr>
            <td colspan="${headers.length}" style="background-color:#0f172a; color:#94a3b8; padding:8px 12px; border-top:2px solid #334155; font-size:11px;">
                Total: ${rows.length} contactos &nbsp;|&nbsp;
                <span style="color:#22c55e; font-weight:bold;">Enviados: ${enviadosTotal}</span> &nbsp;|&nbsp;
                <span style="color:#94a3b8; font-weight:bold;">Sin WhatsApp: ${sinWhatsAppTotal}</span> &nbsp;|&nbsp;
                <span style="color:#ef4444; font-weight:bold;">Errores/Omitidos: ${errTotal}</span>
            </td>
        </tr>`;

        tableHtml += '</table></body></html>';

        const blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel' });
        const fileDateStr = new Date(historyItem.date).toISOString().slice(0, 10);
        triggerDownload(blob, `WHATSAPP_PRO_Campana_${fileDateStr}.xls`);
    }

    function triggerDownload(blob, filename) {
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = filename;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        URL.revokeObjectURL(url);
    }

    // --- Listener de progreso en tiempo real ---
    // --- Detectar fin de campaña para restablecer UI ---
    chrome.storage.onChanged.addListener((changes) => {
        if (changes.campaignFinished && changes.campaignFinished.newValue === true) {
            restaurarBotonesCampania();
            chrome.storage.local.remove('campaignFinished');

            // Mostrar resumen
            chrome.storage.local.get(['history'], (data) => {
                if (data.history && data.history.length > 0) {
                    const lastCampaign = data.history[0];
                    const conteo = { Enviado: 0, NoEncontrado: 0, Error: 0 };

                    if (lastCampaign.contactResults) {
                        for (const r of lastCampaign.contactResults) {
                            const clase = classifyResultStatus(r.status);
                            if (clase === 'Enviado') conteo.Enviado++;
                            else if (clase === 'NoEncontrado') conteo.NoEncontrado++;
                            else if (clase === 'Error') conteo.Error++;
                            // Duplicado/Omitido no se muestran en el resumen (mismo criterio que SMS)
                        }
                    }

                    Analytics.track('campaign_complete', {
                        contactCount: lastCampaign.contactCount,
                        status: lastCampaign.status,
                        enviados: conteo.Enviado,
                        noEncontrados: conteo.NoEncontrado,
                        errores: conteo.Error
                    });

                    const modalResumen = document.getElementById('modal-resumen');
                    if (modalResumen) {
                        document.getElementById('resumen-enviados').textContent = conteo.Enviado;
                        document.getElementById('resumen-no-encontrados').textContent = conteo.NoEncontrado;
                        document.getElementById('resumen-errores').textContent = conteo.Error;

                        const titulo = document.getElementById('resumen-titulo');
                        if (titulo) {
                            titulo.textContent = lastCampaign.status === 'Detenida' ? 'Campaña Detenida' : 'Campaña Finalizada';
                        }

                        const btnRetomar = document.getElementById('btn-resumen-retomar');
                        if (btnRetomar) {
                            const pending = computePendingContacts(lastCampaign.contacts || [], lastCampaign.contactResults || []);
                            if (pending.length > 0) {
                                btnRetomar.style.display = '';
                                btnRetomar.textContent = `▶️ Retomar envío (${pending.length} pendientes)`;
                                btnRetomar.onclick = () => {
                                    closeModal(modalResumen);
                                    resumeCampaignFromHistory(lastCampaign);
                                };
                            } else {
                                btnRetomar.style.display = 'none';
                                btnRetomar.onclick = null;
                            }
                        }

                        openModal(modalResumen);
                    }
                }
            });
        }
    });

    const btnCerrarResumen = document.getElementById('btn-cerrar-resumen');
    if (btnCerrarResumen) {
        btnCerrarResumen.addEventListener('click', () => {
            const modalResumen = document.getElementById('modal-resumen');
            if (modalResumen) closeModal(modalResumen);
        });
    }

    const btnResumenCSV = document.getElementById('btn-resumen-csv');
    const btnResumenXLS = document.getElementById('btn-resumen-xls');

    function getLastCampaignAndExport(exportFn) {
        chrome.storage.local.get(['history'], (data) => {
            if (data.history && data.history.length > 0) {
                exportFn(data.history[0]);
            } else {
                alert('No hay datos de campaña disponibles para exportar.');
            }
        });
    }

    if (btnResumenCSV) {
        btnResumenCSV.addEventListener('click', () => getLastCampaignAndExport(exportHistoryAsCSV));
    }
    if (btnResumenXLS) {
        btnResumenXLS.addEventListener('click', () => getLastCampaignAndExport(exportHistoryAsXLS));
    }

    // --- Lógica de Promociones e Imágenes ---
    // Trigger file click
    if (btnCargarImagen && inputImagen) {
        btnCargarImagen.addEventListener('click', () => inputImagen.click());
    }

    // Handle image file selection
    if (inputImagen) {
        inputImagen.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Validate file size (limit to 5MB for storage safety)
            if (file.size > 5 * 1024 * 1024) {
                alert('La imagen es demasiado grande. Selecciona una menor a 5MB.');
                inputImagen.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = (event) => {
                currentImageDataUrl = event.target.result;
                showImagePreview(currentImageDataUrl);
                saveDraft();
            };
            reader.readAsDataURL(file);
        });
    }

    // Helper to show preview
    function showImagePreview(dataUrl) {
        if (dataUrl) {
            previewImagen.src = dataUrl;
            previewImagenContainer.style.display = 'block';
            btnQuitarImagen.style.display = 'block';
            btnCargarImagen.textContent = 'Cambiar imagen';
        } else {
            previewImagen.src = '';
            previewImagenContainer.style.display = 'none';
            btnQuitarImagen.style.display = 'none';
            btnCargarImagen.textContent = 'Seleccionar imagen';
            if (inputImagen) inputImagen.value = '';
        }
    }

    // Quitar imagen
    if (btnQuitarImagen) {
        btnQuitarImagen.addEventListener('click', () => {
            currentImageDataUrl = '';
            showImagePreview('');
            selectPromocion.value = '';
            saveDraft();
        });
    }

    // Cargar promociones desde storage
    function loadPromotions() {
        chrome.storage.local.get(['promotions'], (data) => {
            promotions = data.promotions || [];
            
            // Si no hay, inicializar con las de ejemplo
            if (promotions.length === 0) {
                promotions = [
                    {
                        id: 'promo-1',
                        name: 'Descuento Especial Uphone 🎁',
                        message: '¡Hola {{Nombre}}! Por ser cliente preferencial de Uphone, tienes un 20% de descuento en tu próximo plan. Tu deuda actual de {{Monto}} ahora tiene descuento. ¡Contáctanos!',
                        image: ''
                    },
                    {
                        id: 'promo-2',
                        name: 'Cobro Pendiente ⚠️',
                        message: 'Estimado/a {{Nombre}}, le recordamos que su saldo pendiente de {{Monto}} (Cédula: {{Cédula}}) vence pronto. Por favor regularice su pago.',
                        image: ''
                    },
                    {
                        id: 'promo-3',
                        name: 'Fidelización Cliente 🎉',
                        message: '¡Gracias por elegir Uphone, {{Nombre}}! Nos alegra contar contigo en nuestra familia tecnológica.',
                        image: ''
                    }
                ];
                chrome.storage.local.set({ promotions });
            }

            renderPromotionsDropdown();
        });
    }

    // Render dropdown options
    function renderPromotionsDropdown() {
        if (!selectPromocion) return;
        
        selectPromocion.innerHTML = '<option value="">-- Sin promoción --</option>';
        
        promotions.forEach(promo => {
            const opt = document.createElement('option');
            opt.value = promo.id;
            opt.textContent = promo.name;
            selectPromocion.appendChild(opt);
        });
    }

    // Handle selection
    if (selectPromocion) {
        selectPromocion.addEventListener('change', () => {
            const promoId = selectPromocion.value;
            if (!promoId) return;
            
            const promo = promotions.find(p => p.id === promoId);
            if (promo) {
                messageText.value = promo.message;
                currentImageDataUrl = promo.image || '';
                showImagePreview(currentImageDataUrl);
                updatePreview();
            }
        });
    }

    // Guardar promoción
    if (btnGuardarPromo) {
        btnGuardarPromo.addEventListener('click', () => {
            const text = messageText.value.trim();
            if (!text) {
                alert('Escribe un mensaje antes de guardarlo como promoción.');
                return;
            }

            const name = prompt('Introduce un nombre para la promoción:');
            if (!name) return;

            const newPromo = {
                id: 'promo-' + Date.now(),
                name: name,
                message: text,
                image: currentImageDataUrl
            };

            promotions.push(newPromo);
            chrome.storage.local.set({ promotions }, () => {
                renderPromotionsDropdown();
                selectPromocion.value = newPromo.id;
                alert('¡Promoción "' + name + '" guardada con éxito!');
            });
        });
    }

    // Eliminar promoción
    if (btnEliminarPromo) {
        btnEliminarPromo.addEventListener('click', () => {
            const promoId = selectPromocion.value;
            if (!promoId) {
                alert('Selecciona una promoción para eliminar.');
                return;
            }

            const promo = promotions.find(p => p.id === promoId);
            if (confirm(`¿Estás seguro de que deseas eliminar la promoción "${promo.name}"?`)) {
                promotions = promotions.filter(p => p.id !== promoId);
                chrome.storage.local.set({ promotions }, () => {
                    renderPromotionsDropdown();
                    selectPromocion.value = '';
                    currentImageDataUrl = '';
                    showImagePreview('');
                    alert('Promoción eliminada.');
                });
            }
        });
    }

    // Cargar promociones al inicio
    loadPromotions();
});

