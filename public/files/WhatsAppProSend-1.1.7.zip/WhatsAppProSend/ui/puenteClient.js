/**
 * puenteClient — cliente WebSocket del puente ADB para el dashboard.
 *
 * El canal ADB no puede correr en el service worker (spec 2.1): vive en
 * `bridge/sesion.js`, detrás del puente local `ws://127.0.0.1:8766`. Este
 * archivo es el único lugar de la extensión que le habla.
 *
 * Fail-closed, igual que `bridge/protocol.js` del otro lado: un `start` solo
 * sale si el puente dijo `isolation:true` en su `connected` y si hay al menos
 * una cuenta tildada. Un puente viejo (sin aislamiento) enviaría por TODOS los
 * celulares conectados, así que ante la duda no se manda nada.
 *
 * Export dual como `ui/utils.js`: Node (tests) + globalThis (dashboard).
 */

var _rootPuente = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

var URL_PUENTE = 'ws://127.0.0.1:8766';

// Mismo defecto que `bridge/cuotas.js`: 150 mensajes por cuenta y por dia.
// Repetido a proposito — cuotas.js es solo-Node y no puede cargarse en el
// dashboard — y el test fija el valor en los dos lados.
var TOPE_POR_DEFECTO = 150;

/**
 * Códigos de los rechazos que decide el cliente, antes de tocar el socket.
 * Los del puente (`ADB_NOT_FOUND`, `NO_ENABLED_TARGETS`, ...) llegan en sus
 * mensajes `error` y no se duplican acá.
 */
var CodigoCliente = Object.freeze({
    PUENTE_DESCONECTADO: 'PUENTE_DESCONECTADO',
    PUENTE_SIN_AISLAMIENTO: 'PUENTE_SIN_AISLAMIENTO',
    SIN_CUENTAS_HABILITADAS: 'SIN_CUENTAS_HABILITADAS',
    CAMPANIA_EN_CURSO: 'CAMPANIA_EN_CURSO'
});

// Resolución perezosa: en Node por require, en el dashboard por el global que
// dejan los <script> de deviceSelection.js y whatsappTargets.js. Perezosa a
// propósito, para no depender del orden de carga de los <script>.
function _seleccion() {
    if (typeof require === 'function' && typeof module !== 'undefined' && module.exports) {
        return require('../channels/deviceSelection.js');
    }
    return _rootPuente.DeviceSelection || {};
}

function _targets() {
    if (typeof require === 'function' && typeof module !== 'undefined' && module.exports) {
        return require('../channels/whatsappTargets.js');
    }
    return _rootPuente.WhatsAppTargets || {};
}

/**
 * Tope diario por cuenta, normalizado a lo que el puente acepta: entero > 0.
 * Cualquier otra cosa (texto, 0, negativo, vacío) vuelve al defecto en vez de
 * salir al puente y volver con `TOPE_INVALIDO` — el input del formulario llega
 * como texto y el operador puede dejarlo vacío.
 */
function normalizarTope(valor) {
    var n = Math.floor(Number(valor));
    return Number.isFinite(n) && n > 0 ? n : TOPE_POR_DEFECTO;
}

/**
 * Una fila por cuenta para la lista del dashboard. Un target que no parsea no
 * se muestra: una cuenta sin etiqueta sería una casilla que el operador no
 * puede identificar. Entradas no-array -> [] (nunca null).
 *
 * `cuota` es el último `{tope, porTarget}` del puente, donde `porTarget` son
 * los ENVIADOS de hoy. El restante se calcula acá: es lo que el operador mira
 * para decidir cuántos contactos cargar. Sin cuota todavía, ninguna cuenta
 * figura agotada — no saber no es lo mismo que estar en el tope.
 *
 * `sinSesion` son las cuentas instaladas sin número registrado: van al final,
 * bloqueadas y nunca habilitadas, para que el operador sepa que existen y por
 * qué no envían.
 */
function filasDeCuentas(cuentas, habilitadas, cuota, sinSesion) {
    var etiquetaTarget = _targets().etiquetaTarget;
    var lista = Array.isArray(cuentas) ? cuentas : [];
    var tildadas = new Set(Array.isArray(habilitadas) ? habilitadas : []);
    var c = cuota && typeof cuota === 'object' ? cuota : {};
    var tope = normalizarTope(c.tope);
    var enviados = c.porTarget && typeof c.porTarget === 'object' ? c.porTarget : {};
    var filas = [];
    lista.forEach(function (target) {
        var etiqueta;
        try {
            etiqueta = etiquetaTarget(target);
        } catch (_) {
            return; // target invalido: no es una cuenta que se pueda elegir
        }
        var usados = Number(enviados[target]);
        if (!Number.isFinite(usados) || usados < 0) usados = 0;
        var restante = tope - usados;
        if (restante < 0) restante = 0;
        filas.push({
            target: target,
            etiqueta: etiqueta,
            habilitado: tildadas.has(target),
            restante: restante,
            tope: tope,
            agotada: restante === 0,
            sinSesion: false
        });
    });
    (Array.isArray(sinSesion) ? sinSesion : []).forEach(function (target) {
        var etiqueta;
        try {
            etiqueta = etiquetaTarget(target);
        } catch (_) {
            return;
        }
        filas.push({
            target: target,
            etiqueta: etiqueta,
            habilitado: false,
            restante: 0,
            tope: tope,
            agotada: false,
            sinSesion: true
        });
    });
    return filas;
}

/**
 * Tilda o destilda una cuenta y devuelve la lista nueva de `enabledDevices`.
 * Un target que no parsea nunca entra: el puente lo rechazaría contacto por
 * contacto con `WHATSAPP_ADB_TARGET_INVALIDO`.
 */
function alternarCuenta(habilitadas, target, tildado) {
    var actuales = Array.isArray(habilitadas) ? habilitadas.slice() : [];
    if (!tildado) {
        return actuales.filter(function (otro) { return otro !== target; });
    }
    try {
        _targets().parsearTarget(target);
    } catch (_) {
        return actuales;
    }
    if (actuales.indexOf(target) === -1) actuales.push(target);
    return actuales;
}

/**
 * Item de historial a partir del `done` del puente, con la misma forma que el
 * que escribe `background.js` para el canal Web — así el resumen, el CSV y
 * "Retomar envío" del dashboard funcionan igual para una campaña ADB.
 * `contactCount` cuenta los contactos PEDIDOS: si la campaña se cortó, los
 * nunca alcanzados siguen siendo parte de ella.
 */
function historialDesdeDone(done, campania) {
    var d = done || {};
    var c = campania || {};
    var contactos = Array.isArray(c.contacts) ? c.contacts : [];
    var resultados = Array.isArray(d.results) ? d.results : [];
    return {
        date: Date.now(),
        campaignId: d.campaignId || '',
        contactCount: contactos.length || resultados.length,
        status: d.stopped ? 'Detenida' : 'Completada',
        contactResults: resultados,
        channel: 'adb',
        contacts: contactos,
        messageTemplate: c.messageTemplate || '',
        messageVariants: Array.isArray(c.messageVariants) ? c.messageVariants : [],
        imageDataUrl: c.imageDataUrl || '',
        config: c.config && typeof c.config === 'object' ? c.config : {}
    };
}

/**
 * Item de historial para un resultado que el puente guardó y nadie confirmó:
 * el popup estaba cerrado al terminar, o el puente murió a mitad de campaña
 * (`interrumpida`). Los contactos salen de la campaña guardada en el
 * navegador solo si es la misma (`campaignId`): con ellos "Retomar envío"
 * calcula lo pendiente; con contactos ajenos retomaría a otros clientes.
 */
function historialDesdePendiente(entrada, campania) {
    var e = entrada || {};
    var c = campania || {};
    var misma = !!e.campaignId && c.campaignId === e.campaignId;
    var item = historialDesdeDone({ campaignId: e.campaignId, results: e.results, stopped: e.stopped }, misma ? c : {});
    if (e.interrumpida === true) item.status = 'Interrumpida';
    var total = Number(e.total);
    if (!misma && Number.isInteger(total) && total > 0) item.contactCount = total;
    return item;
}

/**
 * Al reabrir el popup con una campaña en curso: decide si la campaña guardada
 * al lanzarla (`currentCampaign`) es la que corre en el puente y devuelve sus
 * resultados por fila. Solo restaura si la cantidad de contactos coincide con
 * el `total` del puente: pintar resultados sobre otra lista los pondría en la
 * fila de otro cliente. Caso especial sin restaurar: nunca null.
 */
function campaniaParaRestaurar(campania, estado) {
    var c = campania && typeof campania === 'object' ? campania : {};
    var e = estado && typeof estado === 'object' ? estado : {};
    var contactos = Array.isArray(c.contacts) ? c.contacts : [];
    if (e.isRunning !== true || contactos.length === 0 || contactos.length !== Number(e.total)) {
        return { restaurar: false, campania: {}, resultados: [] };
    }
    var resultados = (Array.isArray(e.results) ? e.results : [])
        .filter(function (r) {
            return r && Number.isInteger(r.index) && r.index >= 0 && r.index < contactos.length;
        })
        .map(function (r) { return { index: r.index, status: String(r.status || '') }; })
        .sort(function (a, b) { return a.index - b.index; });
    return { restaurar: true, campania: c, resultados: resultados };
}

/**
 * Cliente del puente. `crearSocket` se inyecta en los tests; en el dashboard
 * es `new WebSocket(url)`.
 *
 * No reconecta solo: el dashboard es el popup de la extensión y se cierra con
 * la ventana. Al reabrirse llama a `conectar()` y pide `status`, que es como el
 * puente fue diseñado para recuperar una campaña en curso (difunde el progreso
 * a todos los clientes y guarda el resultado durable).
 */
function crearPuenteClient(deps) {
    var d = deps || {};
    var url = d.url || URL_PUENTE;
    var crearSocket = d.crearSocket || function (u) { return new WebSocket(u); };

    var BridgeIsolation = _seleccion().BridgeIsolation;

    var socket = null;
    var conectado = false;
    var bridgeVersion = '';
    var aislamiento = BridgeIsolation.UNKNOWN;
    var enCurso = false;
    var campaignId = '';
    var cuentas = [];
    var sinSesion = [];
    var cuota = { fecha: '', tope: TOPE_POR_DEFECTO, porTarget: {} };
    var conectando = null; // promesa del conectar() en vuelo, si hay uno
    var oyentes = new Map(); // tipo -> [fn]

    function avisar(tipo, msg) {
        var fns = oyentes.get(tipo);
        if (!fns) return;
        fns.slice().forEach(function (fn) {
            try {
                fn(msg);
            } catch (err) {
                // Un oyente que lanza no corta a los demás ni al socket.
                console.warn('[puente] oyente de ' + tipo + ' falló:', err);
            }
        });
    }

    function escuchar(tipo, fn) {
        var fns = oyentes.get(tipo) || [];
        fns.push(fn);
        oyentes.set(tipo, fns);
        return function quitar() {
            oyentes.set(tipo, (oyentes.get(tipo) || []).filter(function (otro) { return otro !== fn; }));
        };
    }

    function estado() {
        return {
            conectado: conectado,
            bridgeVersion: bridgeVersion,
            aislamiento: aislamiento,
            enCurso: enCurso,
            campaignId: campaignId,
            cuentas: cuentas.slice(),
            sinSesion: sinSesion.slice(),
            cuota: { fecha: cuota.fecha, tope: cuota.tope, porTarget: Object.assign({}, cuota.porTarget) }
        };
    }

    function puedeIniciar() {
        return conectado && _seleccion().canStartAdbCampaign(aislamiento);
    }

    function aviso() {
        return _seleccion().bridgeIsolationWarning(aislamiento);
    }

    function mandar(obj) {
        socket.send(JSON.stringify(obj));
    }

    function recibir(texto) {
        var msg;
        try {
            msg = JSON.parse(texto);
        } catch (_) {
            return; // el puente no manda basura; si la manda, no rompe la UI
        }
        switch (msg.type) {
            case 'connected':
                conectado = true;
                bridgeVersion = msg.bridgeVersion || '';
                aislamiento = _seleccion().bridgeIsolationFromHello(msg);
                break;
            case 'devices':
                cuentas = Array.isArray(msg.devices) ? msg.devices.slice() : [];
                sinSesion = Array.isArray(msg.sinSesion) ? msg.sinSesion.slice() : [];
                break;
            case 'started':
                enCurso = true;
                campaignId = msg.campaignId || '';
                break;
            case 'done':
                enCurso = false;
                campaignId = '';
                break;
            case 'error':
                // El puente manda `error` y recién después `done` en los cierres
                // fallidos; soltar la UI acá evita dejarla "en curso" si el
                // `done` nunca llega (socket caído entre los dos mensajes).
                // `CAMPAIGN_RUNNING` es la excepción: llega justamente CON una
                // campaña viva (un segundo `start`), y soltarla ahí habilitaría
                // "Enviar ahora" a mitad de camino.
                if (msg.code !== 'CAMPAIGN_RUNNING') enCurso = false;
                break;
            case 'quota':
                // Llega al cerrar cada campaña (bridge/sesion.js lo manda antes
                // del `done`): es el conteo del día que sobrevive al reinicio.
                cuota = {
                    fecha: msg.fecha || '',
                    tope: normalizarTope(msg.tope),
                    porTarget: msg.porTarget && typeof msg.porTarget === 'object' ? msg.porTarget : {}
                };
                break;
            case 'status':
                enCurso = !!msg.isRunning;
                campaignId = msg.campaignId || '';
                break;
            default:
                break; // ping, stopping, acked: solo se difunden
        }
        avisar(msg.type, msg);
        avisar('*', msg);
    }

    /**
     * Conecta y resuelve con el estado al llegar el `connected` del puente.
     * Rechaza si el socket se cierra o falla antes del hello: sin hello no se
     * sabe si el puente respeta las cuentas habilitadas.
     */
    function conectar() {
        if (socket && conectado) return Promise.resolve(estado());
        // Un segundo `conectar()` mientras el primero espera el hello
        // devolvería un socket nuevo, y el `onclose` del viejo marcaría
        // desconectado al que sí está vivo: se devuelve el intento en vuelo.
        if (conectando) return conectando;
        conectando = new Promise(function (resolve, reject) {
            var resuelto = false;
            try {
                socket = crearSocket(url);
            } catch (err) {
                reject(err);
                return;
            }
            var quitarHello = escuchar('connected', function () {
                resuelto = true;
                quitarHello();
                resolve(estado());
            });
            socket.onmessage = function (ev) { recibir(ev && ev.data); };
            socket.onclose = function () {
                conectado = false;
                bridgeVersion = '';
                // UNKNOWN y no UNSUPPORTED: un puente cerrado no es un puente
                // viejo, y el aviso de "puente desactualizado" sería mentira.
                aislamiento = BridgeIsolation.UNKNOWN;
                enCurso = false;
                campaignId = '';
                socket = null;
                avisar('cerrado', { type: 'cerrado' });
                if (!resuelto) {
                    resuelto = true;
                    quitarHello();
                    reject(new Error('PUENTE_DESCONECTADO: el puente cerró la conexión antes del saludo'));
                }
            };
            socket.onerror = function () {
                avisar('fallo', { type: 'fallo' });
                if (!resuelto) {
                    resuelto = true;
                    quitarHello();
                    reject(new Error('PUENTE_DESCONECTADO: no se pudo conectar a ' + url));
                }
            };
        });
        // El intento deja de estar "en vuelo" en los dos finales; el rechazo lo
        // recibe quien llamó, no el próximo conectar().
        conectando.then(function () { conectando = null; }, function () { conectando = null; });
        return conectando;
    }

    /**
     * `{verificar: true}` ("Buscar cuentas") hace que el puente vuelva a abrir
     * cada cuenta para ver si tiene número; sin él usa lo ya verificado.
     */
    function listarCuentas(opciones) {
        if (!conectado) return { ok: false, code: CodigoCliente.PUENTE_DESCONECTADO, message: 'El puente no está conectado' };
        mandar(opciones && opciones.verificar === true ? { type: 'list_devices', verificar: true } : { type: 'list_devices' });
        return { ok: true, code: 'OK', message: '' };
    }

    function pedirEstado() {
        if (!conectado) return { ok: false, code: CodigoCliente.PUENTE_DESCONECTADO, message: 'El puente no está conectado' };
        mandar({ type: 'status' });
        return { ok: true, code: 'OK', message: '' };
    }

    /**
     * Manda el `start`. Orden de los rechazos: conexión -> aislamiento ->
     * campaña en curso -> cuentas tildadas. El puente revalida todo del otro
     * lado; esto es para no hacerle gastar un viaje y para dar el motivo exacto
     * en la UI.
     */
    function iniciar(pedido) {
        var p = pedido || {};
        if (!conectado) {
            return {
                ok: false,
                code: CodigoCliente.PUENTE_DESCONECTADO,
                message: 'El puente ADB no está conectado: pulsa "Reiniciar puente" y reintenta'
            };
        }
        if (!_seleccion().canStartAdbCampaign(aislamiento)) {
            return {
                ok: false,
                code: CodigoCliente.PUENTE_SIN_AISLAMIENTO,
                message: aviso() || 'El puente ADB no confirmó que respeta las cuentas habilitadas'
            };
        }
        if (enCurso) {
            return {
                ok: false,
                code: CodigoCliente.CAMPANIA_EN_CURSO,
                message: 'Ya hay una campaña en curso'
            };
        }
        if (!Array.isArray(p.enabledDevices) || p.enabledDevices.length === 0) {
            return {
                ok: false,
                code: CodigoCliente.SIN_CUENTAS_HABILITADAS,
                message: 'Tilda al menos una cuenta de WhatsApp antes de enviar'
            };
        }
        mandar({
            type: 'start',
            contacts: Array.isArray(p.contacts) ? p.contacts : [],
            template: p.template || '',
            messageVariants: Array.isArray(p.messageVariants) ? p.messageVariants : [],
            enabledDevices: p.enabledDevices.slice(),
            config: p.config && typeof p.config === 'object' ? p.config : {},
            imageDataUrl: p.imageDataUrl || ''
        });
        return { ok: true, code: 'OK', message: '' };
    }

    function detener() {
        if (!conectado) return { ok: false, code: CodigoCliente.PUENTE_DESCONECTADO, message: 'El puente no está conectado' };
        mandar({ type: 'stop' });
        return { ok: true, code: 'OK', message: '' };
    }

    function confirmar(id) {
        if (!conectado) return { ok: false, code: CodigoCliente.PUENTE_DESCONECTADO, message: 'El puente no está conectado' };
        mandar({ type: 'ack', campaignId: id });
        return { ok: true, code: 'OK', message: '' };
    }

    function cerrar() {
        if (socket) {
            try {
                socket.close();
            } catch (_) { /* ya estaba cerrado */ }
        }
    }

    return {
        url: url,
        conectar: conectar,
        estado: estado,
        puedeIniciar: puedeIniciar,
        aviso: aviso,
        listarCuentas: listarCuentas,
        pedirEstado: pedirEstado,
        iniciar: iniciar,
        detener: detener,
        confirmar: confirmar,
        escuchar: escuchar,
        cerrar: cerrar
    };
}

_rootPuente.PuenteClient = {
    URL_PUENTE: URL_PUENTE,
    TOPE_POR_DEFECTO: TOPE_POR_DEFECTO,
    CodigoCliente: CodigoCliente,
    crearPuenteClient: crearPuenteClient,
    normalizarTope: normalizarTope,
    filasDeCuentas: filasDeCuentas,
    alternarCuenta: alternarCuenta,
    historialDesdeDone: historialDesdeDone,
    campaniaParaRestaurar: campaniaParaRestaurar,
    historialDesdePendiente: historialDesdePendiente
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        URL_PUENTE: URL_PUENTE,
        TOPE_POR_DEFECTO: TOPE_POR_DEFECTO,
        CodigoCliente: CodigoCliente,
        crearPuenteClient: crearPuenteClient,
        normalizarTope: normalizarTope,
        filasDeCuentas: filasDeCuentas,
        alternarCuenta: alternarCuenta,
        historialDesdeDone: historialDesdeDone,
        campaniaParaRestaurar: campaniaParaRestaurar,
        historialDesdePendiente: historialDesdePendiente
    };
}
