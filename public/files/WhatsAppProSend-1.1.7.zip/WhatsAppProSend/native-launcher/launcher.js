/**
 * launcher.js — Native Messaging Host invocado por Chrome vía
 * chrome.runtime.sendNativeMessage(). Traduce el protocolo stdio (mensajes
 * JSON con prefijo de longitud de 4 bytes little-endian) a serverControl.
 *
 * sendNativeMessage es de un solo mensaje: se procesa uno y el proceso
 * termina — Chrome lo relanza en cada llamada siguiente.
 */

const serverControl = require('./serverControl.js');

/** Arma el framing Native Messaging de un objeto: longitud LE + JSON. */
function codificarMensaje(obj) {
    const json = Buffer.from(JSON.stringify(obj), 'utf-8');
    const header = Buffer.alloc(4);
    header.writeUInt32LE(json.length, 0);
    return Buffer.concat([header, json]);
}

/**
 * Lee el primer mensaje de un buffer. Devuelve SIEMPRE un objeto
 * (nunca undefined — regla sin-null):
 * `{ completo: false, msg: {}, resto }` si faltan bytes,
 * `{ completo: true, valido: false, msg: {}, resto }` si el JSON está roto,
 * `{ completo: true, valido: true, msg, resto }` si está bien.
 * Nunca lanza.
 */
function decodificarMensaje(buffer) {
    const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.alloc(0);
    if (buf.length < 4) return { completo: false, msg: {}, resto: buf };
    const len = buf.readUInt32LE(0);
    if (buf.length < 4 + len) return { completo: false, msg: {}, resto: buf };
    try {
        return { completo: true, valido: true, msg: JSON.parse(buf.slice(4, 4 + len).toString('utf-8')), resto: buf.slice(4 + len) };
    } catch (_) {
        return { completo: true, valido: false, msg: {}, resto: buf.slice(4 + len) };
    }
}

function sendMessage(obj) {
    process.stdout.write(codificarMensaje(obj));
}

async function handleMessage(msg) {
    try {
        let result;
        switch (msg && msg.action) {
            case 'status':
                result = await serverControl.statusCheck();
                break;
            case 'start': {
                const status = await serverControl.statusCheck();
                if (status.running) { result = { started: false, alreadyRunning: true, pid: status.pid }; break; }
                result = { started: true, pid: serverControl.startServer() };
                break;
            }
            case 'stop':
                result = { stopped: serverControl.stopServer() };
                break;
            case 'restart':
                result = { restarted: true, pid: await serverControl.restartServer() };
                break;
            case 'register':
                result = await serverControl.registerHost();
                break;
            default:
                result = { error: `Acción desconocida: ${msg && msg.action}` };
        }
        sendMessage(result);
    } catch (err) {
        sendMessage({ error: err.message });
    } finally {
        process.exit(0);
    }
}

let buffer = Buffer.alloc(0);
process.stdin.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    const leido = decodificarMensaje(buffer);
    if (!leido.completo) return;
    buffer = leido.resto;
    handleMessage(leido.msg);
});

process.stdin.on('end', () => process.exit(0));

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { codificarMensaje, decodificarMensaje };
}
