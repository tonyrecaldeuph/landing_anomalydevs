/**
 * serverControl — arranca/detiene/reinicia el puente de WhatsApp
 * (bridge/server.js) como proceso independiente, y reporta si está corriendo.
 * Vive detrás del Native Messaging Host (launcher.js) para que el botón del
 * dashboard pueda controlarlo sin que el usuario abra una terminal.
 *
 * Testeable sin procesos reales vía inyección de dependencias (spawn/kill/
 * isPortOpen), mismo patrón que WhatsAppAdbChannel.execFn.
 */

const { spawn } = require('child_process');
const net = require('net');
const fs = require('fs');
const path = require('path');

const SERVER_DIR = path.join(__dirname, '..', 'bridge');
const SERVER_ENTRY = path.join(SERVER_DIR, 'server.js');
const PIDFILE = path.join(SERVER_DIR, '.server.pid');
const LOGFILE = path.join(SERVER_DIR, 'server.log');
const REGISTER_PS1 = path.join(__dirname, 'register.ps1');
const PORT = 8766;

function isPortOpen(port, host, timeoutMs) {
    const h = host || '127.0.0.1';
    const espera = timeoutMs !== undefined ? timeoutMs : 800;
    return new Promise((resolve) => {
        const socket = new net.Socket();
        let done = false;
        const finish = (result) => {
            if (done) return;
            done = true;
            socket.destroy();
            resolve(result);
        };
        socket.setTimeout(espera);
        socket.once('connect', () => finish(true));
        socket.once('timeout', () => finish(false));
        socket.once('error', () => finish(false));
        socket.connect(port, h);
    });
}

function readPid(readFileFn) {
    const leer = readFileFn || fs.readFileSync;
    try {
        const raw = leer(PIDFILE, 'utf-8').trim();
        const pid = parseInt(raw, 10);
        return Number.isInteger(pid) ? pid : 0;
    } catch (_) {
        return 0;
    }
}

function writePid(pid, writeFileFn) {
    (writeFileFn || fs.writeFileSync)(PIDFILE, String(pid));
}

function clearPidfile(unlinkFn) {
    try { (unlinkFn || fs.unlinkSync)(PIDFILE); } catch (_) { /* ya no existía */ }
}

async function statusCheck(deps) {
    const d = deps || {};
    const portOpen = await (d.isPortOpen || isPortOpen)(PORT);
    return { running: portOpen, pid: readPid(d.readFile) };
}

/** @returns {number} pid del proceso arrancado */
function startServer(deps) {
    const d = deps || {};
    const spawnFn = d.spawn || spawn;
    const openLogFn = d.openLog || ((file) => fs.openSync(file, 'a'));
    const logFd = openLogFn(LOGFILE);
    const child = spawnFn(process.execPath, [SERVER_ENTRY], {
        cwd: SERVER_DIR,
        detached: true,
        stdio: ['ignore', logFd, logFd],
        windowsHide: true
    });
    child.unref();
    writePid(child.pid, d.writeFile);
    return child.pid;
}

/** @returns {boolean} true si había un pid registrado (independiente de si seguía vivo) */
function stopServer(deps) {
    const d = deps || {};
    const killFn = d.kill || process.kill;
    const pid = readPid(d.readFile);
    if (!pid) return false;
    try {
        killFn(pid, 'SIGTERM');
    } catch (_) { /* el proceso ya no existía — igual limpiamos el pidfile */ }
    clearPidfile(d.unlink);
    return true;
}

async function restartServer(deps) {
    const d = deps || {};
    stopServer(d);
    const wait = d.sleep || (ms => new Promise(r => setTimeout(r, ms)));
    await wait(500);
    return startServer(d);
}

/**
 * Re-corre register.ps1 (resuelve adb.exe/node.exe otra vez y regenera
 * launcher.generated.bat) para cuando el usuario reinstala/mueve adb en
 * una máquina donde el Native Messaging Host ya estaba registrado antes.
 *
 * NO sirve para el registro inicial: sendNativeMessage exige que el
 * manifest ya exista en HKCU\...\NativeMessagingHosts para poder lanzar
 * este mismo launcher — ese primer registro sigue siendo manual
 * (ejecutar register.ps1 a mano), documentado en README.md.
 */
function registerHost(deps) {
    const d = deps || {};
    const spawnFn = d.spawn || spawn;
    return new Promise((resolve) => {
        const child = spawnFn('powershell.exe', [
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', REGISTER_PS1
        ], { windowsHide: true });
        let stdout = '';
        let stderr = '';
        child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
        child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
        child.on('error', (err) => resolve({ ok: false, code: null, stdout, stderr: err.message }));
        child.on('close', (code) => resolve({ ok: code === 0, code, stdout: stdout.trim(), stderr: stderr.trim() }));
    });
}

module.exports = {
    isPortOpen,
    statusCheck,
    startServer,
    stopServer,
    restartServer,
    registerHost,
    readPid,
    PIDFILE,
    LOGFILE,
    SERVER_ENTRY,
    SERVER_DIR,
    REGISTER_PS1,
    PORT
};
