/**
 * Background Service Worker - WhatsAppProSend
 *
 * Solo dos responsabilidades:
 *   - Licencia: estado, activación y revalidación periódica.
 *   - Puente ADB: pasa al host nativo los comandos de arranque del puente.
 *
 * La campaña NO corre acá. `channels/WhatsAppAdbChannel.js` es solo-Node
 * (child_process + adb), está excluido del zip y no puede cargar en un
 * service worker MV3: la campaña corre en bridge/sesion.js, y el dashboard
 * la lanza por WebSocket (ui/puenteClient.js). El canal de WhatsApp Web está
 * fuera de alcance (spec 1), así que el SW no tiene bucle de campaña.
 */

importScripts('ui/utils.js', 'ui/licenseGate.js', 'ui/licenseClient.js');

const LICENSE_VALIDATION_ALARM = 'licenseValidationAlarm';
const LICENSE_VALIDATION_PERIOD_MIN = 360; // 6h, revalidación cada 6 h

// Acciones de la campaña Web heredada del padre. Se rechazan con un código en
// vez de ignorarlas: un dashboard viejo en caché no debe quedar esperando.
const ACCIONES_WEB_RETIRADAS = [
    'START_CAMPAIGN', 'STOP_CAMPAIGN', 'PAUSE_CAMPAIGN', 'RESUME_CAMPAIGN', 'GET_CAMPAIGN_STATUS',
    'CHECK_CONNECTION', 'SCHEDULE_CAMPAIGN', 'DEBUGGER_TYPE_ONLY', 'DEBUGGER_CLICK'
];

chrome.runtime.onInstalled.addListener(() => {
    console.log('WhatsAppProSend: instalada.');
    setupLicenseValidationAlarm();
});

chrome.runtime.onStartup.addListener(() => {
    setupLicenseValidationAlarm();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'BRIDGE_CONTROL') {
        controlarPuente(request.command, sendResponse);
        return true;
    }

    if (request.action === 'LICENSE_ACTIVATE') {
        (async () => {
            const state = await activateLicense(request.licenseKey);
            const gate = computeGateDecision(state, Date.now());
            sendResponse({ ...gate, ...state });
        })();
        return true;
    }

    if (request.action === 'LICENSE_STATUS') {
        (async () => {
            const state = await getCachedLicenseState();
            const gate = computeGateDecision(state, Date.now());
            sendResponse({ ...gate, ...(state || {}) });
        })();
        return true;
    }

    if (ACCIONES_WEB_RETIRADAS.includes(request.action)) {
        sendResponse({
            ok: false,
            code: 'ACCION_NO_SOPORTADA',
            message: 'La campaña corre en el puente ADB, no en la extensión: ' + request.action
        });
        return true;
    }

    return false;
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === LICENSE_VALIDATION_ALARM) {
        validateLicense().catch(err => console.warn('[license] validación periódica falló:', err?.message || err));
    }
});

/**
 * Crea la alarma de revalidación periódica de licencia y dispara una
 * validación inmediata (no espera 6h para la primera corrida tras instalar
 * o reiniciar Chrome).
 */
function setupLicenseValidationAlarm() {
    chrome.alarms.create(LICENSE_VALIDATION_ALARM, { periodInMinutes: LICENSE_VALIDATION_PERIOD_MIN });
    validateLicense().catch(err => console.warn('[license] validación inicial falló:', err?.message || err));
}

// ────────────────────────────────────────────────────────────
// Puente ADB: arranque desde el dashboard por Native Messaging
// ────────────────────────────────────────────────────────────
// El canal ADB corre en bridge/server.js, que arranca este host nativo
// (native-launcher/launcher.js). El service worker solo pasa el comando; el
// WebSocket lo abre el dashboard (ui/puenteClient.js).
const BRIDGE_HOST = 'com.anomalydevs.whatsapppro.adblauncher';

// Exactamente los del protocolo de launcher.js. Lista blanca y no validación
// por descarte: lo que viaja acá termina ejecutando procesos en la máquina.
const BRIDGE_COMANDOS = ['status', 'start', 'stop', 'restart', 'register'];

function controlarPuente(command, sendResponse) {
    if (!BRIDGE_COMANDOS.includes(command)) {
        sendResponse({
            ok: false,
            code: 'BRIDGE_COMANDO_INVALIDO',
            message: 'Comando de puente desconocido: ' + command
        });
        return;
    }
    try {
        chrome.runtime.sendNativeMessage(BRIDGE_HOST, { action: command }, (result) => {
            const fallo = chrome.runtime.lastError;
            if (fallo || !result) {
                sendResponse({
                    ok: false,
                    code: 'BRIDGE_LAUNCHER_NO_REGISTRADO',
                    message: 'No se pudo hablar con el lanzador del puente (' + BRIDGE_HOST + '): ' +
                        ((fallo && fallo.message) || 'sin respuesta') +
                        '. Ejecuta native-launcher\\install.exe y vuelve a intentar.'
                });
                return;
            }
            sendResponse({ ok: true, code: 'OK', message: '', result });
        });
    } catch (err) {
        sendResponse({
            ok: false,
            code: 'BRIDGE_LAUNCHER_NO_REGISTRADO',
            message: 'No se pudo hablar con el lanzador del puente: ' + (err && err.message ? err.message : err) +
                '. Ejecuta native-launcher\\install.exe y vuelve a intentar.'
        });
    }
}
