# register.ps1 — Registra el Native Messaging Host ante Chrome (usuario actual).
# Portátil entre máquinas: calcula rutas absolutas a partir de la ubicación
# real de este script ($PSScriptRoot) y del sistema, en vez de asumir nada
# fijo — necesario porque esta carpeta viaja con el repo y puede clonarse en
# cualquier ubicación/usuario.
#
# CLAVE: resuelve adb.exe y node.exe a rutas absolutas AHORA (tiempo de
# registro) y las fija en el .bat generado — el server nunca vuelve a
# depender del PATH que herede quien lo lance. Sin esto, un Chrome que
# lleva abierto desde antes de instalar adb/platform-tools hereda un PATH
# viejo y todo lo que lanza (el server incluido) falla con
# "spawn adb ENOENT", sin importar cuántas veces se reinicie el server —
# el problema está en Chrome, no en el server, y reiniciar el server no
# lo arregla.

$ErrorActionPreference = 'Stop'

# cmd.exe parsea el texto literal de un .bat con el codepage OEM ACTIVO de
# la consola en el momento de tokenizar cada línea (850 en instalaciones en
# español), no con el codepage del archivo. Una ruta de repo con tildes o
# "ñ" (como esta misma carpeta) se corrompe byte a byte al leerla como texto
# — "ñ" en UTF-8 (0xC3 0x91) se decodifica como dos caracteres OEM
# distintos — y node.exe recibe una ruta rota, revienta con MODULE_NOT_FOUND
# antes de escribir el primer mensaje, y Chrome lo reporta como "Error when
# communicating with the native messaging host." (no como host no
# encontrado, porque el manifest sí se resolvió bien).
#
# Se probó `chcp 65001` como primera línea del .bat (cambiar el codepage
# antes de la línea con la ruta): funciona en una sesión de consola normal,
# pero es intermitente bajo el modo sin consola con el que Chrome lanza
# Native Messaging Hosts (stdio 100% redirigido) — a veces corrompe la
# tokenización de la línea SIGUIENTE en su lugar ("C:\Program" no
# reconocido). Comportamiento no confiable de cmd.exe, no vale la pena
# perseguirlo.
#
# Fix real: convertir cada ruta a su nombre corto 8.3 (ASCII puro,
# garantizado por NTFS salvo que 8dot3 esté deshabilitado en el volumen) —
# elimina el problema de raíz porque no hay ningún byte no-ASCII que
# decodificar.
function Get-ShortPath {
    param([string]$Path)
    if (-not ('Win32.Kernel32Native' -as [type])) {
        Add-Type -Namespace Win32 -Name Kernel32Native -MemberDefinition @'
[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
public static extern uint GetShortPathName(string lpszLongPath, System.Text.StringBuilder lpszShortPath, uint cchBuffer);
'@
    }
    $sb = New-Object System.Text.StringBuilder 260
    $len = [Win32.Kernel32Native]::GetShortPathName($Path, $sb, $sb.Capacity)
    if ($len -eq 0) { return $Path }
    $short = $sb.ToString().Substring(0, $len)
    if ($short -match '[^\x00-\x7F]') {
        throw "No se pudo generar una ruta corta ASCII para '$Path' (¿8dot3 deshabilitado en este volumen? revisar con 'fsutil 8dot3name query %systemdrive%'). Mové el repo a una ruta sin tildes/ñ o habilitá 8dot3 y volvé a correr register.ps1."
    }
    return $short
}

function Resolve-AdbPath {
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Android\platform-tools\adb.exe'),
        (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe')
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    $cmd = Get-Command adb -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Resolve-NodePath {
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @('C:\Program Files\nodejs\node.exe', 'C:\Program Files (x86)\nodejs\node.exe')
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    return $null
}

$adbPath = Resolve-AdbPath
if (-not $adbPath) {
    throw "No se encontró adb.exe (ni en %LOCALAPPDATA%\Android\platform-tools ni en PATH). Instala Android platform-tools antes de registrar el lanzador."
}

$nodePath = Resolve-NodePath
if (-not $nodePath) {
    throw "No se encontró node.exe en PATH. Instala Node.js antes de registrar el lanzador."
}

$launcherJs = Join-Path $PSScriptRoot 'launcher.js'
if (-not (Test-Path $launcherJs)) {
    throw "No se encontró launcher.js en $PSScriptRoot"
}

$generatedBat = Join-Path $PSScriptRoot 'launcher.generated.bat'
$adbPathShort = Get-ShortPath $adbPath
$nodePathShort = Get-ShortPath $nodePath
$launcherJsShort = Get-ShortPath $launcherJs
$batContent = @"
@echo off
set "ADB_PATH=$adbPathShort"
"$nodePathShort" "$launcherJsShort"
"@
[System.IO.File]::WriteAllText($generatedBat, $batContent, (New-Object System.Text.UTF8Encoding $false))

$templatePath = Join-Path $PSScriptRoot 'com.anomalydevs.smspro.adblauncher.json'
$manifestPath = Join-Path $PSScriptRoot 'com.anomalydevs.smspro.adblauncher.generated.json'

$template = Get-Content $templatePath -Raw
# JSON requiere barras invertidas escapadas
$escapedPath = $generatedBat.Replace('\', '\\')
$manifestContent = $template.Replace('__LAUNCHER_BAT_PATH__', $escapedPath)
# Set-Content -Encoding utf8 en PowerShell 5.1 agrega BOM, que puede romper
# el parser JSON del Native Messaging Host de Chrome — se escribe sin BOM.
[System.IO.File]::WriteAllText($manifestPath, $manifestContent, (New-Object System.Text.UTF8Encoding $false))

$regKey = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.anomalydevs.smspro.adblauncher'
New-Item -Path $regKey -Force | Out-Null
Set-ItemProperty -Path $regKey -Name '(Default)' -Value $manifestPath

Write-Host "Native Messaging Host registrado."
Write-Host "  adb.exe:  $adbPath"
Write-Host "  node.exe: $nodePath"
Write-Host "  launcher.generated.bat: $generatedBat"
Write-Host "  Manifest: $manifestPath"
Write-Host "  Registro: $regKey"
Write-Host ""
Write-Host "El server ahora usa siempre esta ruta exacta de adb, sin importar el PATH de quien lo lance. Si mueves/reinstalas adb en otra ubicación, corre register.ps1 de nuevo."
