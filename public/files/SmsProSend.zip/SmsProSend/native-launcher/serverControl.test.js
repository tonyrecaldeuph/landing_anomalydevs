const assert = require('assert');
const { EventEmitter } = require('events');
const serverControl = require('./serverControl.js');

function fakeChild() {
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stderr = new EventEmitter();
    return child;
}

(async () => {
    // Caso 1: statusCheck reporta running=true y el pid guardado si el puerto responde
    const status1 = await serverControl.statusCheck({
        isPortOpen: async () => true,
        readFile: () => '4242'
    });
    assert.deepStrictEqual(status1, { running: true, pid: 4242 });
    console.log('OK: statusCheck running=true con pid');

    // Caso 2: statusCheck reporta running=false si el puerto no responde (server caído)
    const status2 = await serverControl.statusCheck({
        isPortOpen: async () => false,
        readFile: () => { throw new Error('ENOENT'); }
    });
    assert.deepStrictEqual(status2, { running: false, pid: null });
    console.log('OK: statusCheck running=false sin pidfile');

    // Caso 3: startServer spawnea con execPath+SERVER_ENTRY, detached, y guarda el pid
    const spawnCalls = [];
    let writtenPid = null;
    const pid = serverControl.startServer({
        spawn: (cmd, args, opts) => {
            spawnCalls.push({ cmd, args, opts });
            return { pid: 9999, unref: () => {} };
        },
        writeFile: (file, data) => { writtenPid = { file, data }; },
        openLog: () => 777
    });
    assert.strictEqual(pid, 9999);
    assert.strictEqual(spawnCalls.length, 1);
    assert.strictEqual(spawnCalls[0].args[0], serverControl.SERVER_ENTRY);
    assert.strictEqual(spawnCalls[0].opts.detached, true);
    assert.strictEqual(writtenPid.data, '9999');
    console.log('OK: startServer spawnea detached y guarda pid');

    // Caso 3b: startServer redirige stdout/stderr del hijo a LOGFILE en vez de
    // descartarlos — sin esto, console.log/error del server se pierden por
    // completo (stdio:'ignore') y no hay forma de diagnosticar fallos.
    const openLogCalls = [];
    const spawnCalls3b = [];
    serverControl.startServer({
        spawn: (cmd, args, opts) => {
            spawnCalls3b.push({ cmd, args, opts });
            return { pid: 1, unref: () => {} };
        },
        writeFile: () => {},
        openLog: (file) => { openLogCalls.push(file); return 888; }
    });
    assert.deepStrictEqual(openLogCalls, [serverControl.LOGFILE]);
    assert.deepStrictEqual(spawnCalls3b[0].opts.stdio, ['ignore', 888, 888]);
    console.log('OK: startServer redirige stdout/stderr a LOGFILE');

    // Caso 4: stopServer mata el pid guardado y limpia el pidfile
    const killCalls = [];
    let unlinked = false;
    const stopped = serverControl.stopServer({
        readFile: () => '4242',
        kill: (pid, sig) => killCalls.push({ pid, sig }),
        unlink: () => { unlinked = true; }
    });
    assert.strictEqual(stopped, true);
    assert.deepStrictEqual(killCalls, [{ pid: 4242, sig: 'SIGTERM' }]);
    assert.strictEqual(unlinked, true);
    console.log('OK: stopServer mata el pid y limpia el pidfile');

    // Caso 5: stopServer sin pidfile no falla, devuelve false, no intenta matar nada
    const killCalls2 = [];
    const stopped2 = serverControl.stopServer({
        readFile: () => { throw new Error('ENOENT'); },
        kill: (pid, sig) => killCalls2.push({ pid, sig })
    });
    assert.strictEqual(stopped2, false);
    assert.strictEqual(killCalls2.length, 0);
    console.log('OK: stopServer sin pidfile no falla');

    // Caso 6: stopServer no falla si el proceso ya no existía (kill lanza error)
    const stopped3 = serverControl.stopServer({
        readFile: () => '111',
        kill: () => { throw new Error('ESRCH: no such process'); },
        unlink: () => {}
    });
    assert.strictEqual(stopped3, true, 'igual limpia el pidfile aunque el proceso ya no existiera');
    console.log('OK: stopServer tolera que el proceso ya no exista');

    // Caso 7: restartServer detiene, espera, y vuelve a arrancar
    const order = [];
    const pidRestart = await serverControl.restartServer({
        readFile: () => '111',
        kill: () => order.push('kill'),
        unlink: () => order.push('unlink'),
        spawn: () => { order.push('spawn'); return { pid: 555, unref: () => {} }; },
        writeFile: () => order.push('write'),
        sleep: async () => order.push('sleep')
    });
    assert.strictEqual(pidRestart, 555);
    assert.deepStrictEqual(order, ['kill', 'unlink', 'sleep', 'spawn', 'write']);
    console.log('OK: restartServer detiene y vuelve a arrancar en orden');

    // Caso 8: registerHost invoca powershell -File register.ps1 y resuelve ok=true si exit code 0
    const spawnArgs8 = [];
    const registerPromise1 = serverControl.registerHost({
        spawn: (cmd, args, opts) => {
            spawnArgs8.push({ cmd, args, opts });
            const child = fakeChild();
            setImmediate(() => {
                child.stdout.emit('data', Buffer.from('Native Messaging Host registrado.\n'));
                child.emit('close', 0);
            });
            return child;
        }
    });
    const result1 = await registerPromise1;
    assert.strictEqual(spawnArgs8[0].cmd, 'powershell.exe');
    assert.deepStrictEqual(spawnArgs8[0].args, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', serverControl.REGISTER_PS1]);
    assert.deepStrictEqual(result1, { ok: true, code: 0, stdout: 'Native Messaging Host registrado.', stderr: '' });
    console.log('OK: registerHost corre register.ps1 y reporta éxito');

    // Caso 9: registerHost reporta ok=false y stderr si register.ps1 termina con error (p.ej. adb no encontrado)
    const result2 = await serverControl.registerHost({
        spawn: () => {
            const child = fakeChild();
            setImmediate(() => {
                child.stderr.emit('data', Buffer.from('No se encontró adb.exe\n'));
                child.emit('close', 1);
            });
            return child;
        }
    });
    assert.deepStrictEqual(result2, { ok: false, code: 1, stdout: '', stderr: 'No se encontró adb.exe' });
    console.log('OK: registerHost reporta fallo de register.ps1');

    // Caso 10: registerHost no falla si powershell.exe no se puede lanzar (spawn emite error)
    const result3 = await serverControl.registerHost({
        spawn: () => {
            const child = fakeChild();
            setImmediate(() => child.emit('error', new Error('spawn powershell.exe ENOENT')));
            return child;
        }
    });
    assert.deepStrictEqual(result3, { ok: false, code: null, stdout: '', stderr: 'spawn powershell.exe ENOENT' });
    console.log('OK: registerHost tolera que powershell.exe no exista');

    console.log('Todos los tests de serverControl pasaron.');
})().catch(e => { console.error('FAIL', e); process.exit(1); });
