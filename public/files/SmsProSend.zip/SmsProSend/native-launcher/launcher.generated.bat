@echo off
set "ADB_PATH=C:\Users\HP\AppData\Local\Android\PLATFO~2\adb.exe"
"C:\PROGRA~1\nodejs\node.exe" "C:\Users\HP\Desktop\DESARR~1\EXTENS~1\SMSPRO~1.0\NATIVE~1\launcher.js"