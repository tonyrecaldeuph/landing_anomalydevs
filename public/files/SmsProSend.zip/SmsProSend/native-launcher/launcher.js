/**
 * launcher.js — Native Messaging Host invocado por Chrome vía
 * chrome.runtime.sendNativeMessage(). Traduce el protocolo stdio (mensajes
 * JSON con prefijo de longitud de 4 bytes little-endian) a serverControl.
 *
 * sendNativeMessage es de un solo mensaje: se procesa uno y el proceso
 * termina — Chrome lo relanza en cada llamada siguiente.
 */

const serverControl = require('./serverControl.js');

function sendMessage(obj) {
    const json = Buffer.from(JSON.stringify(obj), 'utf-8');
    const header = Buffer.alloc(4);
    header.writeUInt32LE(json.length, 0);
    process.stdout.write(Buffer.concat([header, json]));
}

async function handleMessage(msg) {
    try {
        let result;
        switch (msg && msg.action) {
            case 'status':
                result = await serverControl.statusCheck();
                break;
            case 'start': {
                const status = await serverControl.statusCheck();
                if (status.running) { result = { started: false, alreadyRunning: true, pid: status.pid }; break; }
                result = { started: true, pid: serverControl.startServer() };
                break;
            }
            case 'stop':
                result = { stopped: serverControl.stopServer() };
                break;
            case 'restart':
                result = { restarted: true, pid: await serverControl.restartServer() };
                break;
            case 'register':
                result = await serverControl.registerHost();
                break;
            default:
                result = { error: `Acción desconocida: ${msg && msg.action}` };
        }
        sendMessage(result);
    } catch (err) {
        sendMessage({ error: err.message });
    } finally {
        process.exit(0);
    }
}

let buffer = Buffer.alloc(0);
process.stdin.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    if (buffer.length < 4) return;
    const len = buffer.readUInt32LE(0);
    if (buffer.length < 4 + len) return;
    const msgBuf = buffer.slice(4, 4 + len);
    let msg;
    try { msg = JSON.parse(msgBuf.toString('utf-8')); } catch (_) { msg = null; }
    handleMessage(msg);
});

process.stdin.on('end', () => process.exit(0));
