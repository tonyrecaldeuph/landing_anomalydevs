# Envío optimizado: variantes de texto + tiempos aleatorios

Fecha: 2026-06-30
Extensión: RCS PRO v3.0 (Chrome MV3, automatización de messages.google.com)

## Problema

1. **Timing aleatorio neutralizado.** `getCampaignConfig()` fuerza `delayMin: 2, delayMax: 2`
   (fijo 2s). El backend `pauseBetweenSends()` ya soporta rango random min..max, pero la UI
   lo anula. La ráfaga constante facilita el bloqueo de Google a números nuevos.
2. **Sin variación de texto a nivel plantilla.** Existe spin `{a|b|c}` (intra-texto) y
   `{{Var}}` (personalización), pero un solo `messageTemplate` por campaña. El checkbox
   "Aleatorización de Mensajes" (`chk-random`) no se lee en ningún lado → no hace nada.

## Decisiones

- **Mecanismo de textos:** pool de plantillas completas + spin existente.
- **Selección de variante:** aleatorio puro por contacto.
- **Tiempos:** rango min/max configurable (sin lotes/pausas largas).

## Diseño

### 1. UI variantes (dashboard.html / dashboard.js)
- El textarea principal `#message-text` = Variante 1.
- Zona `#variantes-container` con `#variantes-list` (vacía) + botón `➕ Añadir variante`
  (`#btn-add-variante`). Cada extra: textarea `.variante-extra` + botón ✕ que elimina la fila.
- `collectMessageVariants()` → `[main, ...extras]` filtrando vacíos.
- Checkbox `chk-random` controla rotación: ON = elige variante random; OFF = usa Variante 1.

### 2. UI tiempos (dashboard.html / dashboard.js)
- Reemplaza la tarjeta "Fijo: 2 segundos" por inputs `#input-delay-min` / `#input-delay-max`
  (default 15 / 40). `getCampaignConfig()` valida `2 ≤ min ≤ max` y los pasa reales.

### 3. Selección (background.js)
```js
function pickMessage(state) {
  const variants = Array.isArray(state.messageVariants)
    ? state.messageVariants.filter(v => v && v.trim()) : [];
  const randomize = state.config && state.config.randomizeMessages;
  if (randomize && variants.length > 0)
    return variants[Math.floor(Math.random() * variants.length)];
  return variants[0] || state.messageTemplate || '';
}
```
`processSingleContact` usa `pickMessage(state)` como `message`. content.js ya aplica
spin + personalize → **sin cambios en content.js ni utils.js**.

### 4. Persistencia / ciclo de vida
- `messageVariants` se guarda en `currentCampaign` y `campaignState`.
- Restaurado en: `loadOrInitCampaignState` (background), reconstrucción de UI
  (`resumeCampaignState`), `RESUME_CAMPAIGN`, `SCHEDULE_CAMPAIGN`.

## Retrocompatibilidad
1 sola variante ⇒ comportamiento idéntico al actual. `messageTemplate` se conserva como
Variante 1 (backward compat) y fallback de `pickMessage`.

## Archivos
- `dashboard.html` — UI variantes + inputs de tiempo.
- `dashboard.js` — recolectar variantes, config tiempos, persistencia/restauración.
- `background.js` — `pickMessage`, restaurar variantes en resume/schedule.
- `content.js`, `utils.js` — sin cambios.
