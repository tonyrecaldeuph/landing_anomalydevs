# Canal ADB + motor de campaña compartido

Fecha: 2026-08-27
Extensión: SMS PRO V3.0 (Chrome MV3, automatización de messages.google.com) — espejado en SMS PRO V3.O COBROFAST

## Problema

1. **RCS no funciona de forma confiable vía Google Messages Web.** No existe API pública de
   Android para enviar RCS por comando — el protocolo (Jibe) solo lo entrega la app nativa
   Google Messages. La automatización actual (`content.js` + `chrome.debugger` sobre
   `messages.google.com`) depende de una SPA web con selectores frágiles (ver bug recurrente
   de duplicados por conversación mal verificada) y no siempre refleja el comportamiento real
   de RCS del teléfono.
2. **Un solo target de envío.** El flujo actual solo puede operar una pestaña de Chrome a la
   vez. No hay forma de repartir una campaña entre varios teléfonos físicos para aumentar
   throughput o aislar bloqueos por número.
3. **Lógica de negocio atada al entorno.** Reintentos, anti-spam y verificación de envío viven
   mezclados con `chrome.debugger`/DOM dentro de `background.js`/`content.js` — no son
   testeables sin un browser real, y cualquier canal nuevo forzaría a duplicar esas reglas.

## Decisiones

- **Canal ADB coexiste con el canal web** (no lo reemplaza). El dashboard elige uno u otro.
- **Automatización en el teléfono vía `adb shell input` + `uiautomator dump`** contra la app
  Google Messages nativa (sin APK auxiliar en esta iteración) — resuelve RCS real porque usa
  la app real, no una alternativa a las apps de mensajería nativas de Android.
- **Puente nativo = servidor Node local** (`adb-bridge-server`), no un Native Messaging Host —
  sobrevive al ciclo de vida del service worker de Chrome (se descarga a los ~30s de
  inactividad) y puede correr una campaña larga en segundo plano.
- **Multi-dispositivo en paralelo desde v1**, solo por USB (sin ADB inalámbrico en esta
  iteración).
- **Paridad completa desde v1** con el canal web: reintento por fallo de carrier (hasta 3
  intentos), pausa anti-spam tras 2 bloqueos consecutivos, verificación de header de
  conversación antes de confiar en ella.
- **Motor de orquestación único y compartido** (`campaignEngine.js`, JS puro sin `chrome.*` ni
  APIs de Node) entre `background.js` (canal web) y `adb-bridge-server` (canal ADB), en vez de
  duplicar las reglas de negocio por entorno.
- **Alcance de árboles:** se construye primero en `SMS PRO V3.0` (base), se valida con una
  campaña real de prueba, y luego se porta a `SMS PRO V3.O COBROFAST` con su propio formato de
  Excel/branding sobre el mismo motor. La raíz del repo (`EXTENSION SMS CAMPAÑAS`, rama
  `feat/sms-ext-optimizations`) queda fuera de alcance.

## Arquitectura

```
┌─────────────────────────┐        WebSocket/HTTP        ┌──────────────────────────┐
│  Extensión Chrome        │ ◄───────────────────────────► │  Servidor local (Node)   │
│  (SMS PRO V3.0/COBROFAST)│        localhost:PUERTO       │  adb-bridge-server       │
│                          │                                │                          │
│  ui/dashboard.js (popup) │                                │  campaignEngine.js ──┐   │
│  background.js           │                                │  (mismo módulo,      │   │
│    ├─ campaignEngine.js  │                                │   importado también   │   │
│    │   (mismo módulo)    │                                │   acá)                │   │
│    └─ WebChannel         │                                │  AdbChannel ──────────┘   │
│        (chrome.debugger  │                                │    (adb shell input,      │
│         + content.js)    │                                │     uiautomator dump)     │
└──────────────┬───────────┘                                └──────────────┬───────────┘
               │ CDP / DOM                                                  │ USB
               ▼                                                            ▼
    messages.google.com (pestaña Chrome)                    Teléfono(s) físicos — Google
                                                              Messages nativo (real RCS)
```

## Diseño

### 1. `campaignEngine.js` (módulo puro)
Máquina de estados de la campaña: cola de contactos, reparto round-robin entre targets
disponibles, política de reintento (3 intentos por fallo de carrier), pausa anti-spam por
target tras 2 bloqueos consecutivos, verificación de envío. Opera exclusivamente contra la
interfaz `Channel` — nunca contra `chrome.debugger` ni `adb` directamente (Ley de Demeter).

Interfaz `Channel`:
```js
listTargets()              // targets disponibles (web=1 fijo; ADB=N dispositivos)
openConversation(target, phone)
send(target, text)
verifySent(target)         // true/false/pending
detectProtocol(target)     // 'sms' | 'rcs'
isBlocked(target)          // señal de bloqueo del carrier/app
```

### 2. `WebChannel` (envoltorio, sin cambios de comportamiento)
Adapta el `content.js`/`chrome.debugger` existente a la interfaz `Channel`. No se reescribe
la lógica interna — solo se expone con esta superficie. Riesgo bajo: el canal en producción
no cambia de comportamiento.

### 3. `AdbChannel` (nuevo, vive en `adb-bridge-server`)
Traduce cada método de `Channel` a comandos `adb`:
- `listTargets()` → `adb devices` (filtra `device` vs `unauthorized`/`offline`)
- `openConversation`/`send` → `adb shell input tap/text/keyevent` sobre Google Messages nativo
- `verifySent`/`detectProtocol`/`isBlocked` → `adb shell uiautomator dump` + parseo del XML
  (equivalente a los selectores DOM de `content.js`, pero contra `resource-id`/`text` de la UI
  nativa de Android)

### 4. `adb-bridge-server` (proceso Node nuevo)
Aloja `campaignEngine` + `AdbChannel`. Expone WebSocket al dashboard: iniciar/pausar/detener
campaña, progreso en tiempo real por dispositivo, listar dispositivos conectados. Corre
independiente del ciclo de vida de Chrome.

### 5. `ui/dashboard.js`
Selector de canal (Web/ADB). Si es ADB: vista de dispositivos conectados con progreso por
teléfono en vez de una sola barra global. Carga de Excel, plantillas e historial no cambian —
ya son agnósticos del canal.

## Flujo de datos (campaña ADB de punta a punta)

1. Excel cargado en dashboard (`dataProcessor.js`, sin cambios) → lista de contactos.
2. Usuario elige canal ADB → dashboard abre WebSocket contra `adb-bridge-server`. Si no está
   corriendo, se muestra instrucción de arrancarlo (la extensión no puede lanzar procesos del
   sistema).
3. Dashboard envía `{contacts, template}` → servidor llama `AdbChannel.listTargets()` →
   `adb devices` → N teléfonos autorizados.
4. `campaignEngine` reparte contactos entre los N targets (round-robin) y arranca una máquina
   de estados por dispositivo, en paralelo.
5. Por contacto: `openConversation` (ubica compose vía `uiautomator dump`, escribe número,
   **verifica header** comparando últimos 7 dígitos antes de confiar en la conversación
   abierta — mismo principio que evita el bug de duplicados documentado) → `send` (texto +
   `input keyevent 66`) → `verifySent` (nuevo dump, busca indicador de burbuja) →
   `detectProtocol` (chip RCS visible en compose bar antes de enviar).
6. Resultado se emite por WebSocket → dashboard actualiza fila del contacto y panel por
   dispositivo en tiempo real, se persiste en el historial existente (misma estructura, sin
   cambios).
7. Si `isBlocked(target)` se dispara 2 veces seguidas en un dispositivo, ese dispositivo entra
   en pausa anti-spam — los demás dispositivos siguen enviando.
8. Fin de cola o detención manual → servidor notifica fin, dashboard cierra vista de progreso
   (mismo criterio que `finalizeCampaign` actual).

## Manejo de errores

- **Dispositivo se desconecta a mitad de campaña**: detectado en el siguiente poll de
  `adb devices`; `campaignEngine` reasigna sus contactos pendientes a otro dispositivo activo o
  los deja en cola "pendiente de dispositivo" — nunca se marcan como enviados sin confirmación.
- **`uiautomator dump` no encuentra el elemento esperado** (pantalla bloqueada, app distinta en
  foreground, OEM con UI distinta): tratado como fallo de `openConversation`/`send`, mismo
  camino de reintento (3 intentos); si persiste, contacto marcado como fallido en historial.
- **Falso "no enviado"**: `verifySent` debe tolerar el estado "enviando" un tiempo prudente
  antes de fallar (misma corrección ya aplicada al eliminar el veredicto `STUCK` prematuro en
  `waitForSendConfirmation`), no solo 8s fijos.
- **Bloqueo/anti-spam por dispositivo**: aislado por target — un teléfono bloqueado no detiene
  la campaña completa, solo se retira temporalmente del pool de reparto.
- **Servidor local caído o no arrancado**: dashboard detecta el fallo de conexión WebSocket y
  muestra estado explícito ("Servidor ADB no disponible"), sin bloquear el resto del dashboard
  (canal web sigue operativo).
- **`adb` no instalado/sin platform-tools en PATH**: prerrequisito documentado (no se instala
  automáticamente); el servidor falla rápido y explícito al arrancar, no a mitad de campaña.

## Testing (F.I.R.S.T.)

`campaignEngine.js`, al no depender de `chrome.*` ni de `adb`, es testeable sin browser ni
dispositivo real — ganancia estructural sobre el estado actual.

- **Unitarias sobre `campaignEngine`**: `FakeChannel` en memoria (implementa `Channel` con
  stubs controlables) para probar reparto round-robin, política de reintento, disparo de
  pausa anti-spam tras 2 bloqueos, aislamiento de un dispositivo caído sin afectar a los demás.
- **`AdbChannel` (parseo de `uiautomator dump`)**: unitarias con fixtures de XML real
  capturado, mismo patrón que `mapRowToContact()` en `dataProcessor.test.js`.
- **`WebChannel`**: sin cambio de comportamiento, no requiere cobertura nueva más allá de
  confirmar que la envoltura respeta la interfaz `Channel`.
- **Integración manual** (no automatizable de forma confiable): campaña real de pocos
  contactos contra un teléfono de prueba por USB antes de dar por validada cada iteración —
  parte del checklist de aceptación, no test automatizado.

## Rollout

1. `git init` + commit inicial en `SMS PRO V3.0` y en `SMS PRO V3.O COBROFAST` antes de tocar
   código — ninguno de los dos árboles tiene historial hoy. Commits en español, autoría
   `Anomalydevs <anomalydevsec@gmail.com>`.
2. Construir en `SMS PRO V3.0` (base) primero: `campaignEngine.js`, `WebChannel`, `AdbChannel`,
   `adb-bridge-server`, cambios de dashboard.
3. Validar con campaña real de prueba sobre un teléfono físico.
4. Portar a `SMS PRO V3.O COBROFAST` sobre el mismo motor, con su formato de Excel/branding.
5. ADR obligatorio: `SMS PRO V3.0/.agentes/adr/20260827-canal-adb-motor-compartido.md` con el
   trade-off central (velocidad de entrega vs. robustez: `input`+`uiautomator` en vez de una
   app auxiliar con Accessibility Service) y métricas Big O/Big I estimadas del reparto
   multi-dispositivo.
6. Prerrequisitos de entorno a documentar (no automatizados en esta tarea): Android
   platform-tools (`adb`) en PATH, depuración USB habilitada/autorizada por teléfono, Node.js
   instalado para `adb-bridge-server`.

## Fuera de alcance (esta iteración)

- ADB inalámbrico (Wi-Fi).
- App auxiliar con Accessibility Service (posible evolución de `AdbChannel` si
  `input`/`uiautomator` resulta demasiado frágil en campo).
- Reconciliación de la divergencia raíz-vs-forks del repo (`EXTENSION SMS CAMPAÑAS` en git).
- Instalación/gestión automática de `adb-bridge-server` como servicio de Windows.

## Archivos

- `campaignEngine.js` (nuevo, compartido) — motor puro, interfaz `Channel`.
- `background.js` — envoltorio `WebChannel`, importa `campaignEngine.js`.
- `adb-bridge-server/` (nuevo) — servidor Node, `AdbChannel`, WebSocket API.
- `ui/dashboard.js` / `ui/dashboard.html` — selector de canal, vista de dispositivos ADB.
- `.agentes/adr/20260827-canal-adb-motor-compartido.md` (nuevo) — ADR del trade-off.
