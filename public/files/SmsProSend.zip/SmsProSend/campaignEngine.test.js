const assert = require('assert');
const { CampaignEngine, classifyResultStatus, computePendingContacts } = require('./campaignEngine.js');

// FakeChannel determinístico — implementa interfaz Channel
class FakeChannel {
    constructor(id, opts = {}) {
        this.id = id;
        this.calls = [];
        this.sent = 0;
        this.failCarrierCount = opts.failCarrierCount || 0;
        this.blockedAfter = opts.blockedAfter !== undefined ? opts.blockedAfter : Infinity;
        this.failNonCarrierAfter = opts.failNonCarrierAfter !== undefined ? opts.failNonCarrierAfter : Infinity;
    }
    async listTargets() { return [this.id]; }
    async openConversation(target, phone) { this.calls.push(['open', target, phone]); }
    async send(target, text) {
        this.calls.push(['send', target, text]);
        this.sent++;
        if (this.sent <= this.failCarrierCount) throw new Error('CARRIER_FAILED: No se envió');
        if (this.sent === this.failNonCarrierAfter) throw new Error('DOM_TIMEOUT: Elemento no encontrado');
        // isBlocked se delega al engine vía isBlocked()
        return { ok: true };
    }
    async verifySent(target) { return true; }
    async detectProtocol(target) { return 'sms'; }
    async isBlocked(target) { return this.sent >= this.blockedAfter; }
}

(async () => {
    // Caso 1: round-robin entre 2 targets — 4 contactos se reparten 2 y 2
    const ch1 = new FakeChannel('device1');
    const ch2 = new FakeChannel('device2');
    const contacts = [{ TELEFONO: '111' }, { TELEFONO: '222' }, { TELEFONO: '333' }, { TELEFONO: '444' }];
    const engine = new CampaignEngine({ contacts, template: 'Hola {{TELEFONO}}', channels: [ch1, ch2] });
    const result = await engine.run();
    assert.strictEqual(result.results.length, 4, 'deben ser 4 resultados');
    const c1Sends = ch1.calls.filter(c => c[0] === 'send').length;
    const c2Sends = ch2.calls.filter(c => c[0] === 'send').length;
    assert.strictEqual(c1Sends, 2, 'device1 debe enviar 2');
    assert.strictEqual(c2Sends, 2, 'device2 debe enviar 2');
    // Verifica que el reparto fue round-robin (alternado)
    const order = result.results.map(r => r.target);
    assert.deepStrictEqual(order, ['device1', 'device2', 'device1', 'device2']);
    console.log('OK: round-robin entre 2 targets');
})().catch(e => { console.error('FAIL round-robin', e); process.exit(1); });

(async () => {
    // Caso 2: reintento solo para CARRIER_FAILED (hasta 3 intentos), no para errores no-carrier
    const ch = new FakeChannel('d1', { failCarrierCount: 2 });
    const contacts = [{ TELEFONO: '555' }];
    const engine = new CampaignEngine({ contacts, template: 'Test', channels: [ch] });
    const result = await engine.run();
    assert.strictEqual(result.results[0].status.includes('Enviado'), true, 'debe marcar Enviado tras 2 fallos carrier + éxito');
    assert.strictEqual(ch.calls.filter(c => c[0] === 'send').length, 3, 'debe haber 3 intentos');
    console.log('OK: reintento 3× para CARRIER_FAILED');
})().catch(e => { console.error('FAIL reintento carrier', e); process.exit(1); });

(async () => {
    // Caso 3: error no-carrier no se reintenta (falla directo)
    const ch = new FakeChannel('d1', { failNonCarrierAfter: 1 });
    ch.send = async (target, text) => { ch.calls.push(['send', target, text]); ch.sent++; throw new Error('DOM_TIMEOUT: timeout'); };
    const contacts = [{ TELEFONO: '666' }];
    const engine = new CampaignEngine({ contacts, template: 'Test', channels: [ch] });
    const result = await engine.run();
    assert.strictEqual(result.results[0].status.includes('Error'), true, 'debe marcar Error sin reintentar');
    assert.strictEqual(ch.calls.filter(c => c[0] === 'send').length, 1, 'solo 1 intento para error no-carrier');
    console.log('OK: error no-carrier no se reintenta');
})().catch(e => { console.error('FAIL no-carrier', e); process.exit(1); });

(async () => {
    // Caso 4: anti-spam por target tras 2 bloqueos consecutivos — solo el bloqueado pausa
    // Simulamos que device1 se bloquea después de 2 envíos (isBlocked true), device2 no
    const ch1 = new FakeChannel('device1', { blockedAfter: 2 });
    // device1: envía 2, luego isBlocked true → debe pausar y no tomar más contactos hasta reset
    // Para testear sin delay real, usamos config pause corto y verificamos que device2 sigue
    const ch2 = new FakeChannel('device2');
    const contacts = Array.from({ length: 6 }, (_, i) => ({ TELEFONO: `90${i}` }));
    const engine = new CampaignEngine({
        contacts,
        template: 'Hola',
        channels: [ch1, ch2],
        config: { antiSpamPauseMs: 10 } // pausa mínima para test rápido
    });
    const result = await engine.run();
    // Todos los contactos deben completarse aunque un device esté pausado
    assert.strictEqual(result.results.length, 6);
    // device1 debió tomar menos que device2 debido a la pausa
    const c1 = ch1.calls.filter(c => c[0] === 'send').length;
    const c2 = ch2.calls.filter(c => c[0] === 'send').length;
    assert.ok(c2 >= c1, 'device2 debe haber enviado >= que device1 (pausa anti-spam)');
    console.log('OK: anti-spam aislado por target');
})().catch(e => { console.error('FAIL anti-spam', e); process.exit(1); });

(async () => {
    // Caso 5: personalización de template con variables y spin syntax
    const ch = new FakeChannel('d1');
    const contacts = [{ TELEFONO: '777', CLIENTE: 'Juan' }];
    const engine = new CampaignEngine({ contacts, template: 'Hola {{CLIENTE}} {amigo|bro}', channels: [ch] });
    const result = await engine.run();
    const sentText = ch.calls.find(c => c[0] === 'send')[2];
    assert.ok(sentText.includes('Juan'), 'debe personalizar {{CLIENTE}}');
    assert.ok(sentText.includes('amigo') || sentText.includes('bro'), 'debe resolver spin');
    console.log('OK: personalización y spin');
})().catch(e => { console.error('FAIL personalización', e); process.exit(1); });

(async () => {
    // Caso 5b: attachImage se llama (feature-detection) solo si el channel lo implementa
    // y hay imageDataUrl — canales sin attachImage (ej. FakeChannel normal) no rompen.
    class FakeChannelConImagen extends FakeChannel {
        constructor(id) { super(id); this.attachedImages = []; }
        async attachImage(target, dataUrl) { this.attachedImages.push({ target, dataUrl }); }
    }
    const chConImagen = new FakeChannelConImagen('d1');
    const contacts = [{ TELEFONO: '1' }];
    const engineConImagen = new CampaignEngine({ contacts, template: 'Hola', channels: [chConImagen], imageDataUrl: 'data:image/png;base64,AAA' });
    await engineConImagen.run();
    assert.deepStrictEqual(chConImagen.attachedImages, [{ target: 'd1', dataUrl: 'data:image/png;base64,AAA' }]);
    console.log('OK: attachImage se invoca cuando el channel lo soporta y hay imagen');

    const chSinImagen = new FakeChannel('d2'); // no implementa attachImage
    const engineSinImagen = new CampaignEngine({ contacts, template: 'Hola', channels: [chSinImagen], imageDataUrl: 'data:image/png;base64,AAA' });
    const resultSinImagen = await engineSinImagen.run();
    assert.strictEqual(resultSinImagen.results[0].status.includes('Enviado'), true, 'no debe romper si el channel no soporta attachImage');
    console.log('OK: no falla si el channel no implementa attachImage');
})().catch(e => { console.error('FAIL attachImage', e); process.exit(1); });

(async () => {
    // Caso 6: engine.results crece en vivo durante run() (no solo al final) — necesario
    // para que un consumidor externo (adb-bridge-server) reporte progreso real si el
    // cliente se reconecta a mitad de campaña.
    const ch = new FakeChannel('d1');
    const contacts = [{ TELEFONO: '1' }, { TELEFONO: '2' }, { TELEFONO: '3' }];
    const engine = new CampaignEngine({ contacts, template: 'Hola', channels: [ch], config: { retryDelayMs: 0 } });
    const liveLengths = [];
    const donePromise = engine.run((progress) => {
        liveLengths.push(engine.results.length);
    });
    assert.strictEqual(engine.results.length, 0, 'antes de procesar nada, debe estar vacío (no solo al final)');
    await donePromise;
    assert.deepStrictEqual(liveLengths, [1, 2, 3], 'debe crecer de a uno en vivo, en el mismo orden que onProgress');
    assert.strictEqual(engine.results.length, 3, 'al final debe tener los 3 resultados');
    console.log('OK: engine.results expone progreso en vivo durante run()');
})().catch(e => { console.error('FAIL progreso en vivo', e); process.exit(1); });

(() => {
    // Caso 7: classifyResultStatus reconoce el tag de protocolo del canal Web
    // ("Enviado (RCS 🟢)"/"Enviado (SMS 🔵)") y el 'Enviado' liso del canal ADB
    // (que no distingue protocolo) como éxito, no como error.
    assert.strictEqual(classifyResultStatus('Enviado (RCS 🟢)'), 'RCS');
    assert.strictEqual(classifyResultStatus('Enviado (SMS 🔵)'), 'SMS');
    assert.strictEqual(classifyResultStatus('Enviado'), 'SMS');
    assert.strictEqual(classifyResultStatus('Duplicado'), 'Duplicado');
    assert.strictEqual(classifyResultStatus('Omitido'), 'Omitido');
    assert.strictEqual(classifyResultStatus('Error: device offline'), 'Error');
    assert.strictEqual(classifyResultStatus('algo-inesperado'), 'Error');
    console.log('OK: classifyResultStatus clasifica RCS/SMS/Duplicado/Omitido/Error');

    // Caso 8: computePendingContacts retoma los nunca alcanzados (campaña
    // cortada) y los que fallaron con error — nunca los duplicados/omitidos/
    // enviados exitosos.
    const contacts = [
        { TELEFONO: '111' }, // Enviado -> no retomar
        { TELEFONO: '222' }, // Error -> retomar
        { TELEFONO: '333' }, // Duplicado -> no retomar
        { TELEFONO: '444' }, // Omitido -> no retomar
        { TELEFONO: '555' }, // nunca alcanzado (campaña cortada acá) -> retomar
        { TELEFONO: '666' }  // nunca alcanzado -> retomar
    ];
    const contactResults = [
        { phone: '111', status: 'Enviado' },
        { phone: '222', status: 'Error: device offline' },
        { phone: '333', status: 'Duplicado' },
        { phone: '444', status: 'Omitido' }
        // 555 y 666 nunca se procesaron — la campaña se cortó antes de llegar
    ];
    const pending = computePendingContacts(contacts, contactResults);
    assert.deepStrictEqual(pending, [contacts[1], contacts[4], contacts[5]],
        'debe retomar el Error y los dos nunca alcanzados, en orden original');
    console.log('OK: computePendingContacts retoma errores + nunca alcanzados');

    // Caso 9: computePendingContacts con contactResults vacío/ausente retoma todo
    assert.deepStrictEqual(computePendingContacts(contacts, []), contacts);
    assert.deepStrictEqual(computePendingContacts(contacts, undefined), contacts);
    console.log('OK: computePendingContacts sin resultados previos retoma todos los contactos');

    // Caso 10: computePendingContacts sin nada pendiente devuelve []
    const doneContacts = [{ TELEFONO: '1' }];
    const doneResults = [{ phone: '1', status: 'Enviado' }];
    assert.deepStrictEqual(computePendingContacts(doneContacts, doneResults), []);
    console.log('OK: computePendingContacts devuelve vacío si no hay nada que retomar');
})();

// Esperar a que todas las promesas asíncronas terminen antes de declarar éxito global
setTimeout(() => {
    console.log('Todos los tests de campaignEngine pasaron (si no hubo FAIL arriba).');
}, 1500);
