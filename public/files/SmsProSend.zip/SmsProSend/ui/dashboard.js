/**
 * Dashboard UI Logic - SMS/RCS Masivos
 * Maneja eventos de la interfaz y comunicación con el background/content script.
 */

document.addEventListener('DOMContentLoaded', () => {
    console.log('UPHONE Dashboard: Inicializado con éxito.');
    Analytics.track('dashboard_open');

    // --- Selectores principales ---
    const sendBtn = document.getElementById('btn-enviar-ahora');
    const stopBtn = document.getElementById('btn-detener');
    const pauseBtn = document.getElementById('btn-pausar');
    const resumeBtn = document.getElementById('btn-reanudar');
    const messageText = document.getElementById('message-text');
    const resetBtn = document.querySelector('.btn-danger-outline');
    const importBtn = document.querySelector('.btn-import');
    const fileInput = document.getElementById('contact-file-input');
    const contactCountBadge = document.getElementById('contact-count');
    const variablesContainer = document.getElementById('variables-container');
    const variableTags = document.getElementById('variable-tags');

    // Variantes de mensaje (pool) y tiempos
    const variantesList = document.getElementById('variantes-list');
    const btnAddVariante = document.getElementById('btn-add-variante');
    const inputDelayMin = document.getElementById('input-delay-min');
    const inputDelayMax = document.getElementById('input-delay-max');

    // Canal de envío (Web / ADB)
    const selectChannel = document.getElementById('select-channel');
    const adbDevicesPanel = document.getElementById('adb-devices-panel');
    const adbDevicesList = document.getElementById('adb-devices-list');
    const btnRefreshAdb = document.getElementById('btn-refresh-adb');
    const btnServerStart = document.getElementById('btn-server-start');
    const btnServerStop = document.getElementById('btn-server-stop');
    const btnServerRestart = document.getElementById('btn-server-restart');
    const btnServerRegister = document.getElementById('btn-server-register');
    const adbStatus = document.getElementById('adb-status');
    let adbWs = null;
    let adbDevices = [];
    // HUD ADB inferior (paridad con Web)
    const adbHud = document.getElementById('adb-hud');
    const adbHudCount = document.getElementById('adb-hud-count');
    const adbHudPhone = document.getElementById('adb-hud-phone');
    const adbHudDevice = document.getElementById('adb-hud-device');
    const adbHudStatus = document.getElementById('adb-hud-status');
    let adbHudTotal = 0;

    const openSmsBtn = document.getElementById('btn-open-google-sms');
    const connectionDot = document.getElementById('connection-dot');
    const connectionText = document.getElementById('connection-text');

    // Modals
    const btnProgramar = document.getElementById('btn-programar');
    const navHistorial = document.getElementById('nav-historial');
    const navSoporte = document.getElementById('nav-soporte');
    const navLicencia = document.getElementById('nav-licencia');
    const modalProgramar = document.getElementById('modal-programar');
    const modalHistorial = document.getElementById('modal-historial');
    const modalSoporte = document.getElementById('modal-soporte');
    const modalLicencia = document.getElementById('modal-licencia');
    const btnCerrarModals = document.querySelectorAll('.btn-close');

    // Licencia
    const licenseBadge = document.getElementById('license-badge');
    const licenseInfo = document.getElementById('license-info');
    const inputLicenseKey = document.getElementById('input-license-key');
    const btnActivarLicencia = document.getElementById('btn-activar-licencia');

    // Promociones e Imágenes Selectores
    const selectPromocion = document.getElementById('select-promocion');
    const btnEliminarPromo = document.getElementById('btn-eliminar-promo');
    const btnGuardarPromo = document.getElementById('btn-guardar-promo');
    const inputImagen = document.getElementById('input-imagen');
    const btnCargarImagen = document.getElementById('btn-cargar-imagen');
    const btnQuitarImagen = document.getElementById('btn-quitar-imagen');
    const previewImagenContainer = document.getElementById('preview-imagen-container');
    const previewImagen = document.getElementById('preview-imagen');

    // --- Estado de la aplicación ---
    let contacts = [];
    let availableVariables = [];
    let currentImageDataUrl = '';
    let promotions = [];
    
    // --- Configuración Opciones de Envío ---
    // (Sliders de tiempo removidos: ahora el tiempo está fijo a 2 segundos)

    // Evento para abrir Google Messages
    if (openSmsBtn) {
        openSmsBtn.addEventListener('click', () => {
            window.open('https://messages.google.com/web', '_blank');
        });
    }

    // --- Gate combinado del botón Enviar: conexión + contactos + licencia ---
    let isGoogleMessagesOnline = false;
    let isLicenseAllowed = false;
    let hasPromptedForLicense = false;

    function updateSendButtonState() {
        const channel = selectChannel ? selectChannel.value : 'web';
        if (channel === 'adb') {
            const hasDevices = adbDevices.length > 0;
            sendBtn.disabled = !(hasDevices && isLicenseAllowed && contacts.length > 0);
        } else {
            sendBtn.disabled = !(isGoogleMessagesOnline && isLicenseAllowed && contacts.length > 0);
        }
    }

    // --- Canal ADB: WebSocket y lista de dispositivos ---
    function getAdbWsUrl() { return 'ws://localhost:8765'; }

    function renderAdbDevices(devices) {
        adbDevices = Array.isArray(devices) ? devices : [];
        if (!adbDevicesList) return;
        if (adbDevices.length === 0) {
            adbDevicesList.innerHTML = '<span style="color: var(--text-muted);">Sin dispositivos — conecta teléfonos por USB y autoriza depuración</span>';
        } else {
            adbDevicesList.innerHTML = adbDevices.map(d => `<span style="display:flex; align-items:center; gap:6px; padding:4px 6px; background: var(--bg-secondary); border:1px solid var(--border-color); border-radius:6px;">📱 ${d} <span style="margin-left:auto; background:#22c55e; color:white; padding:1px 6px; border-radius:10px; font-size:0.7rem;">conectado</span></span>`).join('');
        }
        if (adbStatus) adbStatus.textContent = adbDevices.length > 0 ? `${adbDevices.length} dispositivo(s) listo(s)` : 'Esperando dispositivos...';
        updateSendButtonState();
    }

    function connectAdbWs() {
        if (adbWs && adbWs.readyState === WebSocket.OPEN) return adbWs;
        try {
            adbWs = new WebSocket(getAdbWsUrl());
            adbWs.onopen = () => {
                if (adbStatus) adbStatus.textContent = 'Conectado al puente ADB — solicitando dispositivos...';
                adbWs.send(JSON.stringify({ type: 'list_devices' }));
                // El server sigue una campaña en curso aunque el popup se haya cerrado —
                // sin esto, reabrir el dashboard mostraba todo en blanco pese a que el
                // envío seguía sucediendo en los teléfonos.
                adbWs.send(JSON.stringify({ type: 'status' }));
            };
            adbWs.onmessage = (ev) => {
                let msg; try { msg = JSON.parse(ev.data); } catch { return; }
                if (msg.type === 'devices') renderAdbDevices(msg.devices);
                else if (msg.type === 'status') {
                    if (msg.isRunning) restoreAdbCampaignUI(msg);
                }
                else if (msg.type === 'error' && msg.code === 'ADB_NOT_FOUND') {
                    if (adbStatus) adbStatus.textContent = 'ADB no encontrado — instala platform-tools y añade adb al PATH';
                    renderAdbDevices([]);
                } else if (msg.type === 'error') {
                    if (adbStatus) adbStatus.textContent = `Error: ${msg.message}`;
                } else if (msg.type === 'progress') {
                    const el = document.getElementById(`status-row-${msg.index}`);
                    if (el) { el.value = `${msg.status} — ${msg.target}`; el.style.color = msg.status.includes('Enviado') ? '#22c55e' : '#eab308'; }
                    updateAdbHud(msg);
                } else if (msg.type === 'done' || msg.type === 'stopped') {
                    const isStopped = msg.stopped === true || msg.type === 'stopped';
                    chrome.storage.local.get(['history', 'currentCampaign'], (data) => {
                        const history = data.history || [];
                        const results = msg.results || [];
                        const cc = data.currentCampaign || {};
                        // Se guardan también contacts + la definición original para poder
                        // "Retomar envío" sin volver a subir el Excel — contacts completo
                        // incluye los nunca alcanzados si la campaña se cortó antes de
                        // tiempo (esos no están en contactResults).
                        history.unshift({
                            date: Date.now(),
                            contactCount: results.length,
                            status: isStopped ? 'Detenida' : 'Completada',
                            contactResults: results,
                            channel: 'adb',
                            contacts: Array.isArray(cc.contacts) ? cc.contacts : [],
                            messageTemplate: cc.messageTemplate || '',
                            messageVariants: Array.isArray(cc.messageVariants) ? cc.messageVariants : [],
                            imageDataUrl: cc.imageDataUrl || '',
                            config: cc.config || {}
                        });
                        chrome.storage.local.set({ history, campaignFinished: true });
                    });
                    // Reset UI para permitir nuevo envío inmediato
                    stopBtn.style.display = 'none';
                    stopBtn.disabled = false;
                    stopBtn.style.opacity = '';
                    stopBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/></svg> Detener Campaña';
                    sendBtn.disabled = false;
                    sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Enviar ahora';
                    if (adbStatus) adbStatus.textContent = isStopped ? 'Campaña detenida — listo para nuevo envío' : 'Campaña completada';
                    updateSendButtonState();
                    // Mantener HUD 3s para que el usuario vea el último estado, luego ocultar
                    setTimeout(hideAdbHud, 3000);
                } else if (msg.type === 'stopping') {
                    if (adbStatus) adbStatus.textContent = 'Deteniendo campaña...';
                }
            };
            adbWs.onclose = () => {
                if (adbStatus) adbStatus.textContent = 'Puente ADB desconectado — ejecuta `node adb-bridge-server/server.js`';
                renderAdbDevices([]);
            };
            adbWs.onerror = () => {
                if (adbStatus) adbStatus.textContent = 'No se pudo conectar a ws://localhost:8765 — ¿está corriendo el servidor?';
            };
        } catch (e) {
            if (adbStatus) adbStatus.textContent = 'Error WebSocket: ' + e.message;
        }
        return adbWs;
    }

    function handleChannelChange() {
        const channel = selectChannel ? selectChannel.value : 'web';
        if (channel === 'adb') {
            if (adbDevicesPanel) adbDevicesPanel.style.display = 'flex';
            connectAdbWs();
            connectionText.textContent = 'ADB';
            connectionDot.className = 'dot green';
        } else {
            if (adbDevicesPanel) adbDevicesPanel.style.display = 'none';
            if (adbWs) { try { adbWs.close(); } catch {} adbWs = null; }
            hideAdbHud();
            checkConnectionStatus();
        }
        updateSendButtonState();
    }

    function showAdbHud(total) {
        adbHudTotal = total || 0;
        if (adbHud) adbHud.style.display = 'flex';
        if (adbHudCount) adbHudCount.textContent = `0 / ${adbHudTotal}`;
        if (adbHudStatus) adbHudStatus.textContent = 'Iniciando...';
        if (adbHudPhone) adbHudPhone.textContent = '-';
        if (adbHudDevice) adbHudDevice.textContent = '-';
    }
    function updateAdbHud(progress) {
        if (!adbHud || adbHud.style.display === 'none') return;
        const idx = typeof progress.index === 'number' ? progress.index + 1 : 0;
        if (adbHudCount) adbHudCount.textContent = `${idx} / ${adbHudTotal}`;
        if (adbHudPhone) adbHudPhone.textContent = progress.phone || '-';
        if (adbHudDevice) adbHudDevice.textContent = progress.target || '-';
        if (adbHudStatus) {
            const s = progress.status || '';
            adbHudStatus.textContent = s;
            adbHudStatus.style.color = s.includes('Enviado') ? '#22c55e' : s.includes('Error') ? '#ef4444' : '#eab308';
        }
    }
    function hideAdbHud() {
        if (adbHud) adbHud.style.display = 'none';
    }

    // --- Borrador (draft) previo a iniciar campaña ---
    // El popup de la extensión se destruye por completo al hacer clic fuera de él
    // (no es una pestaña, MV3 lo cierra) — sin guardar el trabajo en progreso
    // (Excel cargado + mensaje escrito) antes de darle "Enviar", salir del popup
    // borraba todo. currentCampaign solo se guarda AL enviar; esto cubre el resto.
    let draftSaveTimer = null;
    function scheduleDraftSave() {
        clearTimeout(draftSaveTimer);
        draftSaveTimer = setTimeout(saveDraft, 500);
    }
    function saveDraft() {
        if (contacts.length === 0 && !messageText.value) return; // nada que guardar
        chrome.storage.local.set({
            draftCampaign: {
                contacts,
                messageTemplate: messageText.value,
                messageVariants: collectMessageVariants(),
                config: {
                    delayMin: inputDelayMin ? inputDelayMin.value : undefined,
                    delayMax: inputDelayMax ? inputDelayMax.value : undefined
                },
                imageDataUrl: currentImageDataUrl,
                promoId: selectPromocion ? selectPromocion.value : ''
            }
        });
    }
    function restoreDraft() {
        chrome.storage.local.get(['draftCampaign'], (data) => {
            const draft = data.draftCampaign;
            if (!draft || !Array.isArray(draft.contacts) || draft.contacts.length === 0) return;
            if (contacts.length > 0) return; // ya hay datos (ej. campaña activa restaurada), no pisar

            contacts = draft.contacts;
            updateSendButtonState();
            availableVariables = DataProcessor.getAvailableVariables(contacts);

            if (draft.messageTemplate) messageText.value = draft.messageTemplate;
            if (variantesList && Array.isArray(draft.messageVariants) && draft.messageVariants.length > 1) {
                variantesList.innerHTML = '';
                draft.messageVariants.slice(1).forEach(v => addVarianteRow(v));
            }
            if (draft.config) {
                if (inputDelayMin && draft.config.delayMin != null) inputDelayMin.value = draft.config.delayMin;
                if (inputDelayMax && draft.config.delayMax != null) inputDelayMax.value = draft.config.delayMax;
            }
            if (draft.imageDataUrl) {
                currentImageDataUrl = draft.imageDataUrl;
                showImagePreview(draft.imageDataUrl);
            }
            if (draft.promoId && selectPromocion) selectPromocion.value = draft.promoId;

            updateUIWithContacts();
            console.log(`Borrador restaurado: ${contacts.length} contacto(s), mensaje incluido`);
        });
    }

    // --- Reconstrucción de Estado ADB al Re-abrir el Dashboard ---
    // Espejo de resumeCampaignState() (canal web) pero a partir del status del
    // adb-bridge-server: sin esto, cerrar/recargar el popup durante una campaña
    // ADB dejaba el dashboard en blanco aunque el envío seguía en los teléfonos.
    let adbUiRestored = false;
    function restoreAdbCampaignUI(msg) {
        if (adbUiRestored) return; // evitar reconstrucción duplicada si llegan varios 'status'
        chrome.storage.local.get(['currentCampaign'], (data) => {
            if (!data.currentCampaign || !data.currentCampaign.contacts) return;
            adbUiRestored = true;

            const campaign = data.currentCampaign;
            contacts = campaign.contacts;
            updateSendButtonState();
            availableVariables = DataProcessor.getAvailableVariables(contacts);

            if (campaign.messageTemplate) messageText.value = campaign.messageTemplate;
            if (variantesList && Array.isArray(campaign.messageVariants) && campaign.messageVariants.length > 1) {
                variantesList.innerHTML = '';
                campaign.messageVariants.slice(1).forEach(v => addVarianteRow(v));
            }
            if (campaign.config) {
                if (inputDelayMin && campaign.config.delayMin != null) inputDelayMin.value = campaign.config.delayMin;
                if (inputDelayMax && campaign.config.delayMax != null) inputDelayMax.value = campaign.config.delayMax;
            }
            if (campaign.imageDataUrl) {
                currentImageDataUrl = campaign.imageDataUrl;
                showImagePreview(currentImageDataUrl);
            }
            if (campaign.promoId && selectPromocion) selectPromocion.value = campaign.promoId;

            contactCountBadge.textContent = `${contacts.length} contactos cargados`;
            if (availableVariables.length > 0) {
                variablesContainer.style.display = 'block';
                variableTags.innerHTML = '';
                availableVariables.forEach(variable => {
                    const tag = document.createElement('span');
                    tag.className = 'variable-tag';
                    tag.textContent = variable;
                    tag.onclick = () => insertVariable(variable);
                    variableTags.appendChild(tag);
                });
            }

            renderContactList();

            // A diferencia del canal web (que solo sabe "hasta dónde"), el server ADB
            // guarda el resultado exacto por contacto — se usa tal cual, fila por fila.
            (msg.results || []).forEach(r => {
                const el = document.getElementById(`status-row-${r.index}`);
                if (el) {
                    el.value = `${r.status}${r.target ? ' — ' + r.target : ''}`;
                    el.style.color = r.status.includes('Enviado') ? '#22c55e' : r.status.includes('Error') ? '#ef4444' : '#eab308';
                }
            });
            const currentEl = document.getElementById(`status-row-${msg.progressIndex}`);
            if (currentEl) { currentEl.value = 'Enviando... ⏳'; currentEl.style.color = '#eab308'; }

            // Reactivar la vista del canal ADB
            if (selectChannel) selectChannel.value = 'adb';
            if (adbDevicesPanel) adbDevicesPanel.style.display = 'flex';
            if (connectionText) connectionText.textContent = 'ADB';
            if (connectionDot) connectionDot.className = 'dot green';

            sendBtn.disabled = true;
            sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña ADB en curso...';
            stopBtn.style.display = 'flex';
            if (pauseBtn) pauseBtn.style.display = 'none';
            if (resumeBtn) resumeBtn.style.display = 'none';
            if (importBtn) importBtn.disabled = true;

            showAdbHud(msg.total);
            if (adbHudCount) adbHudCount.textContent = `${msg.progressIndex} / ${msg.total}`;
            if (adbHudStatus) adbHudStatus.textContent = 'Reconectado — campaña en curso';

            console.log(`Dashboard ADB reconstruido: campaña activa en ${msg.progressIndex}/${msg.total}`);
        });
    }

    if (selectChannel) {
        selectChannel.addEventListener('change', handleChannelChange);
        // Estado inicial
        handleChannelChange();
    }
    if (btnRefreshAdb) {
        btnRefreshAdb.addEventListener('click', () => {
            if (selectChannel && selectChannel.value === 'adb') {
                if (!adbWs || adbWs.readyState !== WebSocket.OPEN) connectAdbWs();
                else adbWs.send(JSON.stringify({ type: 'list_devices' }));
            }
        });
    }

    // --- Control del adb-bridge-server vía Native Messaging Host ---
    // La extensión no puede lanzar procesos por su cuenta (MV3 no da acceso a
    // child_process); el Native Messaging Host (native-launcher/) es el único
    // mecanismo soportado por Chrome para que un botón del dashboard controle
    // un programa local. Requiere haber corrido native-launcher/register.ps1
    // una vez en esta máquina.
    const ADB_LAUNCHER_HOST = 'com.anomalydevs.smspro.adblauncher';
    function callAdbLauncher(action, onResult) {
        if (!chrome.runtime.sendNativeMessage) {
            if (adbStatus) adbStatus.textContent = 'Native Messaging no disponible en este navegador.';
            return;
        }
        chrome.runtime.sendNativeMessage(ADB_LAUNCHER_HOST, { action }, (response) => {
            if (chrome.runtime.lastError) {
                const msg = chrome.runtime.lastError.message || '';
                // Chrome distingue dos fallos muy distintos bajo lastError.message:
                // "Specified native messaging host not found" → el manifest nunca se
                // registró en HKCU (falta correr register.ps1 la primera vez).
                // Cualquier otro texto ("Error when communicating...", "Native host
                // has exited") → el manifest SÍ existe y Chrome SÍ lanzó el .bat, pero
                // el proceso murió/no respondió (rutas de adb/node stancas tras mover
                // o reinstalarlos) — ahí el fix es "Reconfigurar rutas ADB", no un
                // registro desde cero.
                if (adbStatus) {
                    adbStatus.textContent = /not found/i.test(msg)
                        ? `Puente no instalado — corre native-launcher/register.ps1 (${msg})`
                        : `Puente registrado pero no respondió — probá "Reconfigurar rutas ADB" (por si adb/node se movieron) y si sigue igual, corre native-launcher/register.ps1 a mano (${msg})`;
                }
                return;
            }
            if (onResult) onResult(response);
        });
    }
    if (btnServerStart) {
        btnServerStart.addEventListener('click', () => {
            if (adbStatus) adbStatus.textContent = 'Iniciando puente ADB...';
            callAdbLauncher('start', (res) => {
                if (adbStatus) adbStatus.textContent = res.alreadyRunning ? 'El puente ya estaba corriendo.' : `Puente iniciado (pid ${res.pid}).`;
                setTimeout(() => { if (!adbWs || adbWs.readyState !== WebSocket.OPEN) connectAdbWs(); }, 1000);
            });
        });
    }
    if (btnServerStop) {
        btnServerStop.addEventListener('click', () => {
            if (adbStatus) adbStatus.textContent = 'Deteniendo puente ADB...';
            callAdbLauncher('stop', (res) => {
                if (adbStatus) adbStatus.textContent = res.stopped ? 'Puente detenido.' : 'El puente no estaba corriendo.';
                if (adbWs) { try { adbWs.close(); } catch (_) {} adbWs = null; }
                renderAdbDevices([]);
            });
        });
    }
    if (btnServerRestart) {
        btnServerRestart.addEventListener('click', () => {
            if (adbStatus) adbStatus.textContent = 'Reiniciando puente ADB...';
            callAdbLauncher('restart', (res) => {
                if (adbStatus) adbStatus.textContent = `Puente reiniciado (pid ${res.pid}).`;
                if (adbWs) { try { adbWs.close(); } catch (_) {} adbWs = null; }
                setTimeout(() => connectAdbWs(), 1500);
            });
        });
    }
    if (btnServerRegister) {
        btnServerRegister.addEventListener('click', () => {
            if (adbStatus) adbStatus.textContent = 'Re-detectando adb.exe/node.exe...';
            callAdbLauncher('register', (res) => {
                if (adbStatus) adbStatus.textContent = res.ok ? 'Rutas ADB reconfiguradas. Reinicia el puente para aplicarlas.' : `No se pudo reconfigurar: ${res.stderr || 'error desconocido'}`;
            });
        });
    }

    // --- Lógica de Conexión (Polling) ---
    function checkConnectionStatus() {
        chrome.runtime.sendMessage({ action: 'CHECK_CONNECTION' }, (response) => {
            if (chrome.runtime.lastError || !response || !response.isConnected) {
                connectionDot.className = 'dot red';
                connectionText.textContent = 'Offline';
                isGoogleMessagesOnline = false;
            } else {
                connectionDot.className = 'dot green';
                connectionText.textContent = 'Online';
                isGoogleMessagesOnline = true;
            }
            updateSendButtonState();
        });
    }

    // Chequear cada 3 segundos
    setInterval(checkConnectionStatus, 3000);
    checkConnectionStatus();

    // --- Estado de licencia (badge + gate) ---
    const LICENSE_REASON_TEXT = {
        no_license: 'No hay una licencia activada en este dispositivo.',
        not_found: 'La clave de licencia ingresada no existe.',
        pending: 'La licencia aún no ha iniciado su vigencia.',
        expired: 'La licencia ha vencido.',
        suspended: 'La licencia está suspendida.',
        device_not_registered: 'Este dispositivo no está registrado en la licencia.',
        device_limit_reached: 'Se alcanzó el cupo máximo de dispositivos de esta licencia.',
        offline_grace_expired: 'No se pudo validar la licencia con el servidor y venció el margen de 48h sin conexión.',
        network_error: 'No se pudo contactar al servidor de licencias.',
        invalid_state: 'Estado de licencia inconsistente. Vuelve a activarla.'
    };

    function renderLicenseBadge(result) {
        if (result.allowed) {
            const soonToExpire = typeof result.daysRemaining === 'number' && result.daysRemaining <= 30;
            licenseBadge.textContent = soonToExpire
                ? `🟡 ${result.companyName} — vence en ${result.daysRemaining} día(s)`
                : `🟢 ${result.companyName} — ${result.daysRemaining} día(s) restantes`;
        } else {
            licenseBadge.textContent = `🔴 ${LICENSE_REASON_TEXT[result.reason] || 'Licencia no válida.'}`;
        }

        if (licenseInfo) {
            licenseInfo.textContent = result.allowed
                ? `Empresa: ${result.companyName}\nVigente hasta: ${result.endDate}\nDías restantes: ${result.daysRemaining}`
                : LICENSE_REASON_TEXT[result.reason] || 'Licencia no válida.';
        }
    }

    function refreshLicenseStatus() {
        chrome.runtime.sendMessage({ action: 'LICENSE_STATUS' }, (result) => {
            if (chrome.runtime.lastError || !result) return;
            isLicenseAllowed = result.allowed === true;
            renderLicenseBadge(result);
            updateSendButtonState();

            if (!hasPromptedForLicense && result.reason === 'no_license') {
                hasPromptedForLicense = true;
                if (modalLicencia) modalLicencia.style.display = 'flex';
            }
        });
    }

    // Chequear cada 60 segundos (la revalidación real contra el backend la hace
    // el service worker cada 6h vía chrome.alarms; esto solo refresca la UI
    // con el último estado cacheado)
    setInterval(refreshLicenseStatus, 60000);
    refreshLicenseStatus();

    if (navLicencia && modalLicencia) {
        navLicencia.addEventListener('click', (e) => {
            e.preventDefault();
            modalLicencia.style.display = 'flex';
        });
    }
    if (licenseBadge && modalLicencia) {
        licenseBadge.addEventListener('click', () => {
            modalLicencia.style.display = 'flex';
        });
    }

    if (btnActivarLicencia) {
        btnActivarLicencia.addEventListener('click', () => {
            const key = (inputLicenseKey.value || '').trim();
            if (!key) {
                alert('Ingresa una clave de licencia.');
                return;
            }
            btnActivarLicencia.disabled = true;
            btnActivarLicencia.textContent = 'Activando...';
            chrome.runtime.sendMessage({ action: 'LICENSE_ACTIVATE', licenseKey: key }, (result) => {
                btnActivarLicencia.disabled = false;
                btnActivarLicencia.textContent = 'Activar';
                if (chrome.runtime.lastError || !result) {
                    alert('No se pudo contactar al servidor de licencias. Intenta de nuevo.');
                    return;
                }
                isLicenseAllowed = result.allowed === true;
                renderLicenseBadge(result);
                updateSendButtonState();
                if (result.allowed) {
                    alert(`Licencia activada: ${result.companyName}. Vigente hasta ${result.endDate}.`);
                    if (modalLicencia) modalLicencia.style.display = 'none';
                } else {
                    alert(LICENSE_REASON_TEXT[result.reason] || 'No se pudo activar la licencia.');
                }
            });
        });
    }

    // --- Reconstrucción de Estado al Re-abrir el Dashboard ---
    function resumeCampaignState() {
        chrome.runtime.sendMessage({ action: 'GET_CAMPAIGN_STATUS' }, (statusResponse) => {
            if (chrome.runtime.lastError || !statusResponse) return;

            if (statusResponse.isRunning) {
                // Campaña activa en segundo plano: reconstruir la UI
                chrome.storage.local.get(['currentCampaign'], (data) => {
                    if (!data.currentCampaign || !data.currentCampaign.contacts) return;

                    const campaign = data.currentCampaign;
                    contacts = campaign.contacts;
                    updateSendButtonState();
                    availableVariables = DataProcessor.getAvailableVariables(contacts);

                    // Restaurar mensaje
                    if (campaign.messageTemplate) {
                        messageText.value = campaign.messageTemplate;
                    }

                    // Restaurar variantes extra (la Variante 1 ya está en messageText)
                    if (variantesList && Array.isArray(campaign.messageVariants) && campaign.messageVariants.length > 1) {
                        variantesList.innerHTML = '';
                        campaign.messageVariants.slice(1).forEach(v => addVarianteRow(v));
                    }

                    // Restaurar tiempos configurados
                    if (campaign.config) {
                        if (inputDelayMin && campaign.config.delayMin != null) inputDelayMin.value = campaign.config.delayMin;
                        if (inputDelayMax && campaign.config.delayMax != null) inputDelayMax.value = campaign.config.delayMax;
                    }

                    // Restaurar imagen
                    if (campaign.imageDataUrl) {
                        currentImageDataUrl = campaign.imageDataUrl;
                        showImagePreview(currentImageDataUrl);
                    }
                    
                    // Restaurar promoción seleccionada
                    if (campaign.promoId && selectPromocion) {
                        selectPromocion.value = campaign.promoId;
                    }

                    // Restaurar badge de contactos
                    contactCountBadge.textContent = `${contacts.length} contactos cargados`;

                    // Restaurar variables detectadas
                    if (availableVariables.length > 0) {
                        variablesContainer.style.display = 'block';
                        variableTags.innerHTML = '';
                        availableVariables.forEach(variable => {
                            const tag = document.createElement('span');
                            tag.className = 'variable-tag';
                            tag.textContent = variable;
                            tag.onclick = () => insertVariable(variable);
                            variableTags.appendChild(tag);
                        });
                    }

                    // Renderizar la lista de contactos
                    renderContactList();

                    // Marcar filas ya procesadas como "Enviado" (todas hasta progressIndex)
                    const processedCount = statusResponse.progressIndex || 0;
                    for (let i = 0; i < processedCount; i++) {
                        const statusEl = document.getElementById(`status-row-${i}`);
                        if (statusEl) {
                            statusEl.value = 'Enviado ✅';
                            statusEl.style.color = '#22c55e';
                            statusEl.style.fontWeight = 'bold';
                        }
                    }

                    // Marcar la fila actual como "en proceso"
                    const currentEl = document.getElementById(`status-row-${processedCount}`);
                    if (currentEl) {
                        currentEl.value = 'Enviando... ⏳';
                        currentEl.style.color = '#eab308';
                    }

                    // Bloquear controles para no corromper la campaña activa
                    sendBtn.disabled = true;
                    sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña en curso...';
                    stopBtn.style.display = 'flex';
                    importBtn.disabled = true;
                    
                    if (statusResponse.isPaused) {
                        resumeBtn.style.display = 'flex';
                        pauseBtn.style.display = 'none';
                        sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="none" class="icon"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg> Campaña Pausada...';
                    } else {
                        pauseBtn.style.display = 'flex';
                        resumeBtn.style.display = 'none';
                    }
                    
                    console.log(`Dashboard reconstruido: Campaña activa en fila ${processedCount + 1}/${contacts.length}`);
                });
            }
        });
    }

    resumeCampaignState();
    // Sondea el puente ADB por si hay una campaña ADB corriendo en segundo plano
    // (el server sigue viva aunque este popup se haya cerrado/recargado). Si el
    // puente no está corriendo, connectAdbWs() falla en silencio (onerror) — no
    // afecta al usuario que solo usa el canal web.
    if (!adbWs) connectAdbWs();
    restoreDraft();

    // --- Manejo de Modales ---
    function openModal(modal) {
        modal.style.display = 'flex';
    }

    function closeModal(modal) {
        modal.style.display = 'none';
    }

    if (btnProgramar && modalProgramar) {
        btnProgramar.addEventListener('click', () => openModal(modalProgramar));
    }
    navHistorial.addEventListener('click', (e) => {
        e.preventDefault();

        chrome.storage.local.get(['history'], (data) => {
            const historyList = document.getElementById('historial-lista');
            historyList.innerHTML = '';

            if (data.history && data.history.length > 0) {
                data.history.forEach((item, idx) => {
                    const li = document.createElement('li');
                    li.style.padding = '15px';
                    li.style.marginBottom = '10px';
                    li.style.backgroundColor = 'var(--bg-tertiary)';
                    li.style.borderRadius = 'var(--radius-md)';
                    li.style.border = '1px solid var(--border-color)';
                    li.style.display = 'flex';
                    li.style.flexDirection = 'column';
                    li.style.gap = '10px';

                    const headerDiv = document.createElement('div');
                    headerDiv.style.display = 'flex';
                    headerDiv.style.justifyContent = 'space-between';
                    headerDiv.style.alignItems = 'center';

                    let statusIcon = '✅';
                    let statusColor = '#22c55e';
                    if (item.status === 'Detenida') {
                        statusIcon = '⛔';
                        statusColor = '#eab308';
                    }

                    headerDiv.innerHTML = `
                        <div>
                            <div style="font-weight: 600; font-size: 1.05rem; color: var(--text-main); margin-bottom: 4px;">
                                ${new Date(item.date).toLocaleString()}
                            </div>
                            <div style="font-size: 0.85rem; color: var(--text-muted);">
                                👥 ${item.contactCount} contactos procesados
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 6px; background: rgba(0,0,0,0.2); padding: 4px 10px; border-radius: 20px; font-size: 0.85rem; font-weight: bold; color: ${statusColor}; border: 1px solid ${statusColor}40;">
                            ${statusIcon} ${item.status}
                        </div>
                    `;
                    li.appendChild(headerDiv);

                    // Botones de descarga si hay resultados detallados
                    if (item.contactResults && item.contactResults.length > 0) {
                        const actionsDiv = document.createElement('div');
                        actionsDiv.style.display = 'flex';
                        actionsDiv.style.justifyContent = 'flex-end';
                        actionsDiv.style.gap = '8px';
                        actionsDiv.style.marginTop = '5px';
                        actionsDiv.style.paddingTop = '10px';
                        actionsDiv.style.borderTop = '1px dashed var(--border-color)';

                        const btnCSV = document.createElement('button');
                        btnCSV.className = 'btn btn-muted';
                        btnCSV.style.padding = '6px 12px';
                        btnCSV.style.fontSize = '0.8rem';
                        btnCSV.innerHTML = '📄 CSV';
                        btnCSV.addEventListener('click', () => exportHistoryAsCSV(item));

                        const btnXLS = document.createElement('button');
                        btnXLS.className = 'btn btn-muted';
                        btnXLS.style.padding = '6px 12px';
                        btnXLS.style.fontSize = '0.8rem';
                        btnXLS.innerHTML = '📊 XLS';
                        btnXLS.addEventListener('click', () => exportHistoryAsXLS(item));

                        actionsDiv.appendChild(btnCSV);
                        actionsDiv.appendChild(btnXLS);

                        if (item.status === 'Detenida') {
                            const pending = computePendingContacts(item.contacts || [], item.contactResults || []);
                            if (pending.length > 0) {
                                const btnRetomar = document.createElement('button');
                                btnRetomar.className = 'btn btn-accent';
                                btnRetomar.style.padding = '6px 12px';
                                btnRetomar.style.fontSize = '0.8rem';
                                btnRetomar.innerHTML = `▶️ Retomar (${pending.length})`;
                                btnRetomar.addEventListener('click', () => {
                                    closeModal(modalHistorial);
                                    resumeCampaignFromHistory(item);
                                });
                                actionsDiv.appendChild(btnRetomar);
                            }
                        }

                        li.appendChild(actionsDiv);
                    }

                    historyList.appendChild(li);
                });
            } else {
                historyList.innerHTML = '<li style="padding: 15px; text-align: center; color: var(--text-muted);">Aún no hay campañas guardadas en el historial.</li>';
            }
        });
        openModal(modalHistorial);
    });

    // Soporte modal
    if (navSoporte && modalSoporte) {
        navSoporte.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(modalSoporte);
        });
    }

    // Ayuda → abre el modal de Soporte
    const btnAyuda = document.getElementById('btn-ayuda');
    if (btnAyuda && modalSoporte) {
        btnAyuda.addEventListener('click', () => {
            openModal(modalSoporte);
        });
    }

    btnCerrarModals.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal-overlay');
            closeModal(modal);
        });
    });

    const btnBorrarHistorial = document.getElementById('btn-borrar-historial');
    if (btnBorrarHistorial) {
        btnBorrarHistorial.addEventListener('click', () => {
            if (confirm('¿Estás seguro de que deseas borrar TODO el historial? Esta acción no se puede deshacer.')) {
                chrome.storage.local.remove('history', () => {
                    const historyList = document.getElementById('historial-lista');
                    if (historyList) {
                        historyList.innerHTML = '<li style="padding: 15px; text-align: center; color: var(--text-muted);">El historial ha sido borrado.</li>';
                    }
                    alert('Historial borrado exitosamente.');
                });
            }
        });
    }

    const btnConfirmarProg = document.getElementById('btn-confirmar-programacion');
    if (btnConfirmarProg) {
        btnConfirmarProg.addEventListener('click', () => {
            const fechaInput = document.getElementById('fecha-programada').value;
            if (!fechaInput) {
                alert('Por favor selecciona una fecha y hora.');
                return;
            }
            if (contacts.length === 0) {
                alert('Carga contactos antes de programar.');
                return;
            }

            const programadaDate = new Date(fechaInput);
            const now = new Date();
            if (programadaDate <= now) {
                alert('La fecha debe ser en el futuro.');
                return;
            }

            const msDelay = programadaDate.getTime() - now.getTime();
            const minutesDelay = msDelay / 60000;

            const text = messageText.value;
            const campaignData = getCampaignConfig();
            campaignData.messageTemplate = text;
            campaignData.messageVariants = collectMessageVariants();
            campaignData.contacts = contacts;
            campaignData.timestamp = programadaDate.getTime();
            campaignData.status = 'Programada';

            chrome.storage.local.set({ currentCampaign: campaignData }, () => {
                chrome.runtime.sendMessage({ action: 'SCHEDULE_CAMPAIGN', delayInMinutes: minutesDelay }, (res) => {
                    alert(`¡Campaña programada para: ${programadaDate.toLocaleString()}!`);
                    closeModal(modalProgramar);
                });
            });
        });
    }

    // --- Lógica de IMPORTACIÓN ---
    importBtn.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        try {
            importBtn.disabled = true;
            importBtn.innerHTML = '<span>⏳</span> Procesando...';

            contacts = await DataProcessor.readContacts(file);
            updateSendButtonState();
            availableVariables = DataProcessor.getAvailableVariables(contacts);

            updateUIWithContacts();
            saveDraft();
        } catch (error) {
            alert(error);
        } finally {
            importBtn.disabled = false;
            importBtn.innerHTML = '<span class="icon">📞</span> Importar contactos';
        }
    });

    function updateUIWithContacts() {
        contactCountBadge.textContent = `${contacts.length} contactos cargados`;

        if (availableVariables.length > 0) {
            variablesContainer.style.display = 'block';
            variableTags.innerHTML = '';

            availableVariables.forEach(variable => {
                const tag = document.createElement('span');
                tag.className = 'variable-tag';
                tag.textContent = variable;
                tag.onclick = () => insertVariable(variable);
                variableTags.appendChild(tag);
            });
        }

        // Re-evaluar conexión antes de habilitar
        checkConnectionStatus();
        renderContactList();
        updatePreview();
    }

    function renderContactList() {
        const listContainer = document.getElementById('contacts-list');
        if (!listContainer) return;

        listContainer.innerHTML = '';

        if (contacts.length === 0) {
            listContainer.innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 20px;">No hay contactos cargados. Importa un archivo o añade manualmente.</div>';
            return;
        }

        const fragment = document.createDocumentFragment();

        // 🛡️ ANTI-FREEZE LIMIT: Renderizar máximo 500 filas en el DOM.
        // Evita que la interfaz se congele si el Excel tiene miles de filas vacías.
        const maxRender = Math.min(contacts.length, 500);

        // Campos del formato base (ver CAMPAIGN_COLUMNS en dataProcessor.js) agrupados
        // en 2 líneas legibles en vez de 9 cajitas de texto de ~78px cada una —
        // nombre/apellido/modelo se cortaban a 10-12 caracteres y parecían vacíos.
        for (let i = 0; i < maxRender; i++) {
            const contact = contacts[i];

            const row = document.createElement('div');
            row.className = 'contact-row-v2';

            const header = document.createElement('div');
            header.className = 'contact-row-header';

            const numLabel = document.createElement('span');
            numLabel.className = 'contact-row-num';
            numLabel.textContent = `${i + 1}.`;
            header.appendChild(numLabel);

            const nameSpan = document.createElement('span');
            nameSpan.className = 'contact-row-name';
            const nombreCompleto = [contact['NOMBRE CLIENTE'], contact['APELLIDO CLIENTE']].filter(Boolean).join(' ');
            nameSpan.textContent = nombreCompleto || '(sin nombre)';
            nameSpan.title = nombreCompleto;
            header.appendChild(nameSpan);

            const phoneSpan = document.createElement('span');
            phoneSpan.className = 'contact-row-phone';
            phoneSpan.textContent = `☎ ${contact['TELEFONO 1'] || '-'}`;
            header.appendChild(phoneSpan);

            row.appendChild(header);

            const details = document.createElement('div');
            details.className = 'contact-row-details';

            const DETAIL_FIELDS = [
                ['Contrato', contact['Nº CONTRATO']],
                ['Cédula', contact['CÉDULA']],
                ['Modelo', contact['MODELO']],
                ['Mora', contact['VALOR EN MORA'] ? `$${contact['VALOR EN MORA']}` : ''],
                ['Días', contact['DIAS IMPAGO']]
            ];
            DETAIL_FIELDS.forEach(([label, value]) => {
                if (!value) return;
                const field = document.createElement('span');
                field.className = 'contact-row-field';
                field.title = String(value);
                const b = document.createElement('b');
                b.textContent = `${label}: `;
                field.appendChild(b);
                field.appendChild(document.createTextNode(value));
                details.appendChild(field);
            });

            // Estado (input por compatibilidad con el resto del código, que hace
            // document.getElementById('status-row-N').value = ... en muchos lugares)
            const statusInput = document.createElement('input');
            statusInput.type = 'text';
            statusInput.className = 'contact-row-input contact-row-status';
            statusInput.id = `status-row-${i}`;
            statusInput.value = 'Estado: Pendiente ⏳';
            statusInput.readOnly = true;
            statusInput.style.color = '#a3a3a3'; // Mutered por default
            statusInput.style.fontWeight = 'bold';
            details.appendChild(statusInput);

            row.appendChild(details);
            fragment.appendChild(row);
        }

        listContainer.appendChild(fragment);

        // Mostrar indicador de si hay más escondidos
        if (contacts.length > 500) {
            const divInfo = document.createElement('div');
            divInfo.style.textAlign = 'center';
            divInfo.style.padding = '15px';
            divInfo.style.color = '#38bdf8';
            divInfo.style.fontWeight = 'bold';
            divInfo.innerHTML = `⚠️ Para mantener la rapidez de la ventana, solo se muestran las primeras 500 filas.<br>La campaña de todas formas enviará los ${contacts.length} contactos.`;
            listContainer.appendChild(divInfo);
        }
    }

    function insertVariable(variable) {
        const start = messageText.selectionStart;
        const end = messageText.selectionEnd;
        const text = messageText.value;
        const before = text.substring(0, start);
        const after = text.substring(end, text.length);

        messageText.value = before + `{{${variable}}}` + after;
        messageText.focus();
        messageText.selectionStart = messageText.selectionEnd = start + variable.length + 4;
        updatePreview();
    }

    // --- Vista Previa Dinámica ---
    function updatePreview() {
        if (contacts.length === 0 || !messageText.value) return;

        // Mostrar preview del primer contacto
        const firstContact = contacts[0];
        let previewText = Utils.personalizeMessage(messageText.value, firstContact);
        previewText = Utils.parseSpinSyntax(previewText);

        // Podríamos añadir un elemento de preview en el HTML si quisiéramos
        console.log('Vista previa (1er contacto):', previewText);
    }

    messageText.addEventListener('input', updatePreview);
    messageText.addEventListener('input', scheduleDraftSave);

    // --- Variantes de mensaje (pool) ---
    /**
     * Añade una fila de variante adicional (textarea + botón eliminar).
     * La Variante 1 es siempre el textarea principal #message-text.
     */
    function addVarianteRow(value = '') {
        if (!variantesList) return null;
        const row = document.createElement('div');
        row.className = 'variante-row';
        row.style.cssText = 'display: flex; gap: 8px; align-items: flex-start;';

        const ta = document.createElement('textarea');
        ta.className = 'variante-extra';
        ta.placeholder = 'Variante adicional del mensaje...';
        ta.style.cssText = 'flex: 1; min-height: 70px;';
        ta.value = value;

        const btnDel = document.createElement('button');
        btnDel.type = 'button';
        btnDel.className = 'btn btn-danger-outline';
        btnDel.textContent = '✕';
        btnDel.title = 'Eliminar variante';
        btnDel.style.cssText = 'padding: 4px 10px; min-height: 34px; flex-shrink: 0;';
        btnDel.addEventListener('click', () => row.remove());

        row.appendChild(ta);
        row.appendChild(btnDel);
        variantesList.appendChild(row);
        return ta;
    }

    /**
     * Recolecta todas las variantes no vacías: [Variante 1 (principal), ...extras].
     */
    function collectMessageVariants() {
        const all = [];
        const main = messageText.value.trim();
        if (main) all.push(main);
        document.querySelectorAll('.variante-extra').forEach(t => {
            const v = t.value.trim();
            if (v) all.push(v);
        });
        return all;
    }

    if (btnAddVariante) {
        btnAddVariante.addEventListener('click', () => {
            const ta = addVarianteRow('');
            if (ta) ta.focus();
        });
    }

    /**
     * Despacha el arranque de una campaña por el canal indicado. Compartido
     * entre "Enviar ahora" (campaignData armado desde el formulario) y
     * "Retomar envío" (campaignData armado desde un item del historial, con
     * los contactos pendientes en vez de la lista completa) para no duplicar
     * el branching de canal en dos lugares.
     */
    function launchCampaign(campaignData, channel) {
        if (!isLicenseAllowed) {
            alert('No se pudo iniciar la campaña: licencia no válida.');
            if (modalLicencia) modalLicencia.style.display = 'flex';
            return;
        }

        console.log('Enviando datos de campaña:', campaignData);

        if (channel === 'adb') {
            // Canal ADB: enviar vía WebSocket al puente local
            const ws = connectAdbWs();
            if (!ws || ws.readyState !== WebSocket.OPEN) {
                alert('Puente ADB no conectado. Ejecuta `node adb-bridge-server/server.js` y verifica `ws://localhost:8765`.');
                return;
            }
            if (adbDevices.length === 0) {
                alert('Sin dispositivos ADB conectados — conecta un teléfono por USB y autoriza la depuración.');
                return;
            }
            chrome.storage.local.set({ currentCampaign: campaignData });
            Analytics.track('campaign_start', { contactCount: campaignData.contacts.length, channel: 'adb' });
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña ADB en curso...';
            stopBtn.style.display = 'flex';
            pauseBtn.style.display = 'none';
            resumeBtn.style.display = 'none';
            showAdbHud(campaignData.contacts.length);
            ws.send(JSON.stringify({ type: 'start', contacts: campaignData.contacts, template: campaignData.messageTemplate, messageVariants: campaignData.messageVariants, config: campaignData.config, imageDataUrl: campaignData.imageDataUrl }));
            alert(`Campaña ADB iniciada para ${campaignData.contacts.length} contactos en ${adbDevices.length} dispositivo(s).`);
            return;
        }

        // Canal Web: flujo original vía background
        chrome.storage.local.set({ currentCampaign: campaignData }, () => {
            chrome.runtime.sendMessage({ action: 'START_CAMPAIGN' }, (response) => {
                if (response && response.status === 'STARTED') {
                    Analytics.track('campaign_start', { contactCount: campaignData.contacts.length, channel: 'web' });
                    sendBtn.disabled = true;
                    sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña en curso...';
                    stopBtn.style.display = 'flex';
                    pauseBtn.style.display = 'flex';
                    resumeBtn.style.display = 'none';
                    alert(`Campaña iniciada para ${campaignData.contacts.length} contactos. \n\nAbre la pestaña de Google Messages para ver el progreso.`);
                } else if (response && response.status === 'LICENSE_BLOCKED') {
                    alert(`No se pudo iniciar la campaña: ${LICENSE_REASON_TEXT[response.reason] || 'licencia no válida.'}`);
                    isLicenseAllowed = false;
                    updateSendButtonState();
                    if (modalLicencia) modalLicencia.style.display = 'flex';
                } else {
                    alert('Error al iniciar la campaña. Revisa la consola.');
                }
            });
        });
    }

    /**
     * Retoma una campaña "Detenida" del historial: recalcula los contactos
     * pendientes (nunca alcanzados + con error) contra la definición original
     * guardada, y la relanza por el mismo canal — sin volver a filtrar/subir
     * el Excel.
     */
    function resumeCampaignFromHistory(historyItem) {
        const pending = computePendingContacts(historyItem.contacts || [], historyItem.contactResults || []);
        if (pending.length === 0) {
            alert('No hay contactos pendientes por reintentar en esta campaña.');
            return;
        }
        launchCampaign({
            contacts: pending,
            messageTemplate: historyItem.messageTemplate || '',
            messageVariants: historyItem.messageVariants || [],
            config: historyItem.config || {},
            imageDataUrl: historyItem.imageDataUrl || ''
        }, historyItem.channel || 'web');
    }

    // --- Evento de ENVÍO ---
    sendBtn.addEventListener('click', () => {
        const text = messageText.value;
        if (!text) {
            alert('Por favor, escribe un mensaje.');
            return;
        }

        if (contacts.length === 0) {
            alert('Por favor, importa una lista de contactos primero.');
            return;
        }

        const campaignData = getCampaignConfig();
        campaignData.messageTemplate = text;
        campaignData.messageVariants = collectMessageVariants();
        campaignData.contacts = contacts;
        campaignData.promoId = selectPromocion ? selectPromocion.value : '';

        const selectedChannel = selectChannel ? selectChannel.value : 'web';
        launchCampaign(campaignData, selectedChannel);
    });

    // --- Evento de DETENER CAMPAÑA ---
    stopBtn.addEventListener('click', () => {
        if (stopBtn.disabled) return; // evita doble-clic durante "Deteniendo..."
        stopBtn.disabled = true;
        stopBtn.style.opacity = '0.7';
        stopBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/></svg> Deteniendo...';

        const channel = selectChannel ? selectChannel.value : 'web';
        if (channel === 'adb') {
            // Canal ADB: detener vía bridge (no vía background)
            try {
                if (adbWs && adbWs.readyState === WebSocket.OPEN) {
                    adbWs.send(JSON.stringify({ type: 'stop' }));
                }
            } catch (e) { console.warn('[STOP ADB] fallo al enviar stop', e); }
            // El bridge responde 'stopping' de inmediato, pero el motor solo corta
            // entre contactos — terminar el envío en curso (navegar, escribir,
            // reintentos de uiautomator) puede tardar bastantes segundos. El
            // resumen real (con los resultados acumulados hasta el corte) llega
            // recién en el 'done'/'stopped' de verdad — nunca lo fabricamos acá,
            // porque hacerlo antes de tiempo mostraba "0 enviados" pese a que sí
            // se habían mandado mensajes.
            // Único fallback: si ni el bridge ni su propio timeout interno
            // responden en 40s (conexión caída), desbloquear el botón de
            // Detener para reintentar — sin tocar history/campaignFinished.
            setTimeout(() => {
                if (stopBtn.style.display !== 'none' && stopBtn.disabled) {
                    console.warn('[STOP ADB] El puente no confirmó en 40s — desbloqueando "Detener" para reintentar');
                    stopBtn.disabled = false;
                    stopBtn.style.opacity = '';
                    if (adbStatus) adbStatus.textContent = 'Sin confirmación del puente — probá "Detener Campaña" de nuevo o revisá que siga corriendo';
                }
            }, 40000);
            return;
        }

        chrome.runtime.sendMessage({ action: 'STOP_CAMPAIGN' }, (response) => {
            if (chrome.runtime.lastError) {
                console.warn('[STOP] SW no respondió al instante, pero señal enviada.', chrome.runtime.lastError.message);
            }
            // UI se restaura vía listener `campaignFinished` (storage) cuando
            // el loop de background realmente finaliza.
        });

        // Fallback: si `campaignFinished` nunca llega (SW muerto sin finalizar),
        // forzar reset a los 30s para no dejar UI bloqueada.
        setTimeout(() => {
            if (stopBtn.style.display !== 'none' && stopBtn.disabled) {
                console.warn('[STOP] Fallback timeout 30s — forzando reset UI');
                chrome.storage.local.set({ campaignFinished: true });
            }
        }, 30000);
    });

    if (pauseBtn) {
        pauseBtn.addEventListener('click', () => {
            chrome.runtime.sendMessage({ action: 'PAUSE_CAMPAIGN' }, (res) => {
                if (res && res.status === 'PAUSED') {
                    pauseBtn.style.display = 'none';
                    resumeBtn.style.display = 'flex';
                    sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="none" class="icon"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg> Campaña Pausada...';
                }
            });
        });
    }

    if (resumeBtn) {
        resumeBtn.addEventListener('click', () => {
            const text = messageText.value;
            const promoId = selectPromocion ? selectPromocion.value : '';
            const variants = collectMessageVariants();

            // Actualizar el storage local en caso de que el usuario haya editado el texto estando en pausa
            chrome.storage.local.get(['currentCampaign'], (data) => {
                if (data.currentCampaign) {
                    data.currentCampaign.messageTemplate = text;
                    data.currentCampaign.messageVariants = variants;
                    data.currentCampaign.imageDataUrl = currentImageDataUrl;
                    data.currentCampaign.promoId = promoId;
                    chrome.storage.local.set({ currentCampaign: data.currentCampaign }, () => {
                        chrome.runtime.sendMessage({
                            action: 'RESUME_CAMPAIGN',
                            messageTemplate: text,
                            messageVariants: variants,
                            imageDataUrl: currentImageDataUrl,
                            promoId: promoId
                        }, (res) => {
                            if (res && res.status === 'RESUMED') {
                                resumeBtn.style.display = 'none';
                                pauseBtn.style.display = 'flex';
                                sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña en curso...';
                            }
                        });
                    });
                } else {
                    chrome.runtime.sendMessage({ action: 'RESUME_CAMPAIGN' }, (res) => {
                        if (res && res.status === 'RESUMED') {
                            resumeBtn.style.display = 'none';
                            pauseBtn.style.display = 'flex';
                            sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Campaña en curso...';
                        }
                    });
                }
            });
        });
    }

    // Resetear formulario
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            if (confirm('¿Seguro que quieres borrar toda la configuración?')) {
                messageText.value = '';
                if (variantesList) variantesList.innerHTML = '';
                contacts = [];
                updateSendButtonState();
                availableVariables = [];
                contactCountBadge.textContent = '0 contactos cargados';
                variablesContainer.style.display = 'none';
                fileInput.value = '';

                const listContainer = document.getElementById('contacts-list');
                if (listContainer) {
                    listContainer.innerHTML = '<div style="text-align: center; color: var(--text-muted); padding: 20px;">No hay contactos cargados.</div>';
                }
            }
        });
    }

    function getCampaignConfig() {
        // Tiempos aleatorios: validar 2 <= min <= max
        let dMin = parseInt(inputDelayMin ? inputDelayMin.value : '', 10);
        let dMax = parseInt(inputDelayMax ? inputDelayMax.value : '', 10);
        if (!Number.isFinite(dMin) || dMin < 2) dMin = 2;
        if (!Number.isFinite(dMax) || dMax < dMin) dMax = dMin;

        return {
            config: {
                duplicateRemoval: document.getElementById('chk-dedup') ? document.getElementById('chk-dedup').checked : true,
                randomizeMessages: document.getElementById('chk-random') ? document.getElementById('chk-random').checked : true,
                delayMin: dMin,
                delayMax: dMax
            },
            imageDataUrl: currentImageDataUrl
        };
    }

    // --- Funciones de Exportación de Historial ---
    // classifyResultStatus y computePendingContacts viven en campaignEngine.js
    // (cargado antes que este script en dashboard.html) — son globales, compartidas
    // con background.js (que las trae vía importScripts) para no duplicar la
    // lógica de qué cuenta como éxito/error entre los dos canales.

    /**
     * Construye filas planas a partir de los contactResults de una campaña.
     * Cada fila contiene: Teléfono, Estado, y todos los campos extra del contacto.
     */
    function buildExportRows(historyItem) {
        const results = historyItem.contactResults || [];
        if (results.length === 0) return { headers: [], rows: [] };

        // Extraer las columnas extra del primer contacto con datos
        const sampleData = results.find(r => r.contactData && Object.keys(r.contactData).length > 0);
        const extraKeysRaw = sampleData ? Object.keys(sampleData.contactData) : [];

        const hasNombre = extraKeysRaw.includes('Nombre');
        const hasApellido = extraKeysRaw.includes('Apellido');
        
        let extraKeys = [];
        if (hasNombre || hasApellido) {
            extraKeys.push('Nombre');
        }
        extraKeysRaw.forEach(k => {
            if (k !== 'Nombre' && k !== 'Apellido') {
                extraKeys.push(k);
            }
        });

        const headers = ['Teléfono', 'Estado', ...extraKeys];
        const rows = results.map(r => {
            const baseRow = [r.phone || '', r.status || ''];
            const extraValues = extraKeys.map(key => {
                if (key === 'Nombre') {
                    const n = r.contactData ? (r.contactData['Nombre'] || '') : '';
                    const a = r.contactData ? (r.contactData['Apellido'] || '') : '';
                    return `${n} ${a}`.trim();
                } else {
                    return (r.contactData && r.contactData[key] != null) ? String(r.contactData[key]) : '';
                }
            });
            return [...baseRow, ...extraValues];
        });

        return { headers, rows };
    }

    function exportHistoryAsCSV(historyItem) {
        const { headers, rows } = buildExportRows(historyItem);
        if (headers.length === 0) {
            alert('No hay datos detallados para exportar.');
            return;
        }

        const escapeCsvField = (field) => {
            const str = String(field);
            if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return `"${str.replace(/"/g, '""')}"`;
            }
            return str;
        };

        const csvLines = [
            headers.map(escapeCsvField).join(','),
            ...rows.map(row => row.map(cell => escapeCsvField(String(cell).replace(/🟢|🔵|❌|✅|⏭️|⏳/g, '').trim())).join(','))
        ];
        const csvContent = csvLines.join('\n');
        const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' }); // BOM para Excel

        const dateStr = new Date(historyItem.date).toISOString().slice(0, 10);
        triggerDownload(blob, `campaña_${dateStr}.csv`);
    }

    function exportHistoryAsXLS(historyItem) {
        const { headers: baseHeaders, rows: baseRows } = buildExportRows(historyItem);
        if (baseHeaders.length === 0) {
            alert('No hay datos detallados para exportar.');
            return;
        }

        // Insertar columna 'Tipo' (RCS / SMS / Error) en posición 2 (después de Estado)
        const headers = ['Teléfono', 'Tipo', 'Estado', ...baseHeaders.slice(2)];

        const rows = baseRows.map(row => {
            const rawStatus = String(row[1] || '');
            const tipo = classifyResultStatus(rawStatus);

            // Limpiar emojis del campo Estado usando regex de rangos Unicode
            const cleanStatus = rawStatus
                .replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '') // Surrogate pairs (emojis)
                .replace(/[\u2600-\u27BF]/g, '')                 // Símbolos varios
                .replace(/[\u23E0-\u23FF]/g, '')                 // Flechas y relojes
                .trim();

            return [row[0], tipo, cleanStatus, ...row.slice(2)];
        });

        let tableHtml = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        tableHtml += '<head><meta charset="utf-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Resultados RCS PRO</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>';
        tableHtml += '<body><table border="1" style="border-collapse:collapse; font-family:Calibri,Arial,sans-serif; font-size:12px;">';

        // Fila de título
        const dateStr = new Date(historyItem.date).toLocaleString('es-ES');
        tableHtml += `<tr><td colspan="${headers.length}" style="background-color:#1e293b; color:#ffffff; font-size:14px; font-weight:bold; padding:10px; text-align:center;">RCS PRO &mdash; Reporte de Campa&ntilde;a &mdash; ${dateStr}</td></tr>`;

        // Cabeceras
        tableHtml += '<tr>';
        headers.forEach(h => {
            tableHtml += `<th style="background-color:#334155; color:#ffffff; font-weight:bold; padding:8px 12px; text-align:left; border:1px solid #475569;">${h}</th>`;
        });
        tableHtml += '</tr>';

        // Filas de datos
        rows.forEach((row, rowIdx) => {
            const evenRow = rowIdx % 2 === 0;
            tableHtml += '<tr>';
            row.forEach((cell, idx) => {
                let cellValue = String(cell);
                let bgColor = evenRow ? '#f8fafc' : '#ffffff';
                let color = '#1e293b';
                let fontWeight = 'normal';

                // Columna Tipo (index 1) recibe el color semántico
                if (idx === 1) {
                    switch(cellValue) {
                        case 'RCS':
                            bgColor = '#dcfce7'; color = '#166534'; fontWeight = 'bold'; break;
                        case 'SMS':
                            bgColor = '#dbeafe'; color = '#1e40af'; fontWeight = 'bold'; break;
                        case 'Duplicado':
                        case 'Omitido':
                            bgColor = '#fef9c3'; color = '#92400e'; break;
                        default:
                            bgColor = '#fee2e2'; color = '#991b1b'; fontWeight = 'bold'; break;
                    }
                }

                tableHtml += `<td style="background-color:${bgColor}; color:${color}; font-weight:${fontWeight}; padding:6px 10px; border:1px solid #e2e8f0;">${cellValue}</td>`;
            });
            tableHtml += '</tr>';
        });

        // Fila de resumen final
        const rcsTotal = rows.filter(r => r[1] === 'RCS').length;
        const smsTotal = rows.filter(r => r[1] === 'SMS').length;
        const errTotal = rows.filter(r => r[1] !== 'RCS' && r[1] !== 'SMS' && r[1] !== 'Duplicado' && r[1] !== 'Omitido').length;
        tableHtml += `<tr>
            <td colspan="${headers.length}" style="background-color:#0f172a; color:#94a3b8; padding:8px 12px; border-top:2px solid #334155; font-size:11px;">
                Total: ${rows.length} contactos &nbsp;|&nbsp;
                <span style="color:#22c55e; font-weight:bold;">RCS: ${rcsTotal}</span> &nbsp;|&nbsp;
                <span style="color:#3b82f6; font-weight:bold;">SMS: ${smsTotal}</span> &nbsp;|&nbsp;
                <span style="color:#ef4444; font-weight:bold;">Errores/Omitidos: ${errTotal}</span>
            </td>
        </tr>`;

        tableHtml += '</table></body></html>';

        const blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel' });
        const fileDateStr = new Date(historyItem.date).toISOString().slice(0, 10);
        triggerDownload(blob, `RCS_PRO_Campana_${fileDateStr}.xls`);
    }

    function triggerDownload(blob, filename) {
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a');
        anchor.href = url;
        anchor.download = filename;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        URL.revokeObjectURL(url);
    }

    // --- Listener de progreso en tiempo real ---
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'UPDATE_STATUS') {
            const statusEl = document.getElementById(`status-row-${request.index}`);
            if (statusEl) {
                statusEl.value = request.status;
                if (request.color) {
                    statusEl.style.color = request.color;
                    statusEl.style.borderColor = request.color;
                    setTimeout(() => { statusEl.style.borderColor = 'transparent'; }, 800);
                }
            }
        }
    });

    // --- Detectar fin de campaña para restablecer UI ---
    chrome.storage.onChanged.addListener((changes) => {
        if (changes.campaignFinished && changes.campaignFinished.newValue === true) {
            // Restaurar estado de los botones cuando la campaña finaliza o se detiene verdaderamente
            stopBtn.style.display = 'none';
            stopBtn.disabled = false;
            stopBtn.style.opacity = '';
            stopBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/></svg> Detener Campaña';

            if (pauseBtn) pauseBtn.style.display = 'none';
            if (resumeBtn) resumeBtn.style.display = 'none';

            updateSendButtonState();
            sendBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Enviar ahora';
            chrome.storage.local.remove('campaignFinished');

            // Mostrar resumen
            chrome.storage.local.get(['history'], (data) => {
                if (data.history && data.history.length > 0) {
                    const lastCampaign = data.history[0];
                    let rcsCount = 0;
                    let smsCount = 0;
                    let errorCount = 0;

                    if (lastCampaign.contactResults) {
                        lastCampaign.contactResults.forEach(r => {
                            const tipo = classifyResultStatus(r.status);
                            if (tipo === 'RCS') rcsCount++;
                            else if (tipo === 'SMS') smsCount++;
                            else errorCount++; // Duplicados, Errores, Omitidos
                        });
                    }

                    Analytics.track('campaign_complete', {
                        contactCount: lastCampaign.contactCount,
                        status: lastCampaign.status,
                        rcsCount,
                        smsCount,
                        errorCount
                    });

                    const modalResumen = document.getElementById('modal-resumen');
                    if (modalResumen) {
                        document.getElementById('resumen-rcs').textContent = rcsCount;
                        document.getElementById('resumen-sms').textContent = smsCount;
                        document.getElementById('resumen-errores').textContent = errorCount;

                        const titulo = document.getElementById('resumen-titulo');
                        if (titulo) {
                            titulo.textContent = lastCampaign.status === 'Detenida' ? 'Campaña Detenida' : 'Campaña Finalizada';
                        }

                        const btnRetomar = document.getElementById('btn-resumen-retomar');
                        if (btnRetomar) {
                            const pending = lastCampaign.status === 'Detenida'
                                ? computePendingContacts(lastCampaign.contacts || [], lastCampaign.contactResults || [])
                                : [];
                            if (pending.length > 0) {
                                btnRetomar.style.display = '';
                                btnRetomar.textContent = `▶️ Retomar envío (${pending.length} pendientes)`;
                                btnRetomar.onclick = () => {
                                    closeModal(modalResumen);
                                    resumeCampaignFromHistory(lastCampaign);
                                };
                            } else {
                                btnRetomar.style.display = 'none';
                                btnRetomar.onclick = null;
                            }
                        }

                        openModal(modalResumen);
                    }
                }
            });
        }
    });

    const btnCerrarResumen = document.getElementById('btn-cerrar-resumen');
    if (btnCerrarResumen) {
        btnCerrarResumen.addEventListener('click', () => {
            const modalResumen = document.getElementById('modal-resumen');
            if (modalResumen) closeModal(modalResumen);
        });
    }

    const btnResumenCSV = document.getElementById('btn-resumen-csv');
    const btnResumenXLS = document.getElementById('btn-resumen-xls');

    function getLastCampaignAndExport(exportFn) {
        chrome.storage.local.get(['history'], (data) => {
            if (data.history && data.history.length > 0) {
                exportFn(data.history[0]);
            } else {
                alert('No hay datos de campaña disponibles para exportar.');
            }
        });
    }

    if (btnResumenCSV) {
        btnResumenCSV.addEventListener('click', () => getLastCampaignAndExport(exportHistoryAsCSV));
    }
    if (btnResumenXLS) {
        btnResumenXLS.addEventListener('click', () => getLastCampaignAndExport(exportHistoryAsXLS));
    }

    // --- Lógica de Promociones e Imágenes ---
    // Trigger file click
    if (btnCargarImagen && inputImagen) {
        btnCargarImagen.addEventListener('click', () => inputImagen.click());
    }

    // Handle image file selection
    if (inputImagen) {
        inputImagen.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Validate file size (limit to 5MB for storage safety)
            if (file.size > 5 * 1024 * 1024) {
                alert('La imagen es demasiado grande. Selecciona una menor a 5MB.');
                inputImagen.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = (event) => {
                currentImageDataUrl = event.target.result;
                showImagePreview(currentImageDataUrl);
                saveDraft();
            };
            reader.readAsDataURL(file);
        });
    }

    // Helper to show preview
    function showImagePreview(dataUrl) {
        if (dataUrl) {
            previewImagen.src = dataUrl;
            previewImagenContainer.style.display = 'block';
            btnQuitarImagen.style.display = 'block';
            btnCargarImagen.textContent = 'Cambiar imagen';
        } else {
            previewImagen.src = '';
            previewImagenContainer.style.display = 'none';
            btnQuitarImagen.style.display = 'none';
            btnCargarImagen.textContent = 'Seleccionar imagen';
            if (inputImagen) inputImagen.value = '';
        }
    }

    // Quitar imagen
    if (btnQuitarImagen) {
        btnQuitarImagen.addEventListener('click', () => {
            currentImageDataUrl = '';
            showImagePreview('');
            selectPromocion.value = '';
            saveDraft();
        });
    }

    // Cargar promociones desde storage
    function loadPromotions() {
        chrome.storage.local.get(['promotions'], (data) => {
            promotions = data.promotions || [];
            
            // Si no hay, inicializar con las de ejemplo
            if (promotions.length === 0) {
                promotions = [
                    {
                        id: 'promo-1',
                        name: 'Descuento Especial Uphone 🎁',
                        message: '¡Hola {{Nombre}}! Por ser cliente preferencial de Uphone, tienes un 20% de descuento en tu próximo plan. Tu deuda actual de {{Monto}} ahora tiene descuento. ¡Contáctanos!',
                        image: ''
                    },
                    {
                        id: 'promo-2',
                        name: 'Cobro Pendiente ⚠️',
                        message: 'Estimado/a {{Nombre}}, le recordamos que su saldo pendiente de {{Monto}} (Cédula: {{Cédula}}) vence pronto. Por favor regularice su pago.',
                        image: ''
                    },
                    {
                        id: 'promo-3',
                        name: 'Fidelización Cliente 🎉',
                        message: '¡Gracias por elegir Uphone, {{Nombre}}! Nos alegra contar contigo en nuestra familia tecnológica.',
                        image: ''
                    }
                ];
                chrome.storage.local.set({ promotions });
            }

            renderPromotionsDropdown();
        });
    }

    // Render dropdown options
    function renderPromotionsDropdown() {
        if (!selectPromocion) return;
        
        selectPromocion.innerHTML = '<option value="">-- Sin promoción --</option>';
        
        promotions.forEach(promo => {
            const opt = document.createElement('option');
            opt.value = promo.id;
            opt.textContent = promo.name;
            selectPromocion.appendChild(opt);
        });
    }

    // Handle selection
    if (selectPromocion) {
        selectPromocion.addEventListener('change', () => {
            const promoId = selectPromocion.value;
            if (!promoId) return;
            
            const promo = promotions.find(p => p.id === promoId);
            if (promo) {
                messageText.value = promo.message;
                currentImageDataUrl = promo.image || '';
                showImagePreview(currentImageDataUrl);
                updatePreview();
            }
        });
    }

    // Guardar promoción
    if (btnGuardarPromo) {
        btnGuardarPromo.addEventListener('click', () => {
            const text = messageText.value.trim();
            if (!text) {
                alert('Escribe un mensaje antes de guardarlo como promoción.');
                return;
            }

            const name = prompt('Introduce un nombre para la promoción:');
            if (!name) return;

            const newPromo = {
                id: 'promo-' + Date.now(),
                name: name,
                message: text,
                image: currentImageDataUrl
            };

            promotions.push(newPromo);
            chrome.storage.local.set({ promotions }, () => {
                renderPromotionsDropdown();
                selectPromocion.value = newPromo.id;
                alert('¡Promoción "' + name + '" guardada con éxito!');
            });
        });
    }

    // Eliminar promoción
    if (btnEliminarPromo) {
        btnEliminarPromo.addEventListener('click', () => {
            const promoId = selectPromocion.value;
            if (!promoId) {
                alert('Selecciona una promoción para eliminar.');
                return;
            }

            const promo = promotions.find(p => p.id === promoId);
            if (confirm(`¿Estás seguro de que deseas eliminar la promoción "${promo.name}"?`)) {
                promotions = promotions.filter(p => p.id !== promoId);
                chrome.storage.local.set({ promotions }, () => {
                    renderPromotionsDropdown();
                    selectPromocion.value = '';
                    currentImageDataUrl = '';
                    showImagePreview('');
                    alert('Promoción eliminada.');
                });
            }
        });
    }

    // Cargar promociones al inicio
    loadPromotions();
});

