/**
 * Content Script - SMS/RCS Masivos - UPHONE
 * Automatización de messages.google.com
 */

// --- Guard: Prevenir listeners duplicados por inyecciones múltiples ---
// El manifest.json ya inyecta este script, y ensureGoogleMessagesTab() lo inyecta
// de nuevo programáticamente. Sin este guard, se crean DOS listeners que compiten
// entre sí, causando que la automatización DOM falle silenciosamente.
if (window._uphoneListenerRegistered && chrome.runtime?.id) {
    console.log('UPHONE SMS Automation: Content Script ya activo, saltando re-inyección.');
} else {
    window._uphoneListenerRegistered = true;

    console.log('UPHONE SMS Automation: Content Script v3.0 inyectado.');

    window._uphoneStopRequested = false;

    // --- Audio WakeLock para Tabs en Segundo Plano ---
    // Engaña a Chromium para que trate la pestaña como "Reproduciendo Audio"
    // previniendo el "Intensive Wake-Up Throttling" y manteniendo los timers y
    // MutationObservers al 100% de CPU.
    function playSilentAudioWakeLock() {
        if (window._uphoneAudioCtx) return;
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const ctx = new AudioContext();
            const source = ctx.createBufferSource();
            const buffer = ctx.createBuffer(1, 1, 22050);
            source.buffer = buffer;
            source.loop = true;
            
            const gain = ctx.createGain();
            gain.gain.value = 0; // Silencio absoluto
            
            source.connect(gain);
            gain.connect(ctx.destination);
            source.start();
            window._uphoneAudioCtx = ctx;
            console.log('UPHONE: Audio WakeLock activado para Anti-Throttling.');
        } catch(e) {
            console.warn('UPHONE: No se pudo habilitar HW-WakeLock', e);
        }
    }

    // --- Configuración de Selectores ---
    const SELECTORS = {
        START_CHAT: 'a[href*="conversations/new"], a.fab, a.mdc-button[aria-label*="chat"], [aria-label="Iniciar chat"], [aria-label="Start chat"]',
        PHONE_INPUT: 'input[role="combobox"], input[placeholder*="nombre"], input[placeholder*="name"], input[placeholder*="number"], input[placeholder*="teléfono"], input[placeholder*="correo"]',
        CONFIRM_CONTACT: '.contact-list-item, [role="listbox"] [role="option"], mat-option, mws-contact-list-item',
        MESSAGE_INPUT: 'div[contenteditable="true"], textarea[aria-label*="mensaje"], [aria-label*="Text message"], [aria-label*="text message"]',
        SEND_BUTTON: 'button[aria-label*="enviar"], button[aria-label*="send"], button[aria-label*="Send"], [data-e2e-send-button], mws-message-send-button button'
    };

    // --- Funciones de Utilidad ---
    // NOTA: NO usamos setTimeout polling — es throttled a 1/min en pestañas
    // en segundo plano (Intensive Wake-Up Throttling de Chrome). Todos los
    // waits se basan en MutationObserver, que NO está throttled.

    /**
     * Comprueba si un elemento está efectivamente visible para el usuario.
     * Evita `offsetParent` porque en pestaña en segundo plano Chrome puede
     * suspender el layout y reportar null para nodos visibles.
     */
    function isElementRendered(node) {
        if (!node) return false;
        if (node.hidden) return false;
        // Evita getBoundingClientRect porque en ventanas minimizadas Chrome congela
        // el layout y devuelve width=0 y height=0 para todo.
        const style = window.getComputedStyle(node);
        return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
    }

    function waitForElement(selector, timeout = 15000) {
        return new Promise((resolve) => {
            const match = () => {
                const nodes = document.querySelectorAll(selector);
                for (const node of nodes) {
                    if (isElementRendered(node)) return node;
                }
                return null;
            };

            if (window._uphoneStopRequested) return resolve(null);

            const existing = match();
            if (existing) return resolve(existing);

            let lastCheck = 0;
            let checkTimeout = null;

            const check = () => {
                if (window._uphoneStopRequested) {
                    observer.disconnect();
                    clearTimeout(timer);
                    if (checkTimeout) clearTimeout(checkTimeout);
                    resolve(null);
                    return;
                }
                const node = match();
                if (node) {
                    observer.disconnect();
                    clearTimeout(timer);
                    if (checkTimeout) clearTimeout(checkTimeout);
                    resolve(node);
                }
            };

            const observer = new MutationObserver(() => {
                const now = Date.now();
                if (now - lastCheck >= 200) {
                    lastCheck = now;
                    check();
                } else {
                    if (!checkTimeout) {
                        checkTimeout = setTimeout(() => {
                            checkTimeout = null;
                            lastCheck = Date.now();
                            check();
                        }, 200 - (now - lastCheck));
                    }
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['class', 'style', 'hidden', 'aria-hidden']
            });

            const timer = setTimeout(() => {
                observer.disconnect();
                if (checkTimeout) clearTimeout(checkTimeout);
                resolve(null);
            }, timeout);
        });
    }

    /**
     * Espera hasta que un predicado sobre el DOM se cumpla, observando cambios
     * reales en el árbol. MutationObserver NO es throttled en pestañas en bg.
     * Devuelve true si se cumple, false si expira el timeout.
     */
    function waitForCondition(predicate, timeout = 5000, observeRoot = document.body) {
        return new Promise((resolve) => {
            if (window._uphoneStopRequested) return resolve(false);
            if (predicate()) return resolve(true);

            let lastCheck = 0;
            let checkTimeout = null;

            const check = () => {
                if (window._uphoneStopRequested) {
                    observer.disconnect();
                    clearTimeout(timer);
                    if (checkTimeout) clearTimeout(checkTimeout);
                    resolve(false);
                    return;
                }
                if (predicate()) {
                    observer.disconnect();
                    clearTimeout(timer);
                    if (checkTimeout) clearTimeout(checkTimeout);
                    resolve(true);
                }
            };

            const observer = new MutationObserver(() => {
                const now = Date.now();
                if (now - lastCheck >= 200) {
                    lastCheck = now;
                    check();
                } else {
                    if (!checkTimeout) {
                        checkTimeout = setTimeout(() => {
                            checkTimeout = null;
                            lastCheck = Date.now();
                            check();
                        }, 200 - (now - lastCheck));
                    }
                }
            });

            observer.observe(observeRoot, {
                childList: true,
                subtree: true,
                attributes: true,
                characterData: true
            });

            const timer = setTimeout(() => {
                observer.disconnect();
                if (checkTimeout) clearTimeout(checkTimeout);
                resolve(false);
            }, timeout);
        });
    }

    // --- Funciones Auxiliares para Chrome Debugger ---

    /**
     * Escribe texto en el elemento enfocado usando chrome.debugger (eventos isTrusted:true).
     * Angular/frameworks web ignoran eventos sintéticos; el debugger los bypasea.
     */
    function sendDebuggerType(text) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action: 'DEBUGGER_TYPE', text }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error('Error escribiendo vía debugger: ' + chrome.runtime.lastError.message));
                    return;
                }
                if (response && response.status === 'OK') {
                    resolve(true);
                } else {
                    const msg = response ? response.message : 'Sin respuesta';
                    reject(new Error('Debugger type falló: ' + msg));
                }
            });
        });
    }

    /**
     * Variante que NO envía "Ctrl+A" previo (Type-only).
     * Se usa para el body del mensaje, asumiendo cajón vacío al crear/abrir.
     */
    function sendDebuggerTypeOnly(text) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action: 'DEBUGGER_TYPE_ONLY', text }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error('Error escribiendo vía debugger (type-only): ' + chrome.runtime.lastError.message));
                    return;
                }
                if (response && response.status === 'OK') resolve(true);
                else reject(new Error('Debugger type-only falló: ' + (response ? response.message : 'Sin respuesta')));
            });
        });
    }

    /**
     * Envía Enter key REAL usando chrome.debugger (evento isTrusted:true).
     */
    function sendDebuggerEnter() {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action: 'SEND_ENTER_KEY' }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error('Error enviando Enter vía debugger: ' + chrome.runtime.lastError.message));
                    return;
                }
                if (response && response.status === 'OK') {
                    resolve(true);
                } else {
                    const msg = response ? response.message : 'Sin respuesta';
                    reject(new Error('Debugger Enter falló: ' + msg));
                }
            });
        });
    }

    // --- Lógica de Automatización ---

    // Timeouts escalados para pestaña en segundo plano: GM está throttled en
    // su propio JS interno (setTimeout/rAF), por lo que renderiza más lento
    // cuando la pestaña no tiene foco. MutationObserver no está throttled,
    // pero el elemento puede tardar en existir si GM lo crea con setTimeout.
    const WAIT_SHORT_MS = 8000;
    const WAIT_LONG_MS = 25000;
    const CONVERSATION_MAX_ATTEMPTS = 3;
    // Settle entre "texto escrito" y "Enter de envío": da tiempo a que GM web
    // sincronice la conversación NUEVA con el teléfono antes de despachar. Sin
    // esto, el teléfono recibe "abrir chat" pero a veces no el cuerpo del
    // mensaje (web muestra enviado; el celular abre el chat vacío). Race intermitente.
    const COMPOSE_SETTLE_MS = 2000;

    /**
     * Intenta abrir conversación con reintentos. Si falla de forma transitoria
     * (renders lentos en bg), reintenta hasta CONVERSATION_MAX_ATTEMPTS.
     */
    async function startNewConversation(phone) {
        let lastError = null;
        for (let attempt = 1; attempt <= CONVERSATION_MAX_ATTEMPTS; attempt++) {
            if (window._uphoneStopRequested) throw new Error('Campaña detenida por el usuario.');
            try {
                await openConversationOnce(phone);
                if (window._uphoneStopRequested) throw new Error('Campaña detenida por el usuario.');
                return true;
            } catch (err) {
                lastError = err;
                console.warn(`[attempt ${attempt}/${CONVERSATION_MAX_ATTEMPTS}] Falló apertura de ${phone}: ${err?.message || err}`);
                if (attempt < CONVERSATION_MAX_ATTEMPTS) {
                    await resetConversationUI();
                }
            }
        }
        throw lastError || new Error(`No se pudo abrir conversación para ${phone} tras ${CONVERSATION_MAX_ATTEMPTS} intentos.`);
    }

    /**
     * Apertura atómica — un solo intento. Lanza excepción en fallo para que
     * el wrapper decida si reintentar.
     */
    async function openConversationOnce(phone) {
        console.log('Abriendo chat para:', phone);

        const startBtn = await waitForElement(SELECTORS.START_CHAT, WAIT_LONG_MS);
        if (!startBtn) throw new Error('No se encontró el botón "Iniciar chat". ¿Estás en la pestaña correcta?');
        startBtn.click();

        const phoneInput = await waitForElement(SELECTORS.PHONE_INPUT, WAIT_LONG_MS);
        if (!phoneInput) throw new Error('No se encontró el campo para escribir el teléfono.');

        phoneInput.focus();
        await sendDebuggerType(phone);
        console.log('Teléfono escrito vía debugger:', phone);

        // Sugerencia es opcional — si no aparece, Enter confirma el input crudo.
        await waitForElement(SELECTORS.CONFIRM_CONTACT, WAIT_SHORT_MS);

        phoneInput.focus();
        await sendDebuggerEnter();
        console.log('Enter enviado para confirmar destinatario.');

        let composeArea = await waitForElement(SELECTORS.MESSAGE_INPUT, WAIT_LONG_MS);
        if (composeArea) {
            console.log('Conversación abierta exitosamente para:', phone);
            return;
        }

        // Fallback: clic directo en sugerencia por texto si aparece.
        const clicked = clickSendToSuggestion();
        if (!clicked) {
            await sendDebuggerEnter();
            console.log('Enter de reintento enviado.');
        }

        composeArea = await waitForElement(SELECTORS.MESSAGE_INPUT, WAIT_LONG_MS);
        if (!composeArea) {
            throw new Error('No se pudo abrir la conversación para ' + phone + '. El campo de mensaje no apareció.');
        }
        console.log('Conversación abierta tras reintento para:', phone);
    }

    /**
     * Busca y clica la sugerencia "Enviar a ..." por contenido textual.
     * Devuelve true si encontró y clicó algo, false en otro caso.
     */
    function clickSendToSuggestion() {
        const candidates = document.querySelectorAll(
            'button, a, [role="option"], [role="listitem"], mws-contact-list-item, .contact-list-item'
        );
        for (const el of candidates) {
            if (!isElementRendered(el)) continue;
            if (el.textContent && el.textContent.includes('Enviar a')) {
                el.click();
                console.log('Clic en sugerencia "Enviar a" por texto.');
                return true;
            }
        }
        return false;
    }

    /**
     * Resetea la UI de GM antes de un reintento: cierra el diálogo de nueva
     * conversación si quedó abierto, para que el siguiente intento arranque
     * desde un estado conocido.
     */
    async function resetConversationUI() {
        try {
            const backBtn = document.querySelector('button[aria-label*="Back"], button[aria-label*="Atrás"], button[aria-label*="Cancel"]');
            if (backBtn && isElementRendered(backBtn)) {
                backBtn.click();
                console.log('[reset] UI de conversación reseteada.');
                return;
            }
            // Fallback: Escape vía debugger
            chrome.runtime.sendMessage({ action: 'DEBUGGER_ESCAPE' }).catch(() => {});
        } catch (e) {
            console.warn('[reset] falló reset de UI:', e?.message || e);
        }
    }

    /**
     * Detecta si la conversación activa es RCS o SMS usando múltiples señales del DOM.
     * Google Messages indica el protocolo de varias formas; buscamos la más robusta.
     */
    function detectMessageProtocol(inputEl) {
        // Señal 1: aria-label o placeholder del input contiene palabras clave RCS
        const ariaLabel = (inputEl?.getAttribute('aria-label') || inputEl?.placeholder || '').toLowerCase();
        if (ariaLabel.includes('chat') || ariaLabel.includes('rcs') || ariaLabel.includes('rich')) {
            console.log('[RCS-DETECT] Positivo por aria-label:', ariaLabel);
            return true;
        }

        // Señal 2: indicadores visuales de protocolo en la barra de composición
        // Google Messages muestra "Chat" o "RCS" en el toolbar cuando el protocolo es RCS
        const toolbarText = document.querySelector(
            'mws-compose-bar, .compose-container, .compose-footer, .message-type-chip, ' +
            '[class*="compose"] [class*="type"], [class*="protocol"], mws-protocol-indicator'
        );
        if (toolbarText) {
            const txt = (toolbarText.textContent || '').toLowerCase();
            if (txt.includes('chat') || txt.includes('rcs')) {
                console.log('[RCS-DETECT] Positivo por toolbar text:', txt.slice(0, 50));
                return true;
            }
        }

        // Señal 3: el botón de enviar tiene aria-label con "chat" en RCS
        const sendBtn = document.querySelector(SELECTORS.SEND_BUTTON);
        if (sendBtn) {
            const sendLabel = (sendBtn.getAttribute('aria-label') || '').toLowerCase();
            if (sendLabel.includes('chat') || sendLabel.includes('rcs')) {
                console.log('[RCS-DETECT] Positivo por send button label:', sendLabel);
                return true;
            }
        }

        // Señal 4: presencia de elementos exclusivos de RCS (funciones enriquecidas)
        // Google Messages solo renderiza estos controles en conversaciones RCS activas
        const rcsExclusive = document.querySelector(
            'mws-emoji-picker-icon, mws-giphy-button, mws-attach-button, ' +
            '[aria-label*="emoji" i], [aria-label*="attach" i], [aria-label*="gif" i], ' +
            'button[aria-label*="adjuntar" i], button[aria-label*="sticker" i]'
        );
        if (rcsExclusive && isElementRendered(rcsExclusive)) {
            console.log('[RCS-DETECT] Positivo por controles RCS exclusivos');
            return true;
        }

        // Señal 5: la URL contiene indicadores de tipo de conversación RCS
        // (en algunos builds de GM la URL lleva el tipo codificado)
        const url = window.location.href.toLowerCase();
        if (url.includes('rcs') || url.includes('chat')) {
            console.log('[RCS-DETECT] Positivo por URL');
            return true;
        }

        console.log('[RCS-DETECT] Protocolo detectado: SMS');
        return false;
    }

    /**
     * Escribe el mensaje (y opcionalmente adjunta una imagen) y lo envía con Enter real.
     * Usa chrome.debugger para escribir texto y enviar (eventos trusted).
     * @param {string} text - El texto del mensaje.
     * @param {string} [imageDataUrl] - Data URL en base64 de una imagen a adjuntar (opcional).
     */
    async function sendSmsMessage(text, imageDataUrl = '') {
        console.log('Escribiendo mensaje...');

        let activeInput;
        const input = await waitForElement(SELECTORS.MESSAGE_INPUT);
        if (!input) {
            activeInput = document.querySelector(
                'div[contenteditable="true"][aria-label*="message" i], ' +
                'div[contenteditable="true"][aria-label*="mensaje" i], ' +
                '.mws-compose-box div[contenteditable="true"], ' +
                '.mws-compose-box textarea'
            );
            if(!activeInput) throw new Error('No se encontró el campo de mensaje.');
        } else {
            activeInput = input;
        }

        // Re-focus agresivo: antes y después del primer tick
        activeInput.focus();
        await new Promise(r => setTimeout(r, 50));
        if (document.activeElement !== activeInput) activeInput.focus();

        // Identificar si es RCS o SMS ANTES de enviar (el input puede vaciarse despues)
        const isRCS = detectMessageProtocol(activeInput);

        // --- Adjuntar imagen si viene ---
        if (imageDataUrl) {
            try {
                console.log('[IMG] Intentando adjuntar imagen...');

                // Buscar el botón de adjuntar / attach para que Google Messages lo procese
                const attachBtn = document.querySelector(
                    'mws-attach-button button, ' +
                    'button[aria-label*="adjuntar" i], ' +
                    'button[aria-label*="attach" i], ' +
                    'button[aria-label*="Media" i], ' +
                    'button[aria-label*="imagen" i], ' +
                    '[data-e2e-attach-button] button'
                );

                // Convertir el Data URL a un Blob/File
                const response = await fetch(imageDataUrl);
                const blob = await response.blob();
                const mimeType = blob.type || 'image/jpeg';
                const ext = mimeType.split('/')[1] || 'jpg';
                const file = new File([blob], `promo_uphone.${ext}`, { type: mimeType });

                // Buscar el input[type=file] directamente en el DOM
                let fileInput = document.querySelector(
                    'input[type="file"][accept*="image"], ' +
                    'input[type="file"][accept*="*"]'
                );

                if (attachBtn && !fileInput) {
                    // Si no hay file input visible, hacer clic en el botón de adjuntar para que aparezca
                    attachBtn.click();
                    await new Promise(r => setTimeout(r, 500));
                    fileInput = document.querySelector('input[type="file"]');
                }

                if (fileInput) {
                    const dt = new DataTransfer();
                    dt.items.add(file);
                    fileInput.files = dt.files;
                    fileInput.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log('[IMG] Imagen asignada al input de archivo.');
                    // Esperar 2 segundos para que Google Messages procese y muestre la imagen
                    await new Promise(r => setTimeout(r, 2000));
                } else {
                    // Último recurso: pegar desde el portapapeles (clipboard API)
                    console.warn('[IMG] No se encontró input[type=file]. Intentando paste...');
                    const dt2 = new DataTransfer();
                    dt2.items.add(file);
                    activeInput.focus();
                    activeInput.dispatchEvent(new ClipboardEvent('paste', {
                        clipboardData: dt2,
                        bubbles: true,
                        cancelable: true
                    }));
                    await new Promise(r => setTimeout(r, 2000));
                }
            } catch (imgErr) {
                console.warn('[IMG] No se pudo adjuntar la imagen (continuando sin ella):', imgErr?.message || imgErr);
            }
        }

        // Escribir el texto del mensaje (si lo hay)
        if (text && text.trim()) {
            // Re-focus después de adjuntar la imagen
            activeInput.focus();
            await new Promise(r => setTimeout(r, 50));
            if (document.activeElement !== activeInput) activeInput.focus();

            // Type-only (sin Ctrl+A previo — body está vacío en conversación recién abierta)
            await sendDebuggerTypeOnly(text);

            // Verificar que el texto quedó en el input correcto
            const written = (activeInput.innerText || activeInput.value || '').trim();
            if (!written.includes(text.trim().split('\n')[0].slice(0, 20))) {
                throw new Error('El mensaje no se escribió en el campo correcto. Texto observado: "' +
                                written.slice(0, 40) + '"');
            }
        }

        // Esperar a que el botón de enviar esté habilitado por MutationObserver.
        // Angular habilita el botón al detectar texto o adjunto válido.
        const sendEnabled = await waitForSendEnabled(5000);
        if (!sendEnabled) {
            throw new Error('Botón de enviar no se habilitó tras escribir el mensaje. Body posiblemente vacío.');
        }

        // Settle anti-race: esperar a que GM web sincronice la conversación nueva
        // (y el borrador) con el teléfono ANTES de pulsar Enter. Evita que el
        // teléfono abra el chat sin el cuerpo del mensaje.
        if (!window._uphoneStopRequested) {
            await new Promise(r => setTimeout(r, COMPOSE_SETTLE_MS));
        }

        // Foto previa: nº de indicadores de fallo y confirmación presentes ANTES de
        // enviar. En conversaciones recurrentes el historial ya tiene mensajes (con
        // timestamps) y a veces fallos antiguos ("No se envió"); los registramos
        // para NO confundirlos con el resultado del envío actual.
        const failedBefore = countFailedIndicators();
        const confirmedBefore = countConfirmedIndicators();

        // Enviar con Enter REAL vía chrome.debugger
        await sendDebuggerEnter();
        console.log('Mensaje enviado con Enter vía debugger.');

        // Esperar confirmación de envío: el input debe vaciarse
        const cleared = await waitForInputCleared(activeInput, 4000);
        if (!cleared && !window._uphoneStopRequested) {
            throw new Error('El mensaje no parece haberse enviado (input no vaciado tras 4s).');
        }

        // Verificación real de entrega: solo cuentan fallos/confirmaciones NUEVOS
        // (por encima de las líneas base capturadas justo antes de enviar).
        const deliveryResult = await waitForSendConfirmation(8000, failedBefore, confirmedBefore);
        if (deliveryResult === 'FAILED') {
            throw new Error('Google Messages reportó "No se envió". La petición de red fue cancelada o rechazada.');
        }
        // deliveryResult === 'CONFIRMED' o 'TIMEOUT': ambos se tratan como éxito.
        // Un TIMEOUT sin fallo nuevo (aunque el mensaje siga mostrando "Enviando…")
        // ya NO se considera fallo: el teléfono puede tardar más que esta ventana
        // de verificación en despachar el envío (cola de mensajes, señal débil)
        // sin que eso signifique que el envío falló. Solo un indicador EXPLÍCITO
        // de fallo ("No se envió"/"Not sent") justifica marcar "no enviado".

        return { success: true, isRCS };
    }

    /**
     * Cuenta los indicadores de fallo de envío ("No se envió" / failed) presentes
     * AHORA MISMO en el DOM (incluye historial del hilo y lista de conversaciones).
     *
     * Se usa para distinguir un fallo NUEVO (del mensaje recién enviado) de los
     * fallos HISTÓRICOS que ya existían en una conversación recurrente. Sin este
     * conteo base, un "No se envió" antiguo en el hilo se confundía con el envío
     * actual y producía un falso error en números usados frecuentemente.
     */
    function countFailedIndicators() {
        let count = 0;
        const errorTexts = ['No se envió', 'Not sent', 'Send failed', 'no se pudo enviar'];
        const candidates = document.querySelectorAll(
            'mws-message-failed-indicator, .failed-message-indicator, ' +
            '[data-e2e-failed], .message-failed, ' +
            'span[class*="failed"], div[class*="failed"]'
        );
        for (const el of candidates) {
            if (isElementRendered(el)) count++;
        }
        const allSpans = document.querySelectorAll(
            'mws-conversation-list-item-body span, .message-status span, ' +
            '.bottom-bar span, .failed-message span, [class*="status"] span'
        );
        for (const span of allSpans) {
            const txt = (span.textContent || '').trim();
            if (errorTexts.some(e => txt.includes(e))) count++;
        }
        return count;
    }

    /**
     * Cuenta indicadores de CONFIRMACIÓN REAL del servidor (timestamp / estado
     * "Enviado" / checkmark de leído) presentes ahora en el DOM.
     *
     * Excluye a propósito `mws-message-part-content`: ese nodo aparece apenas se
     * dibuja la burbuja (estado "Enviando…"), ANTES de que el servidor responda,
     * por lo que no prueba que el envío haya tenido éxito. Confirmar con él causaba
     * un corte temprano que marcaba como enviados mensajes que fallaban segundos
     * después en la red.
     */
    function countConfirmedIndicators() {
        let count = 0;
        const candidates = document.querySelectorAll(
            '.message-sent-status, [data-e2e-sent], .read-timestamp'
        );
        for (const el of candidates) {
            if (isElementRendered(el)) count++;
        }
        return count;
    }

    /**
     * Observa el DOM de la conversación activa para determinar el resultado REAL
     * del envío recién hecho. Google Messages muestra "No se envió" en rojo cuando
     * la petición de red falla; o un timestamp/checkmark cuando el servidor confirma.
     *
     * Detección acotada al mensaje ACTUAL mediante líneas base:
     *   - Solo cuenta un fallo si supera `failedBaseline`.
     *   - Solo cuenta una confirmación si supera `confirmedBaseline`.
     * Así, ni los fallos antiguos del historial ni los timestamps de mensajes
     * previos contaminan el veredicto en conversaciones recurrentes.
     *
     * El FALLO tiene prioridad: al detectar una confirmación nueva esperamos una
     * breve ventana de gracia (FAIL_GRACE_MS) revisando si aparece un fallo, porque
     * en GM el "No se envió" puede llegar un instante después.
     *
     * Si al expirar el timeout no apareció ningún fallo nuevo, se resuelve como
     * éxito probable ('TIMEOUT'), aunque el mensaje siga mostrando "Enviando…": el
     * teléfono puede tardar más que esta ventana de verificación en despachar el
     * envío (cola de mensajes, señal débil) sin que eso sea un fallo real. Solo un
     * indicador EXPLÍCITO de fallo justifica marcar el contacto como no enviado.
     *
     * @param {number} timeout - ms máximos de espera.
     * @param {number} failedBaseline - fallos ya presentes antes de enviar.
     * @param {number} confirmedBaseline - confirmaciones ya presentes antes de enviar.
     * Retorna 'CONFIRMED' | 'FAILED' | 'TIMEOUT'.
     */
    function waitForSendConfirmation(timeout = 8000, failedBaseline = 0, confirmedBaseline = 0) {
        return new Promise((resolve) => {
            const FAIL_GRACE_MS = 1500;

            const hasNewFailed = () => countFailedIndicators() > failedBaseline;
            const hasNewConfirmed = () => countConfirmedIndicators() > confirmedBaseline;

            // Si ya hay un fallo NUEVO antes de empezar a observar, resolvemos ya.
            if (hasNewFailed()) {
                resolve('FAILED');
                return;
            }

            const conversationArea = document.querySelector(
                'mws-conversation-container, .conversation-container, main, [role="main"]'
            ) || document.body;

            let settled = false;
            let graceTimer = null;
            let observer = null;
            let timer = null;

            const finish = (result) => {
                if (settled) return;
                settled = true;
                if (observer) observer.disconnect();
                if (timer) clearTimeout(timer);
                if (graceTimer) clearTimeout(graceTimer);
                resolve(result);
            };

            observer = new MutationObserver(() => {
                if (window._uphoneStopRequested) { finish('TIMEOUT'); return; }

                // El fallo nuevo gana siempre, incluso durante la ventana de gracia.
                if (hasNewFailed()) { finish('FAILED'); return; }

                // Confirmación nueva: no resolvemos al instante; damos margen por si
                // el "No se envió" llega justo después del timestamp.
                if (hasNewConfirmed() && !graceTimer) {
                    graceTimer = setTimeout(() => {
                        if (hasNewFailed()) finish('FAILED');
                        else finish('CONFIRMED');
                    }, FAIL_GRACE_MS);
                }
            });

            observer.observe(conversationArea, {
                childList: true,
                subtree: true,
                attributes: true,
                characterData: true
            });

            timer = setTimeout(() => {
                // Al expirar la ventana decidimos el veredicto final: solo un fallo
                // NUEVO explícito cuenta como no-enviado. Si el mensaje sigue
                // "Enviando…" pero no hay ningún indicador de fallo, se acepta como
                // éxito probable — el teléfono puede seguir despachándolo después
                // de esta ventana sin que eso sea un fallo real.
                if (hasNewFailed()) { finish('FAILED'); return; }
                finish('TIMEOUT');
            }, timeout);
        });
    }

    /**
     * Espera hasta que el botón de enviar esté habilitado. Usa MutationObserver
     * sobre el atributo `disabled` / `aria-disabled` — fiable en pestaña bg.
     */
    function waitForSendEnabled(timeout = 5000) {
        return waitForCondition(() => {
            const btn = document.querySelector(SELECTORS.SEND_BUTTON);
            return !!btn && !btn.disabled && btn.getAttribute('aria-disabled') !== 'true';
        }, timeout);
    }

    /**
     * Espera a que el input de mensaje quede vacío (confirmación de envío).
     * Observa mutaciones del propio input — no hace polling.
     */
    function waitForInputCleared(inputEl, timeout = 3000) {
        return waitForCondition(() => {
            const txt = (inputEl.innerText || inputEl.value || '').trim();
            return txt.length === 0;
        }, timeout, inputEl);
    }

    // --- Listener de Mensajes (ÚNICO, protegido contra duplicación) ---
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        (async () => {
            try {
                if (request.action === 'ABORT_CURRENT_SEND') {
                    window._uphoneStopRequested = true;
                    sendResponse({ status: 'ABORTED' });
                    return;
                }

                if (request.action === 'AUTOMATE_SEND') {
                    // Guard: si ya se solicitó stop antes de que llegara este mensaje,
                    // rechazarlo sin iniciar el proceso de envío.
                    if (window._uphoneStopRequested) {
                        sendResponse({ status: 'ABORTED', message: 'Stop solicitado antes del envío.' });
                        return;
                    }
                    window._uphoneStopRequested = false;
                    playSilentAudioWakeLock();
                    
                    const { phone, message, imageDataUrl, contact } = request;
                    
                    // Aplicar personalización y spin syntax antes de enviar
                    let finalMessage = message || '';
                    if (window.Utils && finalMessage) {
                        finalMessage = window.Utils.personalizeMessage(finalMessage, contact);
                        finalMessage = window.Utils.parseSpinSyntax(finalMessage);
                    } else if (!finalMessage) {
                        console.warn('window.Utils no cargado o mensaje vacío. Enviando sin personalización.');
                    }
                    
                    await startNewConversation(phone);
                    const sendResult = await sendSmsMessage(finalMessage, imageDataUrl || '');
                    
                    sendResponse({ status: 'SUCCESS', phone, isRCS: sendResult.isRCS });
                }
                
                if (request.action === 'CHECK_STATUS') {
                    const isReady = document.querySelector(SELECTORS.START_CHAT) || 
                                    document.querySelector('mws-conversations-list') || 
                                    document.querySelector('div[role="listbox"]') ||
                                    document.querySelector('a[href^="/web/conversations"]');
                                    
                    sendResponse({ status: isReady ? 'READY' : 'NOT_READY' });
                }

                // --- Actualización de la UI del HUD (Heads-Up Display) ---
                if (request.action === 'UPDATE_HUD') {
                    updateHUD(request);
                    sendResponse({ status: 'OK' });
                }
                
                if (request.action === 'REMOVE_HUD') {
                    const hud = document.getElementById('uphone-hud');
                    if (hud) hud.remove();
                    sendResponse({ status: 'OK' });
                }
            } catch (error) {
                console.error('Error en content script onMessage listener:', error);
                sendResponse({ status: 'ERROR', message: error?.message || String(error) });
            }
        })();
        return true; // Importante para respuestas asíncronas
    });

    /**
     * Muestra una pequeña barra de estado / HUD flotante encima de Google Messages
     */
    function updateHUD(data) {
        let hud = document.getElementById('uphone-hud');
        if (!hud) {
            hud = document.createElement('div');
            hud.id = 'uphone-hud';
            hud.style.cssText = `
                position: fixed;
                bottom: 24px;
                right: 24px;
                background: #1e293b;
                color: #f8fafc;
                padding: 12px 16px;
                border-radius: 8px;
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
                font-size: 14px;
                z-index: 999999;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.4), 0 4px 6px -2px rgba(0, 0, 0, 0.25);
                border: 1px solid #334155;
                display: flex;
                flex-direction: column;
                gap: 4px;
                min-width: 260px;
                pointer-events: none; /* No bloquear clics debajo */
                transition: all 0.2s ease;
            `;
            document.body.appendChild(hud);
        }
        
        // Colores semánticos
        let headerColor = '#3b82f6'; // Azul
        if (data.status.includes('Error') || data.status.includes('Duplicado') || data.status.includes('Omitido')) {
            headerColor = '#ef4444'; // Rojo/Alerta
        } else if (data.status.includes('Enviado ✅')) {
            headerColor = '#22c55e'; // Verde
        } else if (data.status.includes('Pausando')) {
            headerColor = '#eab308'; // Amarillo
        }
        
        hud.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155; padding-bottom: 8px; margin-bottom: 4px;">
                <strong style="color: ${headerColor}; display: flex; align-items: center; gap: 6px;">
                    <span style="font-size: 1.1em;">🚀</span> UPHONE
                </strong>
                <span style="background: #0f172a; border: 1px solid #334155; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 600; color: #38bdf8;">
                    ${data.progress} / ${data.total}
                </span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-top: 4px;">
                <span style="color: #94a3b8;">Contacto:</span>
                <strong style="color: #e2e8f0; font-family: monospace; font-size: 1.1em;">${data.phone}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="color: #94a3b8;">Estado:</span>
                <span style="font-weight: 600; color: ${headerColor}; max-width: 150px; text-align: right; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    ${data.status}
                </span>
            </div>
        `;
    }

} // Fin del guard de inyección
