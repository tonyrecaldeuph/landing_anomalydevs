/**
 * deviceSelection — aislamiento de teléfonos ADB.
 *
 * El usuario puede tener varios teléfonos conectados con depuración activa y
 * reservar algunos para llamadas: solo los habilitados participan del envío.
 *
 * El dashboard persiste los seriales AISLADOS (no los habilitados) para que un
 * teléfono nunca visto aparezca habilitado por defecto. El servidor recibe la
 * lista de HABILITADOS y nunca usa un serial fuera de ella: sin lista no se
 * usa ninguno (fail-closed), jamás "todos los conectados".
 *
 * Funciones puras, sin chrome.* ni adb — compartidas por dashboard y servidor.
 */

/**
 * Servidor: seriales conectados que además están habilitados.
 */
function selectEnabledTargets(connected, enabled) {
    const connectedList = Array.isArray(connected) ? connected : [];
    const enabledSet = new Set(Array.isArray(enabled) ? enabled : []);
    return connectedList.filter(serial => enabledSet.has(serial));
}

/**
 * Dashboard: seriales conectados que el usuario no aisló.
 */
function computeEnabledDevices(connected, isolated) {
    const connectedList = Array.isArray(connected) ? connected : [];
    const isolatedSet = new Set(Array.isArray(isolated) ? isolated : []);
    return connectedList.filter(serial => !isolatedSet.has(serial));
}

/**
 * Alterna un serial entre aislado y habilitado, devolviendo una lista nueva.
 */
function toggleIsolation(isolated, serial) {
    const isolatedList = Array.isArray(isolated) ? isolated : [];
    return isolatedList.includes(serial)
        ? isolatedList.filter(s => s !== serial)
        : isolatedList.concat(serial);
}

/**
 * Canal que expone solo los targets habilitados. El resto de métodos se
 * hereda por prototipo del canal real, así campaignEngine no cambia.
 */
function withEnabledTargets(channel, enabled) {
    const filtered = Object.create(channel);
    filtered.listTargets = async () => selectEnabledTargets(await channel.listTargets(), enabled);
    return filtered;
}

/**
 * Estado del puente según su mensaje `connected`. UNKNOWN mientras no hay
 * conexión o hello: no es lo mismo un puente apagado que uno viejo.
 */
const BridgeIsolation = Object.freeze({
    UNKNOWN: 'unknown',
    SUPPORTED: 'supported',
    UNSUPPORTED: 'unsupported'
});

/**
 * Un puente anterior al handshake no trae `isolation:true`: arrancar contra
 * él enviaría por todos los teléfonos.
 */
function bridgeIsolationFromHello(hello) {
    return !!hello && hello.isolation === true ? BridgeIsolation.SUPPORTED : BridgeIsolation.UNSUPPORTED;
}

function canStartAdbCampaign(state) {
    return state === BridgeIsolation.SUPPORTED;
}

/**
 * Aviso solo ante un puente que respondió sin aislamiento. Reiniciar relanza el
 * server.js de la carpeta registrada en el host: si el usuario descomprimió la
 * versión nueva en OTRA carpeta, hay que ejecutar install.exe desde ella.
 */
function bridgeIsolationWarning(state) {
    if (state !== BridgeIsolation.UNSUPPORTED) return '';
    return 'Puente ADB desactualizado (no respeta el aislamiento y enviaría por TODOS los teléfonos). ' +
        'Pulsa "Reiniciar puente"; si el aviso persiste, ejecuta native-launcher\\install.exe desde la carpeta de la versión nueva.';
}

// normalizarModos y MODOS_CONEXION viven en vias.js (módulo puro hermano).
// Resuelto EN CADA LLAMADA (no al cargar el módulo): en Node vuelve a
// `require('./vias.js')`; en el dashboard ambos archivos se cargan como
// <script> clásicos sin módulos, así que se leen desde `globalThis`, donde
// quedan los `var`/funciones de tope de vias.js. Resolver en el momento del
// llamado hace que el orden de los <script> deje de importar: para cuando
// se invoca bridgeViasWarning, vias.js ya corrió sin falta.
function _vias() {
    if (typeof require === 'function') return require('./vias.js');
    return globalThis;
}

/**
 * Estado del puente según su mensaje `connected` respecto del soporte de
 * elegir vía. Un puente que no declara `vias:true` siempre manda por la vía
 * automática, sin importar lo que el usuario fijó en el dashboard.
 */
const BridgeVias = Object.freeze({
    UNKNOWN: 'unknown',
    SUPPORTED: 'supported',
    UNSUPPORTED: 'unsupported'
});

/**
 * Un puente anterior a este handshake no trae `vias:true`: ofrecerle un
 * modo "Solo cable"/"Solo Bluetooth" sería una elección que ese puente
 * ignoraría en silencio, enviando por la vía que él decida.
 */
function bridgeViasFromHello(hello) {
    return !!hello && hello.vias === true ? BridgeVias.SUPPORTED : BridgeVias.UNSUPPORTED;
}

function canChooseVia(state) {
    return state === BridgeVias.SUPPORTED;
}

/**
 * Aviso solo si el puente no soporta elegir vía Y hay al menos una elección
 * guardada distinta de «Automática»: un puente viejo sin ninguna elección
 * no molesta a nadie, automática es lo que ese puente ya hace. Mismo
 * remedio que bridgeIsolationWarning: reiniciar el puente o, si persiste,
 * ejecutar install.exe desde la carpeta de la versión nueva.
 */
function bridgeViasWarning(state, modos) {
    if (state !== BridgeVias.UNSUPPORTED) return '';
    const { normalizarModos, MODOS_CONEXION } = _vias();
    const modosGuardados = normalizarModos(modos);
    const hayEleccion = Object.values(modosGuardados).some(modo => modo !== MODOS_CONEXION.automatica);
    if (!hayEleccion) return '';
    return 'Puente ADB desactualizado (no soporta elegir la vía de conexión y enviaría siempre por la automática, ignorando lo que elegiste). ' +
        'Pulsa "Reiniciar puente"; si el aviso persiste, ejecuta native-launcher\\install.exe desde la carpeta de la versión nueva.';
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        selectEnabledTargets, computeEnabledDevices, toggleIsolation, withEnabledTargets,
        BridgeIsolation, bridgeIsolationFromHello, canStartAdbCampaign, bridgeIsolationWarning,
        BridgeVias, bridgeViasFromHello, canChooseVia, bridgeViasWarning
    };
}
