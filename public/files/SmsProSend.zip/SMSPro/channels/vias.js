/**
 * vias — clasificación y elección de vía de transporte ADB.
 *
 * Hasta ahora cada teléfono era un serial de `adb devices`. El puente
 * Bluetooth de un proyecto hermano publica hasta 3 teléfonos por PC como
 * `127.0.0.1:7001..7003`, así que un mismo teléfono puede aparecer DOS veces
 * en `adb devices` a la vez: una por cable (serial de fábrica) y otra por el
 * puente (loopback:70xx). Sin este módulo, campaignEngine lo trataría como
 * dos teléfonos distintos y duplicaría el envío.
 *
 * Reglas de clasificación (en este orden, por especificidad):
 *  - Bluetooth: el puente SIEMPRE usa loopback con puerto 70xx. Es el caso
 *    más específico, así que se prueba primero.
 *  - WiFi: cualquier otro `host:puerto` (adb-over-tcp normal) o el sufijo
 *    mDNS `._adb-tls-connect._tcp` que usa el emparejamiento por WiFi de adb.
 *  - USB: todo lo demás, que es el serial de fábrica de un cable.
 *
 * Preferencia automática: USB > WiFi > Bluetooth. Por Bluetooth el volcado
 * de contactos/mensajes tarda ~2x (el puente serializa todo por un solo
 * enlace), así que si el mismo teléfono está disponible por cable o WiFi se
 * usa esa vía primero.
 *
 * Un modo «Solo cable» o «Solo Bluetooth» es una elección explícita del
 * usuario (p.ej. para aislar un teléfono problemático a una vía conocida):
 * por diseño NUNCA cae a otra vía aunque haya candidatos. Si la vía elegida
 * no está disponible, el teléfono queda sin ruta (`''`), no se envía por él.
 *
 * Funciones puras, sin chrome.* ni adb — compartidas por dashboard y server.
 */

// `var`, no `const`: el dashboard carga este archivo como <script> clásico
// (sin módulos) y deviceSelection.js necesita leer estos nombres desde
// `globalThis`. Un `const` de tope nunca se adjunta al objeto global aunque
// el script corra en orden correcto; `var` sí. `Object.freeze` sigue
// protegiendo el valor igual que antes.
var VIAS = Object.freeze({
    usb: 'usb',
    wifi: 'wifi',
    bluetooth: 'bluetooth'
});

var MODOS_CONEXION = Object.freeze({
    automatica: 'automatica',
    usb: 'usb',
    bluetooth: 'bluetooth'
});

// Orden de preferencia para el modo automático: ver cabezal del archivo.
const ORDEN_AUTOMATICO = [VIAS.usb, VIAS.wifi, VIAS.bluetooth];

const MODOS_VALIDOS = new Set(Object.values(MODOS_CONEXION));

// Un serial con '|' o espacios rompería el framing del protocolo del puente
// o la construcción de un target adb; mejor descartarlo en el borde que
// dejarlo viajar y fallar más adelante de forma confusa.
const SERIAL_NORMALIZABLE = /^[^\s|]+$/;

const REGEX_BLUETOOTH = /^127\.0\.0\.1:70\d\d$/;
const REGEX_WIFI = /:\d+$|\._adb-tls-connect\._tcp$/;

/**
 * Clasifica un serial de `adb devices` en su vía de transporte. Bluetooth se
 * prueba antes que WiFi porque el puente usa loopback:70xx, que también
 * calzaría con el patrón genérico de host:puerto de WiFi.
 */
function clasificarVia(serialAdb) {
    const serial = String(serialAdb);
    if (REGEX_BLUETOOTH.test(serial)) return VIAS.bluetooth;
    if (REGEX_WIFI.test(serial)) return VIAS.wifi;
    return VIAS.usb;
}

/**
 * Elige, entre los seriales de adb de UN teléfono, cuál usar para enviar.
 * En modo automático respeta USB > WiFi > Bluetooth; en modo «Solo X» busca
 * únicamente esa vía y nunca cae a otra. Sin candidato devuelve '' (nunca
 * null/undefined) para que el resto del código no tenga que chequear tipos.
 */
function elegirVia(serialesAdb, modo) {
    const lista = Array.isArray(serialesAdb) ? serialesAdb : [];
    const modoEfectivo = modo || MODOS_CONEXION.automatica;

    if (modoEfectivo === MODOS_CONEXION.usb) {
        return lista.find(serial => clasificarVia(serial) === VIAS.usb) || '';
    }
    if (modoEfectivo === MODOS_CONEXION.bluetooth) {
        return lista.find(serial => clasificarVia(serial) === VIAS.bluetooth) || '';
    }
    for (const via of ORDEN_AUTOMATICO) {
        const candidato = lista.find(serial => clasificarVia(serial) === via);
        if (candidato) return candidato;
    }
    return '';
}

/**
 * Agrupa pares {serialAdb, fisico} por teléfono físico y elige una sola
 * ruta por teléfono, aunque aparezca varias veces en `adb devices` (cable +
 * puente). Sin serial físico (getprop no respondió) se usa el propio
 * serialAdb como clave, así el teléfono sigue siendo direccionable.
 */
function rutasPorTelefono(pares, modos) {
    const lista = Array.isArray(pares) ? pares : [];
    const modosObj = modos && typeof modos === 'object' && !Array.isArray(modos) ? modos : {};

    // Mapa ordenado: conserva el orden de PRIMERA aparición de cada teléfono.
    const serialesPorClave = new Map();
    for (const par of lista) {
        if (!par) continue;
        const clave = par.fisico || par.serialAdb;
        if (!serialesPorClave.has(clave)) serialesPorClave.set(clave, []);
        serialesPorClave.get(clave).push(par.serialAdb);
    }

    const rutas = new Map();
    for (const [clave, serialesAdb] of serialesPorClave) {
        const modo = Object.prototype.hasOwnProperty.call(modosObj, clave) ? modosObj[clave] : undefined;
        rutas.set(clave, elegirVia(serialesAdb, modo));
    }
    return rutas;
}

/**
 * Filtra un objeto {clave: modo} a solo las entradas usables: la clave debe
 * poder viajar como target adb o clave de protocolo (sin espacios ni '|'), y
 * el modo debe ser uno conocido. Usa hasOwnProperty explícito para que una
 * clave como "constructor" no se resuelva por el prototipo de Object.
 */
function normalizarModos(modos) {
    const resultado = {};
    if (!modos || typeof modos !== 'object' || Array.isArray(modos)) return resultado;
    for (const clave of Object.keys(modos)) {
        if (!Object.prototype.hasOwnProperty.call(modos, clave)) continue;
        const valor = modos[clave];
        if (SERIAL_NORMALIZABLE.test(clave) && MODOS_VALIDOS.has(valor)) {
            resultado[clave] = valor;
        }
    }
    return resultado;
}

/**
 * Etiqueta de vía para el dashboard. Un valor desconocido devuelve '' en vez
 * de dejar pasar "undefined" a la pantalla.
 */
function etiquetaVia(via) {
    if (via === VIAS.usb) return 'USB';
    if (via === VIAS.wifi) return 'WiFi';
    if (via === VIAS.bluetooth) return 'Bluetooth';
    return '';
}

/**
 * Etiqueta de modo de conexión para el dashboard. Mismo criterio que
 * etiquetaVia: desconocido -> ''.
 */
function etiquetaModo(modo) {
    if (modo === MODOS_CONEXION.automatica) return 'Automática';
    if (modo === MODOS_CONEXION.usb) return 'Solo cable';
    if (modo === MODOS_CONEXION.bluetooth) return 'Solo Bluetooth';
    return '';
}

/**
 * Arma las filas del panel del dashboard: una por teléfono. Recorre primero
 * `conectados` (en su orden) y después las claves de `sinVia` que no se
 * vieron todavía, así un serial presente en ambas listas se pinta una sola
 * vez, como disponible. Un modo guardado de un teléfono que no aparece en
 * ninguna lista no genera fila: la elección persiste en storage, pero sin
 * teléfono no hay nada que pintar.
 *
 * `vias` mapea serial -> vía EN USO (puede faltar si el puente es viejo y no
 * informa vías: la fila existe igual, solo sin etiqueta). `sinVia` mapea
 * serial -> modo elegido para los teléfonos que no consiguieron esa vía
 * (bloqueados, van al final con el motivo).
 */
function filasDeTelefonos(conectados, vias, sinVia, modos) {
    const conectadosList = Array.isArray(conectados) ? conectados : [];
    const viasPorSerial = vias && typeof vias === 'object' && !Array.isArray(vias) ? vias : {};
    const sinViaPorSerial = sinVia && typeof sinVia === 'object' && !Array.isArray(sinVia) ? sinVia : {};
    const modosPorSerial = normalizarModos(modos);

    const vistos = new Set();
    const filas = [];

    for (const serial of conectadosList) {
        if (vistos.has(serial)) continue;
        vistos.add(serial);
        const modo = Object.prototype.hasOwnProperty.call(modosPorSerial, serial)
            ? modosPorSerial[serial] : MODOS_CONEXION.automatica;
        const via = viasPorSerial[serial] || '';
        const etiqueta = etiquetaVia(via);
        filas.push({
            serial, modo, via, disponible: true,
            estado: etiqueta ? 'por ' + etiqueta : ''
        });
    }

    for (const serial of Object.keys(sinViaPorSerial)) {
        if (vistos.has(serial)) continue;
        vistos.add(serial);
        const modo = Object.prototype.hasOwnProperty.call(modosPorSerial, serial)
            ? modosPorSerial[serial] : MODOS_CONEXION.automatica;
        const modoBloqueado = sinViaPorSerial[serial];
        const palabra = modoBloqueado === MODOS_CONEXION.usb ? 'cable'
            : modoBloqueado === MODOS_CONEXION.bluetooth ? 'Bluetooth' : '';
        filas.push({
            serial, modo, via: '', disponible: false,
            estado: palabra ? 'sin conexión por ' + palabra : ''
        });
    }

    return filas;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        VIAS, MODOS_CONEXION, clasificarVia, elegirVia, rutasPorTelefono,
        normalizarModos, etiquetaVia, etiquetaModo, filasDeTelefonos
    };
}
