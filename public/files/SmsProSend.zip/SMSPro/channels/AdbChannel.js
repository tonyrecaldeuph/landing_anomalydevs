/**
 * AdbChannel — traduce la interfaz Channel a comandos adb + uiautomator dump.
 * Vive en adb-bridge-server y en la extensión (via WebChannel parity).
 *
 * No depende de chrome.* — testeable con fixtures XML.
 *
 * Navegación 100% dinámica: cada tap se calcula del centro de los `bounds`
 * reales devueltos por uiautomator dump, nunca de coordenadas fijas. Cada
 * pantalla se confirma por evidencia (resource-id esperado presente) antes
 * de actuar sobre ella — evidencia real capturada en dispositivo (Honor,
 * Google Messages es-EC): lista → nueva conversación → resultado → compositor.
 *
 * Identidad del teléfono: un mismo celular puede aparecer DOS veces en
 * `adb devices` a la vez — una por cable (serial de fábrica) y otra por el
 * puente Bluetooth de un proyecto hermano, que lo publica como
 * `127.0.0.1:70xx`. Si el canal usara el serial de adb como identidad, la
 * campaña vería dos destinos, abriría dos flujos en paralelo sobre la MISMA
 * pantalla de Google Messages y un SMS podría irse al contacto equivocado.
 * Por eso la identidad es `ro.serialno` (el serial que el propio teléfono
 * reporta, igual por cualquier vía) y el serial de adb pasa a ser solo la
 * *ruta*: `this.rutas` traduce identidad → serial de adb de la vía elegida,
 * y el envoltorio `this.execFn` es el ÚNICO punto donde ocurre esa
 * traducción, así que ningún otro método del canal necesita saber de vías.
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const nodeFs = require('fs');
const os = require('os');
const path = require('path');
const execFileAsync = promisify(execFile);
const { VIAS, clasificarVia, rutasPorTelefono, normalizarModos, etiquetaModo } = require('./vias.js');

const MESSAGING_PACKAGE = 'com.google.android.apps.messaging';

// Errores de adb que significan «ese dispositivo ya no está en esta vía»
// (cable desenchufado, puente Bluetooth caído, teléfono revocando la
// autorización). Son los únicos que justifican rehacer las rutas: cualquier
// otro fallo es del comando en sí y rehacer el mapa no lo arreglaría.
const ADB_DISPOSITIVO_AUSENTE = /device '[^']*' not found|device offline|no devices\/emulators found|device unauthorized/i;

// `ro.serialno` llega del teléfono, así que se valida antes de usarlo como
// identidad: un valor con espacios o '|' rompería el framing del protocolo
// del puente o la construcción de un target adb. Si no pasa, NO se fabrica
// identidad con el puerto — se cae al serial de adb de esa vía.
const SERIAL_FISICO_VALIDO = /^[^\s|]+$/;

const RESOURCE_IDS = {
    fab: 'com.google.android.apps.messaging:id/start_chat_fab',
    searchField: 'ContactSearchField',
    composeText: 'com.google.android.apps.messaging:id/compose_message_text',
    sendButton: 'Compose:Draft:Send'
};

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

/**
 * Por cable adb falla enseguida al perder el teléfono; por un enlace
 * Bluetooth degradado el comando queda esperando para siempre y la campaña se
 * cuelga sin error. Esto lo convierte en una caída visible y reintentable.
 */
function conLimite(execFn, limiteMs) {
    return (args) => new Promise((resolver, rechazar) => {
        const reloj = setTimeout(
            () => rechazar(new Error('ADB_TIMEOUT: adb ' + (Array.isArray(args) ? args.join(' ') : args) + ' sin respuesta en ' + limiteMs + ' ms')),
            limiteMs
        );
        Promise.resolve().then(() => execFn(args)).then(
            (salida) => { clearTimeout(reloj); resolver(salida); },
            (err) => { clearTimeout(reloj); rechazar(err); }
        );
    });
}

class AdbChannel {
    /**
     * @param {Object} [opts]
     * @param {string} [opts.adbPath='adb'] - ruta al binario adb
     * @param {Function} [opts.execFn] - función inyectable (args) => Promise<{stdout,stderr}>
     * @param {number} [opts.launchWaitMs=1500] - espera tras relanzar Messages en frío
     * @param {number} [opts.stepWaitMs=900] - espera tras cada tap antes de volver a hacer dump
     * @param {number} [opts.limiteComandoMs=30000] - un comando adb sin respuesta se corta con ADB_TIMEOUT
     */
    constructor(opts = {}) {
        this.adbPath = opts.adbPath || 'adb';
        this.limiteComandoMs = opts.limiteComandoMs !== undefined ? opts.limiteComandoMs : 30000;
        // El exec crudo contra adb. `execFn` ya NO es esto: es el envoltorio que
        // traduce identidad → serial de adb antes de delegar aquí (ver abajo).
        //
        // windowsHide:true evita que cada llamada a adb abra su propia ventana
        // cmd — el server corre sin consola propia (lanzado por el Native
        // Messaging Host) y adb.exe es una app de consola.
        // maxBuffer: en HiOS/XOS (TECNO, Infinix) un volcado de UI pasa de 1 MB
        // — el default de Node rechaza con ERR_CHILD_PROCESS_STDIO_MAXBUFFER y
        // corta la campaña a mitad de contacto. timeout mata el adb.exe que
        // quedó colgado; conLimite corta igual si el comando lo ejecuta otra
        // capa (el puente inyecta su propio execFn).
        const execCrudo = opts.execFn || ((args) => execFileAsync(this.adbPath, args, {
            windowsHide: true, timeout: this.limiteComandoMs, maxBuffer: 10 * 1024 * 1024
        }));
        this.execAdb = conLimite(execCrudo, this.limiteComandoMs);
        // identidad (ro.serialno, o el serial de adb si getprop no sirvió) → serial
        // de adb de la vía elegida. Vacío hasta el primer listTargets(): antes de
        // listar, los targets pasan tal cual y el canal se comporta como siempre.
        this.rutas = new Map();
        // identidad → modo «Solo X» que el usuario forzó y que hoy no tiene vía.
        // Un modo «Solo» nunca cae a otra vía: estos teléfonos se rechazan.
        this.sinVia = new Map();
        this.modos = {};
        // Los pares {serialAdb, fisico} del ÚLTIMO listado. Se guardan para que
        // fijarModos() pueda re-rutear sin volver a sondear los teléfonos: el
        // modo cambia, pero quién está enchufado dónde no.
        this.pares = [];
        // Refresco en vuelo, para que N fallos simultáneos compartan uno solo
        // en vez de lanzar N cadenas `adb devices` + getprop sobre el único
        // enlace RFCOMM del puente (ver actualizarRutas).
        this.refrescoEnVuelo = null;
        this.execFn = (args) => this.ejecutarPorRuta(args);
        this.launchWaitMs = opts.launchWaitMs !== undefined ? opts.launchWaitMs : 1500;
        this.stepWaitMs = opts.stepWaitMs !== undefined ? opts.stepWaitMs : 900;
        this.pollAttempts = opts.pollAttempts !== undefined ? opts.pollAttempts : 6;
        this.dumpAttempts = opts.dumpAttempts !== undefined ? opts.dumpAttempts : 5;
        this.dumpRetryDelayMs = opts.dumpRetryDelayMs !== undefined ? opts.dumpRetryDelayMs : 600;
        this.fs = opts.fs || nodeFs;
        this.tmpDir = opts.tmpDir || os.tmpdir();
    }

    // ── API Channel ────────────────────────────────────────────────

    async listTargets() {
        // Sin argumento: el `adb devices` se hace DENTRO de actualizarRutas,
        // que es la zona deduplicada. Pedirlo acá dejaría fuera del candado la
        // mitad de la cadena y dos listados simultáneos volverían a solaparse.
        return await this.actualizarRutas();
    }

    // ── Vías: identidad del teléfono y ruteo de comandos ───────────

    /**
     * Único punto de traducción identidad → serial de adb. Todo el resto del
     * canal sigue llamando `this.execFn` y no sabe que existen las vías.
     *
     * Passthrough deliberado cuando el target no está en el mapa: así los
     * comandos emitidos antes del primer listTargets() (y los tests que
     * inyectan un target cualquiera) siguen funcionando igual que siempre.
     */
    async ejecutarPorRuta(args) {
        const lista = Array.isArray(args) ? args : [];
        if (lista[0] !== '-s') return await this.execAdb(lista);

        const identidad = lista[1];
        if (this.sinVia.has(identidad)) {
            // Modo «Solo X» sin esa vía: se rechaza en vez de enviar por otra.
            // campaignEngine solo reintenta CARRIER_FAILED, así que este error
            // no es reintentable y el contacto falla una sola vez — buscado.
            const etiqueta = etiquetaModo(this.sinVia.get(identidad));
            throw new Error(`ADB_VIA_NO_DISPONIBLE: el celular ${identidad} no está conectado por la vía elegida (${etiqueta})`);
        }

        const ruteados = this.rutas.has(identidad)
            ? [lista[0], this.rutas.get(identidad), ...lista.slice(2)]
            : lista;
        try {
            return await this.execAdb(ruteados);
        } catch (err) {
            if (ADB_DISPOSITIVO_AUSENTE.test(String((err && err.message) || ''))) {
                // La vía se cayó a mitad de campaña: se rehace el mapa para que
                // el PRÓXIMO comando salga por la vía que quedó viva, pero NO se
                // repite este comando. Reintentar un `send` aquí duplicaría el
                // SMS: adb pudo haber entregado el tap y perder solo la respuesta.
                try {
                    // Deduplicado: si el puente se cayó con N flujos en vuelo,
                    // los N fallos llegan casi juntos y todos esperan el MISMO
                    // refresco en vez de lanzar N sondeos concurrentes.
                    await this.actualizarRutas();
                } catch (_) {
                    // Si ni `adb devices` responde no hay nada que remapear; el
                    // error original sigue siendo el que explica el fallo.
                }
            }
            throw err;
        }
    }

    /**
     * Rehace `rutas` y `sinVia` sondeando la identidad de cada dispositivo.
     * Devuelve las identidades con ruta, en orden de primera aparición.
     *
     * Sin `salidaDevices` lo pide con `adb devices`; con él usa esa salida.
     *
     * DEDUPLICADO: mientras un refresco corre, cualquier otra llamada espera
     * ESE y no arranca el suyo. Sin esto, el puente cayéndose con N flujos en
     * vuelo produce N cadenas `adb devices` + getprop solapadas sobre el único
     * enlace RFCOMM, que es exactamente lo que provoca los errores
     * 10048/10038. Un `salidaDevices` que llegue durante un refresco se
     * descarta a propósito: el refresco en vuelo es igual de fresco o más, y
     * repetir la cadena de getprop es justo lo que hay que evitar.
     */
    actualizarRutas(salidaDevices) {
        if (this.refrescoEnVuelo) return this.refrescoEnVuelo;

        const trabajo = this.sondearYRutear(salidaDevices);
        this.refrescoEnVuelo = trabajo;
        // El candado se libera pase lo que pase. El doble handler evita que un
        // refresco fallido quede como rechazo no manejado por esta cadena de
        // limpieza (quien llamó sí recibe el rechazo).
        trabajo.then(() => {}, () => {}).then(() => {
            if (this.refrescoEnVuelo === trabajo) this.refrescoEnVuelo = null;
        });
        return trabajo;
    }

    /** El trabajo real de un refresco. Siempre por dentro del candado. */
    async sondearYRutear(salidaDevices) {
        const salida = salidaDevices !== undefined && salidaDevices !== null
            ? salidaDevices
            : (await this.execFn(['devices'])).stdout;

        const pares = [];
        // En serie a propósito, nunca con Promise.all: el puente Bluetooth
        // sostiene un ÚNICO enlace RFCOMM y dos sondeos concurrentes provocan
        // errores 10048/10038. parseDevices ya descartó los seriales que no
        // están en estado `device`, así que un unauthorized/offline no gasta
        // un getprop contra un teléfono que no va a responder.
        for (const serialAdb of AdbChannel.parseDevices(salida)) {
            const fisico = await this.serialFisico(serialAdb);
            // El puente es la excepción al fallback: por cable el serial de adb
            // ES el serial de fábrica, así que usarlo como identidad es correcto;
            // pero `127.0.0.1:70xx` es un puerto que el puente asigna, no una
            // identidad. Si se usara, el MISMO teléfono presente por cable (con
            // getprop OK) y por puente (con getprop fallido, el caso probable:
            // puente lento o saturado) se partiría en dos destinos, y la campaña
            // abriría dos flujos sobre la misma pantalla de Google Messages —
            // precisamente el daño que esta identidad existe para evitar. Sin
            // `ro.serialno`, esa vía se descarta en este refresco.
            if (!fisico && clasificarVia(serialAdb) === VIAS.bluetooth) continue;
            pares.push({ serialAdb, fisico });
        }

        this.pares = pares;
        return this.aplicarRutas();
    }

    /**
     * Recalcula `rutas`/`sinVia` desde los pares del último listado y los modos
     * vigentes. Sin I/O: lo comparten el refresco y fijarModos(), así que un
     * cambio de modo re-rutea sin volver a sondear ningún teléfono.
     *
     * Los mapas se construyen aparte y se asignan al final: así nadie observa
     * un estado a medio armar si un comando entra mientras esto corre.
     */
    aplicarRutas() {
        const elegidas = rutasPorTelefono(this.pares, this.modos);
        const rutas = new Map();
        const sinVia = new Map();
        for (const [identidad, serialAdb] of elegidas) {
            if (serialAdb) {
                rutas.set(identidad, serialAdb);
            } else {
                // Ruta '' solo ocurre con un modo «Solo X» cuya vía falta. El
                // hasOwnProperty es necesario, no decorativo: un teléfono cuya
                // identidad fuera "constructor" leería ese valor del prototipo
                // de Object y lo filtraría al mensaje de error.
                const modo = Object.prototype.hasOwnProperty.call(this.modos, identidad)
                    ? this.modos[identidad] : '';
                sinVia.set(identidad, modo);
            }
        }
        this.rutas = rutas;
        this.sinVia = sinVia;
        return [...rutas.keys()];
    }

    /**
     * Pregunta al teléfono su propio serial de fábrica, que es igual por cable
     * y por el puente. Se llama `execAdb` y no `execFn` a propósito: esto corre
     * mientras se arma el mapa de rutas, así que no hay nada que traducir — y
     * pasar por el envoltorio haría que un getprop fallido dispare otro
     * `adb devices`, que a su vez vuelve a hacer getprop, en bucle.
     *
     * Cualquier fallo o valor inservible devuelve '' y el llamador cae al
     * serial de adb: nunca se fabrica una identidad con el puerto del puente.
     */
    async serialFisico(serialAdb) {
        try {
            const { stdout } = await this.execAdb(['-s', serialAdb, 'shell', 'getprop', 'ro.serialno']);
            const valor = String(stdout || '').trim();
            return SERIAL_FISICO_VALIDO.test(valor) ? valor : '';
        } catch (_) {
            // Teléfono ausente/sin autorizar en esta vía: sin identidad propia.
            return '';
        }
    }

    /** identidad → vía EN USO ('usb' | 'wifi' | 'bluetooth'), para el dashboard. */
    viasDeTelefonos() {
        const vias = {};
        for (const [identidad, serialAdb] of this.rutas) {
            vias[identidad] = clasificarVia(serialAdb);
        }
        return vias;
    }

    /** identidad → modo «Solo X» que hoy no consiguió vía (teléfonos bloqueados). */
    telefonosSinVia() {
        const sinVia = {};
        for (const [identidad, modo] of this.sinVia) {
            sinVia[identidad] = modo;
        }
        return sinVia;
    }

    /**
     * Fija los modos por teléfono. Se normaliza lo que llega porque viene del
     * protocolo del puente/dashboard: un modo inventado no debe forzar nada ni
     * dejar un teléfono sin ruta por un valor que nadie eligió.
     */
    fijarModos(modos) {
        this.modos = normalizarModos(modos);
        // Re-rutear YA, no en el próximo listado: entre medio podrían salir
        // comandos, y saldrían por la vía que el usuario acaba de descartar.
        // La invariante vive en la clase, no en el orden en que llame el server.
        this.aplicarRutas();
    }

    async openConversation(target, phone) {
        const listDump = await this.resetToConversationList(target);

        const fab = AdbChannel.findNodeBounds(listDump, RESOURCE_IDS.fab);
        if (!fab) {
            throw new Error('MESSAGES_NOT_FOREGROUND: no se encontró el botón de nueva conversación en la lista, se aborta');
        }
        await this.tap(target, fab);
        await sleep(this.stepWaitMs);

        const { result: field } = await this.pollDump(target, d => AdbChannel.findNodeBounds(d, RESOURCE_IDS.searchField));
        if (!field) {
            throw new Error('MESSAGES_SEARCH_FIELD_NOT_FOUND: no llegó a la pantalla de nueva conversación, se aborta');
        }
        await this.tap(target, field);
        const safePhone = AdbChannel.sanitizeTypedText(phone).replace(/\s/g, '%s');
        await this.execFn(['-s', target, 'shell', 'input', 'text', safePhone]);

        // El resultado de búsqueda puede tardar en aparecer (lookup de contactos/carrier
        // asíncrono) — sondear varias veces en vez de un único dump evita un falso
        // MESSAGES_NO_SEARCH_RESULT en equipos donde ese lookup es más lento.
        const { result: resultRow } = await this.pollDump(target, d => AdbChannel.findFirstClickableBelow(d, field.y2));
        if (!resultRow) {
            throw new Error('MESSAGES_NO_SEARCH_RESULT: no apareció resultado para el número buscado, se aborta');
        }
        await this.tap(target, resultRow);

        // Según la versión de Google Messages, tocar el resultado lleva directo al
        // compositor (visto en Honor) O a una pantalla intermedia de "confirmar
        // destinatario" con botón "Siguiente" sin resource-id (visto en un Xiaomi/MIUI
        // con versión más nueva de la app) — se detectan ambas por evidencia, no se
        // asume una.
        const { dump: firstDump, result: afterResult } = await this.pollDump(target, d => {
            const compose = AdbChannel.findNodeBounds(d, RESOURCE_IDS.composeText);
            if (compose) return { compose };
            const next = AdbChannel.findNodeByText(d, 'Siguiente');
            if (next) return { next };
            return null;
        });
        if (!afterResult) {
            throw new Error('MESSAGES_COMPOSE_NOT_FOUND: no se llegó al compositor de la conversación, se aborta');
        }

        let composeField = afterResult.compose;
        let composeDump = firstDump;
        if (!composeField) {
            await this.tap(target, afterResult.next);
            const polled = await this.pollDump(target, d => AdbChannel.findNodeBounds(d, RESOURCE_IDS.composeText));
            composeField = polled.result;
            composeDump = polled.dump;
            if (!composeField) {
                throw new Error('MESSAGES_COMPOSE_NOT_FOUND: no se llegó al compositor tras confirmar destinatario, se aborta');
            }
        }
        AdbChannel.assertHeaderForPhone(composeDump, phone);
    }

    /**
     * Vuelve a hacer dump hasta `pollAttempts` veces (esperando `stepWaitMs` entre
     * intentos) hasta que `extract(dump)` devuelva un resultado no nulo. Evita fallar
     * ante pantallas que tardan en renderizar (lookup de contactos, equipos más lentos).
     */
    async pollDump(target, extract) {
        let dump = '';
        let result = null;
        for (let attempt = 0; attempt < this.pollAttempts; attempt++) {
            if (attempt > 0) await sleep(this.stepWaitMs);
            try {
                dump = await this.dump(target);
            } catch (err) {
                // dump() ya agotó sus propios reintentos internos (ej. bug intermitente
                // de uiautomator en MIUI) — se cuenta como un intento fallido más del
                // sondeo, no se aborta todo el pollDump por un solo fallo transitorio.
                continue;
            }
            result = extract(dump);
            if (result) break;
        }
        return { dump, result };
    }

    async send(target, text) {
        // Re-dump: una notificación/diálogo pudo robar el foco entre openConversation()
        // y send(); escribir/tapear a ciegas sin confirmar el compositor repite el fallo.
        const dump = await this.dump(target);
        const composeField = AdbChannel.findNodeBounds(dump, RESOURCE_IDS.composeText);
        if (!composeField) {
            throw new Error('MESSAGES_NOT_FOREGROUND: se perdió el compositor de Google Messages antes de enviar, se aborta');
        }
        await this.tap(target, composeField);
        const safeText = AdbChannel.sanitizeTypedText(text).replace(/\s/g, '%s');
        await this.execFn(['-s', target, 'shell', 'input', 'text', safeText]);
        await sleep(this.stepWaitMs);

        // Re-localizar el botón de enviar DESPUÉS de escribir: un mensaje largo
        // puede hacer crecer el compositor a 2+ líneas y desplazar el botón —
        // usar los bounds capturados antes de escribir apunta a una posición vieja.
        const dumpAfterType = await this.dump(target);
        const sendButton = AdbChannel.findNodeBounds(dumpAfterType, RESOURCE_IDS.sendButton);
        if (!sendButton) {
            throw new Error('MESSAGES_NOT_FOREGROUND: no se encontró el botón de enviar tras escribir el mensaje, se aborta');
        }
        // Enter (keyevent 66) inserta salto de línea en el compositor, NO envía.
        // El envío real es el botón Compose:Draft:Send localizado por bounds.
        await this.tap(target, sendButton);
    }

    /**
     * Reinicia Google Messages en frío (force-stop + relanzar) y confirma que
     * quedó en la lista de conversaciones (presencia de start_chat_fab) antes
     * de devolver el control. Navegar con Back en vez de esto es tan frágil
     * como un tap ciego: puede salir de la app hacia el launcher (home) y
     * terminar tocando otro ícono (Calendario, Música).
     */
    /**
     * Empuja la imagen de campaña al dispositivo y dispara un escaneo de medios
     * para que quede visible en la galería. Devuelve la ruta remota.
     *
     * LIMITACIÓN CONOCIDA: esto deja la imagen en el teléfono pero NO la
     * adjunta al mensaje — falta automatizar el selector de galería de Google
     * Messages (tocar el ícono de adjuntar, navegar el picker, elegir la
     * miniatura correcta). Esa parte requiere evidencia de dispositivo real
     * (dump de uiautomator del picker) que no se capturó todavía; implementarla
     * a ciegas repetiría exactamente los bugs de coordenadas fijas que costó
     * tanto corregir en openConversation/send. Ver native-launcher/README.md
     * y la memoria del proyecto para el resto del pendiente.
     */
    async attachImage(target, dataUrl) {
        const match = /^data:image\/(\w+);base64,([\s\S]+)$/.exec(dataUrl || '');
        if (!match) {
            throw new Error('IMAGE_DATA_INVALID: formato de imagen no reconocido, se aborta el adjunto');
        }
        const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
        const buffer = Buffer.from(match[2], 'base64');
        const localPath = path.join(this.tmpDir, `sms-pro-adjunto-${target}-${Date.now()}.${ext}`);
        this.fs.writeFileSync(localPath, buffer);
        try {
            const remotePath = `/sdcard/Pictures/sms_pro_adjunto.${ext}`;
            await this.execFn(['-s', target, 'push', localPath, remotePath]);
            await this.execFn(['-s', target, 'shell', 'am', 'broadcast', '-a', 'android.intent.action.MEDIA_SCANNER_SCAN_FILE', '-d', `file://${remotePath}`]);
            return remotePath;
        } finally {
            try { this.fs.unlinkSync(localPath); } catch (_) { /* best-effort */ }
        }
    }

    async resetToConversationList(target) {
        await this.execFn(['-s', target, 'shell', 'am', 'force-stop', MESSAGING_PACKAGE]);
        await this.execFn(['-s', target, 'shell', 'input', 'keyevent', '224']); // wake
        await this.execFn(['-s', target, 'shell', 'wm', 'dismiss-keyguard']);
        await this.execFn(['-s', target, 'shell', 'monkey', '-p', MESSAGING_PACKAGE, '-c', 'android.intent.category.LAUNCHER', '1']);
        await sleep(this.launchWaitMs);

        const dump = await this.dump(target);
        if (!AdbChannel.findNodeBounds(dump, RESOURCE_IDS.fab)) {
            throw new Error('MESSAGES_NOT_FOREGROUND: no se pudo confirmar la lista de conversaciones de Google Messages, se aborta para evitar acciones en otra app');
        }
        return dump;
    }

    async tap(target, bounds) {
        await this.execFn(['-s', target, 'shell', 'input', 'tap', String(bounds.cx), String(bounds.cy)]);
    }

    async verifySent(target) {
        const dump = await this.dump(target);
        return AdbChannel.parseVerifySent(dump);
    }

    async detectProtocol(target) {
        const dump = await this.dump(target);
        return AdbChannel.parseDetectProtocol(dump);
    }

    async isBlocked(target) {
        const dump = await this.dump(target);
        return AdbChannel.parseIsBlocked(dump);
    }

    // ── Helpers internos ───────────────────────────────────────────

    async dump(target) {
        // uiautomator dump -> /sdcard/window_dump.xml -> cat
        // En algunos ROM (confirmado en MIUI) `uiautomator dump` falla de forma
        // intermitente por un bug interno de carga de tema (ThemeCompatibility),
        // sin relación con la app ni con esta automatización — reintentar absorbe
        // esa inestabilidad puntual del comando en el propio dispositivo.
        let lastErr;
        for (let attempt = 0; attempt < this.dumpAttempts; attempt++) {
            try {
                await this.execFn(['-s', target, 'shell', 'uiautomator', 'dump', '/sdcard/window_dump.xml']);
                const { stdout } = await this.execFn(['-s', target, 'shell', 'cat', '/sdcard/window_dump.xml']);
                return stdout;
            } catch (err) {
                lastErr = err;
                if (attempt < this.dumpAttempts - 1) await sleep(this.dumpRetryDelayMs);
            }
        }
        throw lastErr;
    }

    // ── Parsers puros (testeables sin adb) ─────────────────────────

    /**
     * Ubica un nodo por resource-id y devuelve sus bounds + centro calculado.
     * El centro se calcula siempre de los bounds reales del dump — nunca de
     * una coordenada fija — para no depender de resolución/densidad del equipo.
     */
    static findNodeBounds(xml, resourceId) {
        if (!xml || !resourceId) return null;
        const escaped = resourceId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const patterns = [
            new RegExp('resource-id="' + escaped + '"[^>]*bounds="\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]"'),
            new RegExp('bounds="\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]"[^>]*resource-id="' + escaped + '"')
        ];
        for (const re of patterns) {
            const m = xml.match(re);
            if (m) return AdbChannel.boundsFromMatch(m);
        }
        return null;
    }

    /**
     * Primer nodo clickable="true" cuyo borde superior está por debajo de `aboveY`,
     * en orden de documento (top-to-bottom visual). Se usa para localizar el
     * resultado de búsqueda de un número sin resource-id estable (UI Compose),
     * evitando así depender del texto localizado ("Enviar al ...").
     */
    static findFirstClickableBelow(xml, aboveY) {
        if (!xml) return null;
        const re = /<node[^>]*clickable="true"[^>]*bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/g;
        let m;
        while ((m = re.exec(xml))) {
            const bounds = AdbChannel.boundsFromMatch(m);
            if (bounds.y1 > aboveY) return bounds;
        }
        return null;
    }

    /**
     * Ubica un nodo por su texto exacto y devuelve sus bounds. Solo se usa cuando no
     * hay resource-id disponible (botones sueltos en UI Compose, ej. "Siguiente") —
     * asume idioma es-EC/es como el resto del producto.
     */
    static findNodeByText(xml, text) {
        if (!xml || !text) return null;
        const escaped = text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const re = new RegExp('text="' + escaped + '"[^>]*bounds="\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]"');
        const m = xml.match(re);
        return m ? AdbChannel.boundsFromMatch(m) : null;
    }

    static boundsFromMatch(m) {
        const [, x1, y1, x2, y2] = m.map(Number);
        return { x1, y1, x2, y2, cx: Math.round((x1 + x2) / 2), cy: Math.round((y1 + y2) / 2) };
    }

    /**
     * Limpia texto antes de pasarlo a `adb shell input text`. Dos problemas distintos:
     *
     * 1. `adb shell` une los argumentos y los ejecuta vía `sh -c` en el dispositivo:
     *    sin filtrar, un mensaje con `;`, `&`, `|`, `$()` o backticks puede ejecutar
     *    comandos adicionales no previstos en el teléfono.
     * 2. `InputShellCommand` (el `input text` nativo de Android) lanza
     *    `NullPointerException` ante CUALQUIER carácter no-ASCII — tildes, `ñ`, `¿`,
     *    `¡` — abortando el comando por completo. Se transcriben a su equivalente
     *    ASCII (á→a, ñ→n, ¿/¡ se eliminan) en vez de escaparlos: el mensaje sigue
     *    siendo legible en español, y cualquier no-ASCII que sobreviva a la
     *    transcripción (emojis, etc.) se elimina como red de seguridad.
     */
    static sanitizeTypedText(value) {
        if (value === null || value === undefined) return '';
        const combiningDiacriticals = new RegExp('[̀-ͯ]', 'g');
        const withoutDiacritics = String(value).normalize('NFD').replace(combiningDiacriticals, '');
        const asciiOnly = withoutDiacritics.replace(/[^\x00-\x7F]/g, '');
        return asciiOnly.replace(/['";&|$`<>(){}\\\n\r]/g, '');
    }

    static parseDevices(output) {
        if (!output) return [];
        const lines = output.split('\n').slice(1); // saltar "List of devices attached"
        const devices = [];
        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) continue;
            const parts = trimmed.split(/\s+/);
            if (parts.length >= 2 && parts[1] === 'device') {
                devices.push(parts[0]);
            }
        }
        return devices;
    }

    static parseVerifySent(xml) {
        if (!xml) return true;
        const lower = xml.toLowerCase();
        // Indicadores de fallo: resource-id específico o texto "no se envió"
        const hasFailedIndicator = lower.includes('message_failed_indicator') ||
            lower.includes('no se envi') || // cubre "no se envió" con tilde normalizada
            lower.includes('not sent') ||
            lower.includes('send failed');
        // Prioridad: si hay failed, es false aunque haya otros indicadores de éxito
        if (hasFailedIndicator) return false;
        // Si no hay failed y hay indicador de éxito, es true
        // Incluso si no hay indicador explícito, tratamos como éxito probable (true)
        return true;
    }

    static parseIsBlocked(xml) {
        return !AdbChannel.parseVerifySent(xml);
    }

    static parseDetectProtocol(xml) {
        if (!xml) return 'sms';
        const lower = xml.toLowerCase();
        // Busca chip RCS / Chat en el compose bar
        if (lower.includes('resource-id="com.google.android.apps.messaging:id/compose_message_type"')) {
            if (lower.includes('>chat<') || lower.includes('>rcs<') || lower.includes('rich')) return 'rcs';
            // Extraer texto del nodo específico
            const match = xml.match(/compose_message_type[^>]*text="([^"]*)"/i) ||
                          xml.match(/compose_message_type[^>]*>([^<]*)/i);
            if (match) {
                const txt = match[1].toLowerCase();
                if (txt.includes('chat') || txt.includes('rcs') || txt.includes('rich')) return 'rcs';
            }
        }
        if (lower.includes('chat') && lower.includes('compose')) return 'rcs';
        return 'sms';
    }

    static assertHeaderForPhone(xml, phone) {
        const digits = String(phone).replace(/\D/g, '').slice(-7);
        if (digits.length < 7) return;
        const textContent = xml.replace(/<[^>]*>/g, ' ');
        const headerDigits = textContent.replace(/\D/g, '');
        if (headerDigits.length >= 7 && !headerDigits.includes(digits)) {
            throw new Error(`Conversación incorrecta abierta. Esperaba ...${digits}, header no coincide`);
        }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AdbChannel };
}
