/**
 * protocol — handshake de capacidad y validación fail-closed del arranque ADB.
 *
 * Origen: un dashboard nuevo contra un puente viejo (o viceversa) fallaba en
 * silencio — el puente ignoraba `enabledDevices` y enviaba por TODOS los
 * teléfonos. Funciones puras, sin net/adb/chrome — testeables sin procesos.
 *
 * Reglas:
 * - El puente anuncia `isolation:true` en el mensaje `connected`.
 * - Un `start` sin lista de habilitados se RECHAZA (fail-closed), nunca se
 *   degrada a "todos los conectados": enviar SMS desde el teléfono equivocado
 *   cuesta dinero y reputación; no enviar con mensaje claro es más barato.
 * - El puente también anuncia `vias:true`: un puente sin este campo ignoraría
 *   los modos elegidos por el operador («Solo cable»/«Solo Bluetooth») y
 *   enviaría por la vía que haya, exactamente el anti-objetivo del diseño de
 *   vías (que una elección explícita caiga a otra vía en silencio).
 */

const { selectEnabledTargets } = require('../channels/deviceSelection.js');

const BRIDGE_VERSION = '3.0.6';

const StartRejectCode = {
    DASHBOARD_OUTDATED: 'DASHBOARD_OUTDATED',
    NO_ENABLED_TARGETS: 'NO_ENABLED_TARGETS'
};

/**
 * Mensaje `connected` con anuncio de capacidad. Los dashboards anteriores al
 * handshake ignoran los campos extra sin romperse.
 */
function buildConnectedMessage(port) {
    return { type: 'connected', port, bridgeVersion: BRIDGE_VERSION, isolation: true, vias: true };
}

/**
 * Decide si un mensaje trae modos para aplicar. La usan por igual los
 * handlers `list_devices` y `start` del server, así los dos quedan atados a
 * la misma regla y no pueden desincronizarse (si `start` tuviera su propio
 * chequeo, bastaría un descuido ahí para que una campaña «Solo Bluetooth»
 * arrancara en modo automático — ver nota en el cabezal del archivo).
 *
 * `modos` ausente (dashboard viejo que nunca lo manda) o que no sea un
 * objeto real (array, string, número) NO cuenta: no hay elección que aplicar.
 * El guard existe para no escribir el `modos || {}` ingenuo, que convertiría
 * esa ausencia en un `{}` y BORRARÍA lo que ya estaba fijado de un mensaje
 * anterior (fijarModos reemplaza el mapa entero, no lo combina). Un `{}` que
 * el dashboard manda de verdad SÍ cuenta: es «todos en automática», la
 * elección que queda cuando el operador saca el último «Solo X».
 */
function tieneModosParaAplicar(modos) {
    return !!(modos && typeof modos === 'object' && !Array.isArray(modos));
}

/**
 * Valida los objetivos de un `start`. Devuelve objeto resultado, nunca null:
 * { ok, code, message, targets } con targets siempre un arreglo.
 */
function validateStartTargets(connected, enabled) {
    if (!Array.isArray(enabled)) {
        return {
            ok: false,
            code: StartRejectCode.DASHBOARD_OUTDATED,
            message: 'Dashboard desactualizado: recarga la extensión en chrome://extensions y reintenta',
            targets: []
        };
    }
    const targets = selectEnabledTargets(connected, enabled);
    if (targets.length === 0) {
        return {
            ok: false,
            code: StartRejectCode.NO_ENABLED_TARGETS,
            message: 'Ningún dispositivo habilitado para el envío — habilita al menos un teléfono en la lista',
            targets: []
        };
    }
    return { ok: true, code: 'OK', message: '', targets };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        BRIDGE_VERSION, StartRejectCode, buildConnectedMessage,
        validateStartTargets, tieneModosParaAplicar
    };
}
