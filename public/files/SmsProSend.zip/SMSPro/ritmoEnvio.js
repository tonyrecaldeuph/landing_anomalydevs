/**
 * ritmoEnvio — la pausa entre envíos, fija y decidida por el producto.
 *
 * Antes el usuario elegía «mín» y «máx» en el dashboard (6 a 20 s por
 * defecto). Esa decisión no le sumaba nada y sí le costaba: con valores bajos
 * a veces el texto salía incompleto o el envío no se ejecutaba, y con valores
 * altos la campaña tardaba de más sin ganar nada.
 *
 * El texto incompleto NO lo causaba esta pausa: ocurre dentro de un envío,
 * cuando se manda Enter antes de que el compositor asiente. Eso lo cuidan las
 * verificaciones del canal Web (`COMPOSE_SETTLE_MS`, `waitForSendEnabled`,
 * `waitForInputCleared`, `waitForSendConfirmation` en content.js) y los
 * sondeos del canal ADB, que no se tocan. Por eso esta pausa puede bajar sin
 * arrastrar ese síntoma.
 *
 * Se mantiene una variación aleatoria dentro del rango: una pausa exacta y
 * repetida es patrón de bot y es justo lo que el carrier mira para bloquear.
 *
 * `var` y no `const`: background.js lo carga con importScripts como script
 * clásico y necesita que los nombres queden en el objeto global; un `const` de
 * tope nunca se adjunta ahí. Mismo criterio que channels/vias.js.
 */

var PAUSA_MIN_MS = 3000;
var PAUSA_MAX_MS = 5000;

/**
 * Milisegundos a esperar antes del próximo contacto. `aleatorio` es inyectable
 * para que los tests fijen los extremos del rango sin depender del azar.
 */
function pausaEntreEnviosMs(aleatorio) {
    const dado = typeof aleatorio === 'function' ? aleatorio : Math.random;
    const rango = PAUSA_MAX_MS - PAUSA_MIN_MS;
    return PAUSA_MIN_MS + Math.floor(dado() * (rango + 1));
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PAUSA_MIN_MS, PAUSA_MAX_MS, pausaEntreEnviosMs };
}
