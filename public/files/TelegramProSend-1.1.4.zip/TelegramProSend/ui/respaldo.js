/**
 * Respaldo exportable del dashboard (historial, promociones y dispositivo).
 * Existe porque la migración de ID de la 1.2.0 borra el `chrome.storage`
 * de la extensión actual: el cliente descarga este `.json` antes y lo
 * reimporta en la nueva versión. Módulo puro (sin `chrome`, sin DOM).
 */

var _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

_root.Respaldo = _root.Respaldo || {
    CLAVES: ['history', 'promotions', 'licenseDeviceId'],

    /**
     * Arma el objeto de respaldo con el formato exacto de la 1.1.4.
     * Solo lee `history`, `promotions` y `licenseDeviceId`; la clave
     * y el estado de licencia nunca se exportan. Faltantes o tipos
     * inválidos se reemplazan por `[]` o `''` (sin null).
     * @param {Object} datos - Lo devuelto por `chrome.storage.local.get(CLAVES)`.
     * @param {string} exportadoEn - Fecha ISO de exportación.
     * @param {string} versionExtension - Versión del manifest.
     * @returns {Object} - Respaldo listo para `JSON.stringify`.
     */
    armar(datos, exportadoEn, versionExtension) {
        const fuente = datos || {};
        return {
            formato: 1,
            producto: 'TelegramProSend',
            versionExtension: versionExtension,
            exportadoEn: exportadoEn,
            history: Array.isArray(fuente.history) ? fuente.history : [],
            promotions: Array.isArray(fuente.promotions) ? fuente.promotions : [],
            licenseDeviceId: typeof fuente.licenseDeviceId === 'string' ? fuente.licenseDeviceId : ''
        };
    },

    /**
     * Nombre del archivo a descargar a partir de la fecha de exportación (UTC).
     * @param {string} exportadoEn - Fecha ISO de exportación.
     * @returns {string} - `TelegramProSend-respaldo-AAAA-MM-DD.json`.
     */
    nombreArchivo(exportadoEn) {
        return 'TelegramProSend-respaldo-' + String(exportadoEn).slice(0, 10) + '.json';
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = _root.Respaldo;
}
