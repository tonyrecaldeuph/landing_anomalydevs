/**
 * whatsappTargets — objetivos compuestos `"<serial>|<paquete>"` y candado por
 * serial. Funciones puras + un candado en memoria: sin adb ni chrome.*.
 *
 * Un telefono puede tener los dos WhatsApps (personal `com.whatsapp` y
 * Business `com.whatsapp.w4b`), y con la app dual del sistema activada, dos
 * copias de cada uno. El clon NO es otro paquete: Android lo corre como otro
 * usuario del sistema con el mismo nombre de paquete, asi que el target lleva
 * los tres datos — `"<serial>|<paquete>|<usuario>"` — y sigue siendo un string,
 * asi que `channels/deviceSelection.js` (que compara contra un Set de strings)
 * y el protocolo del puente no cambian.
 *
 * Los dos paquetes de UN telefono comparten una sola pantalla: si corrieran en
 * paralelo, los taps de uno caerian sobre la pantalla del otro y el mensaje
 * saldria al contacto equivocado. `crearCandadoPorSerial()` los pone en fila
 * por serial, dejando en paralelo los telefonos distintos — que es lo que hace
 * rendir la campania.
 */

const SEPARADOR = '|';

// Usuario principal de Android. Cualquier otro id es una copia hecha con la
// app dual del sistema.
const USUARIO_PRINCIPAL = '0';

const PAQUETES = Object.freeze({
    personal: 'com.whatsapp',
    business: 'com.whatsapp.w4b'
});

// Orden de preferencia cuando hay que elegir (p.ej. al listar un telefono con
// ambos): primero el personal.
const PAQUETES_SOPORTADOS = Object.freeze([PAQUETES.personal, PAQUETES.business]);

const ETIQUETAS = Object.freeze({
    [PAQUETES.personal]: 'WhatsApp',
    [PAQUETES.business]: 'Business'
});

function crearTarget(serial, paquete, usuario) {
    const limpio = String(serial || '').trim();
    if (!limpio || limpio.includes(SEPARADOR)) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: serial invalido ' + JSON.stringify(serial));
    }
    if (!PAQUETES_SOPORTADOS.includes(paquete)) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: paquete no soportado ' + JSON.stringify(paquete));
    }
    const usuarioTexto = String(usuario === undefined || usuario === null ? '' : usuario).trim();
    if (!/^\d+$/.test(usuarioTexto)) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: usuario invalido ' + JSON.stringify(usuario));
    }
    return limpio + SEPARADOR + paquete + SEPARADOR + usuarioTexto;
}

/**
 * Estricto a proposito, incluso con los targets heredados de dos campos: un
 * target sin usuario dejaria al canal eligiendo cuenta por su cuenta en un
 * telefono con app dual, y el envio saldria por la cuenta equivocada. Mejor
 * fallar nombrando el formato.
 */
function parsearTarget(target) {
    const formato = '"<serial>|<paquete>|<usuario>"';
    if (typeof target !== 'string' || !target.includes(SEPARADOR)) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: se esperaba ' + formato + ', llego ' + JSON.stringify(target));
    }
    const partes = target.split(SEPARADOR);
    if (partes.length !== 3) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: se esperaba ' + formato + ', llego ' + JSON.stringify(target));
    }
    const [serial, paquete, usuario] = partes;
    if (!serial) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: serial vacio en ' + JSON.stringify(target));
    }
    if (!PAQUETES_SOPORTADOS.includes(paquete)) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: paquete no soportado en ' + JSON.stringify(target));
    }
    if (!/^\d+$/.test(usuario)) {
        throw new Error('WHATSAPP_ADB_TARGET_INVALIDO: usuario invalido en ' + JSON.stringify(target));
    }
    return { serial, paquete, usuario };
}

function serialDe(target) {
    return parsearTarget(target).serial;
}

function paqueteDe(target) {
    return parsearTarget(target).paquete;
}

function usuarioDe(target) {
    return parsearTarget(target).usuario;
}

/**
 * Texto para la lista de cuentas habilitadas: "ABC123 · Business (clon)". El
 * usuario 0 es la instalacion principal; cualquier otro es una copia de app
 * dual, y el operador necesita distinguirlas para elegir cual usa.
 */
function etiquetaTarget(target) {
    const { serial, paquete, usuario } = parsearTarget(target);
    const sufijo = usuario === USUARIO_PRINCIPAL ? '' : ' (clon)';
    return serial + ' · ' + ETIQUETAS[paquete] + sufijo;
}

/**
 * Usuarios del sistema, desde `adb -s <serial> shell pm list users`:
 *
 *   Users:
 *       UserInfo{0:Propietario:c13} running
 *       UserInfo{999:WhatsApp dual:400000010} running
 *
 * Salida inesperada -> [] (nunca null): un telefono sin app dual trae un solo
 * usuario, y uno que no responde no es un error del parser.
 */
function parseUsuarios(salida) {
    const usuarios = [];
    const re = /UserInfo\{(\d+):([^:]*):/g;
    let m;
    while ((m = re.exec(String(salida || '')))) {
        usuarios.push({ id: m[1], nombre: m[2].trim() });
    }
    return usuarios;
}

/**
 * Cola por serial: `ejecutar(target, fn)` espera lo que haya en curso en ESE
 * telefono y devuelve lo que devuelva `fn`. El eslabon se encadena con
 * `.then(() => ...)` sobre una promesa que nunca rechaza, asi que un contacto
 * que falla no deja el telefono trabado.
 */
function crearCandadoPorSerial() {
    const colas = new Map(); // serial -> promesa del ultimo trabajo encolado

    // async: un target invalido vuelve como rechazo, no como throw sincronico,
    // para que quien llama lo trate igual que cualquier error del canal. El
    // cuerpo encola antes de ceder, asi que el turno queda tomado al llamar.
    async function ejecutar(target, fn) {
        const { serial } = parsearTarget(target);
        const anterior = colas.get(serial) || Promise.resolve();
        const trabajo = anterior.then(() => fn());
        // La cola se encadena sobre la version "silenciosa": el rechazo lo
        // recibe quien llamo, no el siguiente en la fila.
        colas.set(serial, trabajo.then(() => undefined, () => undefined));
        return trabajo;
    }

    return { ejecutar };
}

// Export dual como channels/deviceSelection.js: Node (canal/puente/tests) +
// globalThis (el dashboard lo carga como <script>, sin require).
const API = {
    SEPARADOR,
    USUARIO_PRINCIPAL,
    PAQUETES,
    PAQUETES_SOPORTADOS,
    ETIQUETAS,
    crearTarget,
    parsearTarget,
    serialDe,
    paqueteDe,
    usuarioDe,
    etiquetaTarget,
    parseUsuarios,
    crearCandadoPorSerial
};

const _rootTargets = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});
_rootTargets.WhatsAppTargets = API;

if (typeof module !== 'undefined' && module.exports) {
    module.exports = API;
}
