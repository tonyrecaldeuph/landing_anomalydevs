/**
 * cuotas — tope diario de envios por cuenta de WhatsApp, guardado en un JSON
 * del puente. `fs` y `hoy` inyectables para tests.
 *
 * Mandar demasiados mensajes desde una misma cuenta termina en baneo: el tope
 * reparte el volumen entre las cuentas habilitadas (hasta 4 por celular con la
 * app dual). El contador vive en disco, no en el navegador, porque una cuota
 * que se pierde al cerrar Chrome no es una cuota.
 *
 * La clave es el target completo (`"<serial>|<paquete>|<usuario>"`): el canal no
 * conoce el numero de telefono propio de cada cuenta. Reinstalar el clon cambia
 * su id de usuario y su contador arranca de cero.
 */

const fsReal = require('fs');

const TOPE_POR_DEFECTO = 150;

function fechaLocalHoy() {
    const d = new Date();
    const mes = String(d.getMonth() + 1).padStart(2, '0');
    const dia = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mes + '-' + dia;
}

function crearCuotas(opts) {
    const o = opts || {};
    const ruta = o.ruta || '';
    const fs = o.fs || fsReal;
    const hoy = typeof o.hoy === 'function' ? o.hoy : fechaLocalHoy;
    const tope = o.tope === undefined || o.tope === null ? TOPE_POR_DEFECTO : Number(o.tope);

    /**
     * Caso especial: cualquier lectura que no sea un registro de HOY vuelve
     * como `{}`. Un archivo ausente, a medio escribir o de ayer no es un error:
     * significa que esta jornada arranca en cero.
     */
    function leerDelDia() {
        try {
            const obj = JSON.parse(String(fs.readFileSync(ruta, 'utf-8')));
            if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return {};
            if (obj.fecha !== hoy()) return {};
            const porTarget = obj.porTarget;
            if (!porTarget || typeof porTarget !== 'object' || Array.isArray(porTarget)) return {};
            const limpio = {};
            for (const clave of Object.keys(porTarget)) {
                const n = Number(porTarget[clave]);
                if (Number.isFinite(n) && n > 0) limpio[clave] = Math.floor(n);
            }
            return limpio;
        } catch (_) {
            return {};
        }
    }

    function guardar(porTarget) {
        // Atomico: primero el .tmp y despues rename, para que un corte no deje
        // el JSON a medias y la cuota del dia se pierda.
        const temporal = ruta + '.tmp';
        fs.writeFileSync(temporal, JSON.stringify({ fecha: hoy(), porTarget }));
        fs.renameSync(temporal, ruta);
    }

    function enviadosDe(target) {
        const n = leerDelDia()[target];
        return Number.isFinite(n) && n > 0 ? n : 0;
    }

    /** Un tope <= 0 significa "sin cuota", nunca "ilimitado". */
    function restante(target) {
        if (!Number.isFinite(tope) || tope <= 0) return 0;
        const queda = tope - enviadosDe(target);
        return queda > 0 ? queda : 0;
    }

    function disponible(target) {
        return restante(target) > 0;
    }

    function registrar(target) {
        const porTarget = leerDelDia();
        const siguiente = (porTarget[target] || 0) + 1;
        porTarget[target] = siguiente;
        guardar(porTarget);
        return siguiente;
    }

    function estado() {
        return { fecha: hoy(), tope, porTarget: leerDelDia() };
    }

    return { disponible, registrar, restante, estado };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { crearCuotas, TOPE_POR_DEFECTO };
}
