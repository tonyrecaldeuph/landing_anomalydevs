/**
 * sesion — maneja el protocolo del puente ADB de WhatsApp sobre un WebSocket.
 *
 * Lógica pura/inyectable (sin net ni adb directos): `crearSesion(deps)` deja
 * `manejar(msg, enviar)` donde `enviar(obj)` manda un mensaje al cliente.
 * Sobrevive a clientes desconectados: un `enviar` que lanza nunca corta la
 * campaña en curso.
 */

const { CampaignEngine } = require('../campaignEngine.js');
const { withEnabledTargets } = require('../channels/deviceSelection.js');
const { Codigo, validarInicio } = require('./protocol.js');
const path = require('path');
const { crearCuotas: crearCuotasReal } = require('./cuotas.js');

// Espaciado entre envios de UNA misma cuenta, en segundos. Mandar uno tras
// otro desde la misma cuenta es lo que termina en baneo.
const ESPACIADO_MIN_S = 40;
const ESPACIADO_MAX_S = 90;

// Junto al resultado durable del puente (bridge/ultima-campania.json), en la
// carpeta instalada: el conteo del dia tiene que sobrevivir al reinicio.
const RUTA_CUOTAS = path.join(__dirname, 'cuotas-diarias.json');

const STOP_FORZADO_MS = 30000;

// Caso especial: estado sin campaña (nunca undefined — regla sin-null).
// Todo motor asignado se marca con `enCurso = true`; al terminar vuelve aquí.
const SIN_CAMPANIA = Object.freeze({
    enCurso: false,
    contacts: Object.freeze([]),
    results: Object.freeze([]),
    aborted: false,
    abort() {}
});

function crearCanalReal() {
    // Require perezoso: sesion.test.js inyecta crearCanal y no necesita cargar
    // el canal real (child_process + adb).
    const { WhatsAppAdbChannel } = require('../channels/WhatsAppAdbChannel.js');
    return new WhatsAppAdbChannel(process.env.ADB_PATH ? { adbPath: process.env.ADB_PATH } : {});
}

function crearMotorReal(opts) {
    return new CampaignEngine(opts);
}

function nuevoIdReal() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function ahoraReal() {
    return new Date().toISOString();
}

function crearSesion(deps) {
    const d = deps || {};
    const crearCanal = d.crearCanal || crearCanalReal;
    const crearMotor = d.crearMotor || crearMotorReal;
    const almacen = d.almacen || { guardar: () => {}, leer: () => [], confirmar: () => false };
    const nuevoId = d.nuevoId || nuevoIdReal;
    const ahora = d.ahora || ahoraReal;
    const temporizar = d.temporizar || setTimeout;
    // Cuotas diarias por cuenta. Inyectable para tests; en produccion el JSON
    // vive junto al resultado durable del puente.
    const crearCuotasDep = d.crearCuotas || crearCuotasReal;

    let motor = SIN_CAMPANIA;
    // Un solo canal por sesion: los turnos por telefono y las cuentas ya
    // verificadas valen entre mensajes. Con un canal por mensaje, buscar
    // cuentas durante una campania usaria otro candado y relanzaria WhatsApp
    // a mitad de un envio.
    let canalCompartido = null;
    let campanaId = '';
    let vigente = 0;

    /** Crea el canal la primera vez; si falla (sin adb) se reintenta en el proximo mensaje. */
    function obtenerCanal() {
        if (!canalCompartido) canalCompartido = crearCanal();
        return canalCompartido;
    }

    function enviarSeguro(enviar, obj) {
        try {
            enviar(obj);
        } catch (_) { /* cliente desconectado: la campaña sigue */ }
    }

    function errorSeguro(enviar, code, message) {
        enviarSeguro(enviar, { type: 'error', code, message });
    }

    async function manejar(msg, enviar) {
        const pedido = msg || {};
        switch (pedido.type) {
            case 'list_devices': {
                try {
                    const canal = obtenerCanal();
                    // "Buscar cuentas" pide verificar: un clon pudo registrar su numero
                    if (pedido.verificar === true) canal.olvidarVerificacion();
                    const devices = await canal.listTargets();
                    enviarSeguro(enviar, {
                        type: 'devices',
                        devices: Array.isArray(devices) ? devices : [],
                        sinSesion: canal.cuentasSinSesion()
                    });
                } catch (err) {
                    errorSeguro(enviar, Codigo.ADB_NOT_FOUND, err && err.message ? err.message : 'adb no disponible');
                }
                return;
            }
            case 'start': {
                if (motor.enCurso) {
                    errorSeguro(enviar, Codigo.CAMPAIGN_RUNNING, 'Ya hay una campaña en curso');
                    return;
                }
                const contactos = Array.isArray(pedido.contacts) ? pedido.contacts : [];
                if (contactos.length === 0) {
                    errorSeguro(enviar, Codigo.EMPTY_CONTACTS, 'Sin contactos para enviar: carga al menos un contacto');
                    return;
                }
                let canal;
                try {
                    canal = obtenerCanal();
                } catch (err) {
                    errorSeguro(enviar, Codigo.ADB_NOT_FOUND, err && err.message ? err.message : 'adb no disponible');
                    return;
                }
                let conectados;
                try {
                    conectados = await canal.listTargets();
                } catch (err) {
                    errorSeguro(enviar, Codigo.ADB_NOT_FOUND, err && err.message ? err.message : 'adb no disponible');
                    return;
                }
                const validacion = validarInicio(conectados, pedido);
                if (!validacion.ok) {
                    errorSeguro(enviar, validacion.code, validacion.message);
                    return;
                }
                const id = nuevoId();
                const targets = validacion.targets;
                const configPedido = pedido.config && typeof pedido.config === 'object' ? pedido.config : {};
                const cuotas = crearCuotasDep({
                    ruta: RUTA_CUOTAS,
                    tope: configPedido.tope
                });
                // El espaciado va al final: ningun pedido puede acelerar el envio
                // por debajo de 40-90 s (un dashboard viejo mandaba 6-20 s).
                const config = Object.assign({}, configPedido, {
                    delayMin: ESPACIADO_MIN_S,
                    delayMax: ESPACIADO_MAX_S
                });
                const engine = crearMotor({
                    contacts: contactos,
                    template: pedido.template || '',
                    messageVariants: Array.isArray(pedido.messageVariants) ? pedido.messageVariants : [],
                    channels: [withEnabledTargets(canal, pedido.enabledDevices)],
                    config: config,
                    imageDataUrl: pedido.imageDataUrl || '',
                    cuotaDisponible: (target) => cuotas.disponible(target),
                    registrarEnvio: (target) => cuotas.registrar(target)
                });
                motor = engine;
                motor.enCurso = true;
                campanaId = id;
                vigente += 1;
                const turno = vigente;
                enviarSeguro(enviar, { type: 'started', campaignId: id, devices: targets, total: contactos.length });
                const alProgresar = (progreso) => {
                    // Cada contacto queda en disco al momento: si el puente muere
                    // a mitad de campania, lo enviado se recupera como interrumpido
                    // y "Retomar envio" no lo vuelve a mandar.
                    try {
                        almacen.guardar({
                            campaignId: id,
                            results: Array.isArray(engine.results) ? engine.results.slice() : [progreso],
                            stopped: false,
                            enCurso: true,
                            total: contactos.length
                        });
                    } catch (err) {
                        console.error('[whatsapp-bridge] no se pudo guardar el progreso:', err && err.message ? err.message : err);
                    }
                    enviarSeguro(enviar, {
                        type: 'progress',
                        campaignId: id,
                        index: progreso.index,
                        phone: progreso.phone,
                        status: progreso.status,
                        target: progreso.target
                    });
                };
                let salida;
                try {
                    salida = await engine.run(alProgresar);
                } catch (err) {
                    if (turno !== vigente) return; // done ya forzado por stop
                    const abortado = (engine && engine.aborted) || (err && err.message && err.message.includes('ABORTED'));
                    const resultados = (engine && Array.isArray(engine.results) && engine.results) || [];
                    if (abortado) {
                        almacen.guardar({ campaignId: id, results: resultados, stopped: true, terminadaEn: ahora() });
                        motor = SIN_CAMPANIA;
                        campanaId = '';
                        enviarSeguro(enviar, Object.assign({ type: 'quota' }, cuotas.estado()));
                        enviarSeguro(enviar, { type: 'done', campaignId: id, results: resultados, stopped: true });
                    } else {
                        almacen.guardar({ campaignId: id, results: resultados, stopped: true, terminadaEn: ahora() });
                        motor = SIN_CAMPANIA;
                        campanaId = '';
                        errorSeguro(enviar, Codigo.CAMPANIA_FALLIDA, err && err.message ? err.message : 'Error en la campaña');
                        enviarSeguro(enviar, Object.assign({ type: 'quota' }, cuotas.estado()));
                        enviarSeguro(enviar, { type: 'done', campaignId: id, results: resultados, stopped: true });
                    }
                    return;
                }
                if (turno !== vigente) return; // done ya forzado por stop
                const resultados = (salida && Array.isArray(salida.results) && salida.results)
                    || (engine && Array.isArray(engine.results) && engine.results) || [];
                const detenido = !!engine.aborted;
                almacen.guardar({ campaignId: id, results: resultados, stopped: detenido, terminadaEn: ahora() });
                motor = SIN_CAMPANIA;
                campanaId = '';
                enviarSeguro(enviar, Object.assign({ type: 'quota' }, cuotas.estado()));
                enviarSeguro(enviar, { type: 'done', campaignId: id, results: resultados, stopped: detenido });
                return;
            }
            case 'stop': {
                if (motor.enCurso) {
                    try {
                        motor.abort();
                    } catch (_) { /* abortar nunca rompe el stop */ }
                    const turno = vigente;
                    const motorParado = motor;
                    const idParado = campanaId;
                    temporizar(() => {
                        if (turno !== vigente || !motor.enCurso) return;
                        const resultados = (motorParado && Array.isArray(motorParado.results) && motorParado.results) || [];
                        almacen.guardar({ campaignId: idParado, results: resultados, stopped: true, terminadaEn: ahora() });
                        motor = SIN_CAMPANIA;
                        campanaId = '';
                        vigente += 1;
                        enviarSeguro(enviar, { type: 'done', campaignId: idParado, results: resultados, stopped: true });
                    }, STOP_FORZADO_MS);
                }
                enviarSeguro(enviar, { type: 'stopping' });
                return;
            }
            case 'status': {
                // La campania viva no es un resultado pendiente de confirmar; una
                // entrada todavia "en curso" que no es la viva quedo cortada (el
                // puente murio a mitad) y se informa como interrumpida.
                const sinConfirmar = almacen.leer()
                    .filter((e) => !(motor.enCurso && e.campaignId === campanaId))
                    .map((e) => Object.assign({}, e, { interrumpida: e.enCurso === true }));
                enviarSeguro(enviar, {
                    type: 'status',
                    isRunning: motor.enCurso,
                    campaignId: motor.enCurso ? campanaId : '',
                    total: Array.isArray(motor.contacts) ? motor.contacts.length : 0,
                    progressIndex: Array.isArray(motor.results) ? motor.results.length : 0,
                    results: Array.isArray(motor.results) ? motor.results.slice() : [],
                    sinConfirmar
                });
                return;
            }
            case 'ack': {
                const ok = almacen.confirmar(pedido.campaignId);
                enviarSeguro(enviar, { type: 'acked', campaignId: pedido.campaignId, ok });
                return;
            }
            default: {
                errorSeguro(enviar, Codigo.TIPO_DESCONOCIDO, 'Tipo desconocido: ' + pedido.type);
            }
        }
    }

    return { manejar };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { crearSesion, SIN_CAMPANIA };
}
