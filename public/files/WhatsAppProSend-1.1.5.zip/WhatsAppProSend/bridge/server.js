/**
 * server — HTTP + WebSocket del puente ADB de WhatsApp en 127.0.0.1:8766.
 *
 * `crearServidor` solo cablea: la campaña vive en `sesion.js`. Si este archivo
 * se ejecuta directo (`node server.js`) arranca la sesión real.
 */

const http = require('http');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const { BRIDGE_VERSION, PUERTO, Codigo, mensajeConectado } = require('./protocol.js');
const { crearSesion } = require('./sesion.js');
const { crearAlmacen } = require('./resultadoDurable.js');

function crearServidor(opts) {
    const o = opts || {};
    const puerto = o.puerto !== undefined ? o.puerto : PUERTO;
    const host = o.host || '127.0.0.1';
    // Caso especial: sin sesión inyectada se responde TIPO_DESCONOCIDO
    // (nunca undefined — regla sin-null).
    const sesion = o.sesion || {
        manejar(msg, enviar) {
            const pedido = msg || {};
            enviar({ type: 'error', code: Codigo.TIPO_DESCONOCIDO, message: 'Tipo desconocido: ' + pedido.type });
        }
    };
    const intervaloPingMs = o.intervaloPingMs !== undefined ? o.intervaloPingMs : 20000;

    const httpServer = http.createServer((req, res) => {
        if (req.method === 'GET' && req.url === '/health') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true, bridgeVersion: BRIDGE_VERSION }));
            return;
        }
        res.writeHead(404);
        res.end('Not found');
    });

    const wss = new WebSocketServer({ server: httpServer });

    wss.on('connection', (ws) => {
        const enviarSolo = (obj) => {
            try {
                if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
            } catch (_) { /* cliente desconectado */ }
        };
        // Lo que la sesión envía (progress/done/eco) se DIFUNDE a todos los
        // clientes: el SW reconectado con un socket nuevo no pierde el vivo.
        // Solo `connected` y JSON_INVALIDO van al socket que corresponde.
        const difundir = (obj) => {
            const texto = JSON.stringify(obj);
            wss.clients.forEach((otro) => {
                try {
                    if (otro.readyState === WebSocket.OPEN) otro.send(texto);
                } catch (_) { /* cliente desconectado */ }
            });
        };
        enviarSolo(mensajeConectado());
        ws.on('message', (data) => {
            let msg;
            try {
                msg = JSON.parse(data.toString());
            } catch (_) {
                enviarSolo({ type: 'error', code: Codigo.JSON_INVALIDO, message: 'JSON inválido' });
                return;
            }
            try {
                const r = sesion.manejar(msg, difundir);
                if (r && typeof r.catch === 'function') {
                    r.catch((err) => difundir({ type: 'error', code: Codigo.CAMPANIA_FALLIDA, message: err && err.message ? err.message : 'Error en la campaña' }));
                }
            } catch (err) {
                difundir({ type: 'error', code: Codigo.CAMPANIA_FALLIDA, message: err && err.message ? err.message : 'Error en la campaña' });
            }
        });
    });

    const pingTimer = setInterval(() => {
        wss.clients.forEach((ws) => {
            try {
                if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'ping' }));
            } catch (_) { /* cliente desconectado */ }
        });
    }, intervaloPingMs);
    if (pingTimer.unref) pingTimer.unref();

    function escuchar() {
        return new Promise((resolve, reject) => {
            // El 'error' de listen (p. ej. EADDRINUSE) lo re-emite el
            // WebSocketServer, así que se escucha en ambos.
            const alFallar = (err) => {
                httpServer.removeListener('error', alFallar);
                wss.removeListener('error', alFallar);
                clearInterval(pingTimer);
                reject(err);
            };
            httpServer.once('error', alFallar);
            wss.once('error', alFallar);
            httpServer.listen(puerto, host, () => {
                httpServer.removeListener('error', alFallar);
                wss.removeListener('error', alFallar);
                const info = httpServer.address();
                resolve(info && typeof info === 'object' ? info.port : puerto);
            });
        });
    }

    function cerrar() {
        return new Promise((resolve) => {
            clearInterval(pingTimer);
            try {
                wss.clients.forEach((ws) => { try { ws.terminate(); } catch (_) {} });
            } catch (_) {}
            wss.close(() => {
                httpServer.close(() => resolve());
            });
        });
    }

    return { escuchar, cerrar };
}

if (require.main === module) {
    const almacen = crearAlmacen({ ruta: path.join(__dirname, 'ultima-campania.json') });
    const sesion = crearSesion({ almacen });
    const servidor = crearServidor({ puerto: PUERTO, sesion });
    servidor.escuchar().then((puertoReal) => {
        console.log('[whatsapp-bridge] escuchando en ws://127.0.0.1:' + puertoReal + ' (puente v' + BRIDGE_VERSION + ')');
    }, (err) => {
        console.error('[whatsapp-bridge] no se pudo escuchar en 127.0.0.1:' + PUERTO + ': ' + (err && err.message ? err.message : err));
        process.exit(1);
    });
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { crearServidor };
}
