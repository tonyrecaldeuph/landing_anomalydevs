/**
 * protocol — versión, puerto, códigos y validación fail-closed del arranque.
 *
 * Funciones puras, sin net/adb/chrome — testeables sin procesos.
 * Un `start` sin lista de habilitados o con imagen se RECHAZA (fail-closed),
 * nunca se degrada a "todos los conectados" ni se envía sin la imagen.
 */

const { selectEnabledTargets } = require('../channels/deviceSelection.js');

const BRIDGE_VERSION = '1.2.0';
const PUERTO = 8766;

const Codigo = Object.freeze({
    DASHBOARD_OUTDATED: 'DASHBOARD_OUTDATED',
    NO_ENABLED_TARGETS: 'NO_ENABLED_TARGETS',
    ADB_NOT_FOUND: 'ADB_NOT_FOUND',
    CAMPAIGN_RUNNING: 'CAMPAIGN_RUNNING',
    EMPTY_CONTACTS: 'EMPTY_CONTACTS',
    IMAGEN_NO_SOPORTADA: 'IMAGEN_NO_SOPORTADA',
    CAMPANIA_FALLIDA: 'CAMPANIA_FALLIDA',
    JSON_INVALIDO: 'JSON_INVALIDO',
    TOPE_INVALIDO: 'TOPE_INVALIDO',
    TIPO_DESCONOCIDO: 'TIPO_DESCONOCIDO'
});

/**
 * Mensaje `connected` con anuncio de capacidad. Los clientes anteriores al
 * handshake ignoran los campos extra sin romperse.
 */
function mensajeConectado() {
    return { type: 'connected', port: PUERTO, bridgeVersion: BRIDGE_VERSION, isolation: true };
}

/**
 * Valida un `start`. Devuelve objeto resultado, nunca null:
 * { ok, code, message, targets } con targets siempre un arreglo.
 * Orden: contacts no vacío -> imageDataUrl vacío -> enabledDevices array ->
 * intersección con conectados no vacía.
 */
function validarInicio(conectados, msg) {
    const pedido = msg || {};
    if (!Array.isArray(pedido.contacts) || pedido.contacts.length === 0) {
        return {
            ok: false,
            code: Codigo.EMPTY_CONTACTS,
            message: 'Sin contactos para enviar: carga al menos un contacto',
            targets: []
        };
    }
    if (pedido.imageDataUrl !== undefined && pedido.imageDataUrl !== null && String(pedido.imageDataUrl) !== '') {
        return {
            ok: false,
            code: Codigo.IMAGEN_NO_SOPORTADA,
            message: 'La campaña trae imagen y el puente aún no envía imágenes: no se envió nada',
            targets: []
        };
    }
    if (!Array.isArray(pedido.enabledDevices)) {
        return {
            ok: false,
            code: Codigo.DASHBOARD_OUTDATED,
            message: 'Dashboard desactualizado: recarga la extensión en chrome://extensions y reintenta',
            targets: []
        };
    }
    // El tope diario por cuenta. Un 0 o un texto dejarian la campania sin cuota
    // o con una cuota indefinida: se rechaza antes de tocar ningun telefono.
    const config = pedido.config && typeof pedido.config === 'object' ? pedido.config : {};
    if (config.tope !== undefined) {
        if (typeof config.tope !== 'number' || !Number.isInteger(config.tope) || config.tope <= 0) {
            return {
                ok: false,
                code: Codigo.TOPE_INVALIDO,
                message: 'El tope diario por cuenta debe ser un numero entero mayor a 0',
                targets: []
            };
        }
    }
    const targets = selectEnabledTargets(conectados, pedido.enabledDevices);
    if (targets.length === 0) {
        return {
            ok: false,
            code: Codigo.NO_ENABLED_TARGETS,
            message: 'Ningún celular habilitado para el envío: habilita al menos un celular en la lista',
            targets: []
        };
    }
    return { ok: true, code: 'OK', message: '', targets };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { BRIDGE_VERSION, PUERTO, Codigo, mensajeConectado, validarInicio };
}
