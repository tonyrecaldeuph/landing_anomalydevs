/**
 * Prueba manual del canal ADB contra un celular real: abre la conversación
 * y envía un mensaje a un solo número, por una sola cuenta.
 *
 * Uso: node scripts/probar-adb.js "<serial>|<paquete>|<usuario>" <telefono> <cedula> "<texto>"
 *      node scripts/probar-adb.js "<serial>|<paquete>|<usuario>" <telefono> <cedula> --sin-enviar
 *
 * --sin-enviar abre el chat y se detiene antes de escribir.
 * El adb se toma de ADB_PATH, igual que el puente.
 */
const { WhatsAppAdbChannel } = require('../channels/WhatsAppAdbChannel.js');
const Targets = require('../channels/whatsappTargets.js');

const USO = 'Uso: node scripts/probar-adb.js "<serial>|<paquete>|<usuario>" <telefono> <cedula> "<texto>" | --sin-enviar';
const SIN_ENVIAR = '--sin-enviar';

async function main([target, telefono, cedula, texto]) {
    if (!target || !telefono || !texto) salirConUso(USO);
    try {
        Targets.parsearTarget(target);
    } catch (err) {
        salirConUso(err.message + '\n' + USO);
    }

    const canal = new WhatsAppAdbChannel(process.env.ADB_PATH ? { adbPath: process.env.ADB_PATH } : {});
    const contacto = cedula ? { 'CÉDULA': cedula } : {};
    console.log('Cuenta:', Targets.etiquetaTarget(target));
    await canal.openConversation(target, telefono, contacto);
    if (texto === SIN_ENVIAR) {
        canal.liberarTurno(target);
        console.log('Chat abierto; no se envió nada (--sin-enviar).');
        return;
    }
    await canal.send(target, texto);
    console.log('verifySent:', await canal.verifySent(target));
}

function salirConUso(mensaje) {
    console.error(mensaje);
    process.exit(2);
}

main(process.argv.slice(2)).catch(err => {
    console.error(err.message);
    process.exit(1);
});
