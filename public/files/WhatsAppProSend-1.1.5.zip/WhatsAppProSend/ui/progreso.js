/**
 * progreso.js — miniventana de progreso de la campaña.
 *
 * El popup de la extensión se cierra al hacer clic fuera; esta página se abre
 * como ventana chica de Chrome (abajo a la derecha) y sigue visible mientras
 * se usa el navegador. Se conecta al puente por su cuenta, igual que el
 * dashboard: pide el estado al abrir y escucha cada contacto procesado.
 *
 * Una ventana de Chrome no puede quedar "siempre encima": al hacer clic en la
 * ventana principal, la miniventana queda detrás. Con "Mantener siempre
 * visible" el panel se muda a un Picture-in-Picture de documento (flota sobre
 * todo; Chrome exige un clic para abrirlo) y la ventana se minimiza. Si se
 * cierra la ventanita, el panel vuelve.
 *
 * `vistaProgreso` es pura y se prueba en Node; el cableado al DOM y al puente
 * solo corre dentro de Chrome.
 */

function _motor() {
    if (typeof require === 'function' && typeof module !== 'undefined' && module.exports) return require('../campaignEngine.js');
    return { summarizeResults: summarizeResults, displayResultLabel: displayResultLabel };
}

function _targets() {
    if (typeof require === 'function' && typeof module !== 'undefined' && module.exports) return require('../channels/whatsappTargets.js');
    return WhatsAppTargets;
}

/**
 * Lo que muestra la ventana a partir del estado del puente:
 * `{enCurso, total, results, terminada?, interrumpida?}`. Sin datos -> vista
 * vacía (nunca null).
 */
function vistaProgreso(estado) {
    var e = estado && typeof estado === 'object' ? estado : {};
    var resultados = Array.isArray(e.results) ? e.results : [];
    var total = Number(e.total) > 0 ? Number(e.total) : 0;
    var resumen = _motor().summarizeResults(resultados);
    var procesados = resultados.length;
    var titulo = 'Sin campaña en curso';
    if (e.enCurso) titulo = 'Enviando ' + procesados + ' de ' + total;
    else if (e.interrumpida) titulo = 'Campaña interrumpida: ' + procesados + ' de ' + total;
    else if (e.terminada) titulo = 'Campaña terminada: ' + procesados + ' de ' + total;
    return {
        titulo: titulo,
        enviados: resumen.enviados,
        sinWhatsApp: resumen.sinWhatsApp,
        errores: resumen.errores,
        procesados: procesados,
        total: total,
        porcentaje: total > 0 ? Math.min(100, Math.round((procesados / total) * 100)) : 0,
        ultimo: textoUltimo(resultados[resultados.length - 1])
    };
}

function textoUltimo(r) {
    if (!r) return '';
    var cuenta = '';
    try {
        cuenta = ' (' + _targets().etiquetaTarget(r.target) + ')';
    } catch (_) { /* sin target valido: se omite */ }
    return (r.phone || '') + ' — ' + _motor().displayResultLabel(r.status || '') + cuenta;
}

// ── Cableado en Chrome ──────────────────────────────────────────────

if (typeof document !== 'undefined' && typeof PuenteClient !== 'undefined') {
    document.addEventListener('DOMContentLoaded', function () {
        var puente = PuenteClient.crearPuenteClient();
        var estado = { enCurso: false, total: 0, results: [] };
        // Referencias guardadas: al mudarse al Picture-in-Picture los nodos
        // cambian de documento y getElementById de esta ventana ya no los ve.
        var el = {
            panel: document.getElementById('panel'),
            titulo: document.getElementById('titulo'),
            barra: document.getElementById('barra-relleno'),
            enviados: document.getElementById('n-enviados'),
            sin: document.getElementById('n-sin'),
            errores: document.getElementById('n-errores'),
            ultimo: document.getElementById('ultimo'),
            fijar: document.getElementById('btn-fijar')
        };

        function pintar() {
            var v = vistaProgreso(estado);
            el.titulo.textContent = v.titulo;
            el.barra.style.width = v.porcentaje + '%';
            el.enviados.textContent = v.enviados;
            el.sin.textContent = v.sinWhatsApp;
            el.errores.textContent = v.errores;
            el.ultimo.textContent = v.ultimo;
        }

        function conectar() {
            el.titulo.textContent = 'Conectando con el puente...';
            puente.conectar().then(function () { puente.pedirEstado(); }, function () {
                el.titulo.textContent = 'Puente apagado. Reintentando...';
                setTimeout(conectar, 5000);
            });
        }

        function mantenerVisible() {
            documentPictureInPicture.requestWindow({ width: 320, height: 190 }).then(function (pip) {
                // Los estilos se copian: la ventanita arranca sin ninguno
                document.querySelectorAll('link[rel="stylesheet"], style').forEach(function (nodo) {
                    pip.document.head.appendChild(nodo.cloneNode(true));
                });
                pip.document.body.appendChild(el.panel);
                el.fijar.hidden = true;
                if (chrome.windows) {
                    chrome.windows.getCurrent(function (w) { chrome.windows.update(w.id, { state: 'minimized' }); });
                }
                pip.addEventListener('pagehide', function () {
                    // Se cerró la ventanita: el panel vuelve a la miniventana
                    document.body.insertBefore(el.panel, el.fijar);
                    el.fijar.hidden = false;
                    if (chrome.windows) {
                        chrome.windows.getCurrent(function (w) { chrome.windows.update(w.id, { state: 'normal', focused: true }); });
                    }
                });
            }, function (err) {
                el.ultimo.textContent = 'No se pudo fijar la ventana: ' + (err && err.message ? err.message : err);
            });
        }

        if (typeof documentPictureInPicture !== 'undefined') {
            el.fijar.hidden = false;
            el.fijar.addEventListener('click', mantenerVisible);
        }

        puente.escuchar('status', function (msg) {
            if (msg.isRunning) {
                estado = { enCurso: true, total: msg.total, results: msg.results || [] };
            } else {
                var cortada = (msg.sinConfirmar || []).filter(function (x) { return x.interrumpida; })[0];
                if (cortada) estado = { enCurso: false, total: cortada.total, results: cortada.results, interrumpida: true };
            }
            pintar();
        });
        puente.escuchar('started', function (msg) {
            estado = { enCurso: true, total: msg.total, results: [] };
            pintar();
        });
        puente.escuchar('progress', function (msg) {
            if (!estado.enCurso) estado = { enCurso: true, total: estado.total, results: [] };
            estado.results = estado.results.filter(function (r) { return r.index !== msg.index; }).concat([msg]);
            pintar();
        });
        puente.escuchar('done', function (msg) {
            estado = { enCurso: false, total: estado.total, results: msg.results || estado.results, terminada: true };
            pintar();
        });
        puente.escuchar('cerrado', function () {
            el.titulo.textContent = 'Se perdió la conexión con el puente. Reintentando...';
            setTimeout(conectar, 5000);
        });

        conectar();
    });
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { vistaProgreso };
}
