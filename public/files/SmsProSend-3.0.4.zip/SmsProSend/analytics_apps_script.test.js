/**
 * analytics_apps_script.test.js — Receptor de analítica, con la planilla simulada.
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function planilla(filasIniciales) {
    const filas = filasIniciales.map((f) => [...f]);
    const hoja = {
        filas,
        appendRow: (fila) => filas.push([...fila]),
        getRange: (fila, col) => ({
            getValue: () => (filas[fila - 1] || [])[col - 1] || '',
            setValue(valor) { filas[fila - 1][col - 1] = valor; return this; },
            setFontWeight() { return this; },
        }),
    };
    return {
        hoja,
        ss: {
            getSheetByName: () => (filas.length ? hoja : null),
            insertSheet: () => hoja,
        },
    };
}

function cargar(ss) {
    const contexto = {
        SpreadsheetApp: { getActiveSpreadsheet: () => ss },
        ContentService: {
            createTextOutput: (t) => ({ setMimeType: () => t }),
            MimeType: { JSON: 'json' },
        },
    };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname, 'analytics_apps_script.js'), 'utf8'), contexto);
    return contexto;
}

const evento = (datos) => ({ postData: { contents: JSON.stringify(datos) } });

(() => {
    // Hoja nueva: encabezado con Producto y la fila con el producto del evento.
    const { hoja, ss } = planilla([]);
    const gs = cargar(ss);
    const respuesta = gs.doPost(evento({ installId: 'inst_1', event: 'dashboard_open', product: 'telegram' }));
    assert.deepStrictEqual(JSON.parse(respuesta), { ok: true });
    assert.strictEqual(hoja.filas[0][8], 'Producto');
    assert.strictEqual(hoja.filas[1][8], 'telegram');
    console.log('OK: registra el producto de cada evento');
})();

(() => {
    // Cliente anterior al campo product: solo podía ser SMS PRO.
    const { hoja, ss } = planilla([]);
    cargar(ss).doPost(evento({ installId: 'inst_2', event: 'dashboard_open' }));
    assert.strictEqual(hoja.filas[1][8], 'sms');
    console.log('OK: un evento sin product se registra como sms');
})();

(() => {
    // Hoja creada antes de la columna: se le agrega el encabezado sin tocar lo demás.
    const viejo = ['Fecha/Hora', 'Install ID', 'Evento', 'Contactos', 'Estado Campaña', 'RCS', 'SMS', 'Errores'];
    const { hoja, ss } = planilla([viejo, ['x', 'inst_0', 'dashboard_open', '', '', '', '', '']]);
    cargar(ss).doPost(evento({ installId: 'inst_3', event: 'campaign_start', product: 'sms' }));
    assert.strictEqual(hoja.filas[0][8], 'Producto');
    assert.strictEqual(hoja.filas[0][0], 'Fecha/Hora');
    assert.strictEqual(hoja.filas.length, 3);
    console.log('OK: agrega el encabezado Producto a una hoja existente');
})();
