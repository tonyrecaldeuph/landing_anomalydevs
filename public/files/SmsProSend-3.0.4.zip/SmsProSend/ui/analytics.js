/**
 * Módulo de analítica — envía eventos al Google Apps Script.
 * Genera un installId único por dispositivo, persistido en chrome.storage.local.
 */

const Analytics = (() => {
    // URL completa del despliegue: con el ID suelto, fetch lo resolvía como un
    // archivo de la extensión y ningún evento llegaba a la planilla.
    const ENDPOINT = 'https://script.google.com/macros/s/AKfycbxDIS90uEHhVFaEJgupIbiixbmSUm-ZXBK7J2fiIyOSpuW7KwKGh7rtd4a8Q3H5U0amsw/exec';
    // La planilla es compartida entre SMS PRO y TelegramProSend: cada evento
    // dice de qué producto viene.
    const PRODUCT = 'sms';

    let _installId = null;

    async function getInstallId() {
        if (_installId) return _installId;
        return new Promise(resolve => {
            chrome.storage.local.get(['analyticsInstallId'], (data) => {
                if (data.analyticsInstallId) {
                    _installId = data.analyticsInstallId;
                    resolve(_installId);
                } else {
                    const newId = 'inst_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
                    chrome.storage.local.set({ analyticsInstallId: newId }, () => {
                        _installId = newId;
                        resolve(_installId);
                    });
                }
            });
        });
    }

    async function track(event, data = {}) {
        try {
            const installId = await getInstallId();
            const payload = {
                installId,
                product: PRODUCT,
                event,
                timestamp: new Date().toISOString(),
                ...data
            };

            // Petición simple (text/plain + no-cors): con application/json el
            // navegador manda antes un OPTIONS que Apps Script no responde y el
            // POST nunca sale. doPost lee el cuerpo igual. La respuesta queda
            // opaca, pero esto es fire-and-forget: no bloquea la UI si falla.
            fetch(ENDPOINT, {
                method: 'POST',
                mode: 'no-cors',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify(payload)
            }).catch(() => {});
        } catch (_) {}
    }

    return { track };
})();
