/**
 * ui/analytics.test.js — Envío de eventos al Apps Script de analítica.
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function cargarAnalytics() {
    const llamadas = [];
    const contexto = {
        chrome: { storage: { local: {
            get: (_claves, cb) => cb({ analyticsInstallId: 'inst_prueba' }),
            set: (_valor, cb) => cb && cb(),
        } } },
        fetch: (url, opciones) => { llamadas.push({ url, opciones }); return Promise.resolve({}); },
    };
    const codigo = fs.readFileSync(path.join(__dirname, 'analytics.js'), 'utf8');
    vm.runInNewContext(`${codigo}\nthis.Analytics = Analytics;`, contexto);
    return { Analytics: contexto.Analytics, llamadas };
}

(async () => {
    // El endpoint es la URL completa del Apps Script: con el ID suelto, fetch lo
    // resolvía como un archivo de la extensión y ningún evento llegaba.
    const { Analytics, llamadas } = cargarAnalytics();
    await Analytics.track('dashboard_open');
    assert.strictEqual(llamadas.length, 1);
    assert.match(llamadas[0].url, /^https:\/\/script\.google\.com\/macros\/s\/AKfycb[\w-]+\/exec$/);
    console.log('OK: analytics envía a la URL completa del Apps Script');

    // Petición simple: con application/json el navegador hace un preflight OPTIONS
    // que Apps Script no responde y el POST nunca sale.
    const { opciones } = llamadas[0];
    assert.strictEqual(opciones.method, 'POST');
    assert.strictEqual(opciones.mode, 'no-cors');
    assert.strictEqual(opciones.headers['Content-Type'], 'text/plain;charset=utf-8');
    console.log('OK: analytics manda una petición simple sin preflight');

    // La planilla es compartida con TelegramProSend: cada evento dice de qué producto viene.
    const cuerpo = JSON.parse(opciones.body);
    assert.strictEqual(cuerpo.product, 'sms');
    assert.strictEqual(cuerpo.event, 'dashboard_open');
    assert.strictEqual(cuerpo.installId, 'inst_prueba');
    console.log('OK: analytics identifica el producto en cada evento');
})().catch((err) => { console.error(err); process.exit(1); });
