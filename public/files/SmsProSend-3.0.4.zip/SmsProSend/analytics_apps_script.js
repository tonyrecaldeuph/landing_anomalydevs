/**
 * Google Apps Script — Receptor de analítica de SMS PRO y TelegramProSend
 *
 * PASOS PARA DESPLEGAR:
 * 1. Ir a https://script.google.com → Nuevo proyecto
 * 2. Pegar este código
 * 3. Guardar (Ctrl+S)
 * 4. Clic en "Implementar" → "Nueva implementación"
 * 5. Tipo: "Aplicación web"
 *    - Ejecutar como: "Yo"
 *    - Quién tiene acceso: "Cualquier usuario"
 * 6. Clic en "Implementar" → Copiar la URL generada
 * 7. Pegar la URL completa (https://script.google.com/macros/s/.../exec) en
 *    ENDPOINT de ui/analytics.js de cada extensión.
 *
 * PARA ACTUALIZAR SIN CAMBIAR LA URL: "Implementar" → "Administrar
 * implementaciones" → editar la implementación activa → Versión: "Nueva
 * versión" → "Implementar". Una "Nueva implementación" genera otra URL.
 */

const SHEET_NAME = 'Eventos';

function doPost(e) {
    try {
        const payload = JSON.parse(e.postData.contents);
        const sheet = getOrCreateSheet();

        sheet.appendRow([
            new Date(payload.timestamp || Date.now()),
            payload.installId || '',
            payload.event || '',
            payload.contactCount || '',
            payload.status || '',
            payload.rcsCount || '',
            payload.smsCount || '',
            payload.errorCount || '',
            // Los clientes anteriores al campo product solo podían ser SMS PRO:
            // la copia de Telegram nunca llegó a enviar eventos.
            payload.product || 'sms'
        ]);

        return ContentService
            .createTextOutput(JSON.stringify({ ok: true }))
            .setMimeType(ContentService.MimeType.JSON);
    } catch (err) {
        return ContentService
            .createTextOutput(JSON.stringify({ ok: false, error: err.message }))
            .setMimeType(ContentService.MimeType.JSON);
    }
}

function getOrCreateSheet() {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);

    if (!sheet) {
        sheet = ss.insertSheet(SHEET_NAME);
        sheet.appendRow([
            'Fecha/Hora',
            'Install ID',
            'Evento',
            'Contactos',
            'Estado Campaña',
            'RCS',
            'SMS',
            'Errores',
            'Producto'
        ]);
        sheet.getRange(1, 1, 1, 9).setFontWeight('bold');
    } else if (!sheet.getRange(1, 9).getValue()) {
        // Hoja creada antes de la columna Producto: se agrega el encabezado.
        sheet.getRange(1, 9).setValue('Producto').setFontWeight('bold');
    }

    return sheet;
}

// Función de prueba — ejecutar manualmente para verificar que escribe bien
function testWrite() {
    const sheet = getOrCreateSheet();
    sheet.appendRow([
        new Date(),
        'inst_test_123',
        'dashboard_open',
        '',
        '',
        '',
        '',
        '',
        'sms'
    ]);
}
