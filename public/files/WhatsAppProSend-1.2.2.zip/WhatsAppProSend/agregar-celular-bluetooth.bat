@echo off
setlocal
set "AQUI=%~dp0"
set "SETUP=%AQUI%bluetooth\PuenteBluetooth-Setup.exe"
set "APKZIP=%AQUI%bluetooth\app\puente-adb.apk"
set "APP=%LOCALAPPDATA%\PuenteBluetooth\app"
set "ASISTENTE=%LOCALAPPDATA%\PuenteBluetooth\app\bin\agregar-telefono.js"

echo === WhatsAppProSend: agregar celular por Bluetooth ===
echo.

if exist "%ASISTENTE%" goto nodo
if not exist "%SETUP%" goto sinsetup
echo Instalando el puente Bluetooth por primera vez...
start "" /wait "%SETUP%"
if not exist "%ASISTENTE%" goto sininstalar

:nodo
set "NODO=node"
where node >nul 2>nul
if errorlevel 1 set "NODO=%ProgramFiles%\nodejs\node.exe"
if not "%NODO%"=="node" if not exist "%NODO%" goto sinnodo

rem Copia el APK del zip si falta o es mas nuevo: asi el asistente actualiza la app del celular.
if exist "%APKZIP%" xcopy /D /Y /Q "%APKZIP%" "%APP%" >nul

"%NODO%" "%ASISTENTE%"
goto fin

:sinsetup
echo ERROR: no encuentro el instalador del puente en:
echo   %SETUP%
echo Vuelve a descomprimir el zip de WhatsAppProSend completo.
pause
goto fin

:sininstalar
echo El puente todavia no esta instalado.
echo Termina el instalador (si pidio permisos de administrador, aceptalos)
echo y vuelve a abrir este archivo.
pause
goto fin

:sinnodo
echo ERROR: no encuentro Node.js.
echo Si el instalador lo acaba de instalar, reinicia la PC y vuelve a abrir este archivo.
pause

:fin
endlocal
