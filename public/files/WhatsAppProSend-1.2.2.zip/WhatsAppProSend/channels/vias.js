/**
 * vias — por dónde llega adb a un teléfono: cable USB, WiFi o el puente
 * Bluetooth (Adb_bluetooth, que publica cada teléfono en 127.0.0.1:7001..7003).
 * Funciones puras, sin adb ni chrome.*: las usan el canal y el dashboard.
 *
 * Un mismo teléfono puede aparecer en `adb devices` por dos vías a la vez
 * (cargando con un cable de datos y enlazado por Bluetooth). El canal lo
 * identifica por su serial físico (`ro.serialno`) y manda cada comando por la
 * vía que `elegirVia` prefiera.
 */

const VIAS = Object.freeze({
    usb: 'usb',
    wifi: 'wifi',
    bluetooth: 'bluetooth'
});

// Del más rápido al más lento: por Bluetooth el `cat` del dump tarda ~2x.
const PREFERENCIA = Object.freeze([VIAS.usb, VIAS.wifi, VIAS.bluetooth]);

const ETIQUETAS_VIA = Object.freeze({
    [VIAS.usb]: 'USB',
    [VIAS.wifi]: 'WiFi',
    [VIAS.bluetooth]: 'Bluetooth'
});

/**
 * Conexión que el operador elige por teléfono en el dashboard. "Solo" una vía
 * nunca cae a otra: si esa vía no está, el teléfono no envía.
 */
const MODOS_CONEXION = Object.freeze({
    automatica: 'automatica',
    usb: VIAS.usb,
    bluetooth: VIAS.bluetooth
});

const ETIQUETAS_MODO = Object.freeze({
    [MODOS_CONEXION.automatica]: 'Automática',
    [MODOS_CONEXION.usb]: 'Solo cable',
    [MODOS_CONEXION.bluetooth]: 'Solo Bluetooth'
});

// El puente Bluetooth del PC asigna 127.0.0.1:7001.. a cada teléfono.
const PUENTE_BLUETOOTH = /^127\.0\.0\.1:70\d\d$/;
// adb connect (host:puerto) o la depuración inalámbrica descubierta por mDNS.
const INALAMBRICO = /:\d+$|\._adb-tls-connect\._tcp$/;

function clasificarVia(serialAdb) {
    const serial = String(serialAdb || '');
    if (PUENTE_BLUETOOTH.test(serial)) return VIAS.bluetooth;
    if (INALAMBRICO.test(serial)) return VIAS.wifi;
    return VIAS.usb;
}

/**
 * El serial de adb de la vía preferida; sin candidatos -> '' (nunca null).
 * Con `modo` usb o bluetooth solo cuenta esa vía; otro modo es automático.
 */
function elegirVia(serialesAdb, modo) {
    const todos = Array.isArray(serialesAdb) ? serialesAdb : [];
    const forzada = modo === MODOS_CONEXION.usb || modo === MODOS_CONEXION.bluetooth;
    const lista = forzada ? todos.filter(s => clasificarVia(s) === modo) : todos;
    let mejor = '';
    let rangoMejor = PREFERENCIA.length;
    for (const serial of lista) {
        const rango = PREFERENCIA.indexOf(clasificarVia(serial));
        if (rango < rangoMejor) {
            mejor = serial;
            rangoMejor = rango;
        }
    }
    return mejor;
}

/**
 * `[{serialAdb, fisico}]` -> Map(fisico -> serialAdb elegido), en el orden en
 * que aparece cada teléfono. Sin serial físico (getprop no respondió) el
 * teléfono se identifica por su serial de adb, como antes de este módulo.
 * `modos` es `{ <serial físico>: modo }`; un teléfono sin vía permitida queda
 * con ruta ''.
 */
function rutasPorTelefono(pares, modos) {
    const elegidos = modos && typeof modos === 'object' ? modos : {};
    const candidatos = new Map();
    for (const { serialAdb, fisico } of Array.isArray(pares) ? pares : []) {
        const clave = fisico || serialAdb;
        if (!candidatos.has(clave)) candidatos.set(clave, []);
        candidatos.get(clave).push(serialAdb);
    }
    const rutas = new Map();
    for (const [clave, seriales] of candidatos) {
        const modo = Object.prototype.hasOwnProperty.call(elegidos, clave) ? elegidos[clave] : MODOS_CONEXION.automatica;
        rutas.set(clave, elegirVia(seriales, modo));
    }
    return rutas;
}

/**
 * Solo las entradas `{ <serial>: modo }` válidas: llegan del dashboard por el
 * puente y un serial con "|" rompería el target. Entrada inválida -> {}.
 */
function normalizarModos(modos) {
    const limpios = {};
    if (!modos || typeof modos !== 'object' || Array.isArray(modos)) return limpios;
    for (const [serial, modo] of Object.entries(modos)) {
        if (/^[^\s|]+$/.test(serial) && Object.prototype.hasOwnProperty.call(ETIQUETAS_MODO, modo)) {
            limpios[serial] = modo;
        }
    }
    return limpios;
}

function etiquetaVia(via) {
    return Object.prototype.hasOwnProperty.call(ETIQUETAS_VIA, via) ? ETIQUETAS_VIA[via] : '';
}

function etiquetaModo(modo) {
    return Object.prototype.hasOwnProperty.call(ETIQUETAS_MODO, modo) ? ETIQUETAS_MODO[modo] : '';
}

// Export dual como channels/whatsappTargets.js: Node (canal/tests) +
// globalThis (el dashboard lo carga como <script>, sin require).
const API_VIAS = {
    VIAS,
    MODOS_CONEXION,
    clasificarVia,
    elegirVia,
    rutasPorTelefono,
    normalizarModos,
    etiquetaVia,
    etiquetaModo
};

const _rootVias = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});
_rootVias.WhatsAppVias = API_VIAS;

if (typeof module !== 'undefined' && module.exports) {
    module.exports = API_VIAS;
}
