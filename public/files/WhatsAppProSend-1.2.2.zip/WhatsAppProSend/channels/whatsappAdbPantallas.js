/**
 * whatsappAdbPantallas.js — Parsers puros de dumps de uiautomator de WhatsApp
 * (com.whatsapp y com.whatsapp.w4b). Sin adb ni chrome.*: todo se prueba con
 * fixtures reales de channels/fixtures/ (ver NOTAS.md).
 *
 * WhatsApp expone resource-id estables y el sufijo es el mismo en las dos
 * apps: se ubican nodos por id antes que por texto. Las búsquedas sin
 * resultado devuelven NODO_AUSENTE (Caso Especial).
 */

const Utils = require('../ui/utils.js');

const NODO_AUSENTE = Object.freeze({
    encontrado: false,
    resourceId: '',
    text: '',
    contentDesc: '',
    className: '',
    clickable: false,
    bounds: Object.freeze({ x1: 0, y1: 0, x2: 0, y2: 0, cx: 0, cy: 0 })
});

const PANTALLAS = Object.freeze({
    listaChats: 'listaChats',
    nuevoChat: 'nuevoChat',
    nuevoContacto: 'nuevoContacto',
    noEncontrado: 'noEncontrado',
    descartarCambios: 'descartarCambios',
    perfil: 'perfil',
    chat: 'chat',
    sinSesion: 'sinSesion',
    desconocida: 'desconocida'
});

/** Lo que el formulario de contacto dice del número antes de guardar. */
const ESTADOS_NUMERO = Object.freeze({
    pendiente: 'pendiente',
    conWhatsApp: 'conWhatsApp',
    enAgenda: 'enAgenda',
    sinWhatsApp: 'sinWhatsApp',
    // Aviso vacío: WhatsApp no contestó la consulta. Pasajero mientras consulta; si no
    // cambia, la cuenta está limitada (visto en WhatsApp 2.26.42 con envíos masivos).
    sinRespuesta: 'sinRespuesta',
    desconocido: 'desconocido'
});

const PLACEHOLDER_COMPOSITOR = 'Mensaje';

/**
 * Decide en qué pantalla está WhatsApp. El orden importa: el diálogo se
 * evalúa antes que el formulario que tiene detrás, y "sin WhatsApp" antes
 * que el formulario genérico.
 */
function screenOf(nodos) {
    const hay = nodo => nodo.encontrado;
    // Bienvenida de una instalación sin número registrado (clones de app dual vacíos)
    if (hay(findById(nodos, 'eula_accept'))) return PANTALLAS.sinSesion;
    // WhatsApp esperando el código SMS: también es una cuenta sin sesión
    if (hay(findById(nodos, 'verify_sms_code_input'))) return PANTALLAS.sinSesion;
    if (hay(findByText(nodos, 'No se guardaron tus cambios.'))) return PANTALLAS.descartarCambios;
    if (hay(findById(nodos, 'keyboard_aware_save_button'))) {
        return numberStatus(nodos) === ESTADOS_NUMERO.sinWhatsApp ? PANTALLAS.noEncontrado : PANTALLAS.nuevoContacto;
    }
    if (hay(findById(nodos, 'action_message'))) return PANTALLAS.perfil;
    if (hay(findById(nodos, 'entry')) && hay(findById(nodos, 'conversation_contact_name'))) return PANTALLAS.chat;
    if (hay(findById(nodos, 'menuitem_new_contact_row'))) return PANTALLAS.nuevoChat;
    if (findById(nodos, 'fab').contentDesc === 'Nuevo chat') return PANTALLAS.listaChats;
    return PANTALLAS.desconocida;
}

const AVISOS_NUMERO = Object.freeze({
    'Este número de teléfono está en WhatsApp.': ESTADOS_NUMERO.conWhatsApp,
    'Esta persona ya está en tus contactos.': ESTADOS_NUMERO.enAgenda,
    'Este número de teléfono no está en WhatsApp.': ESTADOS_NUMERO.sinWhatsApp
});

function numberStatus(nodos) {
    const aviso = findById(nodos, 'number_on_whatsapp_message');
    if (!aviso.encontrado) return ESTADOS_NUMERO.pendiente;
    if (aviso.text.trim() === '') return ESTADOS_NUMERO.sinRespuesta;
    return AVISOS_NUMERO[aviso.text] || ESTADOS_NUMERO.desconocido;
}

/**
 * "Ver contacto" e "Invitar a WhatsApp" comparten resource-id: el texto es lo
 * único que los separa, y tocar Invitar manda una invitación al cliente.
 */
function viewContactAction(nodos) {
    const accion = findById(nodos, 'number_on_whatsapp_action');
    return accion.text === 'Ver contacto' ? accion : NODO_AUSENTE;
}

/**
 * Campos del formulario de contacto. Ninguno tiene resource-id y al llenarse
 * pierden el texto de ejemplo: se anclan al código de país, cuyo content-desc
 * no cambia. Nombre es el primero; teléfono, el que sigue al país.
 */
function formFields(nodos) {
    const campos = editTexts(nodos);
    const iPais = campos.findIndex(n => n.contentDesc.includes('código de país'));
    if (iPais < 0) return { nombre: NODO_AUSENTE, pais: NODO_AUSENTE, telefono: NODO_AUSENTE };
    return { nombre: campos[0], pais: campos[iPais], telefono: campos[iPais + 1] || NODO_AUSENTE };
}

/**
 * Filas del selector con ese nombre; el buscador muestra el mismo texto y no
 * cuenta. Más de una fila = dos contactos con la misma cédula y otro número.
 */
function contactRows(nodos, nombre) {
    return nodos.filter(n => n.resourceId === 'contactpicker_row_name' && n.text === nombre);
}

/**
 * Control del buscador del selector. La barra plegada expone `menuitem_search`;
 * abierta, el campo `search_src_text`. El content-desc cubre un resource-id
 * renombrado sin tocar otra cosa de la pantalla.
 */
function searchEntry(nodos) {
    const plegado = findById(nodos, 'menuitem_search');
    if (plegado.encontrado) return plegado;
    const abierto = findById(nodos, 'search_src_text');
    if (abierto.encontrado) return abierto;
    return findByDesc(nodos, 'Buscar');
}

/**
 * El telefono del perfil vive en `field_textview` (cuenta de empresa) o en
 * `contact_subtitle` (perfil personal del TECNO, HiOS 15.1.2). El "+" inicial
 * descarta un estado de texto que termine en esos mismos digitos.
 */
function profilePhoneMatches(nodos, nacional) {
    return nodos.some(n => (n.resourceId === 'field_textview' || n.resourceId === 'contact_subtitle')
        && n.text.startsWith('+') && n.text.replace(/\D/g, '').endsWith(nacional));
}

function chatHeaderName(nodos) {
    return findById(nodos, 'conversation_contact_name').text;
}

function composerText(nodos) {
    return findById(nodos, 'entry').text;
}

const PAIS_POR_DEFECTO = '593';
const CLAVE_CEDULA = /^(cedula|identificacion)$/;
// Ecuador: móvil de 9 dígitos que empieza en 9, fijo de 8 con código de área 2-7.
const NACIONAL_VALIDO = /^(9\d{8}|[2-7]\d{7})$/;

function nationalNumber(phone, countryCode = PAIS_POR_DEFECTO) {
    const intl = Utils.toInternationalDigits(phone, countryCode);
    if (!intl) throw new Error('WHATSAPP_NOT_FOUND: número inválido ' + phone);
    if (!intl.startsWith(countryCode)) {
        throw new Error('WHATSAPP_ADB_PAIS_NO_SOPORTADO: el canal ADB solo envía a +' + countryCode + ', recibido ' + phone);
    }
    // "(593) 0984..." trae el 0 troncal después del código de país
    const nacional = intl.slice(countryCode.length).replace(/^0/, '');
    if (!NACIONAL_VALIDO.test(nacional)) throw new Error('WHATSAPP_NOT_FOUND: número inválido ' + phone);
    return nacional;
}

function contactNameFor(contact, phone) {
    const datos = contact || {};
    const clave = Object.keys(datos).find(k => CLAVE_CEDULA.test(sinTildes(k).toLowerCase()));
    const cedula = clave ? String(datos[clave]).replace(/\D/g, '') : '';
    return cedula || Utils.toInternationalDigits(phone, PAIS_POR_DEFECTO);
}

/**
 * `adb shell input text` corre bajo `sh -c` (riesgo de inyección) y aborta
 * ante cualquier no-ASCII: se transcriben tildes y se quitan metacaracteres.
 */
function sanitizeTypedText(value) {
    if (value === null || value === undefined) return '';
    const ascii = sinTildes(String(value)).replace(/[^\x00-\x7F]/g, '');
    return ascii.replace(/['";&|$`<>(){}\\\n\r]/g, '');
}

function parseDevices(salida) {
    return String(salida || '')
        .split('\n')
        .slice(1)
        .map(l => l.trim().split(/\s+/))
        .filter(partes => partes.length >= 2 && partes[1] === 'device')
        .map(partes => partes[0]);
}

// ── Detalles ────────────────────────────────────────────────────────

function parseNodes(xml) {
    const nodos = [];
    const re = /<node\s([^>]*?)\/?>/g;
    let m;
    while ((m = re.exec(String(xml || '')))) {
        const attrs = leerAtributos(m[1]);
        const b = /\[(\d+),(\d+)\]\[(\d+),(\d+)\]/.exec(attrs.bounds || '');
        if (!b) continue;
        nodos.push({
            encontrado: true,
            resourceId: (attrs['resource-id'] || '').split(':id/').pop(),
            text: attrs.text || '',
            contentDesc: attrs['content-desc'] || '',
            className: attrs.class || '',
            clickable: attrs.clickable === 'true',
            bounds: boundsDesde(b.slice(1).map(Number))
        });
    }
    return nodos;
}

function findById(nodos, id) {
    return nodos.find(n => n.resourceId === id) || NODO_AUSENTE;
}

function findByDesc(nodos, desc) {
    return nodos.find(n => n.contentDesc === desc) || NODO_AUSENTE;
}

function findByText(nodos, text) {
    return nodos.find(n => n.text === text) || NODO_AUSENTE;
}

function editTexts(nodos) {
    return nodos.filter(n => n.className === 'android.widget.EditText');
}

function leerAtributos(fuente) {
    const attrs = {};
    const re = /([\w-]+)=(?:"([^"]*)"|'([^']*)')/g;
    let m;
    while ((m = re.exec(fuente))) {
        attrs[m[1]] = decodificarEntidades(m[2] !== undefined ? m[2] : m[3]);
    }
    return attrs;
}

function decodificarEntidades(valor) {
    return valor
        .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&apos;/g, "'")
        .replace(/&amp;/g, '&');
}

function boundsDesde([x1, y1, x2, y2]) {
    return { x1, y1, x2, y2, cx: Math.round((x1 + x2) / 2), cy: Math.round((y1 + y2) / 2) };
}

function sinTildes(texto) {
    return texto.normalize('NFD').replace(/[̀-ͯ]/g, '');
}

module.exports = {
    NODO_AUSENTE,
    PANTALLAS,
    ESTADOS_NUMERO,
    PLACEHOLDER_COMPOSITOR,
    parseNodes,
    findById,
    findByDesc,
    findByText,
    editTexts,
    screenOf,
    numberStatus,
    viewContactAction,
    formFields,
    contactRows,
    searchEntry,
    profilePhoneMatches,
    chatHeaderName,
    composerText,
    nationalNumber,
    contactNameFor,
    sanitizeTypedText,
    parseDevices
};
