/**
 * WhatsAppAdbChannel — interfaz Channel sobre WhatsApp nativo (personal y
 * Business) manejado por adb + uiautomator dump. Solo Node (child_process):
 * no entra al zip de la extensión.
 *
 * Cada acción se decide sobre el dump actual: se confirma la pantalla con
 * screenOf() antes de tocar, y cada tap sale de los bounds reales. Evidencia:
 * channels/fixtures/ (HONOR ALI-NX3, Android 15, WhatsApp 2.26.39.79 y
 * Business 2.26.40.73, es-EC).
 *
 * Interfaz Channel:
 *   listTargets() -> Promise<string[]>   // "<serial>|<paquete>|<usuario>", solo cuentas con número
 *   openConversation(target, phone, contact) -> Promise<void>  // lanza WHATSAPP_NOT_FOUND si no hay cuenta
 *   send(target, text) -> Promise<void>
 *   verifySent(target) -> Promise<boolean>
 *   detectProtocol(target) -> Promise<'whatsapp'>
 *   isBlocked(target) -> Promise<boolean>
 *   attachImage(target, dataUrl) -> Promise<void>   // no soportado en v1: lanza
 *
 * Turno por teléfono: las cuentas de un mismo serial comparten pantalla, y el
 * motor llama open/send/verifySent por separado. openConversation toma el
 * turno del serial y verifySent (o cualquier error) lo suelta, así otra
 * cuenta del teléfono nunca relanza WhatsApp entre el chat abierto y el envío.
 *
 * Vías: el serial del target es el físico del teléfono (`ro.serialno`), no el
 * de `adb devices`. Un teléfono con cable y puente Bluetooth a la vez aparece
 * dos veces en adb; el canal lo lista una vez y cada `-s <serial>` sale por la
 * vía que prefiera channels/vias.js (USB > WiFi > Bluetooth). Así el turno por
 * teléfono vale para las dos vías y, si se cae el cable, el envío sigue por el
 * puente sin destildar la cuenta.
 *
 * Cuentas sin número: un clon de app dual sin registrar abre en la bienvenida
 * de WhatsApp. listTargets abre una vez cada cuenta (en su turno) y deja
 * fuera las que muestran la bienvenida; cuentasSinSesion() las expone para el
 * dashboard y olvidarVerificacion() fuerza a mirar de nuevo.
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const P = require('./whatsappAdbPantallas.js');
const Targets = require('./whatsappTargets.js');
const Vias = require('./vias.js');

const execFileAsync = promisify(execFile);
const RUTA_DUMP = '/sdcard/window_dump.xml';
const KEYCODE_BACK = '4';
const KEYCODE_WAKEUP = '224';
// Lo que dice adb cuando el celular ya no está (cable, USB en ahorro, autorización,
// enlace inalámbrico colgado) o cuando falta la vía que eligió el operador
const DISPOSITIVO_AUSENTE = /device '[^']*' not found|device offline|no devices\/emulators found|device unauthorized|ADB_TIMEOUT|WHATSAPP_ADB_VIA_NO_DISPONIBLE/i;
const ESTADOS_CONCLUYENTES = [P.ESTADOS_NUMERO.conWhatsApp, P.ESTADOS_NUMERO.enAgenda, P.ESTADOS_NUMERO.sinWhatsApp];

// Actividad de arranque leída del teléfono (`cmd package resolve-activity`),
// igual para el usuario principal y el clon. `monkey` no acepta --user.
const ACTIVIDAD = Object.freeze({
    [Targets.PAQUETES.personal]: 'com.whatsapp/.Main',
    [Targets.PAQUETES.business]: 'com.whatsapp.w4b/com.whatsapp.Main'
});

// Caso Especial: sin almacén inyectado, la evidencia no se guarda en ningún lado.
const EVIDENCIA_NULA = Object.freeze({ guardar() {} });

class WhatsAppAdbChannel {
    /**
     * @param {Object} [opts]
     * @param {string} [opts.adbPath='adb']
     * @param {Function} [opts.execFn] - (args) => Promise<{stdout, stderr}>
     * @param {number} [opts.launchWaitMs=2000] - espera tras relanzar WhatsApp en frío
     * @param {number} [opts.stepWaitMs=900] - espera entre dumps de un mismo sondeo
     * @param {number} [opts.pollAttempts=6] - dumps por pantalla esperada
     * @param {number} [opts.dumpAttempts=5] - reintentos de uiautomator dump
     * @param {number} [opts.dumpRetryDelayMs=600]
     * @param {number} [opts.numberStatusPolls=6] - dumps esperando el aviso del número (consulta al servidor)
     * @param {number} [opts.esperaDispositivoMs=120000] - cuánto se espera a un celular desconectado
     * @param {number} [opts.sondeoDispositivoMs=5000] - cada cuánto se pregunta si volvió
     * @param {number} [opts.limiteComandoMs=30000] - un comando adb sin respuesta se corta con ADB_TIMEOUT
     * @param {Object} [opts.evidencia] - { guardar(fallo) } para PANTALLA_INESPERADA; por defecto no guarda
     */
    constructor(opts = {}) {
        this.adbPath = opts.adbPath || 'adb';
        this.limiteComandoMs = valorO(opts.limiteComandoMs, 30000);
        // windowsHide evita una ventana de consola por cada llamada a adb.exe;
        // timeout mata el adb.exe que quedó colgado. HiOS (TECNO) devuelve más
        // de 1 MB en dumpsys input_method y el default de Node aborta el flujo.
        const execFn = opts.execFn || ((args) => execFileAsync(this.adbPath, args, {
            windowsHide: true, timeout: this.limiteComandoMs, maxBuffer: 10 * 1024 * 1024
        }));
        this.execAdb = conLimite(execFn, this.limiteComandoMs);
        this.rutas = new Map(); // serial físico -> serial de adb de la vía elegida
        this.modos = {}; // serial físico -> modo de conexión elegido en el dashboard
        this.sinVia = new Map(); // serial físico conectado sin la vía elegida -> modo
        // Un solo refresco de rutas por vez: el puente Bluetooth sostiene un
        // único enlace RFCOMM y dos getprop a la vez lo abren y cierran en ciclo.
        this.refrescoEnCurso = false;
        this.refrescoRutas = Promise.resolve([]);
        // `-s <serial físico>` sale por la vía actual; un serial sin ruta conocida
        // (target de antes de listar) va tal cual, como antes de las vías. Un
        // teléfono sin la vía elegida no recibe nada por otra.
        this.execFn = (args) => {
            if (args[0] !== '-s') return this.execAdb(args);
            if (this.sinVia.has(args[1])) {
                return Promise.reject(new Error('WHATSAPP_ADB_VIA_NO_DISPONIBLE: el celular ' + args[1] +
                    ' no está conectado por la vía elegida (' + Vias.etiquetaModo(this.sinVia.get(args[1])) + ')'));
            }
            return this.rutas.has(args[1])
                ? this.execAdb(['-s', this.rutas.get(args[1]), ...args.slice(2)])
                : this.execAdb(args);
        };
        this.launchWaitMs = valorO(opts.launchWaitMs, 2000);
        this.stepWaitMs = valorO(opts.stepWaitMs, 900);
        this.pollAttempts = valorO(opts.pollAttempts, 6);
        this.evidencia = opts.evidencia && typeof opts.evidencia.guardar === 'function' ? opts.evidencia : EVIDENCIA_NULA;
        this.dumpAttempts = valorO(opts.dumpAttempts, 5);
        this.dumpRetryDelayMs = valorO(opts.dumpRetryDelayMs, 600);
        this.numberStatusPolls = valorO(opts.numberStatusPolls, 6);
        this.esperaDispositivoMs = valorO(opts.esperaDispositivoMs, 120000);
        this.sondeoDispositivoMs = valorO(opts.sondeoDispositivoMs, 5000);
        this.candado = Targets.crearCandadoPorSerial();
        this.turnos = new Map(); // target -> liberar()
        this.verificadas = new Set(); // targets ya abiertos una vez
        this.sinSesion = new Set();   // targets que abren en la bienvenida
        this.verificando = new Map(); // target -> verificacion en curso (compartida)
    }

    // ── API Channel ────────────────────────────────────────────────

    async listTargets() {
        const { stdout } = await this.execFn(['devices']);
        const activas = [];
        for (const serial of await this.actualizarRutas(stdout)) {
            for (const target of await this.cuentasDe(serial)) {
                if (!this.verificadas.has(target)) await this.verificarUnaVez(target);
                if (!this.sinSesion.has(target)) activas.push(target);
            }
        }
        return activas;
    }

    /** Vía actual de cada teléfono listado: `{ <serial físico>: 'usb' | 'wifi' | 'bluetooth' }`. */
    viasDeTelefonos() {
        const vias = {};
        for (const [fisico, serialAdb] of this.rutas) vias[fisico] = Vias.clasificarVia(serialAdb);
        return vias;
    }

    /** Teléfonos conectados sin la vía elegida: `{ <serial físico>: modo }`. */
    telefonosSinVia() {
        return Object.fromEntries(this.sinVia);
    }

    /**
     * Conexión elegida por teléfono (`{ <serial físico>: 'automatica' | 'usb' |
     * 'bluetooth' }`). Rige desde el próximo listado o reconexión.
     */
    fijarModos(modos) {
        this.modos = Vias.normalizarModos(modos);
    }

    /** Cuentas instaladas que abren en la bienvenida (sin número registrado). */
    cuentasSinSesion() {
        return [...this.sinSesion];
    }

    /** "Buscar cuentas": la próxima lista vuelve a abrir cada cuenta. */
    olvidarVerificacion() {
        this.verificadas.clear();
        this.sinSesion.clear();
    }

    async openConversation(target, phone, contact) {
        // Validar antes de tocar el teléfono
        const cuenta = Targets.parsearTarget(target);
        const nacional = P.nationalNumber(phone);
        const nombre = P.contactNameFor(contact, phone);

        await this.tomarTurno(target);
        try {
            await this.abrirChat(cuenta, phone, nacional, nombre);
        } catch (err) {
            this.liberarTurno(target);
            throw await this.clasificarCaida(cuenta.serial, err);
        }
    }

    async send(target, text) {
        const { serial } = Targets.parsearTarget(target);
        try {
            // Re-dump: una notificación pudo robar el foco desde openConversation()
            const chat = await this.esperarPantalla(serial, [P.PANTALLAS.chat]);
            // WhatsApp guarda borradores por chat: escribir encima mezclaría dos mensajes
            if (P.composerText(chat.nodos) !== P.PLACEHOLDER_COMPOSITOR) {
                throw new Error('WHATSAPP_ADB_BORRADOR_PENDIENTE: el compositor ya tiene texto');
            }
            await this.tapNodo(serial, P.findById(chat.nodos, 'entry'), 'compositor');
            await this.escribir(serial, text);
            // Enviar recién existe con texto escrito (reemplaza al botón de nota de voz)
            const escrito = await this.esperarPantalla(serial, [P.PANTALLAS.chat]);
            await this.tapNodo(serial, P.findById(escrito.nodos, 'send'), 'Enviar');
        } catch (err) {
            this.liberarTurno(target);
            throw err;
        }
    }

    /** Enviado = el compositor volvió al placeholder "Mensaje" dentro del chat. */
    async verifySent(target) {
        const { serial } = Targets.parsearTarget(target);
        try {
            const nodos = P.parseNodes(await this.dump(serial));
            return P.screenOf(nodos) === P.PANTALLAS.chat && P.composerText(nodos) === P.PLACEHOLDER_COMPOSITOR;
        } finally {
            this.liberarTurno(target);
        }
    }

    async detectProtocol(target) {
        return 'whatsapp';
    }

    async isBlocked(target) {
        return false;
    }

    /**
     * v1 no adjunta imágenes (multimedia es v2). Se lanza en vez de ignorarla
     * para que la campaña no marque "Enviado" sin la imagen.
     */
    async attachImage(target, dataUrl) {
        this.liberarTurno(target);
        throw new Error('WHATSAPP_ADB_IMAGEN_NO_SOPORTADA: el canal ADB aún no envía imágenes');
    }

    // ── Pasos del flujo ────────────────────────────────────────────

    async abrirChat(cuenta, phone, nacional, nombre) {
        const { serial } = cuenta;
        const lista = await this.resetToChatList(cuenta);
        await this.tapNodo(serial, P.findById(lista.nodos, 'fab'), 'Nuevo chat');
        const menu = await this.esperarPantalla(serial, [P.PANTALLAS.nuevoChat]);
        await this.tapNodo(serial, P.findById(menu.nodos, 'menuitem_new_contact_row'), 'Nuevo contacto');

        const formulario = await this.llenarFormulario(serial, nombre, nacional);
        const estado = P.numberStatus(formulario.nodos);
        const vioSinRespuesta = formulario.vioSinRespuesta;
        if (estado === P.ESTADOS_NUMERO.sinWhatsApp) {
            await this.descartarFormulario(serial, formulario.nodos);
            throw new Error('WHATSAPP_NOT_FOUND: sin cuenta de WhatsApp para ' + phone);
        }
        if (estado === P.ESTADOS_NUMERO.sinRespuesta || (estado === P.ESTADOS_NUMERO.pendiente && vioSinRespuesta)) {
            await this.descartarFormulario(serial, formulario.nodos);
            throw new Error('WHATSAPP_ADB_CUENTA_LIMITADA: WhatsApp no contestó la consulta del número ' + phone +
                ' tras ' + this.numberStatusPolls + ' intentos; la cuenta puede estar limitada por envíos masivos');
        }
        if (estado === P.ESTADOS_NUMERO.enAgenda) {
            await this.tapNodo(serial, P.viewContactAction(formulario.nodos), 'Ver contacto');
            return this.entrarDesdePerfil(serial, nacional);
        }
        if (estado !== P.ESTADOS_NUMERO.conWhatsApp) {
            // El texto real del aviso: sin él no hay forma de saber qué mostró WhatsApp
            const aviso = P.findById(formulario.nodos, 'number_on_whatsapp_message').text;
            throw new Error('WHATSAPP_ADB_PANTALLA_INESPERADA: WhatsApp no confirmó el número: ' + JSON.stringify(aviso) + ' (' + estado + ')');
        }
        await this.tapNodo(serial, P.findById(formulario.nodos, 'keyboard_aware_save_button'), 'GUARDAR');
        return this.entrarDesdeBuscador(serial, nombre);
    }

    /**
     * Relanza WhatsApp en frío y confirma la lista de chats antes de actuar.
     * Volver con Back es frágil: puede salir al launcher y tocar otra app.
     */
    async resetToChatList({ serial, paquete, usuario }) {
        await this.execFn(['-s', serial, 'shell', 'am', 'force-stop', '--user', usuario, paquete]);
        await this.execFn(['-s', serial, 'shell', 'input', 'keyevent', KEYCODE_WAKEUP]);
        await this.execFn(['-s', serial, 'shell', 'wm', 'dismiss-keyguard']);
        await this.execFn(['-s', serial, 'shell', 'am', 'start', '--user', usuario, '-n', ACTIVIDAD[paquete]]);
        await sleep(this.launchWaitMs);
        const inicio = await this.esperarPantalla(serial, [P.PANTALLAS.listaChats, P.PANTALLAS.sinSesion]);
        if (inicio.pantalla === P.PANTALLAS.sinSesion) {
            const target = Targets.crearTarget(serial, paquete, usuario);
            this.sinSesion.add(target);
            this.verificadas.add(target);
            throw new Error('WHATSAPP_ADB_SIN_SESION: ' + Targets.etiquetaTarget(target) + ' no tiene un número registrado');
        }
        return inicio;
    }

    /**
     * Llena nombre y teléfono y espera el aviso del número (WhatsApp lo
     * consulta al servidor). Devuelve el último dump del formulario y
     * vioSinRespuesta=true si alguna consulta devolvió sinRespuesta.
     */
    async llenarFormulario(serial, nombre, nacional) {
        const vacio = await this.esperarPantalla(serial, [P.PANTALLAS.nuevoContacto]);
        await this.tapNodo(serial, P.formFields(vacio.nodos).nombre, 'campo Nombre');
        await this.escribir(serial, nombre);

        // Re-dump: el teclado desplaza el formulario y los bounds cambian
        const conNombre = await this.esperarPantalla(serial, [P.PANTALLAS.nuevoContacto]);
        const campos = P.formFields(conNombre.nodos);
        if (campos.pais.text !== 'EC +593') {
            throw new Error('WHATSAPP_ADB_PAIS_NO_SOPORTADO: el formulario tiene código ' + JSON.stringify(campos.pais.text));
        }
        await this.tapNodo(serial, campos.telefono, 'campo Teléfono');
        await this.escribir(serial, nacional);

        // Se espera uno de los tres avisos conocidos: mientras WhatsApp consulta
        // el número puede mostrar otro texto, y cortar ahí abortaba el contacto.
        // También registramos si vimos sinRespuesta en alguna consulta.
        let vioSinRespuesta = false;
        const { nodos } = await this.sondear(serial, this.numberStatusPolls, n => {
            const estado = P.numberStatus(n);
            if (estado === P.ESTADOS_NUMERO.sinRespuesta) vioSinRespuesta = true;
            return ESTADOS_CONCLUYENTES.includes(estado);
        });
        return { nodos, vioSinRespuesta };
    }

    /** Número sin WhatsApp: Atrás y "Descartar", sin guardar un contacto inútil. */
    async descartarFormulario(serial, nodos) {
        await this.tapNodo(serial, P.findById(nodos, 'wds_toolbar_nav_button'), 'Atrás');
        const dialogo = await this.esperarPantalla(serial, [P.PANTALLAS.descartarCambios]);
        await this.tapNodo(serial, P.findByText(dialogo.nodos, 'Descartar'), 'Descartar');
    }

    async entrarDesdePerfil(serial, nacional) {
        const perfil = await this.esperarPantalla(serial, [P.PANTALLAS.perfil]);
        if (!P.profilePhoneMatches(perfil.nodos, nacional)) {
            throw new Error('WHATSAPP_ADB_CHAT_EQUIVOCADO: el perfil abierto no es de ' + nacional);
        }
        await this.tapNodo(serial, P.findById(perfil.nodos, 'action_message'), 'Mensaje');
        await this.esperarPantalla(serial, [P.PANTALLAS.chat]);
    }

    /** GUARDAR vuelve al selector de contactos: se busca la cédula y se abre su fila. */
    async entrarDesdeBuscador(serial, nombre) {
        // La barra de búsqueda puede tardar un dump en pintarse, y si ya está
        // abierta no hay `menuitem_search`: se espera a cualquiera de las dos.
        const selector = await this.sondear(serial, this.pollAttempts,
            n => P.screenOf(n) === P.PANTALLAS.nuevoChat && P.searchEntry(n).encontrado);
        if (!selector.cumple) {
            if (P.screenOf(selector.nodos) !== P.PANTALLAS.nuevoChat) {
                throw new Error('WHATSAPP_ADB_PANTALLA_INESPERADA: se esperaba ' + P.PANTALLAS.nuevoChat + ', se vio ' + P.screenOf(selector.nodos));
            }
            throw new Error('WHATSAPP_ADB_NODO_AUSENTE: no se encontró "Buscar" en pantalla');
        }
        const buscador = P.searchEntry(selector.nodos);
        if (buscador.resourceId !== 'search_src_text') {
            await this.tapNodo(serial, buscador, 'Buscar');
        }
        await this.escribir(serial, nombre);
        const { nodos, cumple } = await this.sondear(serial, this.pollAttempts, n => P.contactRows(n, nombre).length > 0);
        if (!cumple) throw new Error('WHATSAPP_ADB_NODO_AUSENTE: el contacto "' + nombre + '" no aparece en el buscador');
        const filas = P.contactRows(nodos, nombre);
        if (filas.length > 1) {
            throw new Error('WHATSAPP_ADB_CONTACTO_DUPLICADO: hay ' + filas.length + ' contactos "' + nombre + '"');
        }
        await this.tapNodo(serial, filas[0], 'contacto ' + nombre);
        const chat = await this.esperarPantalla(serial, [P.PANTALLAS.chat]);
        if (P.chatHeaderName(chat.nodos) !== nombre) {
            throw new Error('WHATSAPP_ADB_CHAT_EQUIVOCADO: se abrió "' + P.chatHeaderName(chat.nodos) + '", se esperaba "' + nombre + '"');
        }
    }

    /**
     * El celular se desconectó mientras se abría el chat (todavía no se
     * escribió nada): se espera a que vuelva. Si vuelve, CARRIER_FAILED para que
     * el motor repita el contacto desde cero; si no, un error claro. Solo se usa
     * en openConversation: en send el mensaje pudo haber salido y repetirlo lo
     * duplicaría.
     */
    async clasificarCaida(serial, err) {
        const texto = (err && err.message ? err.message : String(err)) + ' ' + (err && err.stderr ? err.stderr : '');
        if (!DISPOSITIVO_AUSENTE.test(texto)) return err;
        const volvio = await this.esperarDispositivo(serial);
        return new Error(volvio
            ? 'CARRIER_FAILED: WHATSAPP_ADB_SIN_DISPOSITIVO: el celular ' + serial + ' se desconectó y volvió; se reintenta el contacto'
            : 'WHATSAPP_ADB_SIN_DISPOSITIVO: el celular ' + serial + ' no volvió a conectarse (revisa el cable, el enlace Bluetooth y la depuración USB)');
    }

    async esperarDispositivo(serial) {
        const limite = Date.now() + this.esperaDispositivoMs;
        do {
            try {
                // Vuelve por cualquier vía: sin cable, el puente Bluetooth sirve
                const { stdout } = await this.execFn(['devices']);
                if ((await this.actualizarRutas(stdout)).includes(serial)) return true;
            } catch (_) { /* adb sin responder: se vuelve a preguntar */ }
            await sleep(this.sondeoDispositivoMs);
        } while (Date.now() < limite);
        return false;
    }

    // ── Vías ───────────────────────────────────────────────────────

    /**
     * Rehace las rutas desde la salida de `adb devices` y devuelve los
     * seriales físicos conectados, uno por teléfono. getprop va directo al
     * serial de adb: la ruta vieja podría apuntar a una vía que ya no está.
     */
    async rehacerRutas(salidaDevices) {
        const pares = [];
        for (const serialAdb of P.parseDevices(salidaDevices)) {
            const fisico = (await this.serialFisico(serialAdb)) || this.identidadConocida(serialAdb);
            if (fisico) pares.push({ serialAdb, fisico });
        }
        const rutas = new Map();
        const sinVia = new Map();
        for (const [fisico, serialAdb] of Vias.rutasPorTelefono(pares, this.modos)) {
            if (serialAdb) rutas.set(fisico, serialAdb);
            else sinVia.set(fisico, this.modos[fisico]);
        }
        this.rutas = rutas;
        this.sinVia = sinVia;
        return [...rutas.keys()];
    }

    /**
     * Un refresco de rutas a la vez: si otro refresco está en curso, este
     * comparte su promesa en vez de preguntar otra vez por el mismo getprop.
     */
    actualizarRutas(salidaDevices) {
        if (this.refrescoEnCurso) return this.refrescoRutas;
        this.refrescoEnCurso = true;
        this.refrescoRutas = this.rehacerRutas(salidaDevices).finally(() => { this.refrescoEnCurso = false; });
        return this.refrescoRutas;
    }

    /** `ro.serialno`, o '' si no responde o no sirve como serial de un target. */
    async serialFisico(serialAdb) {
        try {
            const { stdout } = await this.execAdb(['-s', serialAdb, 'shell', 'getprop', 'ro.serialno']);
            const fisico = String(stdout || '').trim();
            return /^[^\s|]+$/.test(fisico) ? fisico : '';
        } catch (_) {
            return ''; // sin respuesta: decide identidadConocida
        }
    }

    /**
     * Identidad de un serial cuyo getprop no respondió. Por cable el serial de
     * adb es el físico; un puerto (Bluetooth o WiFi) no dice de quién es el
     * teléfono: vale solo la identidad que ya tenía en la ruta vigente. Sin
     * ella, '' y el serial se descarta en este refresco.
     */
    identidadConocida(serialAdb) {
        if (Vias.clasificarVia(serialAdb) === Vias.VIAS.usb) return serialAdb;
        for (const [fisico, ruta] of this.rutas) {
            if (ruta === serialAdb) return fisico;
        }
        return '';
    }

    // ── Cuentas y turnos ───────────────────────────────────────────

    /**
     * Una cuenta por usuario del sistema x paquete instalado. Un usuario al
     * que adb no tiene acceso (p.ej. "Espacio Paralelo") no aporta cuentas.
     */
    async cuentasDe(serial) {
        const { stdout } = await this.execFn(['-s', serial, 'shell', 'pm', 'list', 'users']);
        const cuentas = [];
        for (const { id } of Targets.parseUsuarios(stdout)) {
            for (const paquete of Targets.PAQUETES_SOPORTADOS) {
                try {
                    const { stdout: lista } = await this.execFn(['-s', serial, 'shell', 'pm', 'list', 'packages', '--user', id, paquete]);
                    // `pm list packages com.whatsapp` también lista com.whatsapp.w4b
                    if (lista.split(/\r?\n/).some(l => l.trim() === 'package:' + paquete)) {
                        cuentas.push(Targets.crearTarget(serial, paquete, id));
                    }
                } catch (_) { /* usuario sin acceso para adb: sin cuentas */ }
            }
        }
        return cuentas;
    }

    /**
     * Abre la cuenta en su turno del teléfono (nunca a mitad de un contacto) y
     * anota si tiene sesión. Sin conclusión (dump fallido, pantalla rara) la
     * cuenta queda disponible y sin verificar: se mira de nuevo la próxima vez.
     */
    async verificarSesion(target) {
        const cuenta = Targets.parsearTarget(target);
        await this.candado.ejecutar(target, async () => {
            try {
                await this.resetToChatList(cuenta);
                this.verificadas.add(target);
            } catch (err) {
                if (!this.sinSesion.has(target)) return;
                // Bienvenida: se cierra para no dejarla en pantalla
                await this.execFn(['-s', cuenta.serial, 'shell', 'am', 'force-stop', '--user', cuenta.usuario, cuenta.paquete]);
            }
        });
    }

    /**
     * Pedidos de cuentas simultáneos (dashboard y miniventana al abrir)
     * esperan la misma verificación: abrir cada WhatsApp una vez por pedido
     * duplicaba la espera del usuario.
     */
    verificarUnaVez(target) {
        if (!this.verificando.has(target)) {
            const enCurso = this.verificarSesion(target).finally(() => this.verificando.delete(target));
            this.verificando.set(target, enCurso);
        }
        return this.verificando.get(target);
    }

    async tomarTurno(target) {
        this.liberarTurno(target); // reintento del motor sin verifySent previo
        let empezo;
        const enTurno = new Promise(r => { empezo = r; });
        let liberar;
        const terminado = new Promise(r => { liberar = r; });
        this.candado.ejecutar(target, () => { empezo(); return terminado; });
        await enTurno;
        this.turnos.set(target, liberar);
    }

    liberarTurno(target) {
        const liberar = this.turnos.get(target);
        if (!liberar) return;
        this.turnos.delete(target);
        liberar();
    }

    // ── Primitivas adb ─────────────────────────────────────────────

    async esperarPantalla(serial, esperadas) {
        const { nodos, xml, cumple } = await this.sondear(serial, this.pollAttempts,
            n => esperadas.includes(P.screenOf(n)));
        if (!cumple) {
            const vista = P.screenOf(nodos);
            await this.guardarEvidencia(serial, esperadas, vista, xml);
            throw new Error('WHATSAPP_ADB_PANTALLA_INESPERADA: se esperaba ' + esperadas.join('/') + ', se vio ' + vista);
        }
        return { pantalla: P.screenOf(nodos), nodos };
    }

    /**
     * Lo que se vio y qué actividad estaba al frente (con su usuario: u0, u128).
     * Nunca lanza: la evidencia no puede tapar el error de pantalla.
     */
    async guardarEvidencia(serial, esperadas, vista, xml) {
        try {
            const { stdout } = await this.execFn(['-s', serial, 'shell', 'dumpsys', 'activity', 'activities']);
            const actividad = (String(stdout || '').split(/\r?\n/).find(l => l.includes('topResumedActivity')) || '').trim();
            this.evidencia.guardar({ telefono: serial, esperadas, vista, xml, actividad });
        } catch (_) { /* sin evidencia: el error de pantalla sigue su curso */ }
    }

    /**
     * Hace hasta `intentos` dumps hasta que `condicion(nodos)` se cumpla. Si
     * ningún dump salió, el teléfono no respondió: CARRIER_FAILED para que el
     * motor reintente el contacto.
     */
    async sondear(serial, intentos, condicion) {
        let nodos = [];
        let xml = '';
        let ultimoError = new Error('sin intentos');
        let leidos = 0;
        for (let i = 0; i < intentos; i++) {
            if (i > 0) await sleep(this.stepWaitMs);
            try {
                xml = await this.dump(serial);
                nodos = P.parseNodes(xml);
                leidos += 1;
            } catch (err) {
                ultimoError = err;
                continue; // dump() ya agotó sus reintentos: cuenta como un intento fallido
            }
            if (condicion(nodos)) return { nodos, xml, cumple: true };
        }
        if (leidos === 0) {
            throw new Error('CARRIER_FAILED: WHATSAPP_ADB_DUMP_FALLIDO: ' + (ultimoError.message || String(ultimoError)));
        }
        return { nodos, xml, cumple: false };
    }

    /** uiautomator dump falla de forma intermitente en algunos ROM: se reintenta. */
    async dump(serial) {
        let ultimoError = new Error('uiautomator dump sin intentos');
        for (let i = 0; i < this.dumpAttempts; i++) {
            try {
                await this.execFn(['-s', serial, 'shell', 'uiautomator', 'dump', RUTA_DUMP]);
                const { stdout } = await this.execFn(['-s', serial, 'shell', 'cat', RUTA_DUMP]);
                return stdout;
            } catch (err) {
                ultimoError = err;
                if (i < this.dumpAttempts - 1) await sleep(this.dumpRetryDelayMs);
            }
        }
        throw ultimoError;
    }

    async tapNodo(serial, nodo, descripcion) {
        if (!nodo.encontrado) {
            throw new Error('WHATSAPP_ADB_NODO_AUSENTE: no se encontró "' + descripcion + '" en pantalla');
        }
        await this.execFn(['-s', serial, 'shell', 'input', 'tap', String(nodo.bounds.cx), String(nodo.bounds.cy)]);
    }

    /**
     * Escribe y cierra el teclado: abierto tapa campos del formulario y los
     * bounds del próximo dump no servirían. Con teclado, BACK solo lo cierra.
     */
    async escribir(serial, texto) {
        const seguro = P.sanitizeTypedText(texto).replace(/\s/g, '%s');
        await this.execFn(['-s', serial, 'shell', 'input', 'text', seguro]);
        const { stdout } = await this.execFn(['-s', serial, 'shell', 'dumpsys', 'input_method']);
        if (/mInputShown=true/.test(stdout)) {
            await this.execFn(['-s', serial, 'shell', 'input', 'keyevent', KEYCODE_BACK]);
        }
    }
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

/**
 * Por cable adb falla enseguida al perder el celular; por un enlace inalámbrico
 * degradado puede quedar esperando para siempre y trabar el turno del teléfono.
 */
function conLimite(execFn, limiteMs) {
    return (args) => new Promise((resolver, rechazar) => {
        const reloj = setTimeout(() => rechazar(new Error('ADB_TIMEOUT: adb ' + args.join(' ') + ' sin respuesta en ' + limiteMs + ' ms')), limiteMs);
        Promise.resolve().then(() => execFn(args)).then(
            (salida) => { clearTimeout(reloj); resolver(salida); },
            (err) => { clearTimeout(reloj); rechazar(err); });
    });
}

function valorO(valor, porDefecto) {
    return valor !== undefined ? valor : porDefecto;
}

module.exports = { WhatsAppAdbChannel };
