/**
 * evidencia — guarda en disco lo que el canal vio cuando una pantalla no fue
 * la esperada: el XML del dump y la actividad en primer plano. Sirve para
 * corregir con datos un fallo que no se reproduce. `fs` y `ahora` inyectables.
 *
 * Los dumps traen nombres y números de clientes: la carpeta vive solo en la
 * PC (gitignored) y conserva los `maximo` fallos más nuevos.
 */
const fsReal = require('fs');
const path = require('path');

const MAXIMO_POR_DEFECTO = 50;

function sello(fecha) {
    const dos = (n) => String(n).padStart(2, '0');
    return fecha.getFullYear() + dos(fecha.getMonth() + 1) + dos(fecha.getDate()) + '-' +
        dos(fecha.getHours()) + dos(fecha.getMinutes()) + dos(fecha.getSeconds()) + '-' +
        String(fecha.getMilliseconds()).padStart(3, '0');
}

function crearEvidencia(opts) {
    const o = opts || {};
    const carpeta = o.carpeta || '';
    const fs = o.fs || fsReal;
    const ahora = typeof o.ahora === 'function' ? o.ahora : () => new Date();
    const maximo = Number.isInteger(o.maximo) && o.maximo > 0 ? o.maximo : MAXIMO_POR_DEFECTO;

    /** Nunca lanza: la evidencia no puede tapar el error que la originó. */
    function guardar(fallo) {
        try {
            const f = fallo || {};
            const base = sello(ahora()) + '-' + String(f.telefono || 'telefono').replace(/[^A-Za-z0-9._-]/g, '_');
            fs.mkdirSync(carpeta, { recursive: true });
            fs.writeFileSync(path.join(carpeta, base + '.xml'), String(f.xml || ''), 'utf-8');
            fs.writeFileSync(path.join(carpeta, base + '.txt'), [
                'telefono: ' + (f.telefono || ''),
                'esperadas: ' + (Array.isArray(f.esperadas) ? f.esperadas.join('/') : ''),
                'vista: ' + (f.vista || ''),
                'actividad: ' + (f.actividad || '')
            ].join('\n') + '\n', 'utf-8');
            rotar();
        } catch (_) { /* sin disco o sin permisos: se pierde la evidencia, no la campaña */ }
    }

    function rotar() {
        const bases = [...new Set(fs.readdirSync(carpeta)
            .filter(n => n.endsWith('.xml') || n.endsWith('.txt'))
            .map(n => n.slice(0, -4)))].sort();
        for (const base of bases.slice(0, Math.max(bases.length - maximo, 0))) {
            for (const ext of ['.xml', '.txt']) {
                try { fs.unlinkSync(path.join(carpeta, base + ext)); } catch (_) { /* ya no estaba */ }
            }
        }
    }

    return { guardar };
}

module.exports = { crearEvidencia, MAXIMO_POR_DEFECTO };
