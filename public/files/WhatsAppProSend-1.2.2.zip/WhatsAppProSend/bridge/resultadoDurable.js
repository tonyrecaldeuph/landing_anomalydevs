/**
 * resultadoDurable — guarda los resultados de campaña en un JSON hasta
 * recibir su `ack`. Permite que un cliente reiniciado (popup cerrado) recupere
 * el resultado con `status`, y que una campaña cortada (el puente murió) no
 * pierda lo que ya envió: el puente guarda después de cada contacto con
 * `enCurso: true`. `fs` inyectable para tests.
 *
 * Varias campañas sin confirmar conviven, una entrada por `campaignId`:
 * guardar el progreso de una campaña nueva no puede pisar el resultado sin
 * confirmar de la anterior. Se conservan las MAXIMO_ENTRADAS más recientes.
 */

const fsReal = require('fs');

const MAXIMO_ENTRADAS = 10;

function crearAlmacen(opts) {
    const o = opts || {};
    const ruta = o.ruta || '';
    const fs = o.fs || fsReal;

    function guardar(datos) {
        const registro = normalizar(datos);
        const entradas = leer().filter((e) => e.campaignId !== registro.campaignId);
        entradas.push(registro);
        escribir(entradas.slice(-MAXIMO_ENTRADAS));
    }

    function leer() {
        try {
            const obj = JSON.parse(String(fs.readFileSync(ruta, 'utf-8')));
            // Formato viejo: un solo objeto en vez de { entradas: [...] }
            const crudas = obj && Array.isArray(obj.entradas) ? obj.entradas
                : (obj && typeof obj === 'object' && !Array.isArray(obj) && 'campaignId' in obj ? [obj] : []);
            return crudas.filter((e) => e && typeof e === 'object').map(normalizar);
        } catch (_) {
            return [];
        }
    }

    function confirmar(campaignId) {
        const actuales = leer();
        const resto = actuales.filter((e) => e.campaignId !== campaignId);
        if (resto.length === actuales.length) return false;
        try {
            if (resto.length === 0) fs.unlinkSync(ruta);
            else escribir(resto);
        } catch (_) {
            return false;
        }
        return true;
    }

    // Escritura atómica: primero al .tmp y luego rename sobre la ruta, para
    // que un corte a mitad de escritura no deje el JSON corrupto.
    function escribir(entradas) {
        const temporal = ruta + '.tmp';
        fs.writeFileSync(temporal, JSON.stringify({ entradas }));
        fs.renameSync(temporal, ruta);
    }

    return { guardar, leer, confirmar };
}

function normalizar(datos) {
    const d = datos || {};
    return {
        campaignId: d.campaignId || '',
        results: Array.isArray(d.results) ? d.results : [],
        stopped: d.stopped === true,
        terminadaEn: d.terminadaEn || '',
        enCurso: d.enCurso === true,
        total: Number.isInteger(d.total) && d.total >= 0 ? d.total : 0
    };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { crearAlmacen, MAXIMO_ENTRADAS };
}
