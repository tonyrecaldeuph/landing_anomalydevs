/**
 * campaignEngine.js — Motor puro de campañas (sin chrome.* ni adb)
 * Usado por background.js y por el canal ADB (WhatsAppAdbChannel) a
 * través de la misma interfaz Channel. El target es un serial string.
 * Ley de Demeter: solo habla contra interfaz Channel, nunca contra chrome.debugger/adb directo.
 *
 * Interfaz Channel:
 *   listTargets() -> Promise<string[]>
 *   openConversation(target:string, phone:string, contact:object) -> Promise<void>
 *   send(target:string, text:string) -> Promise<void>
 *   verifySent(target:string) -> Promise<boolean>
 *   detectProtocol(target:string) -> Promise<'sms'|'rcs'>
 *   isBlocked(target:string) -> Promise<boolean>
 */

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

/**
 * Clasifica el `status` de un contactResult en 'RCS'|'SMS'|'Duplicado'|
 * 'Omitido'|'Error'. El canal Web anota el protocolo en el propio texto
 * ("Enviado (RCS 🟢)"/"Enviado (SMS 🔵)"); el canal ADB no distingue
 * protocolo y devuelve 'Enviado' a secas — sin el fallback de la última
 * línea, todo envío exitoso por ADB clasificaría como error.
 */
function classifyResultStatus(status) {
    const s = String(status || '');
    if (s.includes('NoEncontrado') || s.includes('Sin WhatsApp')) return 'NoEncontrado';
    if (s.includes('Duplicado')) return 'Duplicado';
    if (s.includes('Omitido')) return 'Omitido';
    // Pendiente != Omitido: `Omitido` es "no tenia telefono" y no se retoma;
    // `Pendiente` es "no se alcanzo por cuota" y vuelve manana.
    if (s.includes('Pendiente')) return 'Pendiente';
    if (s.includes('Error')) return 'Error';
    if (s.includes('Enviado')) return 'Enviado';
    return 'Error';
}

/**
 * Etiqueta visible para un `status` interno. El valor de negocio sigue siendo
 * `NoEncontrado` (no rompe historiales viejos); en la UI se muestra "Sin WhatsApp".
 */
function displayResultLabel(status) {
    const clase = classifyResultStatus(status);
    if (clase === 'Enviado') return 'Enviado ✅';
    if (clase === 'NoEncontrado') return 'Sin WhatsApp ⚪';
    if (clase === 'Duplicado') return 'Duplicado ⏭️';
    if (clase === 'Omitido') return 'Omitido ⏭️';
    if (String(status || '') === PENDIENTE_CUENTA_LIMITADA) return 'Pendiente: cuenta limitada ⏸️';
    if (clase === 'Pendiente') return 'Pendiente ⏸️';
    return 'Error ❌';
}

/**
 * Color semántico para la etiqueta visible (mismo criterio que displayResultLabel).
 */
function resultColor(status) {
    const clase = classifyResultStatus(status);
    if (clase === 'Enviado') return '#22c55e';
    if (clase === 'NoEncontrado') return '#94a3b8';
    if (clase === 'Duplicado' || clase === 'Omitido' || clase === 'Pendiente') return '#a3a3a3';
    return '#ef4444';
}

/**
 * Texto plano para la columna Estado de los reportes (CSV/XLS), sin emojis.
 * Solo los errores conservan el detalle técnico (`Error: <mensaje>`); el
 * resto sale como etiqueta única (Enviado / Sin WhatsApp / Duplicado /
 * Omitido) para no ensuciar los datos del cliente con reemplazos globales.
 */
function exportStatusText(status) {
    const s = String(status || '');
    const clase = classifyResultStatus(s);
    if (clase === 'Enviado') return 'Enviado';
    if (clase === 'NoEncontrado') return 'Sin WhatsApp';
    if (clase === 'Duplicado') return 'Duplicado';
    if (clase === 'Omitido') return 'Omitido';
    if (s === PENDIENTE_CUENTA_LIMITADA) return PENDIENTE_CUENTA_LIMITADA;
    if (clase === 'Pendiente') return 'Pendiente';
    const detalle = s.replace(/^Error\s*:?\s*/, '');
    return detalle ? `Error: ${detalle}` : 'Error';
}

/**
 * Cuenta resultados por clase de negocio. Acepta objetos { status } o textos.
 */
function summarizeResults(contactResults) {
    const lista = Array.isArray(contactResults) ? contactResults : [];
    const resumen = { enviados: 0, sinWhatsApp: 0, errores: 0, duplicados: 0, omitidos: 0, pendientes: 0 };
    for (const item of lista) {
        const estado = item && typeof item === 'object' ? item.status : item;
        const clase = classifyResultStatus(estado);
        if (clase === 'Enviado') resumen.enviados += 1;
        else if (clase === 'NoEncontrado') resumen.sinWhatsApp += 1;
        else if (clase === 'Duplicado') resumen.duplicados += 1;
        else if (clase === 'Omitido') resumen.omitidos += 1;
        else if (clase === 'Pendiente') resumen.pendientes += 1;
        else resumen.errores += 1;
    }
    return resumen;
}

/**
 * Resultados por índice de contacto. Los del motor traen `index` y pueden
 * tener huecos (campaña detenida con filas por cuenta); los historiales
 * viejos sin `index` se leen por posición, como antes.
 */
function resultadosPorIndice(contactResults) {
    const results = Array.isArray(contactResults) ? contactResults : [];
    const conIndice = results.length > 0 && results.every(r => r && Number.isInteger(r.index));
    const porIndice = new Map();
    results.forEach((r, pos) => porIndice.set(conIndice ? r.index : pos, r));
    return porIndice;
}

/**
 * Contactos a retomar con la cuenta que los tenía: los nunca alcanzados
 * (cuenta SIN_CUENTA) y los que quedaron Error o Pendiente (su `target`).
 * Duplicados, Omitidos, Sin WhatsApp y Enviados no se retoman. El orden de
 * `contacts` se preserva.
 */
function computePendingAssignments(contacts, contactResults) {
    const lista = Array.isArray(contacts) ? contacts : [];
    const porIndice = resultadosPorIndice(contactResults);
    const pendientes = [];
    lista.forEach((contacto, i) => {
        const result = porIndice.get(i);
        if (!result) {
            pendientes.push({ contacto, cuenta: SIN_CUENTA });
            return;
        }
        const clase = classifyResultStatus(result.status);
        // `Pendiente` es lo que la cuota o el disyuntor dejaron sin enviar: se
        // retoma igual que un error, o se perdería.
        if (clase !== 'Error' && clase !== 'Pendiente') return;
        pendientes.push({ contacto, cuenta: typeof result.target === 'string' ? result.target : SIN_CUENTA });
    });
    return pendientes;
}

/** Contactos a retomar tras una campaña cortada (sin su cuenta). */
function computePendingContacts(contacts, contactResults) {
    return computePendingAssignments(contacts, contactResults).map(p => p.contacto);
}

/**
 * Texto del botón "Retomar envío" con el desglose por cuenta. `etiquetar`
 * nombra una cuenta (el dashboard pasa WhatsAppTargets.etiquetaTarget).
 */
function textoRetomar(pendientes, etiquetar) {
    const lista = Array.isArray(pendientes) ? pendientes : [];
    const nombrar = typeof etiquetar === 'function' ? etiquetar : (cuenta) => cuenta;
    const porCuenta = new Map();
    for (const { cuenta } of lista) {
        const nombre = cuenta === SIN_CUENTA ? 'cualquier cuenta' : nombrar(cuenta);
        porCuenta.set(nombre, (porCuenta.get(nombre) || 0) + 1);
    }
    const desglose = [...porCuenta].map(([nombre, n]) => nombre + ' → ' + n).join(', ');
    return '▶️ Retomar envío (' + lista.length + ' pendientes' + (desglose ? ': ' + desglose : '') + ')';
}

function parseSpinSyntax(text) {
    return text.replace(/\{([^{}]*\|[^{}]*)\}/g, (match, options) => {
        const choices = options.split('|');
        return choices[Math.floor(Math.random() * choices.length)];
    });
}

function personalizeMessage(template, data) {
    if (!template) return '';
    let result = template;
    if (data) {
        result = result.replace(/\{\{([^\{\}]+)\}\}/g, (match, key) => {
            const cleanKey = key.trim();
            const foundKey = Object.keys(data).find(k => k.toLowerCase() === cleanKey.toLowerCase());
            return foundKey !== undefined ? String(data[foundKey]) : match;
        });
    }
    return parseSpinSyntax(result);
}

function extractPhone(contact) {
    if (!contact) return '';
    const directKeys = ['telefono', 'Telefono', 'TELEFONO', 'Phone', 'phone', 'Celular', 'celular', 'Cel', 'cel', 'Movil', 'movil'];
    for (const key of directKeys) {
        if (contact[key] !== undefined && contact[key] !== null && String(contact[key]).trim() !== '') {
            return String(contact[key]).trim();
        }
    }
    const keys = Object.keys(contact);
    const phoneKey = keys.find(k => /tel|cel|phone|movil|mobile/i.test(k));
    if (phoneKey && contact[phoneKey] !== undefined && contact[phoneKey] !== null && String(contact[phoneKey]).trim() !== '') {
        const val = String(contact[phoneKey]).trim();
        const digitsOnly = val.replace(/[^\d]/g, '');
        if (digitsOnly.length >= 7) return val;
    }
    for (const rawVal of Object.values(contact)) {
        const val = String(rawVal).replace(/\.0*$/, '');
        if (/^\+?\d{7,15}$/.test(val)) return val;
    }
    return '';
}

// Reparto fijo por cuenta (ADR 20261028): lo que una cuenta no envía se queda
// en ella con su target, para que "Retomar envío" se lo devuelva.
const SIN_CUENTA = '';
const FALLOS_SEGUIDOS_DISYUNTOR = 3;
const PENDIENTE_CUOTA = 'Pendiente: cuota diaria agotada';
const PENDIENTE_FUERA_DE_SERVICIO = 'Pendiente: cuenta fuera de servicio';
const PENDIENTE_NO_HABILITADA = 'Pendiente: cuenta no habilitada';
// WhatsApp dejó de contestar la consulta de números: seguir con esa cuenta solo quema clientes.
const PENDIENTE_CUENTA_LIMITADA = 'Pendiente: cuenta limitada por WhatsApp';

/**
 * Reparte los índices 0..cantidad-1 en una fila por cuenta. Con `asignaciones`
 * (paralelo a los contactos) cada contacto vuelve a su cuenta; sin cuenta
 * (SIN_CUENTA) va por turnos; una cuenta que no está en `targets` deja el
 * contacto en `noHabilitados`. Asignaciones de otro largo se ignoran.
 */
function asignarContactos(cantidad, targets, asignaciones) {
    const lista = Array.isArray(targets) ? targets : [];
    const previas = Array.isArray(asignaciones) && asignaciones.length === cantidad ? asignaciones : [];
    const filas = lista.map(() => []);
    const noHabilitados = [];
    let turno = 0;
    for (let i = 0; i < cantidad; i++) {
        const cuenta = typeof previas[i] === 'string' ? previas[i] : SIN_CUENTA;
        if (cuenta !== SIN_CUENTA) {
            const pos = lista.indexOf(cuenta);
            if (pos >= 0) filas[pos].push(i);
            else noHabilitados.push(i);
            continue;
        }
        if (lista.length === 0) {
            noHabilitados.push(i);
            continue;
        }
        filas[turno % lista.length].push(i);
        turno += 1;
    }
    return { filas, noHabilitados };
}

class CampaignEngine {
    /**
     * @param {Object} opts
     * @param {Array} opts.contacts - lista de contactos (objetos)
     * @param {string} opts.template - plantilla principal
     * @param {Array} [opts.messageVariants] - variantes opcionales (si randomizeMessages=true, elige aleatoria)
     * @param {Array} opts.channels - instancias Channel
     * @param {Object} [opts.channel] - alias singular
     * @param {Object} [opts.config] - { randomizeMessages:boolean, antiSpamPauseMs:number, retryDelayMs:number }
     * @param {Function} [opts.pickMessage] - función personalizada para elegir mensaje (inyectable para tests)
     * @param {Function} [opts.cuotaDisponible] - (target) => boolean; ausente = sin límite
     * @param {Function} [opts.registrarEnvio] - (target) => void; se llama solo con resultado Enviado
     * @param {string[]} [opts.asignaciones] - cuenta de cada contacto al retomar; '' = por turnos
     */
    constructor(opts) {
        this.contacts = Array.isArray(opts.contacts) ? opts.contacts : [];
        this.template = opts.template || '';
        this.messageVariants = Array.isArray(opts.messageVariants) ? opts.messageVariants : [];
        this.channels = Array.isArray(opts.channels) ? opts.channels : (opts.channel ? [opts.channel] : []);
        this.config = opts.config || {};
        this.imageDataUrl = opts.imageDataUrl || '';
        this.pickMessageFn = opts.pickMessage || null;
        // Cuotas por cuenta: el motor no sabe de archivos ni de fechas, solo
        // pregunta y avisa. Ausentes => campaña sin tope, como antes.
        this.cuotaDisponible = typeof opts.cuotaDisponible === 'function' ? opts.cuotaDisponible : null;
        this.registrarEnvio = typeof opts.registrarEnvio === 'function' ? opts.registrarEnvio : null;
        // Retomar: la cuenta de cada contacto (paralelo a contacts). Vacío = por turnos.
        this.asignaciones = Array.isArray(opts.asignaciones) ? opts.asignaciones : [];
        this.results = [];
        this.aborted = false;
        const sp = opts.seenPhones;
        if (sp instanceof Set) this.seenPhones = new Set(sp);
        else if (Array.isArray(sp)) this.seenPhones = new Set(sp);
        else this.seenPhones = new Set();
    }

    abort() {
        this.aborted = true;
    }

    pickMessage() {
        if (this.pickMessageFn) return this.pickMessageFn(this);
        const variants = this.messageVariants.filter(v => v && String(v).trim() !== '');
        const randomize = this.config && this.config.randomizeMessages;
        if (randomize && variants.length > 0) {
            return variants[Math.floor(Math.random() * variants.length)];
        }
        if (variants.length > 0) return variants[0];
        return this.template || '';
    }

    async run(onProgress) {
        if (this.contacts.length === 0) return { results: [], sent: [] };

        // Resolver todos los targets (pueden ser N por canal, ej. AdbChannel)
        const targetEntries = [];
        for (const ch of this.channels) {
            const targets = await ch.listTargets();
            const list = Array.isArray(targets) ? targets : [];
            for (const t of list) {
                targetEntries.push({ channel: ch, target: t, pauseUntil: 0, fallosSeguidos: 0 });
            }
        }

        if (targetEntries.length === 0) {
            // Sin targets — marcar todos como fallidos sin lanzar
            const results = this.contacts.map((c, idx) => ({
                index: idx,
                phone: extractPhone(c),
                status: 'Error: sin targets disponibles',
                contactData: c,
                target: null
            }));
            this.results = results;
            return { results, sent: results.filter(r => r.status.includes('Enviado')) };
        }

        const blockedCounts = new Map(); // target -> consecutive blocks
        // Se acumula directamente en this.results (no en una variable local) para que
        // un consumidor externo (ej. adb-bridge-server) pueda leer el progreso en vivo
        // vía engine.results.length mientras la campaña sigue corriendo.
        this.results = [];
        const results = this.results;
        const resultsLock = { push: (r) => results.push(r) }; // single-thread, no lock needed

        const retryDelayMs = this.config.retryDelayMs !== undefined ? this.config.retryDelayMs : 10; // 10ms en tests, 4000 en prod
        const antiSpamPauseMs = this.config.antiSpamPauseMs !== undefined ? this.config.antiSpamPauseMs : 180000;
        const delayMin = this.config.delayMin !== undefined ? Math.max(this.config.delayMin, 0) : 0;
        const delayMax = this.config.delayMax !== undefined ? Math.max(this.config.delayMax, delayMin) : delayMin;

        const { filas, noHabilitados } = asignarContactos(
            this.contacts.length, targetEntries.map(e => e.target), this.asignaciones);
        targetEntries.forEach((entry, pos) => { entry.fila = filas[pos]; });

        // Un pendiente conserva su cuenta: "Retomar envío" se lo devuelve a ella.
        const registrarPendiente = (idx, status, target) => {
            const contact = this.contacts[idx];
            const pendiente = { index: idx, phone: extractPhone(contact), status, contactData: contact, target };
            resultsLock.push(pendiente);
            if (typeof onProgress === 'function') { try { onProgress(pendiente); } catch (_) {} }
        };
        for (const idx of noHabilitados) registrarPendiente(idx, PENDIENTE_NO_HABILITADA, this.asignaciones[idx]);

        const workers = targetEntries.map(entry => (async () => {
            let pos = 0;
            while (pos < entry.fila.length) {
                if (this.aborted) break;
                // Pausa anti-spam por target
                const now = Date.now();
                if (entry.pauseUntil > now) {
                    await sleep(entry.pauseUntil - now);
                    continue;
                }

                // Cuenta sin cuota del día: el resto de su fila espera en esta
                // misma cuenta (el reparto es fijo, no pasa a otra).
                if (this.cuotaDisponible && !this.cuotaDisponible(entry.target)) {
                    entry.fila.slice(pos).forEach(idx => registrarPendiente(idx, PENDIENTE_CUOTA, entry.target));
                    break;
                }

                const myIdx = entry.fila[pos++];
                const contact = this.contacts[myIdx];
                const phone = extractPhone(contact);
                const rawTemplate = this.pickMessage();
                const text = personalizeMessage(rawTemplate, contact);

                // Deduplicación — respeta config.duplicateRemoval y seenPhones compartido
                if (this.config.duplicateRemoval && phone && this.seenPhones.has(phone)) {
                    const dupResult = { phone, status: 'Duplicado', contactData: contact };
                    const enrichedDup = { index: myIdx, phone: dupResult.phone, status: dupResult.status, contactData: dupResult.contactData, target: entry.target };
                    resultsLock.push(enrichedDup);
                    if (typeof onProgress === 'function') { try { onProgress(enrichedDup); } catch (_) {} }
                    continue;
                }
                if (phone) this.seenPhones.add(phone);

                let result;
                try {
                    result = await this.processContactWithRetry({ contact, phone, text, entry, blockedCounts, retryDelayMs, antiSpamPauseMs });
                } catch (err) {
                    result = {
                        phone: phone || 'Sin teléfono',
                        status: `Error: ${err.message || String(err)}`,
                        contactData: contact
                    };
                }

                const enriched = {
                    index: myIdx,
                    phone: result.phone,
                    status: result.status,
                    contactData: result.contactData || contact,
                    target: entry.target
                };
                resultsLock.push(enriched);
                if (this.registrarEnvio && classifyResultStatus(enriched.status) === 'Enviado') {
                    try { this.registrarEnvio(entry.target); } catch (_) {}
                }
                if (typeof onProgress === 'function') {
                    try { onProgress(enriched); } catch (_) {}
                }

                // Disyuntor: una cuenta que falla seguido deja de quemar clientes.
                // Enviado reinicia; NoEncontrado/Duplicado/Omitido no cuentan.
                const clase = classifyResultStatus(enriched.status);
                if (clase === 'Enviado') entry.fallosSeguidos = 0;
                if (clase === 'Error') entry.fallosSeguidos += 1;
                if (enriched.status === PENDIENTE_CUENTA_LIMITADA) {
                    entry.fila.slice(pos).forEach(idx => registrarPendiente(idx, PENDIENTE_CUENTA_LIMITADA, entry.target));
                    break;
                }
                if (entry.fallosSeguidos >= FALLOS_SEGUIDOS_DISYUNTOR) {
                    entry.fila.slice(pos).forEach(idx => registrarPendiente(idx, PENDIENTE_FUERA_DE_SERVICIO, entry.target));
                    break;
                }

                // Pausa entre envíos por target (simula delayMin..delayMax)
                if (pos < entry.fila.length) {
                    const range = delayMax - delayMin;
                    const delaySecs = range > 0 ? (Math.floor(Math.random() * (range + 1)) + delayMin) : delayMin;
                    if (delaySecs > 0) await sleep(delaySecs * 1000);
                }
            }
        })());

        await Promise.all(workers);

        results.sort((a, b) => a.index - b.index);
        const sent = results.filter(r => r.status.includes('Enviado'));
        return { results, sent };
    }

    async processContactWithRetry({ contact, phone, text, entry, blockedCounts, retryDelayMs, antiSpamPauseMs }) {
        if (this.aborted) throw new Error('ABORTED: campaña detenida por el usuario');
        if (!phone) {
            return { phone: 'Sin teléfono', status: 'Omitido', contactData: contact };
        }
        if (!text || String(text).trim() === '') {
            throw new Error('TEMPLATE_EMPTY: plantilla vacía — abortando para evitar envío sin texto');
        }

        let lastError = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
            if (this.aborted) throw new Error('ABORTED: campaña detenida por el usuario');
            if (attempt > 1) {
                await sleep(retryDelayMs);
            }
            try {
                await entry.channel.openConversation(entry.target, phone, contact);
                // attachImage es opcional (feature-detection): solo los canales que lo
                // implementan (ej. AdbChannel) intentan adjuntar la imagen de campaña.
                if (this.imageDataUrl && typeof entry.channel.attachImage === 'function') {
                    await entry.channel.attachImage(entry.target, this.imageDataUrl);
                }
                await entry.channel.send(entry.target, text);
                // Verificación opcional (si el channel la implementa)
                if (typeof entry.channel.verifySent === 'function') {
                    const verified = await entry.channel.verifySent(entry.target);
                    if (verified === false) {
                        throw new Error('CARRIER_FAILED: verificado como no enviado');
                    }
                }
                // Evaluar bloqueo
                let isBlocked = false;
                if (typeof entry.channel.isBlocked === 'function') {
                    isBlocked = await entry.channel.isBlocked(entry.target);
                }
                const prev = blockedCounts.get(entry.target) || 0;
                if (isBlocked) {
                    const next = prev + 1;
                    blockedCounts.set(entry.target, next);
                    if (next >= 2) {
                        entry.pauseUntil = Date.now() + antiSpamPauseMs;
                        blockedCounts.set(entry.target, 0);
                    }
                } else {
                    blockedCounts.set(entry.target, 0);
                }

                return { phone, status: 'Enviado', contactData: contact };
            } catch (err) {
                lastError = err;
                const msg = err && err.message ? err.message : String(err);
                const isCarrier = msg.startsWith('CARRIER_FAILED');
                const isNotFound = msg.startsWith('WHATSAPP_NOT_FOUND');
                if (isNotFound) {
                    return { phone, status: `NoEncontrado: ${msg}`, contactData: contact };
                }
                if (msg.startsWith('WHATSAPP_ADB_CUENTA_LIMITADA')) {
                    return { phone, status: PENDIENTE_CUENTA_LIMITADA, contactData: contact };
                }
                if (!isCarrier) {
                    // Errores no-carrier no se reintentan
                    throw err;
                }
                if (attempt >= 3) {
                    // Agotados los reintentos
                    break;
                }
                // else reintentar
            }
        }
        const msg = lastError && lastError.message ? lastError.message : 'CARRIER_FAILED: agotados reintentos';
        return { phone, status: `Error: ${msg}`, contactData: contact };
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CampaignEngine, extractPhone, personalizeMessage, parseSpinSyntax, classifyResultStatus, computePendingContacts, displayResultLabel, resultColor, summarizeResults, exportStatusText, asignarContactos, SIN_CUENTA, FALLOS_SEGUIDOS_DISYUNTOR, PENDIENTE_CUOTA, PENDIENTE_FUERA_DE_SERVICIO, PENDIENTE_NO_HABILITADA, PENDIENTE_CUENTA_LIMITADA, computePendingAssignments, textoRetomar };
}
