'use strict';
const path = require('path');

// UUID del servicio RFCOMM: el mismo del spike y de la app Android (spec 2.1).
const UUID_SERVICIO = '6b1f3c2e-6a1d-4c7a-9f3e-adb0b1e70001';
const PAQUETE_ANDROID = 'com.anomalydevs.puenteadb';
const COMPONENTE_ANDROID = `${PAQUETE_ANDROID}/.PantallaEstado`;

function rutas(env = process.env) {
    const app = path.join(env.LOCALAPPDATA || '', 'PuenteBluetooth', 'app');
    return Object.freeze({
        datos: path.join(env.APPDATA || '', 'PuenteBluetooth'),
        app,
        apk: path.join(app, 'puente-adb.apk'),
        adbPorDefecto: path.join(env.LOCALAPPDATA || '', 'Android', 'platform-tools', 'adb.exe')
    });
}

module.exports = { UUID_SERVICIO, PAQUETE_ANDROID, COMPONENTE_ANDROID, rutas };
