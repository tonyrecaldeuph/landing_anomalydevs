'use strict';
const { execFile } = require('child_process');
const { exito, fallo } = require('../dominio/resultado');
const { CODIGOS } = require('../dominio/codigos');

const COMANDO = "Get-PnpDevice -Class Bluetooth | Where-Object InstanceId -like 'BTHENUM\\DEV_*' | Select-Object FriendlyName,InstanceId | ConvertTo-Json -Compress";

// Cada equipo emparejado aparece como BTHENUM\DEV_<MAC sin dos puntos>\...
function interpretarEmparejados(json) {
    const texto = String(json).trim();
    if (texto === '') return [];
    const datos = JSON.parse(texto);
    return (Array.isArray(datos) ? datos : [datos])
        .map((d) => ({ nombre: String(d.FriendlyName || ''), mac: (/DEV_([0-9A-F]{12})/i.exec(String(d.InstanceId)) || ['', ''])[1] }))
        .filter((d) => d.mac !== '')
        .map((d) => ({ nombre: d.nombre, mac: d.mac.toUpperCase().match(/../g).join(':') }));
}

function crearEmparejadosWindows({ ejecutar = execFile } = {}) {
    return {
        listar() {
            return new Promise((resolver) => {
                ejecutar('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', COMANDO], { windowsHide: true, timeout: 30000 }, (err, stdout = '') => {
                    if (err) return resolver(fallo(CODIGOS.SIN_EMPAREJADOS, err.message));
                    try {
                        resolver(exito(interpretarEmparejados(stdout)));
                    } catch (e) {
                        resolver(fallo(CODIGOS.SIN_EMPAREJADOS, e.message));
                    }
                });
            });
        }
    };
}

module.exports = { crearEmparejadosWindows, interpretarEmparejados };
