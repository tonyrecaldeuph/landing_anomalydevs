'use strict';
const fs = require('fs');
const path = require('path');
const { RegistroTelefonos } = require('../dominio/RegistroTelefonos');
const { CODIGOS } = require('../dominio/codigos');
const { escribirAtomico } = require('./escribirAtomico');

// telefonos.json: { "adbPath": "...", "telefonos": [{ nombre, mac, serialUsb, puerto }] }.
// Si falta o es inválido se arranca con el registro vacío (caso especial), nunca se lanza.
function crearConfiguracion({ dir, adbPorDefecto, bitacora }) {
    const archivo = path.join(dir, 'telefonos.json');
    const porDefecto = () => ({ registro: RegistroTelefonos.vacio(), adbPath: adbPorDefecto });

    function invalida(detalle) {
        bitacora.registrar({ telefono: '-', evento: 'configuracion_invalida', codigo: CODIGOS.REGISTRO_INVALIDO, detalle });
        return porDefecto();
    }

    return {
        archivo,
        leer() {
            let texto;
            try { texto = fs.readFileSync(archivo, 'utf8').replace(/^\uFEFF/, ''); } catch { return porDefecto(); }
            let datos;
            try { datos = JSON.parse(texto); } catch (err) { return invalida('JSON inválido: ' + err.message); }
            const registro = RegistroTelefonos.desde(datos && datos.telefonos);
            if (!registro.ok) return invalida(registro.detalle);
            const adbPath = typeof datos.adbPath === 'string' && datos.adbPath !== '' ? datos.adbPath : adbPorDefecto;
            return { registro: registro.valor, adbPath };
        },
        guardar({ registro, adbPath }) {
            escribirAtomico(archivo, JSON.stringify({ adbPath, telefonos: registro.aDatos() }, null, 2));
        }
    };
}

module.exports = { crearConfiguracion };
