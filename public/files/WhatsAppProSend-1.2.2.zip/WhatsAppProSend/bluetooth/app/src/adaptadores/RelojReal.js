'use strict';

function crearRelojReal() {
    return {
        esperar: (ms) => new Promise((resolver) => setTimeout(resolver, ms)),
        cadaIntervalo(ms, fn) {
            const id = setInterval(fn, ms);
            return () => clearInterval(id);
        }
    };
}

module.exports = { crearRelojReal };
