'use strict';
const fs = require('fs');
const path = require('path');

const MAX_BYTES = 1024 * 1024;
const COPIAS = 2; // puente.log + puente.log.1 + puente.log.2: 3 MB como máximo (spec 5)

function crearBitacora({ dir, ahora = () => new Date(), maxBytes = MAX_BYTES }) {
    const archivo = path.join(dir, 'puente.log');

    function rotarSiHaceFalta(bytesNuevos) {
        let tamano;
        try { tamano = fs.statSync(archivo).size; } catch { return; }
        if (tamano + bytesNuevos <= maxBytes) return;
        for (let i = COPIAS; i >= 1; i--) {
            const origen = i === 1 ? archivo : `${archivo}.${i - 1}`;
            try { fs.renameSync(origen, `${archivo}.${i}`); } catch { /* esa copia aún no existe */ }
        }
    }

    return {
        registrar({ telefono = '-', evento, codigo = '', detalle = '' }) {
            const linea = [ahora().toISOString(), telefono, evento, codigo, detalle].join('\t').trimEnd() + '\n';
            try {
                fs.mkdirSync(dir, { recursive: true });
                rotarSiHaceFalta(Buffer.byteLength(linea));
                fs.appendFileSync(archivo, linea);
            } catch {
                // La bitácora nunca debe tumbar el puente: si el disco falla, se pierde la línea.
            }
        }
    };
}

module.exports = { crearBitacora };
