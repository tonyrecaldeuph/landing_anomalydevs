'use strict';

const AF_BTH = 32;
const SOCK_STREAM = 1;
const BTHPROTO_RFCOMM = 3;
const WINSOCK_2_2 = 0x0202;

let api;

// Funciones de ws2_32 que usa el puente, cargadas una sola vez (koffi no admite redefinir
// tipos). SOCKET se declara intptr_t para que INVALID_SOCKET llegue como -1.
function cargarWinsock() {
    if (api) return api;
    const koffi = require('koffi');
    const ws2 = koffi.load('ws2_32.dll');
    const GUID = koffi.struct('PUENTE_GUID', { d1: 'uint32', d2: 'uint16', d3: 'uint16', d4: koffi.array('uint8', 8) });
    const SOCKADDR_BTH = koffi.pack('PUENTE_SOCKADDR_BTH', { family: 'uint16', btAddr: 'uint64', serviceClassId: GUID, port: 'uint32' });
    const WSAStartup = ws2.func('int __stdcall WSAStartup(uint16 version, _Out_ uint8 *datos)');
    WSAStartup(WINSOCK_2_2, Buffer.alloc(512)); // WSADATA ocupa 408 bytes en x64
    api = Object.freeze({
        socket: ws2.func('intptr_t __stdcall socket(int af, int tipo, int protocolo)'),
        conectarBth: ws2.func('int __stdcall connect(intptr_t s, const PUENTE_SOCKADDR_BTH *dir, int largo)'),
        send: ws2.func('int __stdcall send(intptr_t s, const void *datos, int largo, int flags)'),
        recv: ws2.func('int __stdcall recv(intptr_t s, void *datos, int largo, int flags)'),
        closesocket: ws2.func('int __stdcall closesocket(intptr_t s)'),
        WSAGetLastError: ws2.func('int __stdcall WSAGetLastError()'),
        tamanoBth: koffi.sizeof(SOCKADDR_BTH)
    });
    return api;
}

// port 0 + serviceClassId: Windows busca el canal RFCOMM por SDP (spike, ADR 20261021).
function direccionBth(mac, uuid) {
    const [d1, d2, d3] = uuid.split('-');
    const resto = uuid.replace(/-/g, '').slice(16);
    return {
        family: AF_BTH,
        btAddr: BigInt('0x' + mac.replace(/:/g, '')),
        serviceClassId: {
            d1: parseInt(d1, 16),
            d2: parseInt(d2, 16),
            d3: parseInt(d3, 16),
            d4: Array.from(Buffer.from(resto, 'hex'))
        },
        port: 0
    };
}

module.exports = { cargarWinsock, direccionBth, AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM };
