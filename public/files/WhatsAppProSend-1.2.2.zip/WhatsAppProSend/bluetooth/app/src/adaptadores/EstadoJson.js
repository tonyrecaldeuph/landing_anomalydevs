'use strict';
const fs = require('fs');
const path = require('path');
const { escribirAtomico } = require('./escribirAtomico');

// Caso especial: el servicio nunca escribió su latido.
const LATIDO_AUSENTE = Object.freeze({ pid: 0, hora: '' });

// estado.json: lo lee "Estado del puente". Se reescribe en cada transición.
function crearEstadoJson({ dir, ahora = () => new Date() }) {
    const archivo = path.join(dir, 'estado.json');
    const archivoLatido = path.join(dir, 'latido.json');
    const tablero = {};
    return {
        archivo,
        publicar(telefono, { estado, ultimoError }) {
            tablero[telefono.nombre] = { puerto: telefono.puerto, estado, ultimoError, desde: ahora().toISOString() };
            try {
                escribirAtomico(archivo, JSON.stringify(tablero, null, 2));
            } catch {
                // Mostrar el estado nunca debe tumbar el puente.
            }
        },
        leer() {
            try { return JSON.parse(fs.readFileSync(archivo, 'utf8')); } catch { return {}; }
        },
        latir(pid) {
            try {
                escribirAtomico(archivoLatido, JSON.stringify({ pid, hora: ahora().toISOString() }));
            } catch {
                // El latido nunca debe tumbar el puente.
            }
        },
        leerLatido() {
            try {
                const { pid, hora } = JSON.parse(fs.readFileSync(archivoLatido, 'utf8'));
                return Number.isInteger(pid) && typeof hora === 'string' ? { pid, hora } : LATIDO_AUSENTE;
            } catch {
                return LATIDO_AUSENTE;
            }
        }
    };
}

module.exports = { crearEstadoJson };
