'use strict';
const { execFile } = require('child_process');
const { exito, fallo } = require('../dominio/resultado');
const { CODIGOS } = require('../dominio/codigos');

// Windows.Devices.Radios es WinRT: en PowerShell 5.1 hay que esperar la operación
// asíncrona con AsTask. Imprime el estado de cada radio Bluetooth ("On"/"Off").
const COMANDO = [
    'Add-Type -AssemblyName System.Runtime.WindowsRuntime',
    "$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]",
    '[Windows.Devices.Radios.Radio,Windows.System.Devices,ContentType=WindowsRuntime] | Out-Null',
    '$radios = $asTask.MakeGenericMethod([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]]).Invoke($null, @([Windows.Devices.Radios.Radio]::GetRadiosAsync())).Result',
    "($radios | Where-Object { $_.Kind -eq 'Bluetooth' } | ForEach-Object { $_.State }) -join ','"
].join('; ');

function interpretarRadio(salida) {
    return String(salida).trim().split(',').map((estado) => estado.trim()).includes('On');
}

function crearRadioWindows({ ejecutar = execFile } = {}) {
    return {
        encendida() {
            return new Promise((resolver) => {
                ejecutar('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', COMANDO], { windowsHide: true, timeout: 30000 }, (err, stdout = '') => {
                    if (err) return resolver(fallo(CODIGOS.SIN_ADAPTADOR, err.message));
                    resolver(exito(interpretarRadio(stdout)));
                });
            });
        }
    };
}

module.exports = { crearRadioWindows, interpretarRadio };
