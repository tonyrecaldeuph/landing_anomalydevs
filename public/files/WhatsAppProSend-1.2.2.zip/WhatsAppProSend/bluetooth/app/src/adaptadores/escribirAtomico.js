'use strict';
const fs = require('fs');
const path = require('path');

// Escribe a un .tmp y renombra: quien lee nunca ve un JSON a medias.
function escribirAtomico(archivo, contenido) {
    fs.mkdirSync(path.dirname(archivo), { recursive: true });
    const temporal = archivo + '.tmp';
    fs.writeFileSync(temporal, contenido);
    fs.renameSync(temporal, archivo);
}

module.exports = { escribirAtomico };
