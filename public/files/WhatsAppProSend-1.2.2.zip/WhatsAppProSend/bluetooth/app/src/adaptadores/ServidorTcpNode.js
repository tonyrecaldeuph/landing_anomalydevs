'use strict';
const net = require('net');
const { exito, fallo } = require('../dominio/resultado');
const { CODIGOS } = require('../dominio/codigos');

// Extremo (ver Puente) sobre la conexión TCP que abre el servidor adb.
function extremoDeSocket(socket) {
    socket.setNoDelay(true);
    let motivo = '';
    socket.on('error', (err) => { motivo = err.code || CODIGOS.ERROR_DESCONOCIDO; });
    return {
        escribir: (datos) => { if (!socket.destroyed) socket.write(datos); },
        alDatos: (fn) => { socket.on('data', fn); },
        alFin: (fn) => { socket.once('close', () => fn(motivo)); },
        cerrar: () => { socket.destroy(); }
    };
}

// Solo 127.0.0.1: los teléfonos no quedan expuestos a la red local (spec 2.2, seguridad).
function crearServidorTcp() {
    return {
        escuchar(puerto, alConectar) {
            return new Promise((resolver) => {
                const sockets = new Set();
                const servidor = net.createServer((socket) => {
                    sockets.add(socket);
                    socket.once('close', () => sockets.delete(socket));
                    alConectar(extremoDeSocket(socket));
                });
                servidor.on('error', (err) => resolver(fallo(
                    err.code === 'EADDRINUSE' ? CODIGOS.PUERTO_OCUPADO : CODIGOS.ERROR_DESCONOCIDO, err.message)));
                servidor.listen(puerto, '127.0.0.1', () => resolver(exito({
                    puerto: servidor.address().port,
                    cerrar: () => new Promise((listo) => {
                        sockets.forEach((s) => s.destroy());
                        servidor.close(() => listo());
                    })
                })));
            });
        }
    };
}

module.exports = { crearServidorTcp };
