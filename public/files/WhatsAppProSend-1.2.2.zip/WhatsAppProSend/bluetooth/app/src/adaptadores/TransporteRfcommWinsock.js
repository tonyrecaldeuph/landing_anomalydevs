'use strict';
const { exito, fallo } = require('../dominio/resultado');
const { CODIGOS } = require('../dominio/codigos');
const { traducirErrorWinsock } = require('../dominio/traducirErrorWinsock');
const { cargarWinsock, direccionBth, AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM } = require('./Winsock');
const { crearCanalWinsock } = require('./CanalWinsock');

const LIMITE_CONEXION_MS = 10000;

// Transporte (ver Puente) por RFCOMM con Winsock. El `api` se inyecta para probar sin koffi.
function crearTransporteRfcomm({ api = cargarWinsock(), limiteMs = LIMITE_CONEXION_MS } = {}) {
    return {
        abrir(mac, uuid) {
            return new Promise((resolver) => {
                const s = api.socket(AF_BTH, SOCK_STREAM, BTHPROTO_RFCOMM);
                if (s < 0) return resolver(fallo(traducirErrorWinsock(api.WSAGetLastError()), 'socket()'));
                let resuelto = false;
                const reloj = setTimeout(() => {
                    resuelto = true;
                    api.closesocket(s); // aborta el connect pendiente
                    resolver(fallo(CODIGOS.FUERA_DE_ALCANCE, `sin respuesta en ${limiteMs} ms`));
                }, limiteMs);
                api.conectarBth.async(s, direccionBth(mac, uuid), api.tamanoBth, (err, r) => {
                    if (resuelto) return;
                    clearTimeout(reloj);
                    if (err || r !== 0) {
                        const codigo = err ? 0 : api.WSAGetLastError();
                        api.closesocket(s);
                        return resolver(fallo(traducirErrorWinsock(codigo), `WSA ${codigo}`));
                    }
                    resolver(exito(crearCanalWinsock(api, s)));
                });
            });
        }
    };
}

module.exports = { crearTransporteRfcomm };
