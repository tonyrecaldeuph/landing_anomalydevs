'use strict';
const { CODIGOS } = require('../dominio/codigos');
const { traducirErrorWinsock } = require('../dominio/traducirErrorWinsock');

const TAMANO_BLOQUE = 64 * 1024;

// Extremo (ver Puente) sobre un SOCKET de Winsock ya conectado. recv y send corren con
// .async en el pool de libuv (por eso el servicio corre con UV_THREADPOOL_SIZE=16): nunca
// bloquean el event loop ni a los otros teléfonos. Un solo send en vuelo a la vez.
function crearCanalWinsock(api, s) {
    const oyentesDatos = [];
    const oyentesFin = [];
    const cola = [];
    let enviando = false;
    let leyendo = false;
    let terminado = false;

    function terminar(motivo, detalle = '') {
        if (terminado) return;
        terminado = true;
        api.closesocket(s); // desbloquea el recv pendiente, que vuelve con 10053 y se ignora
        oyentesFin.forEach((fn) => fn(motivo, detalle));
    }

    // El detalle lleva el código WSA crudo: la bitácora lo exige en cada corte (spec 5).
    function terminarPorError(err) {
        if (err) return terminar(CODIGOS.ERROR_DESCONOCIDO, String(err.message || err));
        const wsa = api.WSAGetLastError();
        return terminar(traducirErrorWinsock(wsa), `WSA ${wsa}`);
    }

    function leer() {
        const bloque = Buffer.alloc(TAMANO_BLOQUE);
        api.recv.async(s, bloque, bloque.length, 0, (err, n) => {
            if (terminado) return;
            if (err || n < 0) return terminarPorError(err);
            if (n === 0) return terminar('');
            const datos = bloque.subarray(0, n);
            oyentesDatos.forEach((fn) => fn(datos));
            leer();
        });
    }

    function enviarSiguiente() {
        if (enviando || terminado || cola.length === 0) return;
        enviando = true;
        const datos = cola.shift();
        api.send.async(s, datos, datos.length, 0, (err, n) => {
            enviando = false;
            if (terminado) return;
            if (err || n < 0) return terminarPorError(err);
            if (n < datos.length) cola.unshift(datos.subarray(n));
            enviarSiguiente();
        });
    }

    return {
        escribir(datos) {
            if (terminado) return;
            cola.push(Buffer.from(datos));
            enviarSiguiente();
        },
        alDatos(fn) {
            oyentesDatos.push(fn);
            if (!leyendo) {
                leyendo = true;
                leer();
            }
        },
        alFin(fn) {
            oyentesFin.push(fn);
        },
        cerrar() {
            terminar('');
        }
    };
}

module.exports = { crearCanalWinsock };
