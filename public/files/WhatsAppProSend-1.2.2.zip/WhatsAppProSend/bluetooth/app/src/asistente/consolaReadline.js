'use strict';
const readline = require('readline');

function crearConsolaReadline({ entrada = process.stdin, salida = process.stdout } = {}) {
    const rl = readline.createInterface({ input: entrada, output: salida });
    const preguntar = (texto) => new Promise((resolver) => rl.question(texto + ' ', resolver));
    return {
        decir: (texto) => { salida.write(texto + '\n'); },
        pausa: async (texto) => { await preguntar(texto); },
        async elegir(titulo, opciones) {
            salida.write(titulo + '\n');
            opciones.forEach((opcion, i) => salida.write(`  ${i + 1}. ${opcion}\n`));
            for (;;) {
                const n = Number(await preguntar('Escribe el número:'));
                if (Number.isInteger(n) && n >= 1 && n <= opciones.length) return n - 1;
                salida.write('Número inválido.\n');
            }
        },
        cerrar: () => rl.close()
    };
}

module.exports = { crearConsolaReadline };
