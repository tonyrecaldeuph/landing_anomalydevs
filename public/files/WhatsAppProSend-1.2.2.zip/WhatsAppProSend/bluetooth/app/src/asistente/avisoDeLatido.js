'use strict';

const LATIDO_VIEJO_MS = 30000;

function procesoVivo(pid) {
    try {
        process.kill(pid, 0);
        return true;
    } catch (err) {
        return err.code === 'EPERM';
    }
}

// "Estado del puente" no debe mostrar como vigente un estado.json que nadie actualiza.
function avisoDeLatido(latido, ahora = new Date(), estaVivo = procesoVivo) {
    if (latido.hora === '') {
        return 'AVISO: el puente nunca arrancó en esta PC. Cierra sesión y vuelve a entrar, o reinstálalo.';
    }
    const viejo = ahora.getTime() - Date.parse(latido.hora) > LATIDO_VIEJO_MS;
    if (viejo || !estaVivo(latido.pid)) {
        return `AVISO: el puente está detenido desde ${latido.hora}. Los estados de abajo pueden estar viejos. Cierra sesión y vuelve a entrar para reiniciarlo.`;
    }
    return '';
}

module.exports = { avisoDeLatido, procesoVivo };
