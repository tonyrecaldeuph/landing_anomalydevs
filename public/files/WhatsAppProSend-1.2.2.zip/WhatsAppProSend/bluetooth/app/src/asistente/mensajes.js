'use strict';

const MENSAJE_GENERICO = 'Algo falló al agregar el teléfono. Revisa el detalle y vuelve a intentarlo.';

const MENSAJES = Object.freeze({
    SIN_TELEFONO_USB: 'No veo ningún teléfono por cable. Revisa el cable y acepta "Permitir depuración USB" en el teléfono.',
    INSTALACION_FALLIDA: 'No se pudo instalar la app del puente. En HONOR, activa "Instalar vía USB" en Opciones de desarrollador.',
    SIN_EMPAREJADOS: 'Windows no muestra el teléfono como emparejado. Emparéjalo en Configuración > Bluetooth y dispositivos.',
    REGISTRO_LLENO: 'Ya hay 3 teléfonos por Bluetooth en esta PC. Los demás van por cable USB.',
    MAC_REPETIDA: 'Ese equipo Bluetooth ya está registrado con otro teléfono.',
    PRUEBA_FALLIDA: 'El teléfono quedó registrado pero no respondió por Bluetooth. Revisa que la app diga "Esperando PC" y abre "Estado del puente".',
    ADB_AUSENTE: 'No encuentro adb.exe. Vuelve a ejecutar el instalador del puente.',
    ADB_FALLO: 'adb respondió con un error. Desconecta y vuelve a conectar el cable.',
    APP_NO_INSTALADA: 'La app del puente no quedó instalada en el teléfono. Sigue el aviso de arriba y vuelve a abrir el asistente.',
    BATERIA_OPTIMIZADA: 'El teléfono sigue con la optimización de batería para la app del puente: sin quitarla, el enlace se corta a mitad de campaña.',
    BLUETOOTH_APAGADO: 'El Bluetooth de esta PC está apagado. Enciéndelo en Configuración > Bluetooth y dispositivos y vuelve a abrir el asistente.'
});

function mensajeDe(resultado) {
    return MENSAJES[resultado.codigo] || MENSAJE_GENERICO;
}

module.exports = { mensajeDe, MENSAJE_GENERICO };
