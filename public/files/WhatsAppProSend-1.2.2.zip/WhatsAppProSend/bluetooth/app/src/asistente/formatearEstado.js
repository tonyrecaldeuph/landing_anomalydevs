'use strict';

const ENCABEZADO = ['Teléfono', 'Puerto', 'Estado', 'Último error', 'Desde'];

function formatearEstado(tablero) {
    const filas = Object.entries(tablero).sort(([, a], [, b]) => a.puerto - b.puerto);
    if (filas.length === 0) return 'No hay teléfonos registrados. Usa "Agregar teléfono" en el menú Inicio.';
    const datos = filas.map(([nombre, e]) => [nombre, String(e.puerto), e.estado, e.ultimoError || '-', e.desde]);
    const anchos = ENCABEZADO.map((titulo, i) => Math.max(titulo.length, ...datos.map((fila) => fila[i].length)));
    const linea = (celdas) => celdas.map((celda, i) => celda.padEnd(anchos[i])).join('  ').trimEnd();
    return [linea(ENCABEZADO), ...datos.map(linea)].join('\n');
}

module.exports = { formatearEstado };
