'use strict';

// Cada capa de Android nombra distinto los mismos ajustes: el asistente muestra
// los de la marca del teléfono. Una marca desconocida recibe los genéricos.
const TEXTOS_GENERICOS = Object.freeze({
    nombre: 'Android',
    instalarUsb: 'En Opciones de desarrollador activa "Instalar vía USB" (si existe) y acepta el aviso de instalación en el teléfono.',
    soloCarga: 'En la app del teléfono toca "Opciones de desarrollador" y activa "Permitir la depuración de ADB en modo Solo carga" (si tu teléfono la tiene).',
    bateria: 'En la app toca "Batería" y elige "Sin restricciones" (si ves un interruptor de segundo plano, toca el texto, no el interruptor).',
    inicio: 'Si tu teléfono tiene un ajuste de inicio automático de apps, actívalo para "Puente ADB".'
});

const TEXTOS_MIUI = Object.freeze({
    nombre: 'MIUI (Xiaomi)',
    instalarUsb: 'En Opciones de desarrollador activa "Instalar vía USB" (MIUI pide iniciar sesión en tu Mi cuenta) y acepta el aviso de instalación.',
    soloCarga: 'En la app toca "Opciones de desarrollador" y activa "Depuración USB (ajustes de seguridad)" y, si aparece, "Permitir la depuración de ADB en modo Solo carga".',
    bateria: 'En la app toca "Batería" y elige "Sin restricciones".',
    inicio: 'En Ajustes > Aplicaciones > Administrar aplicaciones > Puente ADB, activa "Inicio automático".'
});

const TEXTOS_MAGICOS = Object.freeze({
    nombre: 'MagicOS (HONOR)',
    instalarUsb: 'En Opciones de desarrollador activa "Instalar vía USB" y acepta el aviso de instalación.',
    soloCarga: 'En la app del teléfono toca "Opciones de desarrollador" y activa "Permitir la depuración de ADB en modo Solo carga".',
    bateria: 'En la app toca "Batería" y quita la optimización de batería.',
    inicio: 'En Ajustes > Batería > Inicio de aplicaciones, pon "Puente ADB" en "Gestionar manualmente" con las tres opciones activas.'
});

// TECNO, Infinix e itel (Transsion): no tienen "Instalar vía USB" y, como Android 14+,
// el interruptor de segundo plano solo deja la app en "Optimizado".
const TEXTOS_HIOS = Object.freeze({
    nombre: 'HiOS/XOS (TECNO, Infinix, itel)',
    instalarUsb: 'Acepta el aviso de instalación que aparece en el teléfono (TECNO e Infinix no tienen "Instalar vía USB") y revisa que "Verificar apps por USB" no la bloquee.',
    soloCarga: 'En la app toca "Opciones de desarrollador" y, si aparece, activa "Permitir la depuración de ADB en modo Solo carga".',
    bateria: 'En la app toca "Batería", luego toca el texto "Permitir uso en segundo plano" (no el interruptor) y elige "Sin restricciones".',
    inicio: 'Si tu teléfono tiene "Inicio automático" (en Ajustes o en Phone Master), actívalo para "Puente ADB".'
});

const POR_MARCA = Object.freeze({
    xiaomi: TEXTOS_MIUI,
    redmi: TEXTOS_MIUI,
    poco: TEXTOS_MIUI,
    honor: TEXTOS_MAGICOS,
    huawei: TEXTOS_MAGICOS,
    tecno: TEXTOS_HIOS,
    infinix: TEXTOS_HIOS,
    itel: TEXTOS_HIOS
});

function textosPorMarca(marca) {
    const clave = String(marca === undefined ? '' : marca).trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(POR_MARCA, clave) ? POR_MARCA[clave] : TEXTOS_GENERICOS;
}

module.exports = { textosPorMarca, TEXTOS_GENERICOS, TEXTOS_MIUI, TEXTOS_MAGICOS, TEXTOS_HIOS };
