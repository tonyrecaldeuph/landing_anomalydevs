'use strict';
const { exito, fallo } = require('../dominio/resultado');
const { CODIGOS } = require('../dominio/codigos');
const { textosPorMarca } = require('./textosPorMarca');

// El servicio relee telefonos.json cada 2 s y luego adb tarda en enlazar.
const ESPERA_RECARGA_MS = 6000;
// Tope de reintentos de un ajuste que el asesor debe corregir: evita un bucle sin fin.
// El primer eco suele llegar antes que el enlace: en un Infinix respondió recién a los ~40 s.
const INTENTOS_ECO = 8;
const ESPERA_ECO_MS = 5000;
const INTENTOS_VERIFICACION = 3;

const esUsb = (d) => d.estado === 'device' && !d.serial.includes(':');

// true si `comprobar` se cumple en alguno de los `intentos`; entre uno y otro corre `alFallar`.
async function repetirHasta(intentos, comprobar, alFallar) {
    for (let i = 1; i <= intentos; i++) {
        if (await comprobar()) return true;
        if (i < intentos) await alFallar();
    }
    return false;
}

// Asistente "Agregar teléfono" (spec 4.2): con cable y una sola vez por teléfono.
// Verifica por adb todo lo que se puede leer; lo demás queda como paso guiado.
async function agregarTelefono({ adb, emparejados, radio, configuracion, consola, reloj, apk, paquete, componenteApp }) {
    consola.decir('Paso 1/6: conecta el teléfono por cable USB con la depuración USB activada.');
    await consola.pausa('Cuando esté conectado, presiona Enter.');
    const lista = await adb.dispositivos();
    if (!lista.ok) return lista;
    const usb = lista.valor.filter(esUsb);
    if (usb.length === 0) return fallo(CODIGOS.SIN_TELEFONO_USB, 'no hay teléfonos autorizados por USB');
    const serial = usb.length === 1
        ? usb[0].serial
        : usb[await consola.elegir('¿Qué teléfono agregas?', usb.map((d) => d.serial))].serial;

    const marca = await adb.marca(serial);
    const textos = textosPorMarca(marca.ok ? marca.valor : '');
    consola.decir(`Teléfono detectado: ${textos.nombre}.`);

    const instalarYAbrir = async () => {
        const instalado = await adb.instalar(serial, apk);
        if (!instalado.ok) {
            consola.decir(textos.instalarUsb);
            return fallo(CODIGOS.INSTALACION_FALLIDA, instalado.detalle);
        }
        const presente = await adb.paqueteInstalado(serial, paquete);
        if (!presente.ok || !presente.valor) {
            consola.decir(textos.instalarUsb);
            return fallo(CODIGOS.APP_NO_INSTALADA, presente.ok ? `${paquete} no aparece en pm list packages` : presente.detalle);
        }
        await adb.abrirApp(serial, componenteApp);
        return exito(true);
    };

    const reactivarYProbar = async (telefono) => {
        consola.decir(`Paso 6/6: activando ADB por red y probando por Bluetooth en 127.0.0.1:${telefono.puerto}...`);
        const tcpip = await adb.tcpip(serial);
        if (!tcpip.ok) return fallo(CODIGOS.PRUEBA_FALLIDA, tcpip.detalle);
        await reloj.esperar(ESPERA_RECARGA_MS);
        const direccion = `127.0.0.1:${telefono.puerto}`;
        await adb.conectar(direccion);
        let eco = await adb.probarEco(direccion);
        for (let intento = 2; !eco.ok && intento <= INTENTOS_ECO; intento++) {
            consola.decir(`Esperando a que el teléfono responda por Bluetooth (intento ${intento} de ${INTENTOS_ECO})...`);
            await reloj.esperar(ESPERA_ECO_MS);
            await adb.desconectar(direccion);
            await adb.conectar(direccion);
            eco = await adb.probarEco(direccion);
        }
        if (!eco.ok) return fallo(CODIGOS.PRUEBA_FALLIDA, eco.detalle);
        consola.decir(`Listo: "${telefono.nombre}" responde por Bluetooth en ${direccion}. Ya puedes desconectar el cable.`);
        return exito(telefono);
    };

    const { registro, adbPath } = configuracion.leer();
    const conocido = registro.porSerialUsb(serial);
    if (conocido.esConocido) {
        consola.decir(`Este teléfono ya está registrado como "${conocido.nombre}" (puerto ${conocido.puerto}). Actualizo la app, lo reactivo y lo pruebo.`);
        const app = await instalarYAbrir();
        if (!app.ok) return app;
        return reactivarYProbar(conocido);
    }

    consola.decir('Paso 2/6: instalando la app del puente...');
    const app = await instalarYAbrir();
    if (!app.ok) return app;

    consola.decir(`Paso 3/6: ${textos.soloCarga}`);
    await consola.pausa('Cuando lo actives, presiona Enter.');

    // Primero lo intenta el asistente; el paso guiado queda para el sistema que lo rechace.
    await adb.quitarOptimizacionBateria(serial, paquete);
    const automatica = await adb.sinOptimizacionBateria(serial, paquete);
    const sinOptimizacion = (automatica.ok && automatica.valor) || await repetirHasta(INTENTOS_VERIFICACION, async () => {
        consola.decir(`Paso 4/6: ${textos.bateria} ${textos.inicio}`);
        await consola.pausa('Cuando termines, presiona Enter.');
        const r = await adb.sinOptimizacionBateria(serial, paquete);
        return r.ok && r.valor;
    }, async () => { consola.decir('Todavía tiene la optimización de batería. Repite el paso.'); });
    if (!sinOptimizacion) return fallo(CODIGOS.BATERIA_OPTIMIZADA, `seguía optimizada tras ${INTENTOS_VERIFICACION} intentos`);
    if (automatica.ok && automatica.valor) {
        consola.decir(`Paso 4/6: la app ya funciona sin restricciones de batería. ${textos.inicio}`);
        await consola.pausa('Cuando termines, presiona Enter.');
    }

    const radioLista = await repetirHasta(INTENTOS_VERIFICACION, async () => {
        const r = await radio.encendida();
        if (!r.ok) consola.decir('No pude comprobar el Bluetooth de esta PC; sigo.');
        return !r.ok || r.valor;
    }, async () => {
        consola.decir('El Bluetooth de esta PC está apagado. Enciéndelo en Configuración > Bluetooth y dispositivos.');
        await consola.pausa('Cuando esté encendido, presiona Enter.');
    });
    if (!radioLista) return fallo(CODIGOS.BLUETOOTH_APAGADO, `apagado tras ${INTENTOS_VERIFICACION} intentos`);

    consola.decir('Paso 5/6: empareja el teléfono con esta PC en Configuración de Windows > Bluetooth y dispositivos.');
    await consola.pausa('Cuando esté emparejado, presiona Enter.');

    const equipos = await emparejados.listar();
    if (!equipos.ok) return equipos;
    if (equipos.valor.length === 0) return fallo(CODIGOS.SIN_EMPAREJADOS, 'Windows no tiene equipos Bluetooth emparejados');
    const elegido = equipos.valor[await consola.elegir('¿Cuál es este teléfono?', equipos.valor.map((e) => `${e.nombre} (${e.mac})`))];

    const agregado = registro.agregar({ nombre: elegido.nombre, mac: elegido.mac, serialUsb: serial });
    if (!agregado.ok) return agregado;
    configuracion.guardar({ registro: agregado.valor.registro, adbPath });
    return reactivarYProbar(agregado.valor.telefono);
}

module.exports = { agregarTelefono, INTENTOS_VERIFICACION };
