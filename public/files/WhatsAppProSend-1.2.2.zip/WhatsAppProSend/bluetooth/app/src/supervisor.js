'use strict';
const { spawn: spawnReal } = require('child_process');
const net = require('net');

const MAX_REINICIOS = 3;
const ESPERA_MS = 60000;
const VIDA_ESTABLE_MS = 10 * 60000;
const POOL_LIBUV = '16';
const NOMBRE_CANDADO = 'PuenteBluetoothADB';

// Relanza el servicio si muere con error: 3 intentos, cada 1 min (spec 4.1). Si el
// servicio vivió 10 min o más, la caída cuenta como nueva y el contador vuelve a cero.
async function supervisar({ lanzar, esperar, bitacora, maxReinicios = MAX_REINICIOS, esperaMs = ESPERA_MS, vidaEstableMs = VIDA_ESTABLE_MS }) {
    let reinicios = 0;
    for (;;) {
        const { codigo, duracionMs } = await lanzar();
        if (codigo === 0) return 0;
        if (duracionMs >= vidaEstableMs) reinicios = 0;
        if (reinicios >= maxReinicios) {
            bitacora.registrar({ telefono: '-', evento: 'supervisor_se_rinde', codigo: String(codigo), detalle: `${reinicios} reinicios` });
            return codigo;
        }
        reinicios += 1;
        bitacora.registrar({ telefono: '-', evento: 'servicio_caido', codigo: String(codigo), detalle: `reinicio ${reinicios} de ${maxReinicios} en ${esperaMs} ms` });
        await esperar(esperaMs);
    }
}

// En Windows UV_THREADPOOL_SIZE solo surte efecto si se fija antes de arrancar el proceso
// (medido el 2026-10-21): por eso el servicio corre como hijo y no en este proceso.
function crearLanzadorDeServicio({ rutaServicio, spawn = spawnReal, ahora = Date.now }) {
    return () => new Promise((resolver) => {
        const inicio = ahora();
        const hijo = spawn(process.execPath, [rutaServicio], {
            env: { ...process.env, UV_THREADPOOL_SIZE: POOL_LIBUV },
            windowsHide: true,
            stdio: 'ignore'
        });
        hijo.once('error', () => resolver({ codigo: 1, duracionMs: ahora() - inicio }));
        hijo.once('exit', (codigo) => resolver({ codigo: typeof codigo === 'number' ? codigo : 1, duracionMs: ahora() - inicio }));
    });
}

// Instancia única: solo un proceso puede escuchar el mismo named pipe. Evita dos vigías y que
// un segundo servicio pise estado.json con PuertoOcupado.
function tomarCandado(nombre = NOMBRE_CANDADO) {
    return new Promise((resolver) => {
        const servidor = net.createServer();
        servidor.once('error', () => resolver({ tomado: false, soltar: async () => {} }));
        servidor.listen(`\\\\.\\pipe\\${nombre}`, () => resolver({
            tomado: true,
            soltar: () => new Promise((listo) => servidor.close(() => listo()))
        }));
    });
}

module.exports = { supervisar, crearLanzadorDeServicio, tomarCandado };
