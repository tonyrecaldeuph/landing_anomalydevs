'use strict';

// La radio Bluetooth de la PC busca un teléfono por vez: dos aperturas RFCOMM simultáneas se
// estorban y un teléfono cercano no enlazaba mientras otros dos lejanos agotaban sus 10 s
// (medido el 2026-11-11 con un adaptador Realtek). Encadena las aperturas de todos los
// teléfonos; una que falla o lanza no corta la cadena.
function aperturaDeUnaEnUna(transporte) {
    let cola = Promise.resolve();
    return {
        abrir(mac, uuid) {
            const turno = cola.then(() => transporte.abrir(mac, uuid));
            cola = turno.catch(() => {});
            return turno;
        }
    };
}

module.exports = { aperturaDeUnaEnUna };
