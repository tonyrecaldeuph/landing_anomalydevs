'use strict';
const { exito, fallo } = require('./resultado');
const { CODIGOS } = require('./codigos');

const PUERTOS = Object.freeze([7001, 7002, 7003]);
const FORMATO_MAC = /^([0-9A-F]{2}:){5}[0-9A-F]{2}$/;

// Caso especial: lo que devuelve una búsqueda sin coincidencia, en lugar de null.
const TELEFONO_DESCONOCIDO = Object.freeze({ nombre: 'desconocido', mac: '', serialUsb: '', puerto: 0, esConocido: false });

function normalizarMac(mac) {
    return String(mac).trim().toUpperCase();
}

function esTelefonoValido(t) {
    return Boolean(t) && typeof t.nombre === 'string' && t.nombre.trim() !== ''
        && FORMATO_MAC.test(normalizarMac(t.mac))
        && typeof t.serialUsb === 'string' && t.serialUsb.trim() !== ''
        && PUERTOS.includes(t.puerto);
}

// Hasta 3 teléfonos por Bluetooth por PC (ADR 20261021); los demás van por USB.
class RegistroTelefonos {
    constructor(telefonos) {
        this.lista = Object.freeze(telefonos.map((t) => Object.freeze({
            nombre: t.nombre, mac: normalizarMac(t.mac), serialUsb: t.serialUsb, puerto: t.puerto, esConocido: true
        })));
    }

    static vacio() {
        return new RegistroTelefonos([]);
    }

    static desde(datos) {
        if (!Array.isArray(datos)) return fallo(CODIGOS.REGISTRO_INVALIDO, 'se esperaba una lista de teléfonos');
        if (datos.length > PUERTOS.length) return fallo(CODIGOS.REGISTRO_INVALIDO, `máximo ${PUERTOS.length} teléfonos`);
        const indice = datos.findIndex((t) => !esTelefonoValido(t));
        if (indice !== -1) return fallo(CODIGOS.REGISTRO_INVALIDO, 'teléfono inválido: ' + JSON.stringify(datos[indice]));
        const macs = new Set(datos.map((t) => normalizarMac(t.mac)));
        const puertos = new Set(datos.map((t) => t.puerto));
        if (macs.size !== datos.length || puertos.size !== datos.length) {
            return fallo(CODIGOS.REGISTRO_INVALIDO, 'MAC o puerto repetido');
        }
        return exito(new RegistroTelefonos(datos));
    }

    telefonos() {
        return this.lista;
    }

    agregar({ nombre, mac, serialUsb }) {
        const macNormal = normalizarMac(mac);
        if (this.lista.some((t) => t.mac === macNormal)) return fallo(CODIGOS.MAC_REPETIDA, macNormal);
        const libre = PUERTOS.find((p) => !this.lista.some((t) => t.puerto === p));
        if (libre === undefined) return fallo(CODIGOS.REGISTRO_LLENO, `máximo ${PUERTOS.length} teléfonos por Bluetooth`);
        const nombreFinal = this.lista.some((t) => t.nombre === nombre) ? `${nombre} ${libre}` : nombre;
        const nuevo = { nombre: nombreFinal, mac: macNormal, serialUsb, puerto: libre };
        if (!esTelefonoValido(nuevo)) return fallo(CODIGOS.REGISTRO_INVALIDO, 'teléfono inválido: ' + JSON.stringify(nuevo));
        const registro = new RegistroTelefonos([...this.lista, nuevo]);
        return exito({ registro, telefono: registro.lista[registro.lista.length - 1] });
    }

    porSerialUsb(serial) {
        return this.lista.find((t) => t.serialUsb === serial) || TELEFONO_DESCONOCIDO;
    }

    aDatos() {
        return this.lista.map(({ nombre, mac, serialUsb, puerto }) => ({ nombre, mac, serialUsb, puerto }));
    }
}

module.exports = { RegistroTelefonos, TELEFONO_DESCONOCIDO, PUERTOS };
