'use strict';
const { CODIGOS } = require('./codigos');

const INTERVALO_MS = 10000;
const PUERTO_TCP_ADBD = '5555';

const direccionDe = (telefono) => `127.0.0.1:${telefono.puerto}`;

// Caso especial: sin app configurada, el vigía no revisa si el puente corre en el teléfono.
const SIN_APP = Object.freeze({ conocida: false, paquete: '', componente: '' });

// Cada 10 s: vuelve a enlazar con adb los teléfonos que desaparecieron (p. ej. tras
// `adb kill-server`) y reactiva `tcpip 5555` cuando un teléfono conocido llega por cable
// después de reiniciarse (spec 4.3). Por cable también abre la app del puente si no corre:
// MagicOS no le entrega BOOT_COMPLETED ni MY_PACKAGE_REPLACED (medido el 2026-10-22).
class Vigia {
    constructor({ registro, adb, bitacora, app = SIN_APP }) {
        this.registro = registro;
        this.adb = adb;
        this.bitacora = bitacora;
        this.app = app;
        this.revisando = false;
        this.ultimoAviso = '';
    }

    iniciar(reloj, intervaloMs = INTERVALO_MS) {
        this.revisar();
        return reloj.cadaIntervalo(intervaloMs, () => this.revisar());
    }

    async revisar() {
        if (this.revisando) return;
        this.revisando = true;
        try {
            const lista = await this.adb.dispositivos();
            if (!lista.ok) {
                this.avisarUnaVez(lista.codigo, lista.detalle);
                return;
            }
            this.ultimoAviso = '';
            const estados = new Map(lista.valor.map((d) => [d.serial, d.estado]));
            for (const telefono of this.registro.telefonos()) {
                await this.reactivarPorCable(telefono, estados);
                if (!estados.has(direccionDe(telefono))) await this.reconectar(telefono);
            }
        } catch (err) {
            this.bitacora.registrar({ telefono: '-', evento: 'vigia_error', codigo: CODIGOS.ERROR_DESCONOCIDO, detalle: String(err && err.message) });
        } finally {
            this.revisando = false;
        }
    }

    async reactivarPorCable(telefono, estados) {
        if (estados.get(telefono.serialUsb) !== 'device') return;
        if (estados.get(direccionDe(telefono)) === 'device') return;
        await this.reactivarTcpip(telefono);
        await this.abrirAppSiNoCorre(telefono);
    }

    async reactivarTcpip(telefono) {
        const puerto = await this.adb.puertoTcp(telefono.serialUsb);
        if (puerto.ok && puerto.valor === PUERTO_TCP_ADBD) return;
        const r = await this.adb.tcpip(telefono.serialUsb);
        this.bitacora.registrar(r.ok
            ? { telefono: telefono.nombre, evento: 'tcpip_reactivado', codigo: '', detalle: telefono.serialUsb }
            : { telefono: telefono.nombre, evento: 'tcpip_fallo', codigo: r.codigo, detalle: r.detalle });
    }

    async abrirAppSiNoCorre(telefono) {
        if (!this.app.conocida) return;
        const corriendo = await this.adb.appCorriendo(telefono.serialUsb, this.app.paquete);
        if (!corriendo.ok || corriendo.valor) return;
        const r = await this.adb.abrirApp(telefono.serialUsb, this.app.componente);
        this.bitacora.registrar(r.ok
            ? { telefono: telefono.nombre, evento: 'app_abierta', codigo: '', detalle: telefono.serialUsb }
            : { telefono: telefono.nombre, evento: 'app_fallo', codigo: r.codigo, detalle: r.detalle });
    }

    async reconectar(telefono) {
        const r = await this.adb.conectar(direccionDe(telefono));
        if (!r.ok) this.bitacora.registrar({ telefono: telefono.nombre, evento: 'adb_connect_fallo', codigo: r.codigo, detalle: r.detalle });
    }

    avisarUnaVez(codigo, detalle) {
        if (this.ultimoAviso === codigo) return;
        this.ultimoAviso = codigo;
        this.bitacora.registrar({ telefono: '-', evento: 'adb_no_disponible', codigo, detalle });
    }
}

module.exports = { Vigia, SIN_APP };
