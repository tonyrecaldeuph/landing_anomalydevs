'use strict';
const { CODIGOS } = require('./codigos');

// Códigos WSA observados en el spike (ADR 20261021) y sus vecinos documentados.
const TABLA = new Map([
    [10048, CODIGOS.ENLACE_OCUPADO],   // WSAEADDRINUSE: el servicio RFCOMM ya tiene un enlace
    [10053, CODIGOS.ENLACE_CORTADO],   // WSAECONNABORTED
    [10054, CODIGOS.ENLACE_CORTADO],   // WSAECONNRESET
    [10058, CODIGOS.ENLACE_CORTADO],   // WSAESHUTDOWN
    [10049, CODIGOS.FUERA_DE_ALCANCE], // WSAEADDRNOTAVAIL
    [10051, CODIGOS.FUERA_DE_ALCANCE], // WSAENETUNREACH
    [10060, CODIGOS.FUERA_DE_ALCANCE], // WSAETIMEDOUT
    [10061, CODIGOS.FUERA_DE_ALCANCE], // WSAECONNREFUSED: la app del teléfono no escucha
    [10064, CODIGOS.FUERA_DE_ALCANCE], // WSAEHOSTDOWN
    [10065, CODIGOS.FUERA_DE_ALCANCE], // WSAEHOSTUNREACH
    [10108, CODIGOS.FUERA_DE_ALCANCE], // WSASERVICE_NOT_FOUND: SDP no encontró el UUID
    [10047, CODIGOS.SIN_ADAPTADOR],    // WSAEAFNOSUPPORT: no hay pila Bluetooth
    [10050, CODIGOS.SIN_ADAPTADOR]     // WSAENETDOWN: radio apagada
]);

function traducirErrorWinsock(codigoWsa) {
    return TABLA.get(codigoWsa) || CODIGOS.ERROR_DESCONOCIDO;
}

module.exports = { traducirErrorWinsock };
