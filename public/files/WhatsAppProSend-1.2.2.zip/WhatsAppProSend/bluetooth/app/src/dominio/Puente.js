'use strict';
const { CODIGOS } = require('./codigos');

const ESPERA_ENLACE_OCUPADO_MS = 1000;
// adb reintenta cada pocos segundos y cada apertura fallida ocupa la radio de la PC hasta
// 10 s: con dos teléfonos lejos, la radio no alcanzaba a un tercero (medido el 2026-11-11).
const ENFRIAMIENTO_INICIAL_MS = 5000;
const ENFRIAMIENTO_MAXIMO_MS = 60000;
const ENFRIAN = new Set([CODIGOS.FUERA_DE_ALCANCE, CODIGOS.SIN_ADAPTADOR]);
// Un teléfono congelado deja el RFCOMM abierto sin contestar: adb queda "offline" y la PC lo
// mostraba "Enlazado" para siempre (Infinix con XOS, 2026-11-11). adb confirma cada mensaje en
// milisegundos, así que 20 s sin respuesta a algo enviado es un enlace muerto.
const LIMITE_SIN_RESPUESTA_MS = 20000;
const VIGILANCIA_MS = 5000;
// Caso especial: sin reloj de intervalos no se vigila el enlace.
const SIN_INTERVALO = () => () => {};

// Une la sesión TCP que abre adb en 127.0.0.1:<puerto> con un enlace RFCOMM al teléfono.
// Un solo enlace por teléfono: la sesión más nueva reemplaza a la anterior (ADR, requisito 1),
// y nunca hay dos aperturas en vuelo: una sesión que llega mientras se enlaza se cuelga de la
// apertura en curso. No reintenta salvo con el enlace ocupado (10048): quien reintenta es adb.
// Si el teléfono no aparece, enfría: rechaza las sesiones de adb sin tocar la radio durante
// 5 s, que se duplican en cada fallo hasta 60 s y vuelven a 5 s tras un enlace logrado.
class Puente {
    constructor({ telefono, transporte, uuid, esperar, bitacora, ahora = Date.now, cadaIntervalo = SIN_INTERVALO, alCambiarEstado = () => {} }) {
        this.telefono = telefono;
        this.transporte = transporte;
        this.uuid = uuid;
        this.esperar = esperar;
        this.bitacora = bitacora;
        this.alCambiarEstado = alCambiarEstado;
        this.ahora = ahora;
        this.cadaIntervalo = cadaIntervalo;
        this.enfriamientoMs = 0;
        this.enfriaHasta = 0;
        this.turno = 0;
        this.activo = true;
        this.abriendo = false;
        this.apertura = Promise.resolve();
        this.cerrarActual = () => {};
        this.situacion = Object.freeze({ estado: 'Esperando', ultimoError: '' });
    }

    estado() {
        return this.situacion;
    }

    async atender(sesion) {
        if (this.ahora() < this.enfriaHasta) {
            sesion.cerrar();
            return;
        }
        const turno = ++this.turno;
        this.cerrarActual();
        const pendientes = [];
        let destino = (datos) => pendientes.push(datos);
        let sesionViva = true;
        sesion.alDatos((datos) => destino(datos));
        sesion.alFin(() => { sesionViva = false; });
        this.cerrarActual = () => sesion.cerrar();
        this.cambiar('Enlazando', '');
        try {
            const enlace = await this.aperturaCompartida();
            // Una sesión reemplazada no toca el enlace: lo toma la vigente (o lo cierra cerrar()).
            if (turno !== this.turno) return;
            this.ajustarEnfriamiento(enlace);
            if (!enlace.ok) {
                this.registrar('sin_enlace', enlace.codigo, enlace.detalle);
                sesion.cerrar();
                this.cambiar(enlace.codigo === CODIGOS.SIN_ADAPTADOR ? 'SinAdaptador' : 'Esperando', enlace.codigo);
                return;
            }
            if (!sesionViva) {
                enlace.valor.cerrar();
                this.cambiar('Esperando', '');
                return;
            }
            const enviar = this.cruzar(sesion, enlace.valor, turno);
            for (const datos of pendientes) enviar(datos);
            destino = enviar;
        } catch (err) {
            if (turno !== this.turno) return;
            this.registrar('error_inesperado', CODIGOS.ERROR_DESCONOCIDO, err && err.message);
            sesion.cerrar();
            this.cambiar('Esperando', CODIGOS.ERROR_DESCONOCIDO);
        }
    }

    // Se cumple cuando no queda ninguna apertura en vuelo: la recarga no solapa conexiones.
    cerrar() {
        this.activo = false;
        this.turno += 1;
        this.cerrarActual();
        if (!this.abriendo) return Promise.resolve();
        return this.apertura.then((enlace) => { if (enlace.ok) enlace.valor.cerrar(); }, () => {});
    }

    aperturaCompartida() {
        if (!this.abriendo) {
            this.abriendo = true;
            this.apertura = this.abrirEnlace().finally(() => { this.abriendo = false; });
        }
        return this.apertura;
    }

    async abrirEnlace() {
        const primero = await this.transporte.abrir(this.telefono.mac, this.uuid);
        if (primero.ok || primero.codigo !== CODIGOS.ENLACE_OCUPADO) return primero;
        await this.esperar(ESPERA_ENLACE_OCUPADO_MS);
        if (!this.activo) return primero;
        return this.transporte.abrir(this.telefono.mac, this.uuid);
    }

    ajustarEnfriamiento(enlace) {
        if (enlace.ok) {
            this.enfriamientoMs = 0;
            return;
        }
        if (!ENFRIAN.has(enlace.codigo)) return;
        this.enfriamientoMs = Math.min(this.enfriamientoMs === 0 ? ENFRIAMIENTO_INICIAL_MS : this.enfriamientoMs * 2, ENFRIAMIENTO_MAXIMO_MS);
        this.enfriaHasta = this.ahora() + this.enfriamientoMs;
    }

    // Cierre cruzado: si se cae un extremo, se cierra el otro. Devuelve cómo enviar al teléfono.
    cruzar(sesion, enlace, turno) {
        let terminado = false;
        let esperaRespuesta = false;
        let esperaRespuestaDesde = 0;
        let dejarDeVigilar = () => {};
        const terminar = (motivo) => {
            if (terminado) return;
            terminado = true;
            dejarDeVigilar();
            sesion.cerrar();
            enlace.cerrar();
            if (turno === this.turno) this.cambiar('Esperando', motivo);
        };
        dejarDeVigilar = this.cadaIntervalo(VIGILANCIA_MS, () => {
            if (!esperaRespuesta || this.ahora() - esperaRespuestaDesde <= LIMITE_SIN_RESPUESTA_MS) return;
            this.registrar('enlace_sin_respuesta', CODIGOS.ENLACE_SIN_RESPUESTA, `sin respuesta en ${LIMITE_SIN_RESPUESTA_MS} ms`);
            terminar(CODIGOS.ENLACE_SIN_RESPUESTA);
        });
        enlace.alDatos((datos) => {
            esperaRespuesta = false;
            sesion.escribir(datos);
        });
        enlace.alFin((motivo, detalle) => {
            if (motivo) this.registrar('enlace_cortado', motivo, detalle);
            terminar(motivo);
        });
        sesion.alFin(() => terminar(''));
        this.cerrarActual = () => terminar('');
        this.cambiar('Enlazado', '');
        return (datos) => {
            if (!esperaRespuesta) {
                esperaRespuesta = true;
                esperaRespuestaDesde = this.ahora();
            }
            enlace.escribir(datos);
        };
    }

    registrar(evento, codigo, detalle) {
        this.bitacora.registrar({ telefono: this.telefono.nombre, evento, codigo, detalle: String(detalle || '') });
    }

    cambiar(estado, ultimoError) {
        this.situacion = Object.freeze({ estado, ultimoError });
        this.alCambiarEstado(this.telefono, this.situacion);
    }
}

module.exports = { Puente };
