'use strict';

// Resultado de una operación que puede fallar: { ok: true, valor } | { ok: false, codigo, detalle }.
// Reemplaza a null y a las excepciones en todo el límite entre dominio y adaptadores.
function exito(valor) {
    return Object.freeze({ ok: true, valor });
}

function fallo(codigo, detalle = '') {
    return Object.freeze({ ok: false, codigo, detalle: String(detalle) });
}

module.exports = { exito, fallo };
