'use strict';
const { execFile } = require('child_process');
const { exito, fallo } = require('../dominio/resultado');
const { CODIGOS } = require('../dominio/codigos');

const LIMITE_MS = 15000;
const LIMITE_INSTALAR_MS = 120000;

// Cada línea útil de `adb devices` es "<serial>\t<estado>"; el encabezado y los avisos
// del daemon ("* daemon started...") no llevan tabulador.
function interpretarDispositivos(salida) {
    return String(salida).split(/\r?\n/)
        .map((linea) => /^(\S+)\t(\S+)/.exec(linea.trim()))
        .filter(Boolean)
        .map(([, serial, estado]) => ({ serial, estado }));
}

const lineas = (salida) => String(salida).split(/\r?\n/).map((linea) => linea.trim());

// Mismo adb.exe que usan las apps (spec 4.1): dos versiones distintas se matan el servidor.
function crearAdbCli({ adbPath, limiteMs = LIMITE_MS, ejecutar = execFile }) {
    function correr(args, limite = limiteMs) {
        return new Promise((resolver) => {
            ejecutar(adbPath, args, { windowsHide: true, timeout: limite }, (err, stdout = '', stderr = '') => {
                if (err && err.code === 'ENOENT') return resolver(fallo(CODIGOS.ADB_AUSENTE, adbPath));
                if (err && err.killed) return resolver(fallo(CODIGOS.ADB_FALLO, `sin respuesta en ${limite} ms`));
                if (err) return resolver(fallo(CODIGOS.ADB_FALLO, String(stderr || err.message).trim()));
                resolver(exito(String(stdout)));
            });
        });
    }

    return {
        correr,
        async dispositivos() {
            const r = await correr(['devices']);
            return r.ok ? exito(interpretarDispositivos(r.valor)) : r;
        },
        async conectar(direccion) {
            const r = await correr(['connect', direccion]);
            if (!r.ok) return r;
            return /connected to/.test(r.valor) ? r : fallo(CODIGOS.ADB_FALLO, r.valor.trim());
        },
        async puertoTcp(serial) {
            const r = await correr(['-s', serial, 'shell', 'getprop', 'service.adb.tcp.port']);
            return r.ok ? exito(r.valor.trim()) : r;
        },
        tcpip: (serial) => correr(['-s', serial, 'tcpip', '5555']),
        instalar: (serial, apk) => correr(['-s', serial, 'install', '-r', '-g', apk], LIMITE_INSTALAR_MS),
        // `|| true`: pidof sale con 1 cuando no hay proceso, y eso no es un fallo de adb.
        async appCorriendo(serial, paquete) {
            const r = await correr(['-s', serial, 'shell', 'pidof', paquete, '||', 'true']);
            return r.ok ? exito(r.valor.trim() !== '') : r;
        },
        abrirApp: (serial, componente) => correr(['-s', serial, 'shell', 'am', 'start', '-n', componente]),
        async marca(serial) {
            const r = await correr(['-s', serial, 'shell', 'getprop', 'ro.product.brand']);
            return r.ok ? exito(r.valor.trim()) : r;
        },
        // pm filtra por subcadena: com.x también lista com.x.viejo.
        async paqueteInstalado(serial, paquete) {
            const r = await correr(['-s', serial, 'shell', 'pm', 'list', 'packages', paquete]);
            return r.ok ? exito(lineas(r.valor).includes(`package:${paquete}`)) : r;
        },
        // Cada línea de la lista blanca es "<tipo>,<paquete>,<uid>".
        async sinOptimizacionBateria(serial, paquete) {
            const r = await correr(['-s', serial, 'shell', 'dumpsys', 'deviceidle', 'whitelist']);
            return r.ok ? exito(lineas(r.valor).some((linea) => linea.split(',')[1] === paquete)) : r;
        },
        async probarEco(serial) {
            const r = await correr(['-s', serial, 'shell', 'echo', 'ok']);
            if (!r.ok) return r;
            return r.valor.trim() === 'ok' ? r : fallo(CODIGOS.ADB_FALLO, `respuesta inesperada: "${r.valor.trim()}"`);
        }
    };
}

module.exports = { crearAdbCli, interpretarDispositivos };
