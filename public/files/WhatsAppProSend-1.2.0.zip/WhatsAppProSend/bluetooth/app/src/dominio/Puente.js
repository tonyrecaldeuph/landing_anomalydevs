'use strict';
const { CODIGOS } = require('./codigos');

const ESPERA_ENLACE_OCUPADO_MS = 1000;

// Une la sesión TCP que abre adb en 127.0.0.1:<puerto> con un enlace RFCOMM al teléfono.
// Un solo enlace por teléfono: la sesión más nueva reemplaza a la anterior (ADR, requisito 1),
// y nunca hay dos aperturas en vuelo: una sesión que llega mientras se enlaza se cuelga de la
// apertura en curso. No reintenta salvo con el enlace ocupado (10048): quien reintenta es adb.
class Puente {
    constructor({ telefono, transporte, uuid, esperar, bitacora, alCambiarEstado = () => {} }) {
        this.telefono = telefono;
        this.transporte = transporte;
        this.uuid = uuid;
        this.esperar = esperar;
        this.bitacora = bitacora;
        this.alCambiarEstado = alCambiarEstado;
        this.turno = 0;
        this.activo = true;
        this.abriendo = false;
        this.apertura = Promise.resolve();
        this.cerrarActual = () => {};
        this.situacion = Object.freeze({ estado: 'Esperando', ultimoError: '' });
    }

    estado() {
        return this.situacion;
    }

    async atender(sesion) {
        const turno = ++this.turno;
        this.cerrarActual();
        const pendientes = [];
        let destino = (datos) => pendientes.push(datos);
        let sesionViva = true;
        sesion.alDatos((datos) => destino(datos));
        sesion.alFin(() => { sesionViva = false; });
        this.cerrarActual = () => sesion.cerrar();
        this.cambiar('Enlazando', '');
        try {
            const enlace = await this.aperturaCompartida();
            // Una sesión reemplazada no toca el enlace: lo toma la vigente (o lo cierra cerrar()).
            if (turno !== this.turno) return;
            if (!enlace.ok) {
                this.registrar('sin_enlace', enlace.codigo, enlace.detalle);
                sesion.cerrar();
                this.cambiar(enlace.codigo === CODIGOS.SIN_ADAPTADOR ? 'SinAdaptador' : 'Esperando', enlace.codigo);
                return;
            }
            if (!sesionViva) {
                enlace.valor.cerrar();
                this.cambiar('Esperando', '');
                return;
            }
            for (const datos of pendientes) enlace.valor.escribir(datos);
            destino = (datos) => enlace.valor.escribir(datos);
            this.cruzar(sesion, enlace.valor, turno);
        } catch (err) {
            if (turno !== this.turno) return;
            this.registrar('error_inesperado', CODIGOS.ERROR_DESCONOCIDO, err && err.message);
            sesion.cerrar();
            this.cambiar('Esperando', CODIGOS.ERROR_DESCONOCIDO);
        }
    }

    // Se cumple cuando no queda ninguna apertura en vuelo: la recarga no solapa conexiones.
    cerrar() {
        this.activo = false;
        this.turno += 1;
        this.cerrarActual();
        if (!this.abriendo) return Promise.resolve();
        return this.apertura.then((enlace) => { if (enlace.ok) enlace.valor.cerrar(); }, () => {});
    }

    aperturaCompartida() {
        if (!this.abriendo) {
            this.abriendo = true;
            this.apertura = this.abrirEnlace().finally(() => { this.abriendo = false; });
        }
        return this.apertura;
    }

    async abrirEnlace() {
        const primero = await this.transporte.abrir(this.telefono.mac, this.uuid);
        if (primero.ok || primero.codigo !== CODIGOS.ENLACE_OCUPADO) return primero;
        await this.esperar(ESPERA_ENLACE_OCUPADO_MS);
        if (!this.activo) return primero;
        return this.transporte.abrir(this.telefono.mac, this.uuid);
    }

    // Cierre cruzado: si se cae un extremo, se cierra el otro.
    cruzar(sesion, enlace, turno) {
        let terminado = false;
        const terminar = (motivo) => {
            if (terminado) return;
            terminado = true;
            sesion.cerrar();
            enlace.cerrar();
            if (turno === this.turno) this.cambiar('Esperando', motivo);
        };
        enlace.alDatos((datos) => sesion.escribir(datos));
        enlace.alFin((motivo, detalle) => {
            if (motivo) this.registrar('enlace_cortado', motivo, detalle);
            terminar(motivo);
        });
        sesion.alFin(() => terminar(''));
        this.cerrarActual = () => terminar('');
        this.cambiar('Enlazado', '');
    }

    registrar(evento, codigo, detalle) {
        this.bitacora.registrar({ telefono: this.telefono.nombre, evento, codigo, detalle: String(detalle || '') });
    }

    cambiar(estado, ultimoError) {
        this.situacion = Object.freeze({ estado, ultimoError });
        this.alCambiarEstado(this.telefono, this.situacion);
    }
}

module.exports = { Puente };
