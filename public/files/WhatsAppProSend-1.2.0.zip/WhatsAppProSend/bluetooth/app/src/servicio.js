'use strict';
const { Puente } = require('./dominio/Puente');
const { Vigia } = require('./dominio/Vigia');
const { PAQUETE_ANDROID, COMPONENTE_ANDROID } = require('./entorno');

const INTERVALO_VIGIA_MS = 10000;
const APP_PUENTE = Object.freeze({ conocida: true, paquete: PAQUETE_ANDROID, componente: COMPONENTE_ANDROID });

// Un Puente y un puerto local por teléfono. Un puerto ocupado deja fuera solo a ese
// teléfono (spec 5: un error afecta a un solo teléfono).
async function iniciarServicio({ registro, transporte, servidorTcp, adb, bitacora, estado, reloj, uuid, intervaloVigiaMs = INTERVALO_VIGIA_MS, app = APP_PUENTE }) {
    const activos = [];
    for (const telefono of registro.telefonos()) {
        const puente = new Puente({ telefono, transporte, uuid, esperar: reloj.esperar, bitacora, alCambiarEstado: estado.publicar });
        const servidor = await servidorTcp.escuchar(telefono.puerto, (sesion) => puente.atender(sesion));
        if (!servidor.ok) {
            bitacora.registrar({ telefono: telefono.nombre, evento: 'puerto_ocupado', codigo: servidor.codigo, detalle: servidor.detalle });
            estado.publicar(telefono, { estado: 'PuertoOcupado', ultimoError: servidor.codigo });
            continue;
        }
        estado.publicar(telefono, puente.estado());
        activos.push({ puente, servidor: servidor.valor });
    }
    const detenerVigia = new Vigia({ registro, adb, bitacora, app }).iniciar(reloj, intervaloVigiaMs);
    bitacora.registrar({ telefono: '-', evento: 'servicio_iniciado', codigo: '', detalle: `${activos.length} de ${registro.telefonos().length} teléfonos escuchando` });
    return {
        async detener() {
            detenerVigia();
            for (const { puente, servidor } of activos) {
                await puente.cerrar();
                await servidor.cerrar();
            }
        }
    };
}

// Reinicia el servicio con la configuración nueva cuando el asistente agrega un teléfono.
// Las recargas se encadenan: nunca hay dos servicios escuchando a la vez.
function crearRecargador(iniciar, alFallar) {
    let actual = { detener: async () => {} };
    let cadena = Promise.resolve();
    return {
        recargar() {
            cadena = cadena
                .then(async () => {
                    await actual.detener();
                    actual = { detener: async () => {} };
                    actual = await iniciar();
                })
                .catch(alFallar);
            return cadena;
        }
    };
}

// fs.watchFile llama una vez de inmediato si el archivo aún no existe (mtime 0 en ambos):
// solo un cambio real de la fecha de modificación debe recargar el servicio.
function cambioLaConfiguracion(actual, previo) {
    return actual.mtimeMs !== previo.mtimeMs;
}

module.exports = { iniciarServicio, crearRecargador, cambioLaConfiguracion };
