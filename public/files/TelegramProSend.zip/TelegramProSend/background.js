/**
 * Background Service Worker - TelegramProSend
 * Orquestador de la cola de envíos que sobrevive a:
 *   - Cierre del dashboard (popup)
 *   - Hibernación/terminación del Service Worker (MV3 lifecycle)
 *   - Descarte de la pestaña Telegram Web (tab discarding)
 */

importScripts('ui/utils.js', 'ui/licenseGate.js', 'ui/licenseClient.js', 'campaignEngine.js', 'channels/TelegramWebChannel.js');

// ────────────────────────────────────────────────────────────
// Constantes (sin magic numbers)
// ────────────────────────────────────────────────────────────
const KEEPALIVE_PERIOD_MIN = 0.5;          // 30s: mantiene SW despierto y resume si murió
const TAB_INITIAL_LOAD_MS = 4000;
const DEBUGGER_SETTLE_MS = 1500;
const CAMPAIGN_STATE_KEY = 'campaignState';
const KEEPALIVE_ALARM = 'campaign-keepalive';
const SCHEDULE_ALARM = 'startCampaignAlarm';
const LICENSE_VALIDATION_ALARM = 'licenseValidationAlarm';
const LICENSE_VALIDATION_PERIOD_MIN = 360; // 6h, revalidación cada 6 h
const BADGE_COLOR_RUNNING = '#22c55e';

// ────────────────────────────────────────────────────────────
// Estado volátil del SW (se pierde al hibernar — la verdad vive en storage)
// ────────────────────────────────────────────────────────────
let isCampaignRunning = false;
let backgroundDelayResolver = null;

// ────────────────────────────────────────────────────────────
// Ciclo de vida del SW: instalación y arranque (resume automático)
// ────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
    console.log('UPHONE Telegram Extension: Instalada con éxito.');
    resumeIfPending();
    setupLicenseValidationAlarm();
});

chrome.runtime.onStartup.addListener(() => {
    console.log('UPHONE Telegram Extension: SW arrancado, verificando campaña pendiente...');
    resumeIfPending();
    setupLicenseValidationAlarm();
});

/**
 * Crea la alarma de revalidación periódica de licencia y dispara una
 * validación inmediata (no espera 6h para la primera corrida tras instalar
 * o reiniciar Chrome).
 */
function setupLicenseValidationAlarm() {
    chrome.alarms.create(LICENSE_VALIDATION_ALARM, { periodInMinutes: LICENSE_VALIDATION_PERIOD_MIN });
    validateLicense().catch(err => console.warn('[license] validación inicial falló:', err?.message || err));
}

/**
 * Extrae el número de teléfono de un objeto de contacto.
 * Estrategia de búsqueda escalonada con logging diagnóstico.
 */
function extractPhone(contact) {
    if (!contact) return null;
    
    // 1. Campos directos con nombres exactos conocidos
    const directKeys = ['telefono', 'Telefono', 'TELEFONO', 'Phone', 'phone', 
                        'Celular', 'celular', 'Cel', 'cel', 'Movil', 'movil'];
    for (const key of directKeys) {
        if (contact[key] !== undefined && contact[key] !== null && contact[key] !== '') {
            const val = String(contact[key]);
            console.log(`[extractPhone] Encontrado por clave directa '${key}': ${val}`);
            return val;
        }
    }
    
    // 2. Búsqueda por nombre de columna que contenga tel/cel/phone/movil
    const keys = Object.keys(contact);
    const phoneKey = keys.find(k => /tel|cel|phone|movil|mobile/i.test(k));
    if (phoneKey && contact[phoneKey] !== undefined && contact[phoneKey] !== null && contact[phoneKey] !== '') {
        const val = String(contact[phoneKey]);
        const digitsOnly = val.replace(/[^\d]/g, '');
        if (digitsOnly.length >= 7) {
            console.log(`[extractPhone] Encontrado por patrón de columna '${phoneKey}': ${val}`);
            return val;
        }
    }
    
    // 3. Fallback: buscar en TODOS los valores un patrón de teléfono (7-15 dígitos)
    for (const [key, rawVal] of Object.entries(contact)) {
        const val = String(rawVal);
        // Manejar números de Excel que pueden tener decimales (ej: 593985770811.0)
        const cleaned = val.replace(/\.0*$/, '');
        if (/^\+?\d{7,15}$/.test(cleaned)) {
            console.log(`[extractPhone] Encontrado por fallback en columna '${key}': ${cleaned}`);
            return cleaned;
        }
    }
    
    console.warn('[extractPhone] No se encontró teléfono en:', JSON.stringify(Object.keys(contact)), Object.values(contact).map(v => String(v).substring(0, 20)));
    return null;
}

// --- Listener de Mensajes ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'START_CAMPAIGN') {
        (async () => {
            const gate = await getLicenseGate();
            if (!gate.allowed) {
                sendResponse({ status: 'LICENSE_BLOCKED', reason: gate.reason });
                return;
            }
            startCampaign();
            sendResponse({ status: 'STARTED' });
        })();
        return true;
    }

    if (request.action === 'STOP_CAMPAIGN') {
        (async () => {
            await markStopRequested();
            if (typeof backgroundDelayResolver === 'function') {
                backgroundDelayResolver();
            }
            const tabs = await chrome.tabs.query({ url: '*://web.telegram.org/*' });
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { action: 'ABORT_CURRENT_SEND' }).catch(() => {});
            });
            sendResponse({ status: 'STOP_PENDING' });
        })();
        return true;
    }

    if (request.action === 'PAUSE_CAMPAIGN') {
        (async () => {
            await setPauseRequested(true);
            sendResponse({ status: 'PAUSED' });
        })();
        return true;
    }

    if (request.action === 'RESUME_CAMPAIGN') {
        (async () => {
            const state = await loadPersistedState();
            if (state) {
                if (request.messageTemplate) state.messageTemplate = request.messageTemplate;
                if (Array.isArray(request.messageVariants)) state.messageVariants = request.messageVariants;
                if (request.imageDataUrl !== undefined) state.imageDataUrl = request.imageDataUrl;
                if (request.promoId !== undefined) state.promoId = request.promoId;
                await setPauseRequested(false);
                await savePersistedState(state);
            } else {
                await setPauseRequested(false);
            }
            sendResponse({ status: 'RESUMED' });
        })();
        return true;
    }

    if (request.action === 'GET_CAMPAIGN_STATUS') {
        (async () => {
            const state = await loadPersistedState();
            sendResponse({
                isRunning: isCampaignRunning || (state && state.isRunning === true),
                isPaused: state ? state.pauseRequested === true : false,
                progressIndex: state ? state.index : 0,
                total: state ? state.contacts.length : 0,
                results: state && Array.isArray(state.results) ? state.results.map(r => r.status) : []
            });
        })();
        return true;
    }

    if (request.action === 'CHECK_CONNECTION') {
        (async () => {
            try {
                // Simplificado: Verificamos si la pestaña existe. Si existe, estamos Online.
                // Esto evita bloqueos si el Content Script no se inyectó por falta de recarga.
                const tabs = await chrome.tabs.query({ url: '*://web.telegram.org/*' });
                if (tabs.length === 0) {
                    sendResponse({ isConnected: false });
                } else {
                    sendResponse({ isConnected: true });
                }
            } catch (err) {
                sendResponse({ isConnected: false });
            }
        })();
        return true;
    }

    if (request.action === 'SCHEDULE_CAMPAIGN') {
        const { delayInMinutes } = request;
        chrome.alarms.create('startCampaignAlarm', { delayInMinutes });
        sendResponse({ status: 'ALARM_SET' });
        return true;
    }

    if (request.action === 'DEBUGGER_TYPE_ONLY') {
        (async () => {
            try {
                const tabId = sender && sender.tab ? sender.tab.id : null;
                if (tabId == null) {
                    sendResponse({ status: 'ERROR', message: 'Sin pestaña emisora para escribir.' });
                    return;
                }
                const debugTarget = { tabId };
                try { await chrome.debugger.attach(debugTarget, '1.3'); } catch (_) {}

                // SIN Ctrl+A — asumimos body vacío (conversación recién abierta)
                await chrome.debugger.sendCommand(debugTarget, 'Input.insertText', {
                    text: request.text
                });
                sendResponse({ status: 'OK' });
            } catch (err) {
                console.error('Error en DEBUGGER_TYPE_ONLY:', err);
                sendResponse({ status: 'ERROR', message: err?.message || String(err) });
            }
        })();
        return true;
    }

    if (request.action === 'DEBUGGER_CLICK') {
        (async () => {
            const debugTarget = { tabId: sender.tab.id };
            try {
                try { await chrome.debugger.attach(debugTarget, '1.3'); } catch (_) {}
                await chrome.debugger.sendCommand(debugTarget, 'Input.dispatchMouseEvent', {
                    type: 'mousePressed', x: request.x, y: request.y, button: 'left', clickCount: 1
                });
                await chrome.debugger.sendCommand(debugTarget, 'Input.dispatchMouseEvent', {
                    type: 'mouseReleased', x: request.x, y: request.y, button: 'left', clickCount: 1
                });
                sendResponse({ ok: true });
            } catch (err) {
                console.error('Error con chrome.debugger (clic real):', err);
                sendResponse({ ok: false, error: err.message });
            }
        })();
        return true;
    }

    if (request.action === 'LICENSE_ACTIVATE') {
        (async () => {
            const state = await activateLicense(request.licenseKey);
            const gate = computeGateDecision(state, Date.now());
            sendResponse({ ...gate, ...state });
        })();
        return true;
    }

    if (request.action === 'LICENSE_STATUS') {
        (async () => {
            const state = await getCachedLicenseState();
            const gate = computeGateDecision(state, Date.now());
            sendResponse({ ...gate, ...(state || {}) });
        })();
        return true;
    }

    return true;
});

// Listener de alarmas: campañas programadas + keepalive con resume + licencia
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === SCHEDULE_ALARM) {
        console.log('Alarma disparada: Iniciando campaña programada');
        startCampaign();
        return;
    }
    if (alarm.name === KEEPALIVE_ALARM) {
        // Despierta al SW y verifica si el loop murió por terminación del SW.
        // Si hay estado persistente pero el flag en memoria no está corriendo → resumir.
        resumeIfPending();
        return;
    }
    if (alarm.name === LICENSE_VALIDATION_ALARM) {
        validateLicense().catch(err => console.warn('[license] validación periódica falló:', err?.message || err));
    }
});

// ────────────────────────────────────────────────────────────
// Orquestación de campaña — estructura de alto nivel
// ────────────────────────────────────────────────────────────

/**
 * Punto de entrada para iniciar o reanudar una campaña.
 * Si hay estado persistente con isRunning=true, reanuda desde el índice guardado.
 * Si no, carga la campaña actual y empieza desde cero.
 */
async function startCampaign() {
    if (isCampaignRunning) {
        console.log('Campaña ya en ejecución en este SW, omitiendo.');
        return;
    }

    const gate = await getLicenseGate();
    if (!gate.allowed) {
        console.warn(`[license] Campaña bloqueada, razón: ${gate.reason}`);
        return;
    }

    const state = await loadOrInitCampaignState();
    if (!state) return;

    isCampaignRunning = true;
    console.log(`[campaign] Iniciando desde índice ${state.index}/${state.contacts.length}`);

    const tab = await ensureTelegramWebTab();
    if (!tab) {
        console.error('No se pudo encontrar o abrir Telegram Web.');
        isCampaignRunning = false;
        return;
    }

    await activateKeepalive();
    await attachDebuggerForCampaign(tab.id);

    chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR_RUNNING });
    chrome.power.requestKeepAwake('system');

    try {
        await runCampaignLoop(state, tab);
    } catch (error) {
        console.error('Error crítico en la campaña:', error);
    } finally {
        await finalizeCampaign(tab);
    }
}

/**
 * Carga estado persistente o inicializa uno nuevo desde la campaña actual.
 * Devuelve null si no hay campaña configurada (no lanza excepción — caso legítimo).
 */
async function loadOrInitCampaignState() {
    const persisted = await loadPersistedState();
    if (persisted && persisted.isRunning) return persisted;

    const { currentCampaign } = await chrome.storage.local.get(['currentCampaign']);
    if (!currentCampaign || !Array.isArray(currentCampaign.contacts)) {
        console.error('No hay campaña configurada.');
        return null;
    }

    const freshState = {
        isRunning: true,
        stopRequested: false,
        pauseRequested: false,
        contacts: currentCampaign.contacts,
        messageTemplate: currentCampaign.messageTemplate,
        messageVariants: Array.isArray(currentCampaign.messageVariants) ? currentCampaign.messageVariants : [],
        imageDataUrl: currentCampaign.imageDataUrl || '',
        config: currentCampaign.config || {},
        index: 0,
        results: [],
        seenPhones: []
    };
    await savePersistedState(freshState);
    return freshState;
}

/**
 * Bucle principal. Cada iteración: procesa 1 contacto, persiste estado, pausa.
 * Tras cada await, re-lee el flag stopRequested del storage para respetar detenciones
 * desde cualquier contexto (dashboard, alarm, SW restart).
 */
async function runCampaignLoop(state, tab) {
    const seenPhones = new Set(state.seenPhones);

    for (let i = state.index; i < state.contacts.length; i++) {
        const percent = Math.round(((i + 1) / state.contacts.length) * 100);
        chrome.action.setBadgeText({ text: `${percent}%` });

        if (await isStopRequested()) {
            console.log('Campaña detenida por el usuario.');
            state.stopRequested = true;
            break;
        }

        const contact = state.contacts[i];
        const result = await processSingleContact({ contact, index: i, tab, state, seenPhones });
        state.results.push(result);
        state.index = i + 1;
        state.seenPhones = Array.from(seenPhones);
        
        // FIX CRÍTICO: Leer el flag de storage ANTES de guardar el estado.
        // Si el usuario presionó STOP mientras se enviaba el mensaje, storage tiene stopRequested=true,
        // pero la variable en memoria 'state' tiene stopRequested=false. Si guardamos ciegamente, SOBREESCRIBIMOS el STOP!
        if (await isStopRequested()) {
            state.stopRequested = true;
        }
        if (await isPauseRequested()) {
            state.pauseRequested = true;
        }
        
        await savePersistedState(state);

        // Check inmediato post-envío: evita iniciar la pausa si se solicitó stop.
        if (state.stopRequested) {
            break;
        }

        // Loop de pausa manual
        let wasPaused = false;
        while (await isPauseRequested()) {
            if (!wasPaused) {
                console.log('Campaña pausada por el usuario.');
                broadcastStatusUpdate({ index: i, status: 'Pausado ⏸️', color: '#eab308', phone: state.results[state.results.length - 1]?.phone || '', total: state.contacts.length, tabId: tab.id });
                chrome.action.setBadgeText({ text: 'PAUS' });
                chrome.action.setBadgeBackgroundColor({ color: '#eab308' });
                wasPaused = true;
            }
            await cancellableDelay(1000);
            if (await isStopRequested()) {
                state.stopRequested = true;
                break;
            }
        }
        if (state.stopRequested) break;
        if (wasPaused) {
            chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR_RUNNING });
            state.pauseRequested = false;
            await savePersistedState(state);
        }

        const isLast = i === state.contacts.length - 1;
        if (!isLast) await pauseBetweenSends({ index: i, state, tab, phone: result.phone });
    }
}

/**
 * Delegación al motor compartido (CampaignEngine + TelegramWebChannel).
 * No se usa aún en producción para el canal web (preserve comportamiento clásico),
 * pero deja el punto de integración listo para la próxima iteración.
 * Un futuro canal ADB usaría CampaignEngine directamente contra su propia
 * interfaz Channel (hoy no existe en este repo).
 */
async function runCampaignLoopWithEngine(state, tab) {
    const webChannel = new TelegramWebChannel(tab.id);
    const engine = new CampaignEngine({
        contacts: state.contacts,
        template: state.messageTemplate,
        messageVariants: state.messageVariants,
        channels: [webChannel],
        config: state.config,
        seenPhones: state.seenPhones
    });
    const onProgress = async (progress) => {
        const percent = Math.round(((progress.index + 1) / state.contacts.length) * 100);
        chrome.action.setBadgeText({ text: `${percent}%` });
        // Persistir estado incremental
        state.results[progress.index] = { phone: progress.phone, status: progress.status, contactData: progress.contactData };
        state.index = Math.max(state.index, progress.index + 1);
        state.seenPhones = Array.from(new Set([...state.seenPhones, progress.phone].filter(Boolean)));
        await savePersistedState(state);
        broadcastStatusUpdate({ index: progress.index, status: progress.status, color: progress.status.includes('Enviado') ? '#22c55e' : '#ef4444', phone: progress.phone, total: state.contacts.length, tabId: tab.id });
    };
    const result = await engine.run(onProgress);
    return result;
}

/**
 * Selecciona el texto a enviar para un contacto.
 * Si la aleatorización está activa y hay un pool de variantes, elige una al azar
 * (selección aleatoria pura por contacto). Si no, usa la Variante 1 / messageTemplate.
 * processSingleContact aplica luego spin {a|b|c} y personalización {{Var}} vía
 * personalizeMessage — el content de Telegram escribe el texto tal cual.
 */
function pickMessage(state) {
    const variants = Array.isArray(state.messageVariants)
        ? state.messageVariants.filter(v => v && v.trim())
        : [];
    const randomize = state.config && state.config.randomizeMessages;
    if (randomize && variants.length > 0) {
        return variants[Math.floor(Math.random() * variants.length)];
    }
    return variants[0] || state.messageTemplate || '';
}

/**
 * Procesa un único contacto vía TelegramWebChannel (API interna de la página:
 * resuelve por teléfono a peerId y verifica el envío por historial). Solo
 * habla contra la interfaz Channel. La personalización se aplica aquí: la
 * página envía el texto tal cual, sin resolver {{Var}} ni spin.
 */
async function processSingleContact({ contact, index, tab, state, seenPhones }) {
    const phone = extractPhone(contact);

    if (!phone) {
        console.warn('Contacto sin teléfono válido:', contact);
        broadcastStatusUpdate({ index, status: 'Omitido ⏭️', color: '#a3a3a3', phone: 'Sin teléfono', total: state.contacts.length, tabId: tab.id });
        return { phone: 'Sin teléfono', status: 'Omitido', contactData: contact };
    }

    if (state.config.duplicateRemoval && seenPhones.has(phone)) {
        console.log(`Duplicado detectado: ${phone}. Omitiendo.`);
        broadcastStatusUpdate({ index, status: 'Duplicado ⏭️', color: '#a3a3a3', phone, total: state.contacts.length, tabId: tab.id });
        return { phone, status: 'Duplicado', contactData: contact };
    }
    seenPhones.add(phone);

    console.log(`[${index + 1}/${state.contacts.length}] Enviando a ${phone}...`);
    broadcastStatusUpdate({ index, status: 'Enviando... ⏳', color: '#eab308', phone, total: state.contacts.length, tabId: tab.id });

    const message = personalizeMessage(pickMessage(state), contact);

    const channel = new TelegramWebChannel(tab.id);

    try {
        await channel.openConversation('web', phone);
    } catch (err) {
        const errMsg = err && err.message ? err.message : String(err);
        if (errMsg.startsWith('TELEGRAM_NOT_FOUND')) {
            console.warn(`Sin cuenta de Telegram para ${phone}.`);
            broadcastStatusUpdate({ index, status: 'Sin Telegram ⚪', color: '#94a3b8', phone, total: state.contacts.length, tabId: tab.id });
            return { phone, status: `NoEncontrado: ${errMsg}`, contactData: contact };
        }
        console.error(`Error abriendo chat de ${phone}:`, errMsg);
        broadcastStatusUpdate({ index, status: `Error ❌: ${errMsg}`, color: '#ef4444', phone, total: state.contacts.length, tabId: tab.id });
        return { phone, status: `Error: ${errMsg}`, contactData: contact };
    }

    if (state.imageDataUrl) {
        try {
            await channel.attachImage('web', state.imageDataUrl);
        } catch (err) {
            const errMsg = err && err.message ? err.message : String(err);
            console.error(`Error adjuntando imagen para ${phone}:`, errMsg);
            broadcastStatusUpdate({ index, status: `Error ❌: ${errMsg}`, color: '#ef4444', phone, total: state.contacts.length, tabId: tab.id });
            return { phone, status: `Error: ${errMsg}`, contactData: contact };
        }
    }

    try {
        await channel.send('web', message);
    } catch (err) {
        const errMsg = err && err.message ? err.message : String(err);
        console.error(`Error enviando a ${phone}:`, errMsg);
        broadcastStatusUpdate({ index, status: `Error ❌: ${errMsg}`, color: '#ef4444', phone, total: state.contacts.length, tabId: tab.id });
        return { phone, status: `Error: ${errMsg}`, contactData: contact };
    }

    console.log(`Envío exitoso a ${phone} (Telegram 🟢)`);
    contact.TipoMensaje = 'Telegram';
    broadcastStatusUpdate({ index, status: 'Enviado ✅ (Telegram 🟢)', color: '#22c55e', phone, total: state.contacts.length, tabId: tab.id });
    return { phone, status: 'Enviado (Telegram 🟢)', contactData: contact };
}

/**
 * Pausa configurada entre envíos. Cancelable vía backgroundDelayResolver (STOP_CAMPAIGN).
 */
async function pauseBetweenSends({ index, state, tab, phone }) {
    const min = Math.max(state.config.delayMin || 6, 2);
    const max = Math.max(state.config.delayMax || 20, min);
    const randomDelaySecs = Math.floor(Math.random() * (max - min + 1)) + min;
    console.log(`Pausando por ${randomDelaySecs}s antes del siguiente contacto...`);
    broadcastStatusUpdate({ index, status: `Pausando ${randomDelaySecs}s... ⏳`, color: '#eab308', phone, total: state.contacts.length, tabId: tab.id });
    await cancellableDelay(randomDelaySecs * 1000);
}

/**
 * Limpieza tras terminar (éxito, error o stop): detach debugger, alarm, historial.
 */
async function finalizeCampaign(tab) {
    const state = await loadPersistedState();
    const results = state ? state.results : [];
    const stopped = state ? state.stopRequested : false;
    const totalContacts = state ? state.contacts.length : 0;

    await deactivateKeepalive();
    await detachDebuggerSafely(tab ? tab.id : null);

    isCampaignRunning = false;
    chrome.action.setBadgeText({ text: '' });
    chrome.power.releaseKeepAwake();
    console.log('Finalización de la ejecución de campaña.');

    if (tab) {
        chrome.tabs.sendMessage(tab.id, { action: 'REMOVE_HUD' }).catch(() => {});
        // Restaurar comportamiento normal de descarte al terminar la campaña
        chrome.tabs.update(tab.id, { autoDiscardable: true }).catch(() => {});
    }

    const finishedCampaign = {
        date: Date.now(),
        contactCount: totalContacts,
        status: stopped ? 'Detenida' : 'Completada',
        contactResults: results,
        // Se guardan también para poder "Retomar envío" sin volver a subir el
        // Excel: contacts completo (incluye los nunca alcanzados si se cortó
        // antes de tiempo, que no están en contactResults) + la definición
        // original de la campaña.
        channel: 'web',
        contacts: state ? state.contacts : [],
        messageTemplate: state ? state.messageTemplate : '',
        messageVariants: state ? state.messageVariants : [],
        imageDataUrl: state ? state.imageDataUrl : '',
        config: state ? state.config : {}
    };
    const { history = [] } = await chrome.storage.local.get(['history']);
    history.unshift(finishedCampaign);
    await chrome.storage.local.set({ history, campaignFinished: true });
    await clearPersistedState();
}

// ────────────────────────────────────────────────────────────
// Persistencia de estado (sobrevive a terminación del SW)
// ────────────────────────────────────────────────────────────

async function loadPersistedState() {
    const { [CAMPAIGN_STATE_KEY]: state } = await chrome.storage.local.get([CAMPAIGN_STATE_KEY]);
    return state || null;
}

async function savePersistedState(state) {
    await chrome.storage.local.set({ [CAMPAIGN_STATE_KEY]: state });
}

async function clearPersistedState() {
    await chrome.storage.local.remove(CAMPAIGN_STATE_KEY);
}

async function isStopRequested() {
    const state = await loadPersistedState();
    return state ? state.stopRequested === true : false;
}

async function markStopRequested() {
    const state = await loadPersistedState();
    if (!state) return;
    state.stopRequested = true;
    await savePersistedState(state);
}

async function isPauseRequested() {
    const state = await loadPersistedState();
    return state ? state.pauseRequested === true : false;
}

async function setPauseRequested(val) {
    const state = await loadPersistedState();
    if (!state) return;
    state.pauseRequested = val;
    await savePersistedState(state);
}

/**
 * Si hay estado persistente con isRunning=true pero el SW no está ejecutando el loop,
 * significa que el SW fue terminado mid-campaña. Reanudar desde el índice guardado.
 */
async function resumeIfPending() {
    if (isCampaignRunning) return;
    const state = await loadPersistedState();
    if (!state || !state.isRunning) return;
    if (state.stopRequested) {
        await clearPersistedState();
        return;
    }
    console.log('[resume] Detectada campaña huérfana, reanudando...');
    startCampaign();
}

// ────────────────────────────────────────────────────────────
// Comunicación SW ↔ Content / Dashboard (con manejo de errores aislado)
// ────────────────────────────────────────────────────────────

/**
 * Envía actualización de estado al dashboard (si está abierto) y HUD del content.
 * Usa .catch para absorber "receiving end does not exist" sin romper el flujo.
 */
function broadcastStatusUpdate({ index, status, color, phone, total, tabId }) {
    chrome.runtime.sendMessage({ action: 'UPDATE_STATUS', index, status, color }).catch(() => {});
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, {
        action: 'UPDATE_HUD',
        progress: index + 1,
        total,
        phone: phone || 'Desconocido',
        status
    }).catch(() => {});
}

// ────────────────────────────────────────────────────────────
// Infraestructura: keepalive, debugger, delay cancelable
// ────────────────────────────────────────────────────────────

async function activateKeepalive() {
    try {
        await chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: KEEPALIVE_PERIOD_MIN });
        console.log('[keepalive] activado para campaña');
    } catch (e) {
        console.warn('[keepalive] no se pudo crear alarm:', e);
    }
}

async function deactivateKeepalive() {
    try {
        await chrome.alarms.clear(KEEPALIVE_ALARM);
        console.log('[keepalive] desactivado');
    } catch (e) { /* ignorar */ }
}

async function attachDebuggerForCampaign(tabId) {
    try {
        await chrome.debugger.attach({ tabId }, '1.3');
        console.log('Debugger conectado globalmente para la campaña.');
        // Truco Anti-Throttling: Forzar a Chrome a considerar la pestaña como enfocada.
        // Evita que la función setTimeout se cuelgue al minimizar.
        await chrome.debugger.sendCommand({ tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: true }).catch(() => {});
        await cancellableDelay(DEBUGGER_SETTLE_MS);
    } catch (e) {
        console.log('Debugger podría estar ya conectado:', e?.message || e);
        await cancellableDelay(1000);
    }
}

async function detachDebuggerSafely(tabId) {
    if (tabId == null) return;
    try {
        await chrome.debugger.detach({ tabId });
        console.log('Debugger desconectado globalmente.');
    } catch (e) { /* Ignorar */ }
}

/**
 * Delay cancelable que sondea isStopRequested() cada 500ms.
 * A diferencia de una Promise única, este enfoque chunked garantiza que
 * al presionar DETENER, la espera se interrumpe en ≤ 500ms — incluso si
 * backgroundDelayResolver() fue llamado antes de que empezara esta pausa.
 */
async function cancellableDelay(ms) {
    const CHUNK_MS = 500;
    let elapsed = 0;

    while (elapsed < ms) {
        if (await isStopRequested()) {
            console.log('[delay] Stop detectado durante pausa. Interrumpiendo.');
            return;
        }
        const remaining = ms - elapsed;
        const chunkDuration = Math.min(CHUNK_MS, remaining);
        await new Promise(resolve => {
            backgroundDelayResolver = resolve;
            setTimeout(resolve, chunkDuration);
        });
        // Limpiar el resolver tras consumirlo para que no quede un puntero stále
        backgroundDelayResolver = null;
        elapsed += chunkDuration;
    }
}

/**
 * Busca o abre la pestaña de Telegram Web.
 * Se reutilizará la pestaña donde el usuario ya inició sesión sin abrir ventanas nuevas.
 */
async function ensureTelegramWebTab() {
    const tabs = await chrome.tabs.query({ url: '*://web.telegram.org/*' });
    let targetTab;
    
    if (tabs.length > 0) {
        targetTab = tabs[0];
        try {
            // Marcar como no-descartable durante la campaña — Chrome no la liberará
            // por presión de memoria, evitando "Receiving end does not exist".
            await chrome.tabs.update(targetTab.id, { active: true, autoDiscardable: false });
            const winInfo = await chrome.windows.get(targetTab.windowId);
            if (winInfo.state === 'minimized') {
                await chrome.windows.update(targetTab.windowId, { state: 'normal' });
            }
        } catch(e) {}
    } else {
        targetTab = await chrome.tabs.create({ url: 'https://web.telegram.org/k/' });
        await new Promise(r => setTimeout(r, TAB_INITIAL_LOAD_MS));
        try {
            await chrome.tabs.update(targetTab.id, { autoDiscardable: false });
        } catch (e) {}
    }

    // Inyectar forzosamente los scripts para asegurar conexión (Fix de Pestaña Desconectada)
    try {
        await chrome.scripting.executeScript({
            target: { tabId: targetTab.id },
            files: ['ui/utils.js', 'content.js']
        });
        console.log('Scripts inyectados con éxito programáticamente.');
    } catch (err) {
        console.warn('La inyección programática falló o ya estaba inyectado.', err);
    }

    return targetTab;
}
