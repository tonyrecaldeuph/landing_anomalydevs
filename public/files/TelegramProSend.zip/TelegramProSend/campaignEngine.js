/**
 * campaignEngine.js — Motor puro de campañas (sin chrome.* ni adb)
 * Usado por background.js (TelegramWebChannel); un futuro canal ADB lo
 * reutilizaría contra su propia interfaz Channel (hoy no existe en este repo).
 * Ley de Demeter: solo habla contra interfaz Channel, nunca contra chrome.debugger/adb directo.
 *
 * Interfaz Channel:
 *   listTargets() -> Promise<string[]>
 *   openConversation(target:string, phone:string) -> Promise<void>
 *   send(target:string, text:string) -> Promise<void>
 *   verifySent(target:string) -> Promise<boolean>
 *   detectProtocol(target:string) -> Promise<'sms'|'rcs'>
 *   isBlocked(target:string) -> Promise<boolean>
 */

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

/**
 * Clasifica el `status` de un contactResult en 'RCS'|'SMS'|'Duplicado'|
 * 'Omitido'|'Error'. El canal Web anota el protocolo en el propio texto
 * ("Enviado (RCS 🟢)"/"Enviado (SMS 🔵)"); el canal ADB no distingue
 * protocolo y devuelve 'Enviado' a secas — sin el fallback de la última
 * línea, todo envío exitoso por ADB clasificaría como error.
 */
function classifyResultStatus(status) {
    const s = String(status || '');
    if (s.includes('NoEncontrado') || s.includes('Sin Telegram')) return 'NoEncontrado';
    if (s.includes('Duplicado')) return 'Duplicado';
    if (s.includes('Omitido')) return 'Omitido';
    if (s.includes('Error')) return 'Error';
    if (s.includes('Enviado')) return 'Enviado';
    return 'Error';
}

/**
 * Etiqueta visible para un `status` interno. El valor de negocio sigue siendo
 * `NoEncontrado` (no rompe historiales viejos); en la UI se muestra "Sin Telegram".
 */
function displayResultLabel(status) {
    const clase = classifyResultStatus(status);
    if (clase === 'Enviado') return 'Enviado ✅';
    if (clase === 'NoEncontrado') return 'Sin Telegram ⚪';
    if (clase === 'Duplicado') return 'Duplicado ⏭️';
    if (clase === 'Omitido') return 'Omitido ⏭️';
    return 'Error ❌';
}

/**
 * Color semántico para la etiqueta visible (mismo criterio que displayResultLabel).
 */
function resultColor(status) {
    const clase = classifyResultStatus(status);
    if (clase === 'Enviado') return '#22c55e';
    if (clase === 'NoEncontrado') return '#94a3b8';
    if (clase === 'Duplicado' || clase === 'Omitido') return '#a3a3a3';
    return '#ef4444';
}

/**
 * Texto plano para la columna Estado de los reportes (CSV/XLS), sin emojis.
 * Solo los errores conservan el detalle técnico (`Error: <mensaje>`); el
 * resto sale como etiqueta única (Enviado / Sin Telegram / Duplicado /
 * Omitido) para no ensuciar los datos del cliente con reemplazos globales.
 */
function exportStatusText(status) {
    const s = String(status || '');
    const clase = classifyResultStatus(s);
    if (clase === 'Enviado') return 'Enviado';
    if (clase === 'NoEncontrado') return 'Sin Telegram';
    if (clase === 'Duplicado') return 'Duplicado';
    if (clase === 'Omitido') return 'Omitido';
    const detalle = s.replace(/^Error\s*:?\s*/, '');
    return detalle ? `Error: ${detalle}` : 'Error';
}

/**
 * Cuenta resultados por clase de negocio. Acepta objetos { status } o textos.
 */
function summarizeResults(contactResults) {
    const lista = Array.isArray(contactResults) ? contactResults : [];
    const resumen = { enviados: 0, sinTelegram: 0, errores: 0, duplicados: 0, omitidos: 0 };
    for (const item of lista) {
        const estado = item && typeof item === 'object' ? item.status : item;
        const clase = classifyResultStatus(estado);
        if (clase === 'Enviado') resumen.enviados += 1;
        else if (clase === 'NoEncontrado') resumen.sinTelegram += 1;
        else if (clase === 'Duplicado') resumen.duplicados += 1;
        else if (clase === 'Omitido') resumen.omitidos += 1;
        else resumen.errores += 1;
    }
    return resumen;
}

/**
 * Contactos a retomar tras una campaña cortada: los que nunca se alcanzaron
 * (contactResults más corto que contacts, por el corte) y los que fallaron
 * con error. Duplicados, Omitidos sin teléfono y envíos exitosos no se
 * retoman. El orden de `contacts` se preserva.
 */
function computePendingContacts(contacts, contactResults) {
    const results = contactResults || [];
    return contacts.filter((contact, i) => {
        const result = results[i];
        if (!result) return true;
        return classifyResultStatus(result.status) === 'Error';
    });
}

function parseSpinSyntax(text) {
    return text.replace(/\{([^{}]*\|[^{}]*)\}/g, (match, options) => {
        const choices = options.split('|');
        return choices[Math.floor(Math.random() * choices.length)];
    });
}

function personalizeMessage(template, data) {
    if (!template) return '';
    let result = template;
    if (data) {
        result = result.replace(/\{\{([^\{\}]+)\}\}/g, (match, key) => {
            const cleanKey = key.trim();
            const foundKey = Object.keys(data).find(k => k.toLowerCase() === cleanKey.toLowerCase());
            return foundKey !== undefined ? String(data[foundKey]) : match;
        });
    }
    return parseSpinSyntax(result);
}

function extractPhone(contact) {
    if (!contact) return '';
    const directKeys = ['telefono', 'Telefono', 'TELEFONO', 'Phone', 'phone', 'Celular', 'celular', 'Cel', 'cel', 'Movil', 'movil'];
    for (const key of directKeys) {
        if (contact[key] !== undefined && contact[key] !== null && String(contact[key]).trim() !== '') {
            return String(contact[key]).trim();
        }
    }
    const keys = Object.keys(contact);
    const phoneKey = keys.find(k => /tel|cel|phone|movil|mobile/i.test(k));
    if (phoneKey && contact[phoneKey] !== undefined && contact[phoneKey] !== null && String(contact[phoneKey]).trim() !== '') {
        const val = String(contact[phoneKey]).trim();
        const digitsOnly = val.replace(/[^\d]/g, '');
        if (digitsOnly.length >= 7) return val;
    }
    for (const rawVal of Object.values(contact)) {
        const val = String(rawVal).replace(/\.0*$/, '');
        if (/^\+?\d{7,15}$/.test(val)) return val;
    }
    return '';
}

class CampaignEngine {
    /**
     * @param {Object} opts
     * @param {Array} opts.contacts - lista de contactos (objetos)
     * @param {string} opts.template - plantilla principal
     * @param {Array} [opts.messageVariants] - variantes opcionales (si randomizeMessages=true, elige aleatoria)
     * @param {Array} opts.channels - instancias Channel
     * @param {Object} [opts.channel] - alias singular
     * @param {Object} [opts.config] - { randomizeMessages:boolean, antiSpamPauseMs:number, retryDelayMs:number }
     * @param {Function} [opts.pickMessage] - función personalizada para elegir mensaje (inyectable para tests)
     */
    constructor(opts) {
        this.contacts = Array.isArray(opts.contacts) ? opts.contacts : [];
        this.template = opts.template || '';
        this.messageVariants = Array.isArray(opts.messageVariants) ? opts.messageVariants : [];
        this.channels = Array.isArray(opts.channels) ? opts.channels : (opts.channel ? [opts.channel] : []);
        this.config = opts.config || {};
        this.imageDataUrl = opts.imageDataUrl || '';
        this.pickMessageFn = opts.pickMessage || null;
        this.results = [];
        this.aborted = false;
        const sp = opts.seenPhones;
        if (sp instanceof Set) this.seenPhones = new Set(sp);
        else if (Array.isArray(sp)) this.seenPhones = new Set(sp);
        else this.seenPhones = new Set();
    }

    abort() {
        this.aborted = true;
    }

    pickMessage() {
        if (this.pickMessageFn) return this.pickMessageFn(this);
        const variants = this.messageVariants.filter(v => v && String(v).trim() !== '');
        const randomize = this.config && this.config.randomizeMessages;
        if (randomize && variants.length > 0) {
            return variants[Math.floor(Math.random() * variants.length)];
        }
        if (variants.length > 0) return variants[0];
        return this.template || '';
    }

    async run(onProgress) {
        if (this.contacts.length === 0) return { results: [], sent: [] };

        // Resolver todos los targets (pueden ser N por canal, ej. AdbChannel)
        const targetEntries = [];
        for (const ch of this.channels) {
            const targets = await ch.listTargets();
            const list = Array.isArray(targets) ? targets : [];
            for (const t of list) {
                targetEntries.push({ channel: ch, target: t, pauseUntil: 0 });
            }
        }

        if (targetEntries.length === 0) {
            // Sin targets — marcar todos como fallidos sin lanzar
            const results = this.contacts.map((c, idx) => ({
                index: idx,
                phone: extractPhone(c),
                status: 'Error: sin targets disponibles',
                contactData: c,
                target: null
            }));
            this.results = results;
            return { results, sent: results.filter(r => r.status.includes('Enviado')) };
        }

        const blockedCounts = new Map(); // target -> consecutive blocks
        let nextIdx = 0;
        // Se acumula directamente en this.results (no en una variable local) para que
        // un consumidor externo (ej. adb-bridge-server) pueda leer el progreso en vivo
        // vía engine.results.length mientras la campaña sigue corriendo.
        this.results = [];
        const results = this.results;
        const resultsLock = { push: (r) => results.push(r) }; // single-thread, no lock needed

        const retryDelayMs = this.config.retryDelayMs !== undefined ? this.config.retryDelayMs : 10; // 10ms en tests, 4000 en prod
        const antiSpamPauseMs = this.config.antiSpamPauseMs !== undefined ? this.config.antiSpamPauseMs : 180000;
        const delayMin = this.config.delayMin !== undefined ? Math.max(this.config.delayMin, 0) : 0;
        const delayMax = this.config.delayMax !== undefined ? Math.max(this.config.delayMax, delayMin) : delayMin;

        const workers = targetEntries.map(entry => (async () => {
            while (true) {
                if (this.aborted) break;
                // Pausa anti-spam por target
                const now = Date.now();
                if (entry.pauseUntil > now) {
                    await sleep(entry.pauseUntil - now);
                    continue;
                }

                // Tomar siguiente contacto de forma atómica (JS es single-thread, ++ es atómico entre awaits)
                if (nextIdx >= this.contacts.length) break;
                if (this.aborted) break;
                const myIdx = nextIdx++;
                if (myIdx >= this.contacts.length) break;
                const contact = this.contacts[myIdx];
                const phone = extractPhone(contact);
                const rawTemplate = this.pickMessage();
                const text = personalizeMessage(rawTemplate, contact);

                // Deduplicación — respeta config.duplicateRemoval y seenPhones compartido
                if (this.config.duplicateRemoval && phone && this.seenPhones.has(phone)) {
                    const dupResult = { phone, status: 'Duplicado', contactData: contact };
                    const enrichedDup = { index: myIdx, phone: dupResult.phone, status: dupResult.status, contactData: dupResult.contactData, target: entry.target };
                    resultsLock.push(enrichedDup);
                    if (typeof onProgress === 'function') { try { onProgress(enrichedDup); } catch (_) {} }
                    continue;
                }
                if (phone) this.seenPhones.add(phone);

                let result;
                try {
                    result = await this.processContactWithRetry({ contact, phone, text, entry, blockedCounts, retryDelayMs, antiSpamPauseMs });
                } catch (err) {
                    result = {
                        phone: phone || 'Sin teléfono',
                        status: `Error: ${err.message || String(err)}`,
                        contactData: contact
                    };
                }

                const enriched = {
                    index: myIdx,
                    phone: result.phone,
                    status: result.status,
                    contactData: result.contactData || contact,
                    target: entry.target
                };
                resultsLock.push(enriched);
                if (typeof onProgress === 'function') {
                    try { onProgress(enriched); } catch (_) {}
                }

                // Pausa entre envíos por target (simula delayMin..delayMax)
                if (nextIdx < this.contacts.length) {
                    const range = delayMax - delayMin;
                    const delaySecs = range > 0 ? (Math.floor(Math.random() * (range + 1)) + delayMin) : delayMin;
                    if (delaySecs > 0) await sleep(delaySecs * 1000);
                }
            }
        })());

        await Promise.all(workers);
        results.sort((a, b) => a.index - b.index);
        const sent = results.filter(r => r.status.includes('Enviado'));
        return { results, sent };
    }

    async processContactWithRetry({ contact, phone, text, entry, blockedCounts, retryDelayMs, antiSpamPauseMs }) {
        if (this.aborted) throw new Error('ABORTED: campaña detenida por el usuario');
        if (!phone) {
            return { phone: 'Sin teléfono', status: 'Omitido', contactData: contact };
        }
        if (!text || String(text).trim() === '') {
            throw new Error('TEMPLATE_EMPTY: plantilla vacía — abortando para evitar envío sin texto');
        }

        let lastError = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
            if (this.aborted) throw new Error('ABORTED: campaña detenida por el usuario');
            if (attempt > 1) {
                await sleep(retryDelayMs);
            }
            try {
                await entry.channel.openConversation(entry.target, phone);
                // attachImage es opcional (feature-detection): solo los canales que lo
                // implementan (ej. AdbChannel) intentan adjuntar la imagen de campaña.
                if (this.imageDataUrl && typeof entry.channel.attachImage === 'function') {
                    await entry.channel.attachImage(entry.target, this.imageDataUrl);
                }
                await entry.channel.send(entry.target, text);
                // Verificación opcional (si el channel la implementa)
                if (typeof entry.channel.verifySent === 'function') {
                    const verified = await entry.channel.verifySent(entry.target);
                    if (verified === false) {
                        throw new Error('CARRIER_FAILED: verificado como no enviado');
                    }
                }
                // Evaluar bloqueo
                let isBlocked = false;
                if (typeof entry.channel.isBlocked === 'function') {
                    isBlocked = await entry.channel.isBlocked(entry.target);
                }
                const prev = blockedCounts.get(entry.target) || 0;
                if (isBlocked) {
                    const next = prev + 1;
                    blockedCounts.set(entry.target, next);
                    if (next >= 2) {
                        entry.pauseUntil = Date.now() + antiSpamPauseMs;
                        blockedCounts.set(entry.target, 0);
                    }
                } else {
                    blockedCounts.set(entry.target, 0);
                }

                return { phone, status: 'Enviado', contactData: contact };
            } catch (err) {
                lastError = err;
                const msg = err && err.message ? err.message : String(err);
                const isCarrier = msg.startsWith('CARRIER_FAILED');
                const isNotFound = msg.startsWith('TELEGRAM_NOT_FOUND');
                if (isNotFound) {
                    return { phone, status: `NoEncontrado: ${msg}`, contactData: contact };
                }
                if (!isCarrier) {
                    // Errores no-carrier no se reintentan
                    throw err;
                }
                if (attempt >= 3) {
                    // Agotados los reintentos
                    break;
                }
                // else reintentar
            }
        }
        const msg = lastError && lastError.message ? lastError.message : 'CARRIER_FAILED: agotados reintentos';
        return { phone, status: `Error: ${msg}`, contactData: contact };
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CampaignEngine, extractPhone, personalizeMessage, parseSpinSyntax, classifyResultStatus, computePendingContacts, displayResultLabel, resultColor, summarizeResults, exportStatusText };
}
