/**
 * content.js — gancho mínimo en web.telegram.org/k para el envío masivo.
 * El envío (texto e imagen) vive en channels/telegramPageApi.js (mundo MAIN)
 * vía chrome.scripting; este content no tiene responsabilidades activas.
 * Se conserva el script en el manifest como punto de anclaje futuro (HUD).
 */

(function () {
    // Guard: el manifest ya inyecta este script y background puede reinyectarlo.
    // Sin este guard se acumulan ejecuciones duplicadas del mismo anclaje.
    if (window.__telegramProContentLoaded) return;
    window.__telegramProContentLoaded = true;
})();
