/**
 * Utilidades para procesamiento de texto y variables.
 * SMS/RCS Masivos - UPHONE
 */

var _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

_root.Utils = _root.Utils || {
    /**
     * Procesa el Spin Syntax en un texto.
     * Ejemplo: "{Hola|Saludos|Buen día}" -> retorna una de las opciones aleatoriamente.
     * @param {string} text - El texto con spin syntax.
     * @returns {string} - Texto procesado.
     */
    parseSpinSyntax(text) {
        return text.replace(/\{([^{}]*)\}/g, (match, options) => {
            const choices = options.split('|');
            return choices[Math.floor(Math.random() * choices.length)];
        });
    },

    /**
     * Reemplaza variables personalizadas en el mensaje.
     * Ejemplo: "Hola {{Nombre}}, tu deuda es {{Valor}}" -> "Hola Juan, tu deuda es 100"
     * @param {string} template - El texto con placeholders {{Var}}.
     * @param {Object} data - Objeto con los datos del contacto.
     * @returns {string} - Mensaje personalizado.
     */
    personalizeMessage(template, data) {
        if (!data) return template;
        
        return template.replace(/\{\{([^\{\}]+)\}\}/g, (match, key) => {
            const cleanKey = key.trim();
            // Buscar la clave de forma insensible a mayúsculas/minúsculas si es necesario
            const foundKey = Object.keys(data).find(k => k.toLowerCase() === cleanKey.toLowerCase());
            return foundKey ? data[foundKey] : match;
        });
    },

    /**
     * Limpia y valida un número de teléfono.
     * @param {string} phone - El número a limpiar.
     * @returns {string} - Número limpio.
     */
    cleanPhoneNumber(phone) {
        if (!phone) return '';
        // Eliminar caracteres no numéricos excepto el '+'
        return String(phone).replace(/[^\d+]/g, '');
    },

    /**
     * Extrae solo los dígitos de un texto (teléfonos, filas de resultados).
     * @param {string} text - Texto arbitrario.
     * @returns {string} - Solo dígitos ('' si no hay ninguno).
     */
    normalizeDigits(text) {
        return String(text || '').replace(/\D/g, '');
    },

    /**
     * Normaliza un teléfono a dígitos internacionales sin '+'.
     * El 0 inicial o hasta 9 dígitos se asumen locales del país por defecto.
     * @param {string} phone - Número en cualquier formato.
     * @param {string} defaultCountryCode - Código país por defecto ('593').
     * @returns {string} - Solo dígitos internacionales ('' si vacío).
     */
    toInternationalDigits(phone, defaultCountryCode = '593') {
        if (phone === null || phone === undefined || phone === '') return '';
        const trimmed = String(phone).trim();
        if (!trimmed) return '';
        const sinExcel = trimmed.replace(/\.0+$/, '');
        let digitos = sinExcel.replace(/\D/g, '');
        if (!digitos) return '';
        if (digitos.startsWith('00')) digitos = digitos.slice(2);
        if (digitos.startsWith(defaultCountryCode)) return digitos;
        if (digitos.startsWith('0')) return defaultCountryCode + digitos.slice(1);
        if (digitos.length <= 9) return defaultCountryCode + digitos;
        return digitos;
    }
};

// Exportar para uso en otros scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = _root.Utils;
}
