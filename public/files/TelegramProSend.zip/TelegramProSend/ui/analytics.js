/**
 * Módulo de analítica — envía eventos al Google Apps Script.
 * Genera un installId único por dispositivo, persistido en chrome.storage.local.
 */

const Analytics = (() => {
    // ⚠️ Reemplazar con la URL del Apps Script desplegado
    const ENDPOINT = 'AKfycbxDIS90uEHhVFaEJgupIbiixbmSUm-ZXBK7J2fiIyOSpuW7KwKGh7rtd4a8Q3H5U0amsw';

    let _installId = null;

    async function getInstallId() {
        if (_installId) return _installId;
        return new Promise(resolve => {
            chrome.storage.local.get(['analyticsInstallId'], (data) => {
                if (data.analyticsInstallId) {
                    _installId = data.analyticsInstallId;
                    resolve(_installId);
                } else {
                    const newId = 'inst_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
                    chrome.storage.local.set({ analyticsInstallId: newId }, () => {
                        _installId = newId;
                        resolve(_installId);
                    });
                }
            });
        });
    }

    async function track(event, data = {}) {
        if (ENDPOINT === 'APPS_SCRIPT_URL_AQUI') return; // sin endpoint configurado, no enviar

        try {
            const installId = await getInstallId();
            const payload = {
                installId,
                event,
                timestamp: new Date().toISOString(),
                ...data
            };

            // fire-and-forget: no bloquear la UI si falla
            fetch(ENDPOINT, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).catch(() => {});
        } catch (_) {}
    }

    return { track };
})();
