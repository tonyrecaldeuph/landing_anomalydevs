/**
 * Cliente HTTP + cacheo para el backend de licencias (licensing-server).
 * Vive en el service worker (background.js lo carga vía importScripts).
 * No decide si se puede enviar una campaña — eso lo hace licenseGate.js
 * (computeGateDecision) a partir de lo que este módulo cachea.
 */

const LICENSE_API_BASE = 'https://licencias.anomalydevs.qzz.io/api/v1';
const LICENSE_KEY_STORAGE = 'licenseKey';
const LICENSE_DEVICE_ID_STORAGE = 'licenseDeviceId';
const LICENSE_STATE_STORAGE = 'licenseState';

async function getOrCreateDeviceId() {
    const { [LICENSE_DEVICE_ID_STORAGE]: existing } = await chrome.storage.local.get([LICENSE_DEVICE_ID_STORAGE]);
    if (existing) return existing;
    const deviceId = crypto.randomUUID();
    await chrome.storage.local.set({ [LICENSE_DEVICE_ID_STORAGE]: deviceId });
    return deviceId;
}

/**
 * Label descriptivo del dispositivo, solo para identificación humana en el
 * panel admin (no hay fingerprint de hardware real disponible en MV3).
 */
function getDeviceLabel() {
    const ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    const chromeMatch = ua.match(/Chrome\/([\d.]+)/);
    const platform = ua.includes('Windows') ? 'Windows'
        : ua.includes('Mac') ? 'macOS'
        : ua.includes('Linux') ? 'Linux'
        : 'Desconocido';
    return `${platform} · Chrome ${chromeMatch ? chromeMatch[1] : '?'}`;
}

async function callLicenseApi(path, body) {
    const response = await fetch(`${LICENSE_API_BASE}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });
    const data = await response.json().catch(() => ({}));
    return { httpStatus: response.status, data };
}

function toCachedState(data, lastValidatedAt) {
    return {
        status: data.status,
        companyName: data.company_name || null,
        endDate: data.end_date || null,
        daysRemaining: typeof data.days_remaining === 'number' ? data.days_remaining : null,
        lastValidatedAt
    };
}

function errorState(status) {
    return { status, companyName: null, endDate: null, daysRemaining: null, lastValidatedAt: null };
}

/**
 * Activa (o re-confirma) este dispositivo contra una license_key.
 * Persiste licenseKey + licenseState en chrome.storage.local.
 */
async function activateLicense(licenseKey) {
    const deviceId = await getOrCreateDeviceId();
    const deviceLabel = getDeviceLabel();
    try {
        const { httpStatus, data } = await callLicenseApi('/activate', {
            license_key: licenseKey,
            device_id: deviceId,
            device_label: deviceLabel,
            product: 'telegram'
        });

        if (httpStatus === 200) {
            const state = toCachedState(data, Date.now());
            await chrome.storage.local.set({ [LICENSE_KEY_STORAGE]: licenseKey, [LICENSE_STATE_STORAGE]: state });
            return state;
        }
        if (httpStatus === 404) {
            return errorState('not_found');
        }
        if (httpStatus === 409) {
            return errorState('device_limit_reached');
        }
        // Cualquier otro status inesperado: no persistir, para no pisar una
        // licencia previamente válida por un error transitorio del backend
        // o un intento de reactivación fallido (ver ui/dashboard.js: el
        // modal de licencia es accesible en cualquier momento, no solo en
        // el primer uso).
        return errorState('network_error');
    } catch (err) {
        console.warn('[license] activate falló (red/backend):', err?.message || err);
        return errorState('network_error');
    }
}

/**
 * Revalida el dispositivo ya activado. Si falla la red, conserva el último
 * estado cacheado tal cual (no toca lastValidatedAt) para que la gracia
 * offline de 48h siga contando desde la última validación exitosa real.
 */
async function validateLicense() {
    const { [LICENSE_KEY_STORAGE]: licenseKey, [LICENSE_STATE_STORAGE]: cachedState } =
        await chrome.storage.local.get([LICENSE_KEY_STORAGE, LICENSE_STATE_STORAGE]);
    if (!licenseKey) return null;

    const deviceId = await getOrCreateDeviceId();
    try {
        const { httpStatus, data } = await callLicenseApi('/validate', { license_key: licenseKey, device_id: deviceId, product: 'telegram' });
        if (httpStatus === 200) {
            const state = toCachedState(data, Date.now());
            await chrome.storage.local.set({ [LICENSE_STATE_STORAGE]: state });
            return state;
        }
        if (httpStatus === 404) {
            const state = errorState('not_found');
            await chrome.storage.local.set({ [LICENSE_STATE_STORAGE]: state });
            return state;
        }
        // Cualquier otro status inesperado (5xx, proxy error, etc.) se trata igual
        // que una falla de red: se conserva el último estado cacheado tal cual,
        // sin tocar lastValidatedAt, para no cortar la gracia offline de 48h
        // por un error transitorio del backend.
        console.warn(`[license] validate devolvió status inesperado ${httpStatus}, se conserva el último estado cacheado`);
        return cachedState || null;
    } catch (err) {
        console.warn('[license] validate falló (red/backend), se conserva el último estado cacheado:', err?.message || err);
        return cachedState || null;
    }
}

async function getCachedLicenseState() {
    const { [LICENSE_STATE_STORAGE]: state } = await chrome.storage.local.get([LICENSE_STATE_STORAGE]);
    return state || null;
}

/**
 * Decisión de gate lista para usar (combina el estado cacheado con
 * computeGateDecision, que vive en licenseGate.js — cargado antes que este
 * archivo vía importScripts en background.js, ambos comparten scope global).
 */
async function getLicenseGate() {
    const state = await getCachedLicenseState();
    return computeGateDecision(state, Date.now());
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        activateLicense,
        validateLicense,
        getCachedLicenseState,
        getLicenseGate,
        getOrCreateDeviceId,
        getDeviceLabel,
        LICENSE_KEY_STORAGE,
        LICENSE_STATE_STORAGE
    };
}
