/**
 * Lógica de procesamiento de archivos Excel usando SheetJS.
 * Estructura fija: FORMATO BASE CAMPAÑA TERMINAL.xlsx
 */

// Columnas que se extraen del formato base (en este orden)
const CAMPAIGN_COLUMNS = [
    'Nº CONTRATO',
    'CÉDULA',
    'NOMBRE CLIENTE',
    'APELLIDO CLIENTE',
    'MODELO',
    'DIAS IMPAGO',
    'TELEFONO 1',
    'VALOR EN MORA'
];

/**
 * Resuelve el valor de una celda de teléfono, recuperando ceros a la izquierda
 * perdidos cuando la celda de Excel tiene formato numérico (ej. "0000000000"
 * para forzar el 0 inicial de un celular ecuatoriano en pantalla). Excel solo
 * aplica ese relleno como formato de visualización — el valor crudo subyacente
 * no lo incluye, así que sheet_to_json({raw:true}) devuelve el número sin el 0.
 *
 * @param {*} rawVal - Valor crudo de la celda (row[col] con raw:true).
 * @param {*} formattedVal - Mismo valor con raw:false (texto tal como se ve en Excel).
 * @returns {string}
 */
// Reportes reales de UPHONE no siempre nombran la columna de teléfono igual:
// algunas hojas usan "TELEFONO 1", otras (confirmado en un reporte de ventas
// real, hoja "GLOBAL") usan solo "TELEFONO" — sin el "1". Antes, si la hoja
// no tenía la columna EXACTA "TELEFONO 1", TODOS los contactos quedaban sin
// teléfono y la campaña completa se descartaba silenciosamente (0 contactos).
const PHONE_COLUMN_CANDIDATES = ['TELEFONO 1', 'TELEFONO'];

/**
 * Busca en `row` la primera columna candidata de teléfono presente (en orden
 * de preferencia). Usa `hasOwnProperty` en vez de un valor truthy porque
 * `sheet_to_json({defval:''})` rellena TODA columna declarada en la hoja —
 * la ausencia de la key significa que la columna no existe en ese archivo,
 * no que esté vacía.
 */
function resolvePhoneColumnKey(row) {
    for (const key of PHONE_COLUMN_CANDIDATES) {
        if (Object.prototype.hasOwnProperty.call(row, key)) return key;
    }
    return null;
}

function resolvePhoneCell(rawVal, formattedVal) {
    if (rawVal === undefined || rawVal === null || rawVal === '') return '';
    if (typeof rawVal === 'string') return rawVal.trim();

    const rawDigits = String(rawVal).replace(/\D/g, '');
    const formattedDigits = typeof formattedVal === 'string' ? formattedVal.replace(/\D/g, '') : '';

    // Solo preferir el formateado si extiende el crudo por el INICIO (recupera
    // ceros a la izquierda). Si el formateado es más largo por otra razón (ej.
    // decimales de un formato de moneda aplicado por error), esto no calza y
    // se conserva el crudo para no corromper el número con dígitos falsos.
    if (formattedDigits.length > rawDigits.length && formattedDigits.endsWith(rawDigits)) {
        return formattedDigits;
    }
    return rawDigits;
}

const DataProcessor = {
    /**
     * Lee un archivo Excel y devuelve contactos con solo las columnas del formato base.
     * @param {File} file - El archivo subido (.xlsx / .xls).
     * @returns {Promise<Array>} - Contactos con las 8 columnas definidas.
     */
    async readContacts(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });

                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];

                    // Fila 1 como headers, vacíos como string vacío
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
                    // Texto formateado (raw:false): solo se usa para recuperar ceros a la
                    // izquierda en TELEFONO 1 cuando la celda es numérica (ver resolvePhoneCell).
                    const jsonDataFormatted = XLSX.utils.sheet_to_json(worksheet, { defval: '', raw: false });

                    if (jsonData.length === 0) {
                        reject('El archivo no tiene filas de datos.');
                        return;
                    }

                    // La columna de teléfono no siempre se llama igual entre reportes
                    // (ver PHONE_COLUMN_CANDIDATES) — se resuelve una vez por hoja, no
                    // por fila, porque sheet_to_json({defval:''}) garantiza el mismo
                    // conjunto de keys en todas las filas de una misma hoja.
                    const phoneKey = resolvePhoneColumnKey(jsonData[0]);
                    if (!phoneKey) {
                        reject(`No se encontró columna de teléfono (se esperaba "${PHONE_COLUMN_CANDIDATES.join('" o "')}"). Verifica que el archivo tenga el formato base correcto.`);
                        return;
                    }

                    // Extraer solo las columnas del formato base y descartar filas sin teléfono
                    const cleanedData = jsonData
                        .map((row, i) => {
                            const contact = {};
                            for (const col of CAMPAIGN_COLUMNS) {
                                if (col === 'TELEFONO 1') {
                                    const formattedRow = jsonDataFormatted[i];
                                    const rawCell = row[phoneKey];
                                    const formattedCell = formattedRow ? formattedRow[phoneKey] : undefined;
                                    contact[col] = resolvePhoneCell(rawCell, formattedCell);
                                } else {
                                    contact[col] = row[col] !== undefined ? String(row[col]).trim() : '';
                                }
                            }
                            return contact;
                        })
                        .filter(contact => contact['TELEFONO 1'] !== '');

                    if (cleanedData.length === 0) {
                        reject('No se encontraron contactos con teléfono válido. Verifica que el archivo tenga el formato base correcto.');
                        return;
                    }

                    resolve(cleanedData);
                } catch (error) {
                    console.error('Error procesando archivo:', error);
                    reject('Error al leer el archivo. Asegúrate que sea un archivo Excel (.xlsx) con el formato base.');
                }
            };

            reader.onerror = () => reject('Error al leer el archivo.');
            reader.readAsArrayBuffer(file);
        });
    },

    /**
     * Devuelve las columnas disponibles como variables para el mensaje.
     * @param {Array} contacts - Lista de contactos.
     * @returns {Array} - Nombres de columnas.
     */
    getAvailableVariables(contacts) {
        if (contacts.length === 0) return [];
        return Object.keys(contacts[0]);
    }
};

// Exportar
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataProcessor;
    module.exports.resolvePhoneCell = resolvePhoneCell;
    module.exports.resolvePhoneColumnKey = resolvePhoneColumnKey;
}
