/**
 * telegramPageApi.js — lógica que corre en la página de Telegram Web K (mundo MAIN).
 * Sin dependencias: instalable vía chrome.scripting.executeScript({ world: 'MAIN' })
 * y testeable en Node con un `win` falso (en la página será `window`).
 *
 * Trade-off: depende de la API interna de Telegram Web K (puede cambiar en un
 * build nuevo) a cambio de funcionar minimizado y sin entrega cruzada (por peerId).
 */

(function () {
function managersOf(win) {
    if (!win) return {};
    const scope = win.rootScope;
    if (!scope) return {};
    return scope.managers || {};
}

function baseMaxMid(historial) {
    let base = 0;
    const lista = Array.isArray(historial) ? historial : [];
    for (const mid of lista) {
        if (Number.isInteger(mid) && mid > base) base = mid;
    }
    return base;
}

async function leeBase(managers, peerId) {
    try {
        const res = await managers.appMessagesManager.getHistory({ peerId, limit: 5 });
        const historial = res && res.history ? res.history : [];
        return baseMaxMid(historial);
    } catch (_) {
        return 0;
    }
}

function isReady(win) {
    if (!win || !win.rootScope || !win.appImManager) return false;
    const scope = win.rootScope;
    const managers = scope.managers;
    if (!managers) return false;
    if (!managers.appUsersManager || !managers.appMessagesManager) return false;
    return typeof scope.myId === 'number';
}

function errorMessage(err) {
    if (!err) return 'error desconocido';
    if (typeof err.type === 'string' && err.type) return err.type;
    if (typeof err.message === 'string' && err.message) return err.message;
    return String(err);
}

// Límite de caracteres del pie (caption) que Telegram acepta junto a una foto.
const CAPTION_LIMIT = 1024;

async function resolvePeer(win, intlDigits) {
    if (!isReady(win)) {
        return { status: 'ERROR', message: 'Telegram Web no está listo' };
    }
    const managers = managersOf(win);
    try {
        const user = await managers.appUsersManager.resolvePhone(intlDigits);
        return { status: 'FOUND', peerId: user.id };
    } catch (err) {
        if (err && err.type === 'PHONE_NOT_OCCUPIED') {
            return { status: 'NOT_FOUND', message: 'sin cuenta de Telegram' };
        }
        return { status: 'ERROR', message: errorMessage(err) };
    }
}

async function sendAndVerify(win, peerId, text, opts = {}) {
    const verifyTimeoutMs = opts.verifyTimeoutMs != null ? opts.verifyTimeoutMs : 15000;
    const pollMs = opts.pollMs != null ? opts.pollMs : 500;
    const nowSec = opts.nowSec || (() => Math.floor(Date.now() / 1000));
    const sleep = opts.sleep || ((ms) => new Promise(r => setTimeout(r, ms)));
    const inicio = nowSec();
    const managers = managersOf(win);
    const myId = win && win.rootScope ? win.rootScope.myId : undefined;
    const base = await leeBase(managers, peerId);
    try {
        await managers.appMessagesManager.sendText({ peerId, text });
    } catch (err) {
        return { status: 'ERROR', message: errorMessage(err) };
    }
    const limite = Date.now() + verifyTimeoutMs;
    for (;;) {
        const confirmado = await buscaConfirmacion(managers, peerId, base, inicio, myId);
        if (confirmado.status === 'SUCCESS') return confirmado;
        if (Date.now() >= limite) {
            return { status: 'ERROR', message: 'Envío no confirmado por Telegram' };
        }
        await sleep(pollMs);
    }
}

async function buscaConfirmacion(managers, peerId, base, inicio, myId) {
    let historial;
    try {
        const res = await managers.appMessagesManager.getHistory({ peerId, limit: 5 });
        historial = res && res.history ? res.history : [];
    } catch (_) {
        return { status: 'PENDING' };
    }
    for (const mid of historial) {
        let msg;
        try {
            msg = await managers.appMessagesManager.getMessageByPeer(peerId, mid);
        } catch (_) {
            continue;
        }
        if (!msg) continue;
        const saliente = (msg.pFlags && msg.pFlags.out === true) || (myId != null && msg.fromId === myId);
        if (Number.isInteger(msg.mid) && msg.mid > base && saliente && msg.date >= inicio - 5) {
            return { status: 'SUCCESS', mid: msg.mid };
        }
    }
    return { status: 'PENDING' };
}

async function buscaConfirmacionMedia(managers, peerId, base, inicio, myId) {
    let historial;
    try {
        const res = await managers.appMessagesManager.getHistory({ peerId, limit: 5 });
        historial = res && res.history ? res.history : [];
    } catch (_) {
        return { status: 'PENDING' };
    }
    for (const mid of historial) {
        let msg;
        try {
            msg = await managers.appMessagesManager.getMessageByPeer(peerId, mid);
        } catch (_) {
            continue;
        }
        if (!msg) continue;
        if (!msg.media) continue;
        const saliente = (msg.pFlags && msg.pFlags.out === true) || (myId != null && msg.fromId === myId);
        if (Number.isInteger(msg.mid) && msg.mid > base && saliente && msg.date >= inicio - 5) {
            return { status: 'SUCCESS', mid: msg.mid };
        }
    }
    return { status: 'PENDING' };
}

async function sendMediaAndVerify(win, peerId, dataUrl, caption, opts = {}) {
    const verifyTimeoutMs = opts.verifyTimeoutMs != null ? opts.verifyTimeoutMs : 60000;
    const pollMs = opts.pollMs != null ? opts.pollMs : 500;
    const nowSec = opts.nowSec || (() => Math.floor(Date.now() / 1000));
    const sleep = opts.sleep || ((ms) => new Promise(r => setTimeout(r, ms)));
    const texto = typeof caption === 'string' ? caption : '';
    let blob;
    try {
        const fetchFn = opts.fetchFn
            || (win && typeof win.fetch === 'function' ? win.fetch.bind(win) : undefined)
            || (typeof fetch !== 'undefined' ? fetch : undefined);
        if (!fetchFn) return { status: 'ERROR', message: 'Imagen inválida' };
        const respuesta = await fetchFn(dataUrl);
        blob = await respuesta.blob();
    } catch (_) {
        return { status: 'ERROR', message: 'Imagen inválida' };
    }
    if (!blob || typeof blob.type !== 'string' || blob.type.indexOf('image/') !== 0) {
        return { status: 'ERROR', message: 'Imagen inválida' };
    }
    const inicio = nowSec();
    const managers = managersOf(win);
    const myId = win && win.rootScope ? win.rootScope.myId : undefined;
    const base = await leeBase(managers, peerId);
    const conPie = texto.length > 0 && texto.length <= CAPTION_LIMIT;
    try {
        if (conPie) {
            await managers.appMessagesManager.sendFile({ peerId, file: blob, caption: texto, isMedia: true });
        } else {
            await managers.appMessagesManager.sendFile({ peerId, file: blob, isMedia: true });
        }
    } catch (err) {
        return { status: 'ERROR', message: errorMessage(err) };
    }
    const limite = Date.now() + verifyTimeoutMs;
    let imagenMid = 0;
    for (;;) {
        const confirmado = await buscaConfirmacionMedia(managers, peerId, base, inicio, myId);
        if (confirmado.status === 'SUCCESS') {
            imagenMid = confirmado.mid;
            break;
        }
        if (Date.now() >= limite) {
            return { status: 'ERROR', message: 'Envío no confirmado por Telegram' };
        }
        await sleep(pollMs);
    }
    if (texto.length > CAPTION_LIMIT) {
        const textoRes = await sendAndVerify(win, peerId, texto, opts);
        return textoRes;
    }
    return { status: 'SUCCESS', mid: imagenMid };
}

const api = { isReady, resolvePeer, sendAndVerify, sendMediaAndVerify };

if (typeof window !== 'undefined' && window) {
    window.__telegramProPageApi = api;
}
if (typeof module !== 'undefined' && module.exports) {
    if (typeof window !== 'undefined' && window && window.__telegramProPageApi) {
        module.exports = window.__telegramProPageApi;
    } else {
        module.exports = api;
    }
}
})();
