/**
 * TelegramWebChannel — adaptador del canal Telegram Web a la interfaz Channel.
 * Envía por la API interna de Telegram Web K (mundo MAIN), sin DOM ni deep links:
 * resuelve por teléfono a peerId y verifica el envío por historial. Funciona
 * con la ventana minimizada; solo el arranque inicial necesita un frame visible.
 *
 * Interfaz Channel:
 *   listTargets() -> ['web']
 *   openConversation(target, phone) -> Promise<void>  // lanza TELEGRAM_NOT_FOUND si no hay cuenta
 *   send(target, text) -> Promise<void>
 *   verifySent(target) -> Promise<boolean>
 *   detectProtocol(target) -> Promise<'telegram'>
 *   isBlocked(target) -> Promise<boolean>
 *   attachImage(target, dataUrl) -> Promise<void>
 */

function utilsNoDisponible() {
    throw new Error('Utils no disponible');
}

// Special Case: evita retornar null cuando no hay Utils; cada uso falla
// con un mensaje claro en vez de un TypeError sobre null.
const ChannelUtilsAusente = {
    toInternationalDigits: utilsNoDisponible
};

function resolveChannelUtils(explicit) {
    if (explicit) return explicit;
    if (typeof globalThis !== 'undefined' && globalThis.Utils) return globalThis.Utils;
    if (typeof window !== 'undefined' && window.Utils) return window.Utils;
    if (typeof require === 'function') {
        try { return require('../ui/utils.js'); } catch (_) {}
        try { return require('./ui/utils.js'); } catch (_) {}
    }
    return ChannelUtilsAusente;
}

class TelegramWebChannel {
    /**
     * @param {number} tabId - ID de la pestaña de Telegram Web
     * @param {Object} [deps] - inyección para tests { chrome, utils, sleepFn, callTimeoutMs, mediaCallTimeoutMs, readyTimeoutMs, readyPollMs }
     */
    constructor(tabId, deps = {}) {
        this.tabId = tabId;
        this.chrome = deps.chrome || (typeof chrome !== 'undefined' ? chrome : null);
        this.utils = resolveChannelUtils(deps.utils);
        this.sleepFn = deps.sleepFn || ((ms) => new Promise((r) => setTimeout(r, ms)));
        this.callTimeoutMs = deps.callTimeoutMs != null ? deps.callTimeoutMs : 45000;
        this.mediaCallTimeoutMs = deps.mediaCallTimeoutMs != null ? deps.mediaCallTimeoutMs : 90000;
        this.readyTimeoutMs = deps.readyTimeoutMs != null ? deps.readyTimeoutMs : 60000;
        this.readyPollMs = deps.readyPollMs != null ? deps.readyPollMs : 500;
        this.currentPeerId = 0;
        this.hasPeer = false;
        this.hasImage = false;
        this.pendingImage = '';
    }

    async listTargets() {
        return ['web'];
    }

    async runInPage(fnName, args, timeoutMs) {
        const scripting = this.chrome && this.chrome.scripting;
        if (!scripting || typeof scripting.executeScript !== 'function') {
            throw new Error('Telegram Web no respondió');
        }
        const llamada = (async () => {
            await scripting.executeScript({
                target: { tabId: this.tabId },
                world: 'MAIN',
                files: ['channels/telegramPageApi.js']
            });
            const results = await scripting.executeScript({
                target: { tabId: this.tabId },
                world: 'MAIN',
                func: (name, a) => window.__telegramProPageApi[name](window, ...a),
                args: [fnName, args]
            });
            if (!results || !results[0]) throw new Error('Telegram Web no respondió');
            return results[0].result;
        })();
        let temporizador = null;
        const espera = timeoutMs != null ? timeoutMs : this.callTimeoutMs;
        const expira = new Promise((_, rechaza) => {
            temporizador = setTimeout(() => rechaza(new Error('Telegram Web no respondió')), espera);
        });
        try {
            return await Promise.race([llamada, expira]);
        } finally {
            if (temporizador) clearTimeout(temporizador);
        }
    }

    async ensureReady() {
        const tab = await this.chrome.tabs.get(this.tabId);
        try { await this.chrome.tabs.update(this.tabId, { autoDiscardable: false }); } catch (_) {}
        if (tab && tab.discarded) {
            await this.chrome.tabs.reload(this.tabId);
        } else {
            const listo = await this.runInPage('isReady', []);
            if (listo) return;
        }
        if (tab && tab.windowId != null && this.chrome.windows) {
            try { await this.chrome.windows.update(tab.windowId, { state: 'normal' }); } catch (_) {}
        }
        try { await this.chrome.tabs.update(this.tabId, { active: true }); } catch (_) {}
        const limite = Date.now() + this.readyTimeoutMs;
        for (;;) {
            await this.sleepFn(this.readyPollMs);
            let actual = false;
            try {
                actual = await this.runInPage('isReady', []);
            } catch (err) {
                if (err && err.message && err.message.includes('no respondió')) throw err;
                actual = false;
            }
            if (actual) return;
            if (Date.now() >= limite) {
                throw new Error('Telegram Web no está listo: abre la pestaña y verifica la sesión');
            }
        }
    }

    async openConversation(target, phone) {
        this.hasPeer = false;
        this.currentPeerId = 0;
        this.hasImage = false;
        this.pendingImage = '';
        const intl = this.utils.toInternationalDigits(phone);
        if (!intl) {
            throw new Error('TELEGRAM_NOT_FOUND: número inválido ' + phone);
        }
        await this.ensureReady();
        const response = await this.runInPage('resolvePeer', [intl]);
        if (!response) throw new Error('Telegram Web no respondió');
        if (response.status === 'FOUND') {
            this.currentPeerId = response.peerId;
            this.hasPeer = true;
            return;
        }
        if (response.status === 'NOT_FOUND') {
            throw new Error('TELEGRAM_NOT_FOUND: sin cuenta de Telegram para ' + phone);
        }
        throw new Error(response.message || 'No se pudo abrir la conversación');
    }

    async send(target, text) {
        if (!this.hasPeer) {
            throw new Error('Sin conversación abierta: llama openConversation primero');
        }
        if (this.hasImage) {
            const dataUrl = this.pendingImage;
            try {
                const response = await this.runInPage('sendMediaAndVerify', [this.currentPeerId, dataUrl, text], this.mediaCallTimeoutMs);
                if (!response || response.status !== 'SUCCESS') {
                    throw new Error((response && response.message) || 'Envío no confirmado por Telegram');
                }
            } finally {
                this.hasImage = false;
                this.pendingImage = '';
            }
            return;
        }
        const response = await this.runInPage('sendAndVerify', [this.currentPeerId, text]);
        if (!response || response.status !== 'SUCCESS') {
            throw new Error((response && response.message) || 'Envío no confirmado por Telegram');
        }
    }

    async verifySent(target) {
        // La confirmación real ya la hizo sendAndVerify por historial.
        return true;
    }

    async detectProtocol(target) {
        return 'telegram';
    }

    async isBlocked(target) {
        return false;
    }

    async attachImage(target, dataUrl) {
        if (typeof dataUrl !== 'string' || dataUrl.indexOf('data:image/') !== 0) {
            throw new Error('Imagen inválida');
        }
        this.hasImage = true;
        this.pendingImage = dataUrl;
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { TelegramWebChannel, resolveChannelUtils, ChannelUtilsAusente };
}
