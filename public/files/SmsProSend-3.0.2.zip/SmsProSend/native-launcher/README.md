# Native Messaging Host — lanzador del adb-bridge-server

Permite que el botón "Iniciar/Detener/Reiniciar puente" del dashboard controle
`adb-bridge-server` sin que el usuario abra una terminal. Una extensión Chrome
(MV3) no puede lanzar procesos por su cuenta — esta es la única vía soportada
por Chrome para que un botón de la UI controle un programa local.

## Instalación (una vez por máquina)

```powershell
cd "SMS PRO V3.0\native-launcher"
.\register.ps1
```

Esto registra el host ante Chrome (usuario actual, `HKCU`). Resuelve las rutas
absolutas reales de `adb.exe` y `node.exe` en ese momento y las fija dentro de
`launcher.generated.bat` (no se commitea, es específico de cada máquina) — el
server **nunca depende del PATH de quien lo lance**. Esto es intencional:
Chrome puede llevar horas/días abierto desde antes de instalar
`adb`/platform-tools, y todo lo que lanza hereda ese PATH viejo — reiniciar el
server con el botón del dashboard no lo arregla, porque el problema está en el
PATH heredado de Chrome, no en el server. Si mueves o reinstalas `adb` en otra
ruta, hay que volver a correr `register.ps1`.

Requiere Node.js instalado (`register.ps1` lo busca en PATH la primera vez,
solo para resolver la ruta — después queda fija).

## Protocolo

Mensajes `chrome.runtime.sendNativeMessage('com.anomalydevs.smspro.adblauncher', {action}, cb)`:

- `{action:'status'}` → `{running:bool, pid:number|null}`
- `{action:'start'}` → `{started:bool, pid}` o `{started:false, alreadyRunning:true, pid}`
- `{action:'stop'}` → `{stopped:bool}`
- `{action:'restart'}` → `{restarted:true, pid}`

Cada llamada lanza `launcher.js`, procesa un mensaje y termina — `chrome.runtime.sendNativeMessage` es de un solo request/response, no una conexión persistente.

## Archivos

- `serverControl.js` — arranca/detiene/verifica el server real (testeable, sin I/O real vía inyección de dependencias)
- `launcher.js` — traduce el protocolo stdio de Native Messaging a `serverControl`
- `launcher.bat` — punto de entrada que Chrome ejecuta (invoca `node launcher.js`)
- `com.anomalydevs.smspro.adblauncher.json` — plantilla del manifest (con `__LAUNCHER_BAT_PATH__` como placeholder)
- `register.ps1` — genera el manifest real (`*.generated.json`, no se commitea) y registra la clave en el registro de Windows
- `serverControl.test.js` — tests unitarios (`node serverControl.test.js`)

## Extensión ID fija

`manifest.json` de la extensión tiene un campo `"key"` fijo para que el ID sea
siempre `lohpckdboolnobchgdobijffgkilmfem` sin importar desde qué carpeta se
cargue "descomprimida" — el manifest del Native Messaging Host autoriza
explícitamente ese ID en `allowed_origins`. Sin esto, el ID cambiaría por
máquina/ruta y el host rechazaría la conexión.
