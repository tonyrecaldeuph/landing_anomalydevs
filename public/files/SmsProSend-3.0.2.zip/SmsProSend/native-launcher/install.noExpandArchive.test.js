const assert = require('assert');
const fs = require('fs');
const path = require('path');

// install.ps1 se compila a .exe con ps2exe y corre en PCs de clientes.
// Expand-Archive depende del módulo Microsoft.PowerShell.Archive, que en
// varias máquinas no carga dentro del host de ps2exe ("el módulo no pudo
// cargarse"). System.IO.Compression.ZipFile es .NET puro y no depende de
// ningún módulo, así que la extracción debe hacerse con él.
const script = fs
    .readFileSync(path.join(__dirname, 'install.ps1'), 'utf8')
    .split(/\r?\n/)
    .filter((line) => !line.trim().startsWith('#'))
    .join('\n');

assert.ok(!/Expand-Archive/i.test(script),
    'install.ps1 no debe usar Expand-Archive (depende de un módulo que puede no cargar bajo ps2exe)');

assert.ok(/\[System\.IO\.Compression\.ZipFile\]::ExtractToDirectory/.test(script),
    'install.ps1 debe extraer el zip con [System.IO.Compression.ZipFile]::ExtractToDirectory');

assert.ok(/Add-Type\s+-AssemblyName\s+System\.IO\.Compression\.FileSystem/i.test(script),
    'install.ps1 debe cargar el ensamblado System.IO.Compression.FileSystem antes de usar ZipFile');

console.log('OK: install.ps1 extrae el zip con .NET y no depende de Expand-Archive');
