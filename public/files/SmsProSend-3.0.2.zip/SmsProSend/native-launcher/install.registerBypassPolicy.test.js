const assert = require('assert');
const fs = require('fs');
const path = require('path');

// install.ps1 corre en PCs de clientes con políticas de ejecución arbitrarias
// (AllSigned, o RemoteSigned con el archivo marcado como descargado). Invocar
// register.ps1 con `&` dentro del mismo proceso aplica esa política y falla con
// "no está firmado digitalmente". Se debe lanzar en un powershell hijo con
// -ExecutionPolicy Bypass, igual que hace serverControl.registerHost.
const script = fs
    .readFileSync(path.join(__dirname, 'install.ps1'), 'utf8')
    .split(/\r?\n/)
    .filter((line) => !line.trim().startsWith('#'))
    .join('\n');

assert.ok(!/&\s*\(\s*Join-Path\s+\$InstallScriptDir\s+'register\.ps1'\s*\)/i.test(script),
    'install.ps1 no debe invocar register.ps1 con & en el mismo proceso (le aplica la política de ejecución)');

assert.ok(/-ExecutionPolicy\s+Bypass/i.test(script),
    'install.ps1 debe lanzar register.ps1 con -ExecutionPolicy Bypass');

assert.ok(/-File\s+`?"?\$registerPath/i.test(script),
    'install.ps1 debe pasar register.ps1 al powershell hijo con -File');

assert.ok(/\$LASTEXITCODE/.test(script),
    'install.ps1 debe comprobar el código de salida del powershell hijo (un fallo nativo no lanza excepción)');

console.log('OK: install.ps1 registra el host en un powershell hijo con ExecutionPolicy Bypass');
