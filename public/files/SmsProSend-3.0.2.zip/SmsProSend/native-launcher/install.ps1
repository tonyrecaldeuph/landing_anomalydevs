# install.ps1 — Instalador unico para el Native Messaging Host de SMS PRO V3.0
# Orquesta: Node.js -> platform-tools (adb) -> register.ps1

$ErrorActionPreference = 'Stop'

if ($PSScriptRoot) {
    $InstallScriptDir = $PSScriptRoot
} elseif ($ScriptRoot) {
    # $ScriptRoot es una variable que solo existe cuando ps2exe compila este script a .exe
    $InstallScriptDir = $ScriptRoot
} else {
    $InstallScriptDir = Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)
}

Write-Host "=============================================="
Write-Host " SMS PRO - Instalador de puente ADB"
Write-Host "=============================================="
Write-Host ""

# ── Paso 1: Node.js ──────────────────────────────────────────────
Write-Host "[Paso 1/3] Verificando Node.js..."

try {
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if (-not $nodeCmd) {
        Write-Host "Node.js no encontrado. Se intentara instalar..."

        $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

        if (-not $isAdmin) {
            Write-Host "Se requiere permisos de administrador para instalar Node.js."
            Write-Host "Relanzando el instalador como administrador..."
            $currentExePath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
            $isCompiledExe = ($currentExePath -notmatch 'powershell\.exe$') -and ($currentExePath -notmatch 'pwsh\.exe$')

            if ($isCompiledExe) {
                Start-Process -FilePath $currentExePath -Verb RunAs
            } else {
                $psPath = (Get-Command powershell -ErrorAction SilentlyContinue).Source
                if (-not $psPath) {
                    $psPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
                }
                $scriptPath = $PSCommandPath
                Start-Process -FilePath $psPath -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs
            }
            exit
        }

        Write-Host "Instalando Node.js LTS con winget (puede tardar varios minutos)..."

        $wingetCmd = Get-Command winget -ErrorAction SilentlyContinue
        if (-not $wingetCmd) {
            Write-Host "ERROR: winget no esta disponible en este sistema." -ForegroundColor Red
            Write-Host "Instala Node.js manualmente desde https://nodejs.org y volve a ejecutar este instalador." -ForegroundColor Yellow
            Read-Host "Presione Enter para cerrar"
            exit 1
        }

        try {
            winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements
        } catch {
            Write-Host "ERROR: fallo la instalacion de Node.js con winget: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host "Instala Node.js manualmente desde https://nodejs.org y volve a ejecutar este instalador." -ForegroundColor Yellow
            Read-Host "Presione Enter para cerrar"
            exit 1
        }

        # Verificar que node quedo disponible tras la instalacion
        $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
        if (-not $nodeCmd) {
            # Refrescar PATH de la sesion actual por si winget lo actualizo
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
            $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
        }

        if ($nodeCmd) {
            Write-Host "Node.js instalado correctamente: $($nodeCmd.Source)" -ForegroundColor Green
        } else {
            Write-Host "Node.js se instalo pero no se detecta en esta sesion. Cerra y volve a abrir el instalador, o instalalo manualmente desde https://nodejs.org." -ForegroundColor Yellow
            Read-Host "Presione Enter para cerrar"
            exit 1
        }
    } else {
        Write-Host "Node.js encontrado: $($nodeCmd.Source)" -ForegroundColor Green
    }
} catch {
    Write-Host "ERROR en la verificacion/instalacion de Node.js: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Instala Node.js manualmente desde https://nodejs.org y volve a ejecutar este instalador." -ForegroundColor Yellow
    Read-Host "Presione Enter para cerrar"
    exit 1
}

Write-Host ""

# ── Paso 2: adb / platform-tools ─────────────────────────────────
Write-Host "[Paso 2/3] Verificando adb (platform-tools)..."

try {
    $adbPath = Join-Path $env:LOCALAPPDATA 'Android\platform-tools\adb.exe'

    if (-not (Test-Path $adbPath)) {
        Write-Host "adb.exe no encontrado en $adbPath"
        Write-Host "Descargando Android platform-tools desde Google..."

        $platformToolsUrl = 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip'
        $tempBase = Join-Path $env:TEMP 'smspro-platform-tools-install'
        $zipPath = Join-Path $tempBase 'platform-tools-latest-windows.zip'
        $extractPath = Join-Path $tempBase 'extract'
        $destDir = Join-Path $env:LOCALAPPDATA 'Android\platform-tools'

        try {
            if (Test-Path $tempBase) { Remove-Item $tempBase -Recurse -Force -ErrorAction SilentlyContinue }
            New-Item -ItemType Directory -Path $tempBase -Force | Out-Null
            New-Item -ItemType Directory -Path $extractPath -Force | Out-Null

            Write-Host "Descargando $platformToolsUrl ..."
            Invoke-WebRequest -Uri $platformToolsUrl -OutFile $zipPath

            Write-Host "Extrayendo archivo..."
            # .NET directo: Expand-Archive depende del modulo Microsoft.PowerShell.Archive,
            # que en algunas PCs no carga dentro del .exe compilado con ps2exe.
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $extractPath)

            $innerDir = Join-Path $extractPath 'platform-tools'
            if (-not (Test-Path $innerDir)) {
                throw "No se encontro la carpeta 'platform-tools' dentro del zip descargado."
            }

            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }

            Write-Host "Copiando archivos a $destDir ..."
            Copy-Item -Path (Join-Path $innerDir '*') -Destination $destDir -Recurse -Force

            Write-Host "Limpiando archivos temporales..."
            Remove-Item $tempBase -Recurse -Force -ErrorAction SilentlyContinue

            if (Test-Path $adbPath) {
                Write-Host "adb instalado correctamente en $adbPath" -ForegroundColor Green
            } else {
                throw "La copia finalizo pero no se encuentra adb.exe en $adbPath"
            }
        } catch {
            Write-Host "ERROR al descargar/instalar platform-tools: $($_.Exception.Message)" -ForegroundColor Red
            if (Test-Path $tempBase) {
                try { Remove-Item $tempBase -Recurse -Force -ErrorAction SilentlyContinue } catch {}
            }
            Read-Host "Presione Enter para cerrar"
            exit 1
        }
    } else {
        Write-Host "adb encontrado en $adbPath" -ForegroundColor Green
    }
} catch {
    Write-Host "ERROR en la verificacion/instalacion de adb: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host "Presione Enter para cerrar"
    exit 1
}

Write-Host ""

# ── Paso 3: Registrar Native Messaging Host ────────────────────────
Write-Host "[Paso 3/3] Registrando Native Messaging Host..."

try {
    $registerPath = Join-Path $InstallScriptDir 'register.ps1'
    if (-not (Test-Path $registerPath)) {
        throw "No se encontro register.ps1 en $InstallScriptDir"
    }
    # Proceso hijo con Bypass: invocar con & aplicaria la politica de ejecucion de la PC
    # (AllSigned, o RemoteSigned con el archivo marcado como descargado) y fallaria
    # con "no esta firmado digitalmente". Mismo criterio que serverControl.registerHost.
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    & $psExe -NoProfile -ExecutionPolicy Bypass -File $registerPath
    if ($LASTEXITCODE -ne 0) {
        throw "register.ps1 termino con codigo de salida $LASTEXITCODE (ver el detalle arriba)."
    }
    Write-Host "Registro del Native Messaging Host completado." -ForegroundColor Green
} catch {
    Write-Host "ERROR al registrar el Native Messaging Host: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host "Presione Enter para cerrar"
    exit 1
}

Write-Host ""
Write-Host "=============================================="
Write-Host " Instalacion completada con exito." -ForegroundColor Green
Write-Host " Cerra TODAS las ventanas de Chrome y volve a abrirlo"
Write-Host " para que tome el nuevo Native Messaging Host."
Write-Host "=============================================="

Read-Host "Presione Enter para cerrar"
