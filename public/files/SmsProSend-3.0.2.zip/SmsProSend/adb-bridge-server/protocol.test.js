const assert = require('assert');
const {
    BRIDGE_VERSION,
    buildConnectedMessage,
    validateStartTargets
} = require('./protocol.js');
const manifest = require('../manifest.json');

(function () {
    try {
    // El handshake anuncia capacidad de aislamiento + versión igual a manifest.json.
    // Sin esto, un dashboard nuevo no puede distinguir un puente viejo (que ignora
    // enabledDevices y envía por TODOS los teléfonos) de uno actual.
    const hello = buildConnectedMessage(8765);
    assert.strictEqual(hello.type, 'connected');
    assert.strictEqual(hello.port, 8765);
    assert.strictEqual(hello.isolation, true);
    assert.strictEqual(hello.bridgeVersion, manifest.version);
    assert.strictEqual(BRIDGE_VERSION, manifest.version);
    console.log('OK: buildConnectedMessage anuncia isolation + versión de manifest');

    // Caso campo: 3 conectados, 1 habilitado -> solo ese participa.
    const ok = validateStartTargets(['A', 'B', 'C'], ['B']);
    assert.strictEqual(ok.ok, true);
    assert.deepStrictEqual(ok.targets, ['B']);
    console.log('OK: validateStartTargets deja solo el habilitado');

    // Dashboard antiguo que no manda la lista -> rechazo fail-closed con código
    // accionable (antes se enviaba por todos en silencio).
    for (const missing of [undefined, null, 'B', 42]) {
        const rejected = validateStartTargets(['A', 'B'], missing);
        assert.strictEqual(rejected.ok, false, `debió rechazar ${String(missing)}`);
        assert.strictEqual(rejected.code, 'DASHBOARD_OUTDATED');
        assert.ok(typeof rejected.message === 'string' && rejected.message.length > 0);
        assert.deepStrictEqual(rejected.targets, []);
    }
    console.log('OK: validateStartTargets rechaza start sin lista (fail-closed)');

    // Lista vacía o sin intersección -> rechazo, nunca null ni undefined.
    for (const enabled of [[], ['Z']]) {
        const rejected = validateStartTargets(['A', 'B'], enabled);
        assert.strictEqual(rejected.ok, false);
        assert.strictEqual(rejected.code, 'NO_ENABLED_TARGETS');
        assert.deepStrictEqual(rejected.targets, []);
    }
    console.log('OK: validateStartTargets rechaza habilitados vacíos/sin intersección');

    // Conectados inválidos -> colección vacía, nunca null.
    const empty = validateStartTargets(undefined, ['A']);
    assert.deepStrictEqual(empty.targets, []);
    console.log('OK: validateStartTargets nunca devuelve null');

    console.log('Todos los tests de protocol pasaron.');
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
})();
