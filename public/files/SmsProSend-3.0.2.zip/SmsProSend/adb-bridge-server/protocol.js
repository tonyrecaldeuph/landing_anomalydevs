/**
 * protocol — handshake de capacidad y validación fail-closed del arranque ADB.
 *
 * Origen: un dashboard nuevo contra un puente viejo (o viceversa) fallaba en
 * silencio — el puente ignoraba `enabledDevices` y enviaba por TODOS los
 * teléfonos. Funciones puras, sin net/adb/chrome — testeables sin procesos.
 *
 * Reglas:
 * - El puente anuncia `isolation:true` en el mensaje `connected`.
 * - Un `start` sin lista de habilitados se RECHAZA (fail-closed), nunca se
 *   degrada a "todos los conectados": enviar SMS desde el teléfono equivocado
 *   cuesta dinero y reputación; no enviar con mensaje claro es más barato.
 */

const { selectEnabledTargets } = require('../channels/deviceSelection.js');

const BRIDGE_VERSION = '3.0.2';

const StartRejectCode = {
    DASHBOARD_OUTDATED: 'DASHBOARD_OUTDATED',
    NO_ENABLED_TARGETS: 'NO_ENABLED_TARGETS'
};

/**
 * Mensaje `connected` con anuncio de capacidad. Los dashboards anteriores al
 * handshake ignoran los campos extra sin romperse.
 */
function buildConnectedMessage(port) {
    return { type: 'connected', port, bridgeVersion: BRIDGE_VERSION, isolation: true };
}

/**
 * Valida los objetivos de un `start`. Devuelve objeto resultado, nunca null:
 * { ok, code, message, targets } con targets siempre un arreglo.
 */
function validateStartTargets(connected, enabled) {
    if (!Array.isArray(enabled)) {
        return {
            ok: false,
            code: StartRejectCode.DASHBOARD_OUTDATED,
            message: 'Dashboard desactualizado: recarga la extensión en chrome://extensions y reintenta',
            targets: []
        };
    }
    const targets = selectEnabledTargets(connected, enabled);
    if (targets.length === 0) {
        return {
            ok: false,
            code: StartRejectCode.NO_ENABLED_TARGETS,
            message: 'Ningún dispositivo habilitado para el envío — habilita al menos un teléfono en la lista',
            targets: []
        };
    }
    return { ok: true, code: 'OK', message: '', targets };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { BRIDGE_VERSION, StartRejectCode, buildConnectedMessage, validateStartTargets };
}
