# ADB Bridge Server

Puente local Node entre el dashboard de la extensión y teléfonos Android vía `adb`.

## Prerrequisitos

- **Node.js 18+**
- **Android platform-tools** (`adb`) en `PATH` — descargar de https://developer.android.com/tools/adb
- Depuración USB habilitada en cada teléfono y autorizada (diálogo "Permitir depuración USB")
- Teléfonos conectados por USB, visibles en `adb devices` como `device` (no `unauthorized`/`offline`)

## Instalación

```bash
cd adb-bridge-server
npm install
```

## Uso

```bash
node server.js
# o
npm start
# puerto por defecto 8765, configurable:
PORT=8766 node server.js
```

El servidor expone:

- `ws://localhost:8765` — WebSocket para el dashboard (mensajes `list_devices`, `start`, `stop`, `progress`, `done`)
- `http://localhost:8765/health` — health check `{"ok":true,"devices":N}`

## Protocolo WebSocket

**Cliente → Servidor:**
- `{"type":"list_devices"}` → `{"type":"devices","devices":["emulator-5554"]}`
- `{"type":"status"}` → `{"type":"status","isRunning":bool,"total":N,"progressIndex":N,"results":[...]}` — permite reconstruir el dashboard si se reabre a mitad de campaña
- `{"type":"start","contacts":[...],"template":"Hola {{CLIENTE}}","messageVariants":[],"config":{},"enabledDevices":["serial1"]}` → `{"type":"started","devices":["serial1"],"total":N}` luego N `{"type":"progress",...}` y `{"type":"done","results":[...]}`
  - `enabledDevices` es obligatorio desde v3.0.1: sin la lista el servidor rechaza con `DASHBOARD_OUTDATED` (fail-closed, nunca envía por todos en silencio).
- `{"type":"stop"}` → `{"type":"stopping"}`

**Servidor → Cliente:**
- `{"type":"connected","port":8765,"bridgeVersion":"3.0.2","isolation":true}` — el dashboard bloquea el envío si falta `isolation:true` (puente viejo: ignoraría el aislamiento)
- `{"type":"error","message":"...","code":"ADB_NOT_FOUND"}` — otros códigos: `DASHBOARD_OUTDATED`, `NO_ENABLED_TARGETS`

## Notas

- Sobrevive al ciclo de vida del Service Worker de Chrome (proceso independiente).
- Multi-dispositivo en paralelo desde v1 (USB, sin ADB Wi-Fi en esta iteración).
- Paridad con canal web: reintento 3× por `CARRIER_FAILED`, pausa anti-spam por target tras 2 bloqueos.
