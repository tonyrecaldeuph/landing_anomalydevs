/**
 * adb-bridge-server — Puente Node entre dashboard (WebSocket) y teléfonos vía ADB.
 * Aloja campaignEngine + AdbChannel, sobrevive al ciclo de vida del SW de Chrome.
 */

const http = require('http');
const { WebSocketServer } = require('ws');
const { CampaignEngine } = require('../campaignEngine.js');
const { AdbChannel } = require('../channels/AdbChannel.js');
const { withEnabledTargets } = require('../channels/deviceSelection.js');
const { buildConnectedMessage, validateStartTargets } = require('./protocol.js');

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 8765;

// register.ps1 resuelve la ruta absoluta real de adb.exe y la fija como
// ADB_PATH al registrar el Native Messaging Host — así el server no depende
// del PATH que haya heredado quien lo lanzó (Chrome puede llevar abierto
// desde antes de que adb quedara instalado, y ese PATH viejo se hereda por
// toda la cadena: Chrome -> launcher -> este proceso). Sin ADB_PATH, cae al
// 'adb' de PATH normal (uso manual/desarrollo).
function createAdbChannel() {
    return new AdbChannel(process.env.ADB_PATH ? { adbPath: process.env.ADB_PATH } : {});
}

let currentEngine = null;
let isRunning = false;

// Health HTTP + WebSocket en mismo puerto
const server = http.createServer((req, res) => {
    if (req.url === '/health' && req.method === 'GET') {
        // Intentar listar dispositivos sin bloquear
        const ch = createAdbChannel();
        ch.listTargets().then(devices => {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true, devices: devices.length, deviceList: devices }));
        }).catch(err => {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true, devices: 0, error: err.message }));
        });
        return;
    }
    res.writeHead(404);
    res.end('Not found');
});

const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
    console.log('[adb-bridge] cliente conectado');
    ws.send(JSON.stringify(buildConnectedMessage(PORT)));

    ws.on('message', async (data) => {
        let msg;
        try { msg = JSON.parse(data.toString()); } catch (e) {
            ws.send(JSON.stringify({ type: 'error', message: 'JSON inválido' }));
            return;
        }

        if (msg.type === 'list_devices') {
            try {
                const ch = createAdbChannel();
                const devices = await ch.listTargets();
                ws.send(JSON.stringify({ type: 'devices', devices }));
            } catch (err) {
                ws.send(JSON.stringify({ type: 'error', message: err.message, code: 'ADB_NOT_FOUND' }));
            }
            return;
        }

        if (msg.type === 'status') {
            // Permite al dashboard reconstruir su estado si se cerró/recargó el popup
            // a mitad de campaña — el server sigue corriendo la campaña de forma
            // independiente (sobrevive al ciclo de vida del popup/Service Worker),
            // pero sin esto el dashboard no tenía forma de saberlo al reabrirse.
            ws.send(JSON.stringify({
                type: 'status',
                isRunning,
                total: currentEngine ? currentEngine.contacts.length : 0,
                progressIndex: currentEngine ? currentEngine.results.length : 0,
                results: currentEngine ? currentEngine.results : []
            }));
            return;
        }

        if (msg.type === 'start') {
            if (isRunning) {
                ws.send(JSON.stringify({ type: 'error', message: 'Campaña ya en curso' }));
                return;
            }
            const { contacts, template, messageVariants, config, imageDataUrl, enabledDevices } = msg;
            if (!Array.isArray(contacts) || contacts.length === 0) {
                ws.send(JSON.stringify({ type: 'error', message: 'contacts vacío' }));
                return;
            }
            try {
                const adbChannel = createAdbChannel();
                const connectedDevices = await adbChannel.listTargets();
                if (connectedDevices.length === 0) {
                    ws.send(JSON.stringify({ type: 'error', message: 'Sin dispositivos ADB conectados' }));
                    return;
                }
                // Teléfonos aislados por el usuario (ej. reservados para llamadas)
                // nunca participan. Fail-closed: sin lista de habilitados
                // (dashboard anterior al handshake) se rechaza en vez de
                // degradar a "todos los conectados" en silencio.
                const validation = validateStartTargets(connectedDevices, enabledDevices);
                if (!validation.ok) {
                    ws.send(JSON.stringify({ type: 'error', message: validation.message, code: validation.code }));
                    return;
                }
                const rawDevices = validation.targets;
                console.log(`[adb-bridge] start: conectados=${connectedDevices.length} habilitados=${Array.isArray(enabledDevices) ? enabledDevices.length : 0} seleccionados=${JSON.stringify(rawDevices)}`);
                // Una sola instancia AdbChannel devuelve N targets; campaignEngine
                // reparte por target. El envoltorio expone solo los habilitados.
                const channels = [withEnabledTargets(adbChannel, enabledDevices)];
                const engine = new CampaignEngine({
                    contacts,
                    template: template || '',
                    messageVariants: messageVariants || [],
                    channels,
                    config: config || {},
                    imageDataUrl: imageDataUrl || ''
                });
                currentEngine = engine;
                isRunning = true;
                ws.send(JSON.stringify({ type: 'started', devices: rawDevices, total: contacts.length }));

                const onProgress = (progress) => {
                    try {
                        ws.send(JSON.stringify({ type: 'progress', ...progress }));
                    } catch (_) {}
                };

                const result = await engine.run(onProgress);
                const wasAborted = engine.aborted;
                isRunning = false;
                currentEngine = null;
                ws.send(JSON.stringify({ type: 'done', results: result.results, stopped: wasAborted }));
            } catch (err) {
                const wasAborted = currentEngine && currentEngine.aborted;
                isRunning = false;
                currentEngine = null;
                if (wasAborted || (err.message && err.message.includes('ABORTED'))) {
                    ws.send(JSON.stringify({ type: 'done', results: [], stopped: true }));
                } else {
                    ws.send(JSON.stringify({ type: 'error', message: err.message }));
                }
            }
            return;
        }

        if (msg.type === 'stop') {
            if (currentEngine) {
                currentEngine.abort();
                console.log('[adb-bridge] stop solicitado — abortando motor');
            }
            // isRunning NO se apaga acá: el motor solo corta entre contactos
            // (uiautomator/taps/tipeo del envío en curso puede tardar varios
            // segundos), y el handler de 'start' usa isRunning para rechazar un
            // segundo arranque concurrente ("Campaña ya en curso"). Apagarlo de
            // inmediato dejaba una ventana donde dos campañas podían correr a
            // la vez sobre el mismo dispositivo.
            try { ws.send(JSON.stringify({ type: 'stopping' })); } catch (_) {}
            // Forzar done solo si el motor queda realmente colgado (ej. un
            // execFile de adb sin timeout, tras desconectar el USB a mitad de
            // comando) — 30s es más que el peor caso real de un solo contacto
            // (navegación + reintentos de uiautomator), no el camino normal.
            setTimeout(() => {
                if (isRunning) {
                    console.warn('[adb-bridge] motor no respondió tras stop en 30s — forzando done');
                    isRunning = false;
                    currentEngine = null;
                    try { ws.send(JSON.stringify({ type: 'done', results: [], stopped: true })); } catch (_) {}
                }
            }, 30000);
            return;
        }

        ws.send(JSON.stringify({ type: 'error', message: `Tipo desconocido: ${msg.type}` }));
    });

    ws.on('close', () => console.log('[adb-bridge] cliente desconectado'));
});

server.listen(PORT, () => {
    console.log(`[adb-bridge] escuchando en ws://localhost:${PORT} y http://localhost:${PORT}/health`);
});

// Validación rápida al arrancar: ¿adb existe?
(async () => {
    try {
        const ch = createAdbChannel();
        const devices = await ch.listTargets();
        console.log(`[adb-bridge] adb disponible, ${devices.length} dispositivo(s) conectado(s)`);
    } catch (err) {
        console.warn('[adb-bridge] adb no disponible o no en PATH:', err.message);
        console.warn('[adb-bridge] instala Android platform-tools y añade adb al PATH');
    }
})();
