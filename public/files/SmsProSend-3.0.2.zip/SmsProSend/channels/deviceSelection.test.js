const assert = require('assert');
const {
    selectEnabledTargets,
    computeEnabledDevices,
    toggleIsolation,
    withEnabledTargets,
    BridgeIsolation,
    bridgeIsolationFromHello,
    canStartAdbCampaign,
    bridgeIsolationWarning
} = require('./deviceSelection.js');

(async () => {
    // ── selectEnabledTargets (servidor): intersección conectados ∩ habilitados ──

    // Caso 1: solo se usan los conectados que el usuario habilitó
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B', 'C'], ['B']), ['B']);
    console.log('OK: selectEnabledTargets deja solo los habilitados');

    // Caso 2: un serial habilitado que ya no está conectado se ignora
    assert.deepStrictEqual(selectEnabledTargets(['A'], ['A', 'Z']), ['A']);
    console.log('OK: selectEnabledTargets ignora habilitados desconectados');

    // Caso 3: lista de habilitados vacía -> ninguno (nunca cae a "todos")
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B'], []), []);
    console.log('OK: selectEnabledTargets con habilitados vacío devuelve []');

    // Caso 4: sin lista de habilitados -> ninguno. Fail-closed: nunca se
    // degrada a "todos los conectados" (así falló el aislamiento en campo).
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B'], undefined), []);
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B'], null), []);
    console.log('OK: selectEnabledTargets sin lista no usa ningún teléfono');

    // Caso 5: entrada de conectados inválida -> colección vacía, nunca null
    assert.deepStrictEqual(selectEnabledTargets(undefined, ['A']), []);
    console.log('OK: selectEnabledTargets nunca devuelve null');

    // ── computeEnabledDevices (UI): conectados − aislados ──

    // Caso 6: un teléfono nuevo (no aislado) aparece habilitado por defecto
    assert.deepStrictEqual(computeEnabledDevices(['A', 'B', 'C'], ['A', 'C']), ['B']);
    assert.deepStrictEqual(computeEnabledDevices(['N'], []), ['N']);
    console.log('OK: computeEnabledDevices habilita por defecto lo no aislado');

    // Caso 7: aislados inválidos (storage vacío) -> todos habilitados
    assert.deepStrictEqual(computeEnabledDevices(['A'], undefined), ['A']);
    console.log('OK: computeEnabledDevices tolera aislados ausentes');

    // ── toggleIsolation: alterna sin mutar la lista original ──

    // Caso 8: aislar y volver a habilitar
    const original = ['A'];
    assert.deepStrictEqual(toggleIsolation(original, 'B'), ['A', 'B']);
    assert.deepStrictEqual(toggleIsolation(original, 'A'), []);
    assert.deepStrictEqual(original, ['A'], 'no debe mutar la lista recibida');
    console.log('OK: toggleIsolation alterna sin mutar');

    // ── withEnabledTargets: canal que solo expone los habilitados ──

    // Caso 9: listTargets filtrado; el resto de métodos se delega al canal real
    const sent = [];
    const realChannel = {
        async listTargets() { return ['A', 'B', 'C']; },
        async send(target, text) { sent.push({ target, text, self: this }); }
    };
    const filtered = withEnabledTargets(realChannel, ['C', 'A']);
    assert.deepStrictEqual(await filtered.listTargets(), ['A', 'C']);
    await filtered.send('A', 'hola');
    assert.strictEqual(sent.length, 1);
    assert.strictEqual(sent[0].target, 'A');
    console.log('OK: withEnabledTargets filtra listTargets y delega el resto');

    // ── Estado del puente (dashboard): desconocido / con / sin aislamiento ──

    // Caso 10: solo un hello con isolation:true es un puente con filtro; uno
    // anterior al handshake (sin campo) queda como NO soportado.
    assert.strictEqual(bridgeIsolationFromHello({ type: 'connected', isolation: true }), BridgeIsolation.SUPPORTED);
    assert.strictEqual(bridgeIsolationFromHello({ type: 'connected' }), BridgeIsolation.UNSUPPORTED);
    assert.strictEqual(bridgeIsolationFromHello({ type: 'connected', isolation: false }), BridgeIsolation.UNSUPPORTED);
    assert.strictEqual(bridgeIsolationFromHello(null), BridgeIsolation.UNSUPPORTED);
    assert.strictEqual(bridgeIsolationFromHello(undefined), BridgeIsolation.UNSUPPORTED);
    console.log('OK: bridgeIsolationFromHello distingue puente con filtro de puente viejo');

    // Caso 11: solo se arranca con aislamiento confirmado; desconocido
    // (puente apagado o sin hello todavía) también bloquea.
    assert.strictEqual(canStartAdbCampaign(BridgeIsolation.SUPPORTED), true);
    assert.strictEqual(canStartAdbCampaign(BridgeIsolation.UNSUPPORTED), false);
    assert.strictEqual(canStartAdbCampaign(BridgeIsolation.UNKNOWN), false);
    console.log('OK: canStartAdbCampaign exige aislamiento confirmado');

    // Caso 12: "desactualizado" solo cuando el puente respondió sin aislamiento.
    // Con el puente apagado/desconocido no se diagnostica un puente viejo.
    assert.strictEqual(bridgeIsolationWarning(BridgeIsolation.SUPPORTED), '');
    assert.strictEqual(bridgeIsolationWarning(BridgeIsolation.UNKNOWN), '');
    const warning = bridgeIsolationWarning(BridgeIsolation.UNSUPPORTED);
    assert.ok(/desactualizado/i.test(warning));
    assert.ok(/Reiniciar puente/.test(warning));
    // Si se actualizó descomprimiendo en otra carpeta, reiniciar relanza el
    // server.js viejo de la carpeta registrada: hay que reinstalar el host.
    assert.ok(warning.includes('native-launcher\\install.exe'), 'debe nombrar la ruta de install.exe');
    console.log('OK: bridgeIsolationWarning solo avisa ante puente sin aislamiento');

    console.log('Todos los tests de deviceSelection pasaron.');
})().catch(err => {
    console.error(err);
    process.exit(1);
});
