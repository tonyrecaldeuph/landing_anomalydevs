const assert = require('assert');
const {
    selectEnabledTargets,
    computeEnabledDevices,
    toggleIsolation,
    withEnabledTargets
} = require('./deviceSelection.js');

(async () => {
    // ── selectEnabledTargets (servidor): intersección conectados ∩ habilitados ──

    // Caso 1: solo se usan los conectados que el usuario habilitó
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B', 'C'], ['B']), ['B']);
    console.log('OK: selectEnabledTargets deja solo los habilitados');

    // Caso 2: un serial habilitado que ya no está conectado se ignora
    assert.deepStrictEqual(selectEnabledTargets(['A'], ['A', 'Z']), ['A']);
    console.log('OK: selectEnabledTargets ignora habilitados desconectados');

    // Caso 3: lista de habilitados vacía -> ninguno (nunca cae a "todos")
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B'], []), []);
    console.log('OK: selectEnabledTargets con habilitados vacío devuelve []');

    // Caso 4: dashboard antiguo que no envía la lista -> todos los conectados
    assert.deepStrictEqual(selectEnabledTargets(['A', 'B'], undefined), ['A', 'B']);
    console.log('OK: selectEnabledTargets sin lista conserva compatibilidad');

    // Caso 5: entrada de conectados inválida -> colección vacía, nunca null
    assert.deepStrictEqual(selectEnabledTargets(undefined, ['A']), []);
    console.log('OK: selectEnabledTargets nunca devuelve null');

    // ── computeEnabledDevices (UI): conectados − aislados ──

    // Caso 6: un teléfono nuevo (no aislado) aparece habilitado por defecto
    assert.deepStrictEqual(computeEnabledDevices(['A', 'B', 'C'], ['A', 'C']), ['B']);
    assert.deepStrictEqual(computeEnabledDevices(['N'], []), ['N']);
    console.log('OK: computeEnabledDevices habilita por defecto lo no aislado');

    // Caso 7: aislados inválidos (storage vacío) -> todos habilitados
    assert.deepStrictEqual(computeEnabledDevices(['A'], undefined), ['A']);
    console.log('OK: computeEnabledDevices tolera aislados ausentes');

    // ── toggleIsolation: alterna sin mutar la lista original ──

    // Caso 8: aislar y volver a habilitar
    const original = ['A'];
    assert.deepStrictEqual(toggleIsolation(original, 'B'), ['A', 'B']);
    assert.deepStrictEqual(toggleIsolation(original, 'A'), []);
    assert.deepStrictEqual(original, ['A'], 'no debe mutar la lista recibida');
    console.log('OK: toggleIsolation alterna sin mutar');

    // ── withEnabledTargets: canal que solo expone los habilitados ──

    // Caso 9: listTargets filtrado; el resto de métodos se delega al canal real
    const sent = [];
    const realChannel = {
        async listTargets() { return ['A', 'B', 'C']; },
        async send(target, text) { sent.push({ target, text, self: this }); }
    };
    const filtered = withEnabledTargets(realChannel, ['C', 'A']);
    assert.deepStrictEqual(await filtered.listTargets(), ['A', 'C']);
    await filtered.send('A', 'hola');
    assert.strictEqual(sent.length, 1);
    assert.strictEqual(sent[0].target, 'A');
    console.log('OK: withEnabledTargets filtra listTargets y delega el resto');

    console.log('Todos los tests de deviceSelection pasaron.');
})().catch(err => {
    console.error(err);
    process.exit(1);
});
