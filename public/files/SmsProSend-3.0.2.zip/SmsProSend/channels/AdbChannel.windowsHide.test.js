const assert = require('assert');
const cp = require('child_process');

// Se monkey-patchea child_process.execFile ANTES de requerir AdbChannel.js:
// AdbChannel.js hace `const { execFile } = require('child_process')` y
// `promisify(execFile)` al cargar el módulo, así que la sustitución debe
// existir antes de ese primer require para que quede capturada.
const calls = [];
cp.execFile = (file, args, optionsOrCallback, maybeCallback) => {
    const hasOptions = typeof optionsOrCallback !== 'function';
    const options = hasOptions ? optionsOrCallback : undefined;
    const callback = hasOptions ? maybeCallback : optionsOrCallback;
    calls.push({ file, args, options });
    callback(null, { stdout: '', stderr: '' });
};

const { AdbChannel } = require('./AdbChannel.js');

(async () => {
    // Caso: el execFn por defecto (sin inyectar) debe pasar windowsHide:true
    // a execFile — si no, cada llamada a adb abre una ventana cmd visible
    // porque el server corre sin consola propia (lanzado por el Native
    // Messaging Host) y adb.exe es una app de consola.
    const ch = new AdbChannel({ adbPath: 'adb' });
    await ch.listTargets();

    assert.strictEqual(calls.length, 1, 'debe haber invocado execFile una vez');
    assert.ok(calls[0].options && calls[0].options.windowsHide === true,
        'execFile debe recibir windowsHide:true para no abrir ventanas cmd visibles');

    console.log('OK: el execFn por defecto de AdbChannel oculta la ventana de adb (windowsHide)');
})();
