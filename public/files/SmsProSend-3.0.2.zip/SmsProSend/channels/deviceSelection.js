/**
 * deviceSelection — aislamiento de teléfonos ADB.
 *
 * El usuario puede tener varios teléfonos conectados con depuración activa y
 * reservar algunos para llamadas: solo los habilitados participan del envío.
 *
 * El dashboard persiste los seriales AISLADOS (no los habilitados) para que un
 * teléfono nunca visto aparezca habilitado por defecto. El servidor recibe la
 * lista de HABILITADOS y nunca usa un serial fuera de ella: sin lista no se
 * usa ninguno (fail-closed), jamás "todos los conectados".
 *
 * Funciones puras, sin chrome.* ni adb — compartidas por dashboard y servidor.
 */

/**
 * Servidor: seriales conectados que además están habilitados.
 */
function selectEnabledTargets(connected, enabled) {
    const connectedList = Array.isArray(connected) ? connected : [];
    const enabledSet = new Set(Array.isArray(enabled) ? enabled : []);
    return connectedList.filter(serial => enabledSet.has(serial));
}

/**
 * Dashboard: seriales conectados que el usuario no aisló.
 */
function computeEnabledDevices(connected, isolated) {
    const connectedList = Array.isArray(connected) ? connected : [];
    const isolatedSet = new Set(Array.isArray(isolated) ? isolated : []);
    return connectedList.filter(serial => !isolatedSet.has(serial));
}

/**
 * Alterna un serial entre aislado y habilitado, devolviendo una lista nueva.
 */
function toggleIsolation(isolated, serial) {
    const isolatedList = Array.isArray(isolated) ? isolated : [];
    return isolatedList.includes(serial)
        ? isolatedList.filter(s => s !== serial)
        : isolatedList.concat(serial);
}

/**
 * Canal que expone solo los targets habilitados. El resto de métodos se
 * hereda por prototipo del canal real, así campaignEngine no cambia.
 */
function withEnabledTargets(channel, enabled) {
    const filtered = Object.create(channel);
    filtered.listTargets = async () => selectEnabledTargets(await channel.listTargets(), enabled);
    return filtered;
}

/**
 * Estado del puente según su mensaje `connected`. UNKNOWN mientras no hay
 * conexión o hello: no es lo mismo un puente apagado que uno viejo.
 */
const BridgeIsolation = Object.freeze({
    UNKNOWN: 'unknown',
    SUPPORTED: 'supported',
    UNSUPPORTED: 'unsupported'
});

/**
 * Un puente anterior al handshake no trae `isolation:true`: arrancar contra
 * él enviaría por todos los teléfonos.
 */
function bridgeIsolationFromHello(hello) {
    return !!hello && hello.isolation === true ? BridgeIsolation.SUPPORTED : BridgeIsolation.UNSUPPORTED;
}

function canStartAdbCampaign(state) {
    return state === BridgeIsolation.SUPPORTED;
}

/**
 * Aviso solo ante un puente que respondió sin aislamiento. Reiniciar relanza el
 * server.js de la carpeta registrada en el host: si el usuario descomprimió la
 * versión nueva en OTRA carpeta, hay que ejecutar install.exe desde ella.
 */
function bridgeIsolationWarning(state) {
    if (state !== BridgeIsolation.UNSUPPORTED) return '';
    return 'Puente ADB desactualizado (no respeta el aislamiento y enviaría por TODOS los teléfonos). ' +
        'Pulsa "Reiniciar puente"; si el aviso persiste, ejecuta native-launcher\\install.exe desde la carpeta de la versión nueva.';
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        selectEnabledTargets, computeEnabledDevices, toggleIsolation, withEnabledTargets,
        BridgeIsolation, bridgeIsolationFromHello, canStartAdbCampaign, bridgeIsolationWarning
    };
}
