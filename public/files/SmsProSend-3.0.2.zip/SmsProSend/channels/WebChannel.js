/**
 * WebChannel — adaptador del canal web existente a la interfaz Channel.
 * No reescribe la lógica interna de content.js/chrome.debugger; solo expone la superficie
 * unificada que consume campaignEngine.js (Ley de Demeter).
 *
 * Interfaz Channel:
 *   listTargets() -> ['web']
 *   openConversation(target, phone) -> Promise<void>
 *   send(target, text) -> Promise<void>
 *   verifySent(target) -> Promise<boolean>
 *   detectProtocol(target) -> Promise<'sms'|'rcs'>
 *   isBlocked(target) -> Promise<boolean> (siempre false en web; el bloqueo se detecta por CARRIER_FAILED)
 */

class WebChannel {
    /**
     * @param {number} tabId - ID de la pestaña Google Messages
     * @param {Object} [deps] - inyección para tests { chrome, sendToContent }
     */
    constructor(tabId, deps = {}) {
        this.tabId = tabId;
        this.chrome = deps.chrome || (typeof chrome !== 'undefined' ? chrome : null);
        this.sendToContent = deps.sendToContent || null;
    }

    async listTargets() {
        return ['web'];
    }

    async openConversation(target, phone) {
        // Delega a content.js vía runtime message que internamente hace startNewConversation
        // Se usa el mismo payload que background.js:processSingleContact hace hoy
        if (this.sendToContent) {
            return this.sendToContent(this.tabId, { action: 'AUTOMATE_SEND_OPEN', phone });
        }
        // En producción, el engine llamará a send() que internamente abre conversación + envía.
        // Para compatibilidad, openConversation es no-op si el flujo ya hace open+send atomico.
        // Mantenemos la llamada para respetar la interfaz, pero no falla si no hay handler.
        return;
    }

    async send(target, text) {
        if (this.sendToContent) {
            const res = await this.sendToContent(this.tabId, { action: 'AUTOMATE_SEND', phone: target, message: text });
            if (res && res.ok === false) throw new Error(res.error || 'Send failed');
            return;
        }
        if (!this.chrome || !this.chrome.tabs) throw new Error('WebChannel: chrome.tabs no disponible');
        // Fallback real: envía mensaje al content script (content.js espera AUTOMATE_SEND con phone+message)
        // Este path se usa cuando campaignEngine corre dentro de background.js
        return new Promise((resolve, reject) => {
            this.chrome.tabs.sendMessage(this.tabId, { action: 'AUTOMATE_SEND', phone: target, message: text }, (response) => {
                if (this.chrome.runtime && this.chrome.runtime.lastError) {
                    reject(new Error(this.chrome.runtime.lastError.message));
                    return;
                }
                if (response && response.status === 'SUCCESS') resolve();
                else reject(new Error(response ? response.message : 'Sin respuesta del content'));
            });
        });
    }

    async verifySent(target) {
        // La verificación real vive en content.js:waitForSendConfirmation.
        // WebChannel delega implícitamente: si send() no lanzó CARRIER_FAILED, se asume verificado.
        return true;
    }

    async detectProtocol(target) {
        // En web, la detección se hace en content.js:detectMessageProtocol y se retorna en send()
        // Como canal puro, retornamos 'sms' por defecto; el caller puede leer isRCS de send() si lo necesita.
        return 'sms';
    }

    async isBlocked(target) {
        // WebChannel no mantiene estado de bloqueo; campaignEngine lo infiere por CARRIER_FAILED
        return false;
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { WebChannel };
}
