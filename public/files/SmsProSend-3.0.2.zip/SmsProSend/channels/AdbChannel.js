/**
 * AdbChannel — traduce la interfaz Channel a comandos adb + uiautomator dump.
 * Vive en adb-bridge-server y en la extensión (via WebChannel parity).
 *
 * No depende de chrome.* — testeable con fixtures XML.
 *
 * Navegación 100% dinámica: cada tap se calcula del centro de los `bounds`
 * reales devueltos por uiautomator dump, nunca de coordenadas fijas. Cada
 * pantalla se confirma por evidencia (resource-id esperado presente) antes
 * de actuar sobre ella — evidencia real capturada en dispositivo (Honor,
 * Google Messages es-EC): lista → nueva conversación → resultado → compositor.
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const nodeFs = require('fs');
const os = require('os');
const path = require('path');
const execFileAsync = promisify(execFile);

const MESSAGING_PACKAGE = 'com.google.android.apps.messaging';

const RESOURCE_IDS = {
    fab: 'com.google.android.apps.messaging:id/start_chat_fab',
    searchField: 'ContactSearchField',
    composeText: 'com.google.android.apps.messaging:id/compose_message_text',
    sendButton: 'Compose:Draft:Send'
};

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

class AdbChannel {
    /**
     * @param {Object} [opts]
     * @param {string} [opts.adbPath='adb'] - ruta al binario adb
     * @param {Function} [opts.execFn] - función inyectable (args) => Promise<{stdout,stderr}>
     * @param {number} [opts.launchWaitMs=1500] - espera tras relanzar Messages en frío
     * @param {number} [opts.stepWaitMs=900] - espera tras cada tap antes de volver a hacer dump
     */
    constructor(opts = {}) {
        this.adbPath = opts.adbPath || 'adb';
        // windowsHide:true evita que cada llamada a adb abra su propia ventana
        // cmd — el server corre sin consola propia (lanzado por el Native
        // Messaging Host) y adb.exe es una app de consola.
        this.execFn = opts.execFn || ((args) => execFileAsync(this.adbPath, args, { windowsHide: true }));
        this.launchWaitMs = opts.launchWaitMs !== undefined ? opts.launchWaitMs : 1500;
        this.stepWaitMs = opts.stepWaitMs !== undefined ? opts.stepWaitMs : 900;
        this.pollAttempts = opts.pollAttempts !== undefined ? opts.pollAttempts : 6;
        this.dumpAttempts = opts.dumpAttempts !== undefined ? opts.dumpAttempts : 5;
        this.dumpRetryDelayMs = opts.dumpRetryDelayMs !== undefined ? opts.dumpRetryDelayMs : 600;
        this.fs = opts.fs || nodeFs;
        this.tmpDir = opts.tmpDir || os.tmpdir();
    }

    // ── API Channel ────────────────────────────────────────────────

    async listTargets() {
        const { stdout } = await this.execFn(['devices']);
        return AdbChannel.parseDevices(stdout);
    }

    async openConversation(target, phone) {
        const listDump = await this.resetToConversationList(target);

        const fab = AdbChannel.findNodeBounds(listDump, RESOURCE_IDS.fab);
        if (!fab) {
            throw new Error('MESSAGES_NOT_FOREGROUND: no se encontró el botón de nueva conversación en la lista, se aborta');
        }
        await this.tap(target, fab);
        await sleep(this.stepWaitMs);

        const { result: field } = await this.pollDump(target, d => AdbChannel.findNodeBounds(d, RESOURCE_IDS.searchField));
        if (!field) {
            throw new Error('MESSAGES_SEARCH_FIELD_NOT_FOUND: no llegó a la pantalla de nueva conversación, se aborta');
        }
        await this.tap(target, field);
        const safePhone = AdbChannel.sanitizeTypedText(phone).replace(/\s/g, '%s');
        await this.execFn(['-s', target, 'shell', 'input', 'text', safePhone]);

        // El resultado de búsqueda puede tardar en aparecer (lookup de contactos/carrier
        // asíncrono) — sondear varias veces en vez de un único dump evita un falso
        // MESSAGES_NO_SEARCH_RESULT en equipos donde ese lookup es más lento.
        const { result: resultRow } = await this.pollDump(target, d => AdbChannel.findFirstClickableBelow(d, field.y2));
        if (!resultRow) {
            throw new Error('MESSAGES_NO_SEARCH_RESULT: no apareció resultado para el número buscado, se aborta');
        }
        await this.tap(target, resultRow);

        // Según la versión de Google Messages, tocar el resultado lleva directo al
        // compositor (visto en Honor) O a una pantalla intermedia de "confirmar
        // destinatario" con botón "Siguiente" sin resource-id (visto en un Xiaomi/MIUI
        // con versión más nueva de la app) — se detectan ambas por evidencia, no se
        // asume una.
        const { dump: firstDump, result: afterResult } = await this.pollDump(target, d => {
            const compose = AdbChannel.findNodeBounds(d, RESOURCE_IDS.composeText);
            if (compose) return { compose };
            const next = AdbChannel.findNodeByText(d, 'Siguiente');
            if (next) return { next };
            return null;
        });
        if (!afterResult) {
            throw new Error('MESSAGES_COMPOSE_NOT_FOUND: no se llegó al compositor de la conversación, se aborta');
        }

        let composeField = afterResult.compose;
        let composeDump = firstDump;
        if (!composeField) {
            await this.tap(target, afterResult.next);
            const polled = await this.pollDump(target, d => AdbChannel.findNodeBounds(d, RESOURCE_IDS.composeText));
            composeField = polled.result;
            composeDump = polled.dump;
            if (!composeField) {
                throw new Error('MESSAGES_COMPOSE_NOT_FOUND: no se llegó al compositor tras confirmar destinatario, se aborta');
            }
        }
        AdbChannel.assertHeaderForPhone(composeDump, phone);
    }

    /**
     * Vuelve a hacer dump hasta `pollAttempts` veces (esperando `stepWaitMs` entre
     * intentos) hasta que `extract(dump)` devuelva un resultado no nulo. Evita fallar
     * ante pantallas que tardan en renderizar (lookup de contactos, equipos más lentos).
     */
    async pollDump(target, extract) {
        let dump = '';
        let result = null;
        for (let attempt = 0; attempt < this.pollAttempts; attempt++) {
            if (attempt > 0) await sleep(this.stepWaitMs);
            try {
                dump = await this.dump(target);
            } catch (err) {
                // dump() ya agotó sus propios reintentos internos (ej. bug intermitente
                // de uiautomator en MIUI) — se cuenta como un intento fallido más del
                // sondeo, no se aborta todo el pollDump por un solo fallo transitorio.
                continue;
            }
            result = extract(dump);
            if (result) break;
        }
        return { dump, result };
    }

    async send(target, text) {
        // Re-dump: una notificación/diálogo pudo robar el foco entre openConversation()
        // y send(); escribir/tapear a ciegas sin confirmar el compositor repite el fallo.
        const dump = await this.dump(target);
        const composeField = AdbChannel.findNodeBounds(dump, RESOURCE_IDS.composeText);
        if (!composeField) {
            throw new Error('MESSAGES_NOT_FOREGROUND: se perdió el compositor de Google Messages antes de enviar, se aborta');
        }
        await this.tap(target, composeField);
        const safeText = AdbChannel.sanitizeTypedText(text).replace(/\s/g, '%s');
        await this.execFn(['-s', target, 'shell', 'input', 'text', safeText]);
        await sleep(this.stepWaitMs);

        // Re-localizar el botón de enviar DESPUÉS de escribir: un mensaje largo
        // puede hacer crecer el compositor a 2+ líneas y desplazar el botón —
        // usar los bounds capturados antes de escribir apunta a una posición vieja.
        const dumpAfterType = await this.dump(target);
        const sendButton = AdbChannel.findNodeBounds(dumpAfterType, RESOURCE_IDS.sendButton);
        if (!sendButton) {
            throw new Error('MESSAGES_NOT_FOREGROUND: no se encontró el botón de enviar tras escribir el mensaje, se aborta');
        }
        // Enter (keyevent 66) inserta salto de línea en el compositor, NO envía.
        // El envío real es el botón Compose:Draft:Send localizado por bounds.
        await this.tap(target, sendButton);
    }

    /**
     * Reinicia Google Messages en frío (force-stop + relanzar) y confirma que
     * quedó en la lista de conversaciones (presencia de start_chat_fab) antes
     * de devolver el control. Navegar con Back en vez de esto es tan frágil
     * como un tap ciego: puede salir de la app hacia el launcher (home) y
     * terminar tocando otro ícono (Calendario, Música).
     */
    /**
     * Empuja la imagen de campaña al dispositivo y dispara un escaneo de medios
     * para que quede visible en la galería. Devuelve la ruta remota.
     *
     * LIMITACIÓN CONOCIDA: esto deja la imagen en el teléfono pero NO la
     * adjunta al mensaje — falta automatizar el selector de galería de Google
     * Messages (tocar el ícono de adjuntar, navegar el picker, elegir la
     * miniatura correcta). Esa parte requiere evidencia de dispositivo real
     * (dump de uiautomator del picker) que no se capturó todavía; implementarla
     * a ciegas repetiría exactamente los bugs de coordenadas fijas que costó
     * tanto corregir en openConversation/send. Ver native-launcher/README.md
     * y la memoria del proyecto para el resto del pendiente.
     */
    async attachImage(target, dataUrl) {
        const match = /^data:image\/(\w+);base64,([\s\S]+)$/.exec(dataUrl || '');
        if (!match) {
            throw new Error('IMAGE_DATA_INVALID: formato de imagen no reconocido, se aborta el adjunto');
        }
        const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
        const buffer = Buffer.from(match[2], 'base64');
        const localPath = path.join(this.tmpDir, `sms-pro-adjunto-${target}-${Date.now()}.${ext}`);
        this.fs.writeFileSync(localPath, buffer);
        try {
            const remotePath = `/sdcard/Pictures/sms_pro_adjunto.${ext}`;
            await this.execFn(['-s', target, 'push', localPath, remotePath]);
            await this.execFn(['-s', target, 'shell', 'am', 'broadcast', '-a', 'android.intent.action.MEDIA_SCANNER_SCAN_FILE', '-d', `file://${remotePath}`]);
            return remotePath;
        } finally {
            try { this.fs.unlinkSync(localPath); } catch (_) { /* best-effort */ }
        }
    }

    async resetToConversationList(target) {
        await this.execFn(['-s', target, 'shell', 'am', 'force-stop', MESSAGING_PACKAGE]);
        await this.execFn(['-s', target, 'shell', 'input', 'keyevent', '224']); // wake
        await this.execFn(['-s', target, 'shell', 'wm', 'dismiss-keyguard']);
        await this.execFn(['-s', target, 'shell', 'monkey', '-p', MESSAGING_PACKAGE, '-c', 'android.intent.category.LAUNCHER', '1']);
        await sleep(this.launchWaitMs);

        const dump = await this.dump(target);
        if (!AdbChannel.findNodeBounds(dump, RESOURCE_IDS.fab)) {
            throw new Error('MESSAGES_NOT_FOREGROUND: no se pudo confirmar la lista de conversaciones de Google Messages, se aborta para evitar acciones en otra app');
        }
        return dump;
    }

    async tap(target, bounds) {
        await this.execFn(['-s', target, 'shell', 'input', 'tap', String(bounds.cx), String(bounds.cy)]);
    }

    async verifySent(target) {
        const dump = await this.dump(target);
        return AdbChannel.parseVerifySent(dump);
    }

    async detectProtocol(target) {
        const dump = await this.dump(target);
        return AdbChannel.parseDetectProtocol(dump);
    }

    async isBlocked(target) {
        const dump = await this.dump(target);
        return AdbChannel.parseIsBlocked(dump);
    }

    // ── Helpers internos ───────────────────────────────────────────

    async dump(target) {
        // uiautomator dump -> /sdcard/window_dump.xml -> cat
        // En algunos ROM (confirmado en MIUI) `uiautomator dump` falla de forma
        // intermitente por un bug interno de carga de tema (ThemeCompatibility),
        // sin relación con la app ni con esta automatización — reintentar absorbe
        // esa inestabilidad puntual del comando en el propio dispositivo.
        let lastErr;
        for (let attempt = 0; attempt < this.dumpAttempts; attempt++) {
            try {
                await this.execFn(['-s', target, 'shell', 'uiautomator', 'dump', '/sdcard/window_dump.xml']);
                const { stdout } = await this.execFn(['-s', target, 'shell', 'cat', '/sdcard/window_dump.xml']);
                return stdout;
            } catch (err) {
                lastErr = err;
                if (attempt < this.dumpAttempts - 1) await sleep(this.dumpRetryDelayMs);
            }
        }
        throw lastErr;
    }

    // ── Parsers puros (testeables sin adb) ─────────────────────────

    /**
     * Ubica un nodo por resource-id y devuelve sus bounds + centro calculado.
     * El centro se calcula siempre de los bounds reales del dump — nunca de
     * una coordenada fija — para no depender de resolución/densidad del equipo.
     */
    static findNodeBounds(xml, resourceId) {
        if (!xml || !resourceId) return null;
        const escaped = resourceId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const patterns = [
            new RegExp('resource-id="' + escaped + '"[^>]*bounds="\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]"'),
            new RegExp('bounds="\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]"[^>]*resource-id="' + escaped + '"')
        ];
        for (const re of patterns) {
            const m = xml.match(re);
            if (m) return AdbChannel.boundsFromMatch(m);
        }
        return null;
    }

    /**
     * Primer nodo clickable="true" cuyo borde superior está por debajo de `aboveY`,
     * en orden de documento (top-to-bottom visual). Se usa para localizar el
     * resultado de búsqueda de un número sin resource-id estable (UI Compose),
     * evitando así depender del texto localizado ("Enviar al ...").
     */
    static findFirstClickableBelow(xml, aboveY) {
        if (!xml) return null;
        const re = /<node[^>]*clickable="true"[^>]*bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/g;
        let m;
        while ((m = re.exec(xml))) {
            const bounds = AdbChannel.boundsFromMatch(m);
            if (bounds.y1 > aboveY) return bounds;
        }
        return null;
    }

    /**
     * Ubica un nodo por su texto exacto y devuelve sus bounds. Solo se usa cuando no
     * hay resource-id disponible (botones sueltos en UI Compose, ej. "Siguiente") —
     * asume idioma es-EC/es como el resto del producto.
     */
    static findNodeByText(xml, text) {
        if (!xml || !text) return null;
        const escaped = text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const re = new RegExp('text="' + escaped + '"[^>]*bounds="\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]"');
        const m = xml.match(re);
        return m ? AdbChannel.boundsFromMatch(m) : null;
    }

    static boundsFromMatch(m) {
        const [, x1, y1, x2, y2] = m.map(Number);
        return { x1, y1, x2, y2, cx: Math.round((x1 + x2) / 2), cy: Math.round((y1 + y2) / 2) };
    }

    /**
     * Limpia texto antes de pasarlo a `adb shell input text`. Dos problemas distintos:
     *
     * 1. `adb shell` une los argumentos y los ejecuta vía `sh -c` en el dispositivo:
     *    sin filtrar, un mensaje con `;`, `&`, `|`, `$()` o backticks puede ejecutar
     *    comandos adicionales no previstos en el teléfono.
     * 2. `InputShellCommand` (el `input text` nativo de Android) lanza
     *    `NullPointerException` ante CUALQUIER carácter no-ASCII — tildes, `ñ`, `¿`,
     *    `¡` — abortando el comando por completo. Se transcriben a su equivalente
     *    ASCII (á→a, ñ→n, ¿/¡ se eliminan) en vez de escaparlos: el mensaje sigue
     *    siendo legible en español, y cualquier no-ASCII que sobreviva a la
     *    transcripción (emojis, etc.) se elimina como red de seguridad.
     */
    static sanitizeTypedText(value) {
        if (value === null || value === undefined) return '';
        const combiningDiacriticals = new RegExp('[̀-ͯ]', 'g');
        const withoutDiacritics = String(value).normalize('NFD').replace(combiningDiacriticals, '');
        const asciiOnly = withoutDiacritics.replace(/[^\x00-\x7F]/g, '');
        return asciiOnly.replace(/['";&|$`<>(){}\\\n\r]/g, '');
    }

    static parseDevices(output) {
        if (!output) return [];
        const lines = output.split('\n').slice(1); // saltar "List of devices attached"
        const devices = [];
        for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) continue;
            const parts = trimmed.split(/\s+/);
            if (parts.length >= 2 && parts[1] === 'device') {
                devices.push(parts[0]);
            }
        }
        return devices;
    }

    static parseVerifySent(xml) {
        if (!xml) return true;
        const lower = xml.toLowerCase();
        // Indicadores de fallo: resource-id específico o texto "no se envió"
        const hasFailedIndicator = lower.includes('message_failed_indicator') ||
            lower.includes('no se envi') || // cubre "no se envió" con tilde normalizada
            lower.includes('not sent') ||
            lower.includes('send failed');
        // Prioridad: si hay failed, es false aunque haya otros indicadores de éxito
        if (hasFailedIndicator) return false;
        // Si no hay failed y hay indicador de éxito, es true
        // Incluso si no hay indicador explícito, tratamos como éxito probable (true)
        return true;
    }

    static parseIsBlocked(xml) {
        return !AdbChannel.parseVerifySent(xml);
    }

    static parseDetectProtocol(xml) {
        if (!xml) return 'sms';
        const lower = xml.toLowerCase();
        // Busca chip RCS / Chat en el compose bar
        if (lower.includes('resource-id="com.google.android.apps.messaging:id/compose_message_type"')) {
            if (lower.includes('>chat<') || lower.includes('>rcs<') || lower.includes('rich')) return 'rcs';
            // Extraer texto del nodo específico
            const match = xml.match(/compose_message_type[^>]*text="([^"]*)"/i) ||
                          xml.match(/compose_message_type[^>]*>([^<]*)/i);
            if (match) {
                const txt = match[1].toLowerCase();
                if (txt.includes('chat') || txt.includes('rcs') || txt.includes('rich')) return 'rcs';
            }
        }
        if (lower.includes('chat') && lower.includes('compose')) return 'rcs';
        return 'sms';
    }

    static assertHeaderForPhone(xml, phone) {
        const digits = String(phone).replace(/\D/g, '').slice(-7);
        if (digits.length < 7) return;
        const textContent = xml.replace(/<[^>]*>/g, ' ');
        const headerDigits = textContent.replace(/\D/g, '');
        if (headerDigits.length >= 7 && !headerDigits.includes(digits)) {
            throw new Error(`Conversación incorrecta abierta. Esperaba ...${digits}, header no coincide`);
        }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AdbChannel };
}
