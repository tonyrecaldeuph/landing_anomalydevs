const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { AdbChannel } = require('./AdbChannel.js');

function fixture(name) {
    return fs.readFileSync(path.join(__dirname, 'fixtures', name), 'utf-8');
}

// Fixtures capturados de un dispositivo real (Honor, Google Messages es-EC):
// lista de conversaciones -> nueva conversación -> resultado de búsqueda -> compositor.
const dumpList = fixture('dump_conversation_list.xml');
const dumpNewConversation = fixture('dump_new_conversation.xml');
const dumpSearchResult = fixture('dump_search_result.xml');
const dumpCompose = fixture('dump_compose.xml');
const dumpComposeAfterType = fixture('dump_compose_after_type.xml');
const dumpConfirmRecipient = fixture('dump_confirm_recipient.xml');

const xmlFailed = `
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout">
    <node index="1" text="No se envió" resource-id="com.google.android.apps.messaging:id/message_failed_indicator" class="android.widget.TextView" />
    <node index="2" text="Hola Juan" resource-id="com.google.android.apps.messaging:id/message_text" class="android.widget.TextView" />
  </node>
</hierarchy>`;

const xmlOk = `
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout">
    <node index="1" text="Enviado" resource-id="com.google.android.apps.messaging:id/message_status" class="android.widget.TextView" />
    <node index="2" text="Hola Juan" resource-id="com.google.android.apps.messaging:id/message_text" class="android.widget.TextView" />
  </node>
</hierarchy>`;

const xmlRcs = `
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout">
    <node index="1" text="Chat" resource-id="com.google.android.apps.messaging:id/compose_message_type" class="android.widget.TextView" />
  </node>
</hierarchy>`;

const xmlSms = `
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout">
    <node index="1" text="SMS" resource-id="com.google.android.apps.messaging:id/compose_message_type" class="android.widget.TextView" />
  </node>
</hierarchy>`;

// Caso 1: parseVerifySent detecta fallo y éxito
assert.strictEqual(AdbChannel.parseVerifySent(xmlFailed), false, 'failed debe ser false');
console.log('OK: parseVerifySent detecta fallo');
assert.strictEqual(AdbChannel.parseVerifySent(xmlOk), true, 'ok debe ser true');
console.log('OK: parseVerifySent detecta éxito');

// Caso 2: parseIsBlocked
assert.strictEqual(AdbChannel.parseIsBlocked(xmlFailed), true, 'failed es blocked');
assert.strictEqual(AdbChannel.parseIsBlocked(xmlOk), false, 'ok no es blocked');
console.log('OK: parseIsBlocked');

// Caso 3: parseDevices filtra device vs unauthorized/offline
const adbOut = `List of devices attached
emulator-5554\tdevice
9889aa\tunauthorized
192.168.1.10:5555\toffline
device123\tdevice
`;
assert.deepStrictEqual(AdbChannel.parseDevices(adbOut), ['emulator-5554', 'device123']);
console.log('OK: parseDevices filtra correctamente');

// Caso 4: parseDevices vacío
assert.deepStrictEqual(AdbChannel.parseDevices('List of devices attached\n\n'), []);
console.log('OK: parseDevices vacío');

// Caso 5: detectProtocol
assert.strictEqual(AdbChannel.parseDetectProtocol(xmlRcs), 'rcs');
assert.strictEqual(AdbChannel.parseDetectProtocol(xmlSms), 'sms');
console.log('OK: parseDetectProtocol');

// Caso 6: verify no se confunde con historial (fixture con failed antiguo pero nuevo ok)
const xmlMixed = `
<hierarchy>
  <node text="No se envió" resource-id="com.google.android.apps.messaging:id/message_failed_indicator" />
  <node text="Enviado" resource-id="com.google.android.apps.messaging:id/message_status" />
</hierarchy>`;
assert.strictEqual(AdbChannel.parseVerifySent(xmlMixed), false, 'si hay failed, aunque haya enviado, es false (prioridad fallo)');
console.log('OK: parseVerifySent prioriza fallo');

// Caso 7: sanitizeTypedText elimina metacaracteres de shell (adb shell -> sh -c en el dispositivo)
assert.strictEqual(AdbChannel.sanitizeTypedText(`hola; am start -n com.android.calendar/.a`), 'hola am start -n com.android.calendar/.a');
assert.strictEqual(AdbChannel.sanitizeTypedText("cliente's & data"), 'clientes  data');
assert.strictEqual(AdbChannel.sanitizeTypedText(null), '');
console.log('OK: sanitizeTypedText');

// Caso 7b: sanitizeTypedText transcribe a ASCII — `adb shell input text` (InputShellCommand
// de Android) lanza NullPointerException ante cualquier carácter no-ASCII (tildes, ñ, ¿, ¡)
assert.strictEqual(AdbChannel.sanitizeTypedText('Cédula: 1311534752'), 'Cedula: 1311534752');
assert.strictEqual(AdbChannel.sanitizeTypedText('Señor Muñoz, ¿vence pronto?'), 'Senor Munoz, vence pronto?');
assert.strictEqual(AdbChannel.sanitizeTypedText('Á É Í Ó Ú ü ¡Atención!'), 'A E I O U u Atencion!');
console.log('OK: sanitizeTypedText transcribe tildes/ñ/¿/¡ a ASCII');

// Caso 8: findNodeBounds ubica un nodo real por resource-id y calcula su centro
const fab = AdbChannel.findNodeBounds(dumpList, 'com.google.android.apps.messaging:id/start_chat_fab');
assert.deepStrictEqual(fab, { x1: 637, y1: 2264, x2: 1122, y2: 2446, cx: 880, cy: 2355 });
const field = AdbChannel.findNodeBounds(dumpNewConversation, 'ContactSearchField');
assert.deepStrictEqual(field, { x1: 268, y1: 338, x2: 1109, y2: 494, cx: 689, cy: 416 });
assert.strictEqual(AdbChannel.findNodeBounds(dumpList, 'no-existe'), null);
assert.strictEqual(AdbChannel.findNodeBounds('', 'x'), null);
console.log('OK: findNodeBounds');

// Caso 9: findFirstClickableBelow ubica el resultado de búsqueda (sin resource-id estable, UI Compose)
const result = AdbChannel.findFirstClickableBelow(dumpSearchResult, 494);
assert.deepStrictEqual(result, { x1: 0, y1: 679, x2: 1200, y2: 913, cx: 600, cy: 796 });
assert.strictEqual(AdbChannel.findFirstClickableBelow(dumpList, 99999), null, 'sin candidatos por debajo, null');
console.log('OK: findFirstClickableBelow');

// Caso 9b: findNodeByText ubica un botón sin resource-id por su texto exacto (UI Compose)
const siguienteBtn = AdbChannel.findNodeByText(dumpConfirmRecipient, 'Siguiente');
assert.deepStrictEqual(siguienteBtn, { x1: 700, y1: 1400, x2: 1010, y2: 1480, cx: 855, cy: 1440 });
assert.strictEqual(AdbChannel.findNodeByText(dumpCompose, 'Siguiente'), null);
console.log('OK: findNodeByText');

// Caso 10: resetToConversationList confirma la lista (fab presente) tras force-stop + relanzar
(async () => {
    const calls = [];
    const ch = new AdbChannel({
        launchWaitMs: 0,
        stepWaitMs: 0,
        execFn: async (args) => {
            calls.push(args.join(' '));
            if (args.includes('cat')) return { stdout: dumpList };
            return { stdout: '' };
        }
    });
    await ch.resetToConversationList('device1');
    assert.ok(calls.some(c => c.startsWith('-s device1 shell am force-stop com.google.android.apps.messaging')), 'debe reiniciar Messages en frío (force-stop)');
    assert.ok(calls.some(c => c.includes('monkey') && c.includes(('com.google.android.apps.messaging'))), 'debe relanzar vía monkey');
    console.log('OK: resetToConversationList reinicia en frío y confirma la lista');

    // Caso 11: si tras relanzar la lista no muestra el FAB (ej. quedó en el launcher/home), aborta sin tapear
    const chHome = new AdbChannel({
        launchWaitMs: 0,
        stepWaitMs: 0,
        execFn: async (args) => {
            if (args.includes('cat')) return { stdout: '<hierarchy><node package="com.hihonor.android.launcher" /></hierarchy>' };
            return { stdout: '' };
        }
    });
    await assert.rejects(() => chHome.resetToConversationList('device1'), /MESSAGES_NOT_FOREGROUND/);
    console.log('OK: resetToConversationList aborta si no confirma la lista (evita tocar el launcher)');

    // Caso 12: openConversation recorre lista -> nueva conversación -> resultado -> compositor,
    // tapeando siempre en el centro de bounds reales (nunca una coordenada fija)
    const tapCoords = [];
    let dumpCallCount = 0;
    const dumpSequence = [dumpList, dumpNewConversation, dumpSearchResult, dumpCompose];
    const chFlow = new AdbChannel({
        launchWaitMs: 0,
        stepWaitMs: 0,
        execFn: async (args) => {
            if (args.includes('tap')) {
                const i = args.indexOf('tap');
                tapCoords.push([Number(args[i + 1]), Number(args[i + 2])]);
            }
            if (args.includes('cat')) {
                const xml = dumpSequence[Math.min(dumpCallCount, dumpSequence.length - 1)];
                dumpCallCount++;
                return { stdout: xml };
            }
            return { stdout: '' };
        }
    });
    await chFlow.openConversation('device1', '0980964513');
    assert.deepStrictEqual(tapCoords, [[880, 2355], [689, 416], [600, 796]], 'debe tapear FAB, campo de búsqueda y resultado, en ese orden y en sus centros reales');
    console.log('OK: openConversation navega con bounds reales, sin coordenadas fijas');

    // Caso 12b: openConversation soporta la pantalla intermedia "confirmar destinatario"
    // (con botón "Siguiente" sin resource-id, vista en un Xiaomi/MIUI con Google Messages
    // más nuevo) cuando tocar el resultado NO lleva directo al compositor como en Honor.
    const tapCoords2 = [];
    let dumpCallCount2 = 0;
    const dumpSequence2 = [dumpList, dumpNewConversation, dumpSearchResult, dumpConfirmRecipient, dumpCompose];
    const chFlowConfirm = new AdbChannel({
        launchWaitMs: 0,
        stepWaitMs: 0,
        execFn: async (args) => {
            if (args.includes('tap')) {
                const i = args.indexOf('tap');
                tapCoords2.push([Number(args[i + 1]), Number(args[i + 2])]);
            }
            if (args.includes('cat')) {
                const xml = dumpSequence2[Math.min(dumpCallCount2, dumpSequence2.length - 1)];
                dumpCallCount2++;
                return { stdout: xml };
            }
            return { stdout: '' };
        }
    });
    await chFlowConfirm.openConversation('device1', '0980964513');
    assert.deepStrictEqual(tapCoords2, [[880, 2355], [689, 416], [600, 796], [855, 1440]], 'debe tapear FAB, campo, resultado y además "Siguiente" al detectar la pantalla de confirmación');
    console.log('OK: openConversation soporta la pantalla intermedia de confirmar destinatario (Siguiente)');

    // Caso 13: openConversation aborta si nunca aparece la pantalla de nueva conversación (sin tapear a ciegas)
    const chNoField = new AdbChannel({
        launchWaitMs: 0,
        stepWaitMs: 0,
        execFn: async (args) => {
            if (args.includes('cat')) return { stdout: dumpList }; // siempre lista, nunca avanza
            return { stdout: '' };
        }
    });
    await assert.rejects(() => chNoField.openConversation('device1', '0980964513'), /MESSAGES_SEARCH_FIELD_NOT_FOUND/);
    console.log('OK: openConversation aborta si no encuentra el campo de búsqueda');

    // Caso 14: send() tapea el compositor, escribe, y RE-LOCALIZA el botón de enviar
    // en un dump tomado DESPUÉS de escribir (un mensaje largo puede hacer crecer el
    // compositor y desplazar el botón — usar bounds de antes de escribir lo pierde).
    // Enter/keyevent 66 en el compositor inserta salto de línea, no envía.
    const sendTapCoords = [];
    const textCalls = [];
    let sendDumpCount = 0;
    const chSend = new AdbChannel({
        stepWaitMs: 0,
        execFn: async (args) => {
            if (args.includes('tap')) {
                const i = args.indexOf('tap');
                sendTapCoords.push([Number(args[i + 1]), Number(args[i + 2])]);
            }
            if (args.includes('text')) textCalls.push(args[args.indexOf('text') + 1]);
            if (args.includes('cat')) {
                sendDumpCount++;
                return { stdout: sendDumpCount === 1 ? dumpCompose : dumpComposeAfterType };
            }
            return { stdout: '' };
        }
    });
    await chSend.send('device1', 'Hola Juan');
    assert.deepStrictEqual(sendTapCoords, [[418, 2407], [1083, 2491]], 'debe tapear el campo de mensaje (dump inicial) y luego enviar con las coordenadas RE-LOCALIZADAS tras escribir');
    assert.strictEqual(textCalls[0], 'Hola%sJuan');
    console.log('OK: send re-localiza el botón de enviar tras escribir (no usa bounds obsoletos)');

    // Caso 15: send() aborta si se perdió el compositor (sin tapear/escribir a ciegas)
    const chSendLost = new AdbChannel({
        execFn: async (args) => {
            if (args.includes('cat')) return { stdout: dumpList };
            return { stdout: '' };
        }
    });
    await assert.rejects(() => chSendLost.send('device1', 'Hola'), /MESSAGES_NOT_FOREGROUND/);
    console.log('OK: send aborta si se perdió el compositor de Google Messages');

    // Caso 16: pollDump reintenta hasta que aparece el resultado (pantallas que tardan en renderizar)
    let pollDumpCalls = 0;
    const chPoll = new AdbChannel({
        stepWaitMs: 0,
        pollAttempts: 4,
        execFn: async (args) => {
            if (args.includes('cat')) {
                pollDumpCalls++;
                // Los primeros 2 intentos aún no muestran resultado; el 3ro sí.
                return { stdout: pollDumpCalls < 3 ? dumpNewConversation : dumpSearchResult };
            }
            return { stdout: '' };
        }
    });
    const { result: polled } = await chPoll.pollDump('device1', d => AdbChannel.findFirstClickableBelow(d, 494));
    assert.deepStrictEqual(polled, { x1: 0, y1: 679, x2: 1200, y2: 913, cx: 600, cy: 796 });
    assert.strictEqual(pollDumpCalls, 3, 'debe reintentar exactamente hasta encontrar resultado (2 fallidos + 1 exitoso)');
    console.log('OK: pollDump reintenta hasta que la pantalla renderiza el resultado');

    // Caso 16b: pollDump no aborta si dump() agota sus propios reintentos (MIUI flaky) —
    // lo cuenta como un intento fallido más del sondeo, no mata todo el flujo.
    let pollDumpCalls2 = 0;
    const chPollFlaky = new AdbChannel({
        stepWaitMs: 0,
        dumpAttempts: 1,
        pollAttempts: 3,
        execFn: async (args) => {
            if (args.includes('uiautomator')) {
                pollDumpCalls2++;
                if (pollDumpCalls2 < 2) throw new Error('Command failed: uiautomator dump');
                return { stdout: '' };
            }
            if (args.includes('cat')) return { stdout: dumpSearchResult };
            return { stdout: '' };
        }
    });
    const { result: polledFlaky } = await chPollFlaky.pollDump('device1', d => AdbChannel.findFirstClickableBelow(d, 494));
    assert.deepStrictEqual(polledFlaky, { x1: 0, y1: 679, x2: 1200, y2: 913, cx: 600, cy: 796 });
    console.log('OK: pollDump absorbe un dump() que agota sus reintentos y sigue sondeando');

    // Caso 17: dump() reintenta si `uiautomator dump` falla de forma intermitente
    // (confirmado en MIUI: bug interno de ThemeCompatibility, ~intermitente)
    let dumpAttemptsMade = 0;
    const chFlaky = new AdbChannel({
        dumpRetryDelayMs: 0,
        execFn: async (args) => {
            if (args.includes('uiautomator')) {
                dumpAttemptsMade++;
                if (dumpAttemptsMade < 2) throw new Error('Command failed: uiautomator dump (ThemeCompatibility)');
                return { stdout: '' };
            }
            if (args.includes('cat')) return { stdout: dumpList };
            return { stdout: '' };
        }
    });
    const dumpedXml = await chFlaky.dump('device1');
    assert.strictEqual(dumpedXml, dumpList);
    assert.strictEqual(dumpAttemptsMade, 2, 'debe reintentar tras el primer fallo y lograrlo en el segundo intento');
    console.log('OK: dump reintenta ante fallos intermitentes de uiautomator');

    // Caso 18: dump() propaga el error si TODOS los intentos fallan (no cuelga en silencio)
    const chAlwaysFails = new AdbChannel({
        dumpAttempts: 2,
        dumpRetryDelayMs: 0,
        execFn: async () => { throw new Error('Command failed: uiautomator dump'); }
    });
    await assert.rejects(() => chAlwaysFails.dump('device1'), /uiautomator dump/);
    console.log('OK: dump propaga el error tras agotar los reintentos');

    // Caso 19: attachImage decodifica el data URL, lo escribe local, lo empuja
    // al dispositivo y dispara escaneo de medios — y limpia el archivo local
    const writes = [];
    const unlinks = [];
    const pushCalls = [];
    const broadcastCalls = [];
    const chImg = new AdbChannel({
        fs: {
            writeFileSync: (p, buf) => writes.push({ path: p, size: buf.length }),
            unlinkSync: (p) => unlinks.push(p)
        },
        tmpDir: 'C:\\fake-tmp',
        execFn: async (args) => {
            if (args.includes('push')) pushCalls.push(args);
            if (args.includes('broadcast')) broadcastCalls.push(args);
            return { stdout: '' };
        }
    });
    const tinyPngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
    const remotePath = await chImg.attachImage('device1', `data:image/png;base64,${tinyPngBase64}`);
    assert.strictEqual(remotePath, '/sdcard/Pictures/sms_pro_adjunto.png');
    assert.strictEqual(writes.length, 1, 'debe escribir el archivo local una vez');
    assert.ok(writes[0].path.startsWith('C:\\fake-tmp'), 'debe usar el tmpDir inyectado');
    assert.strictEqual(pushCalls.length, 1);
    assert.ok(pushCalls[0].includes('push') && pushCalls[0].includes(remotePath));
    assert.strictEqual(broadcastCalls.length, 1, 'debe disparar MEDIA_SCANNER_SCAN_FILE');
    assert.deepStrictEqual(unlinks, [writes[0].path], 'debe limpiar el archivo local tras empujarlo');
    console.log('OK: attachImage empuja la imagen y limpia el archivo local');

    // Caso 20: attachImage rechaza un data URL con formato no reconocido, sin tocar adb
    const chImgBad = new AdbChannel({
        fs: { writeFileSync: () => {}, unlinkSync: () => {} },
        execFn: async () => { throw new Error('no debería llamarse'); }
    });
    await assert.rejects(() => chImgBad.attachImage('device1', 'no-es-un-data-url'), /IMAGE_DATA_INVALID/);
    console.log('OK: attachImage rechaza data URLs inválidos sin tocar adb');

    // Caso 21: attachImage limpia el archivo local incluso si el push falla
    const unlinksOnError = [];
    const chImgFail = new AdbChannel({
        fs: { writeFileSync: () => {}, unlinkSync: (p) => unlinksOnError.push(p) },
        tmpDir: 'C:\\fake-tmp',
        execFn: async (args) => { if (args.includes('push')) throw new Error('device offline'); return { stdout: '' }; }
    });
    await assert.rejects(() => chImgFail.attachImage('device1', `data:image/png;base64,${tinyPngBase64}`), /device offline/);
    assert.strictEqual(unlinksOnError.length, 1, 'debe limpiar el archivo local aunque el push falle');
    console.log('OK: attachImage limpia el archivo local aunque el push falle');

    console.log('Todos los tests de AdbChannel pasaron.');
})();
