const assert = require('assert');
const path = require('path');
const XLSX = require(path.join(__dirname, 'lib', 'xlsx.full.min.js'));
const { resolvePhoneCell, resolvePhoneColumnKey } = require('./dataProcessor.js');

// --- resolvePhoneCell: casos unitarios ---

// Caso 1: celda de texto con cero inicial -> se conserva tal cual (sin cambio de comportamiento)
assert.strictEqual(resolvePhoneCell('0993456789', '0993456789'), '0993456789');
console.log('OK: celda de texto con cero inicial se conserva tal cual');

// Caso 2: celda numérica simple sin padding -> igual que hoy (raw == formatted)
assert.strictEqual(resolvePhoneCell(993456789, '993456789'), '993456789');
console.log('OK: celda numérica simple sin padding no cambia');

// Caso 3: celda numérica con formato de relleno de ceros -> recupera el cero inicial
assert.strictEqual(resolvePhoneCell(993456789, '0993456789'), '0993456789');
console.log('OK: celda numérica con formato zero-pad recupera el cero inicial');

// Caso 4: celda numérica con formato de moneda/decimales -> NO se corrompe con dígitos falsos
assert.strictEqual(resolvePhoneCell(993456789, '993,456,789.00'), '993456789');
console.log('OK: formato de moneda con decimales no corrompe el número');

// Caso 5: celda vacía -> string vacío
assert.strictEqual(resolvePhoneCell('', ''), '');
assert.strictEqual(resolvePhoneCell(undefined, undefined), '');
console.log('OK: celda vacía/undefined devuelve string vacío');

// --- Integración con XLSX real: reproduce el bug reportado ---

function buildWorksheet(telefonoValue, numFmt) {
    const ws = XLSX.utils.aoa_to_sheet([
        ['Nº CONTRATO', 'TELEFONO 1'],
        ['C1', telefonoValue]
    ]);
    if (numFmt) ws['B2'].z = numFmt;
    return ws;
}

function readTelefono1(ws) {
    const raw = XLSX.utils.sheet_to_json(ws, { defval: '' });
    const formatted = XLSX.utils.sheet_to_json(ws, { defval: '', raw: false });
    return resolvePhoneCell(raw[0]['TELEFONO 1'], formatted[0]['TELEFONO 1']);
}

// Caso 6: celda TELEFONO 1 con formato "0000000000" (caso real reportado) -> 10 dígitos con el 0 inicial
const ws6 = buildWorksheet(993456789, '0000000000');
assert.strictEqual(readTelefono1(ws6), '0993456789');
console.log('OK: integración XLSX — formato zero-pad de 10 dígitos recupera el 0 inicial');

// Caso 7: celda TELEFONO 1 sin formato especial (General) -> sin cambio
const ws7 = buildWorksheet(993456789, null);
assert.strictEqual(readTelefono1(ws7), '993456789');
console.log('OK: integración XLSX — formato General no cambia el valor');

// --- resolvePhoneColumnKey: reproduce el bug real (reporte con columna "TELEFONO", no "TELEFONO 1") ---

// Caso 8: hoja con "TELEFONO 1" -> se prefiere ese nombre (comportamiento existente intacto)
const rowConTelefono1 = { 'Nº CONTRATO': 'C1', 'TELEFONO 1': '0993456789', 'TELEFONO 2': '0987654321' };
assert.strictEqual(resolvePhoneColumnKey(rowConTelefono1), 'TELEFONO 1');
console.log('OK: resolvePhoneColumnKey prefiere "TELEFONO 1" cuando existe');

// Caso 9: hoja SIN "TELEFONO 1" pero con "TELEFONO" (caso real: reporte de ventas, hoja "GLOBAL")
// Antes de este fix, esto hacía que TODOS los contactos quedaran sin teléfono
// y la campaña completa se descartara con "No se encontraron contactos".
const rowSoloTelefono = { 'Nº CONTRATO': 'C1', 'TELEFONO': '0993456789', 'TELEFONO 2': '0987654321' };
assert.strictEqual(resolvePhoneColumnKey(rowSoloTelefono), 'TELEFONO');
console.log('OK: resolvePhoneColumnKey cae a "TELEFONO" cuando "TELEFONO 1" no existe en la hoja');

// Caso 10: ninguna columna de teléfono reconocida -> null (no revienta, deja que readContacts rechace con mensaje claro)
const rowSinTelefono = { 'Nº CONTRATO': 'C1', 'TELEFONO 2': '0987654321' };
assert.strictEqual(resolvePhoneColumnKey(rowSinTelefono), null);
console.log('OK: resolvePhoneColumnKey devuelve null si no hay columna de teléfono reconocida');

// Caso 11: integración XLSX completa — hoja real con columna "TELEFONO" (sin "1") se lee correctamente
function buildWorksheetSoloTelefono(telefonoValue) {
    return XLSX.utils.aoa_to_sheet([
        ['Nº CONTRATO', 'TELEFONO'],
        ['C1', telefonoValue]
    ]);
}
const ws11 = buildWorksheetSoloTelefono('0993456789');
const raw11 = XLSX.utils.sheet_to_json(ws11, { defval: '' });
const phoneKey11 = resolvePhoneColumnKey(raw11[0]);
assert.strictEqual(phoneKey11, 'TELEFONO');
assert.strictEqual(resolvePhoneCell(raw11[0][phoneKey11], raw11[0][phoneKey11]), '0993456789');
console.log('OK: integración XLSX — hoja con columna "TELEFONO" (sin "1") resuelve el teléfono correctamente');

console.log('Todos los tests de dataProcessor.js pasaron.');
