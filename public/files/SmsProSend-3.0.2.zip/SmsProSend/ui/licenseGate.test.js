const assert = require('assert');
const { computeGateDecision, isRenewalWarning, GRACE_MS } = require('./licenseGate.js');

const NOW = 1_800_000_000_000; // instante fijo de referencia para los tests

// Caso 1: sin licencia activada nunca -> bloqueado, razón 'no_license'
assert.deepStrictEqual(
    computeGateDecision(null, NOW),
    { allowed: false, reason: 'no_license' }
);
console.log('OK: sin estado cacheado -> no_license');

// Caso 2: licencia vencida (el backend ya lo dice en el último validate/activate)
assert.deepStrictEqual(
    computeGateDecision({ status: 'expired', lastValidatedAt: NOW - 1000 }, NOW),
    { allowed: false, reason: 'expired' }
);
console.log('OK: status expired -> bloqueado con esa razón');

// Caso 3: licencia suspendida
assert.deepStrictEqual(
    computeGateDecision({ status: 'suspended', lastValidatedAt: NOW - 1000 }, NOW),
    { allowed: false, reason: 'suspended' }
);
console.log('OK: status suspended -> bloqueado con esa razón');

// Caso 4: dispositivo no registrado (key vigente pero este device no está activo)
assert.deepStrictEqual(
    computeGateDecision({ status: 'device_not_registered', lastValidatedAt: NOW - 1000 }, NOW),
    { allowed: false, reason: 'device_not_registered' }
);
console.log('OK: status device_not_registered -> bloqueado con esa razón');

// Caso 5: activa y validada hace instantes -> permitido
assert.deepStrictEqual(
    computeGateDecision({ status: 'active', lastValidatedAt: NOW - 1000 }, NOW),
    { allowed: true, reason: null }
);
console.log('OK: active + validación reciente -> permitido');

// Caso 6: activa, última validación hace 47h59m (dentro de la gracia de 48h) -> permitido
assert.deepStrictEqual(
    computeGateDecision({ status: 'active', lastValidatedAt: NOW - (GRACE_MS - 60_000) }, NOW),
    { allowed: true, reason: null }
);
console.log('OK: active + dentro de la gracia offline de 48h -> permitido');

// Caso 7: activa, última validación hace 48h01m (fuera de la gracia) -> bloqueado
assert.deepStrictEqual(
    computeGateDecision({ status: 'active', lastValidatedAt: NOW - (GRACE_MS + 60_000) }, NOW),
    { allowed: false, reason: 'offline_grace_expired' }
);
console.log('OK: active + gracia offline vencida -> bloqueado');

// Caso 8: status 'active' pero sin lastValidatedAt (estado corrupto/inesperado) -> bloqueado
assert.deepStrictEqual(
    computeGateDecision({ status: 'active', lastValidatedAt: null }, NOW),
    { allowed: false, reason: 'invalid_state' }
);
console.log('OK: active sin lastValidatedAt -> invalid_state');

// Caso 9: aviso de renovación (<=30 días restantes)
assert.strictEqual(isRenewalWarning(30), true);
assert.strictEqual(isRenewalWarning(31), false);
assert.strictEqual(isRenewalWarning(0), true);
assert.strictEqual(isRenewalWarning(null), false);
console.log('OK: isRenewalWarning marca <=30 días, ignora null');

// Caso 10: elapsed exactamente igual a GRACE_MS -> todavía permitido (límite inclusivo)
assert.deepStrictEqual(
    computeGateDecision({ status: 'active', lastValidatedAt: NOW - GRACE_MS }, NOW),
    { allowed: true, reason: null }
);
console.log('OK: elapsed === GRACE_MS (límite exacto) -> permitido');

console.log('Todos los tests de licenseGate pasaron.');
