/**
 * sesion — maneja el protocolo del puente ADB de Telegram sobre un WebSocket.
 *
 * Lógica pura/inyectable (sin net ni adb directos): `crearSesion(deps)` deja
 * `manejar(msg, enviar)` donde `enviar(obj)` manda un mensaje al cliente.
 * Sobrevive a clientes desconectados: un `enviar` que lanza nunca corta la
 * campaña en curso.
 */

const { TelegramAdbChannel } = require('../channels/TelegramAdbChannel.js');
const { CampaignEngine } = require('../campaignEngine.js');
const { withEnabledTargets } = require('../channels/deviceSelection.js');
const { Codigo, validarInicio } = require('./protocol.js');

const STOP_FORZADO_MS = 30000;

// Caso especial: estado sin campaña (nunca undefined — regla sin-null).
// Todo motor asignado se marca con `enCurso = true`; al terminar vuelve aquí.
const SIN_CAMPANIA = Object.freeze({
    enCurso: false,
    contacts: Object.freeze([]),
    results: Object.freeze([]),
    aborted: false,
    abort() {}
});

function crearCanalReal() {
    return new TelegramAdbChannel(process.env.ADB_PATH ? { adbPath: process.env.ADB_PATH } : {});
}

function crearMotorReal(opts) {
    return new CampaignEngine(opts);
}

function nuevoIdReal() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function ahoraReal() {
    return new Date().toISOString();
}

function crearSesion(deps) {
    const d = deps || {};
    const crearCanal = d.crearCanal || crearCanalReal;
    const crearMotor = d.crearMotor || crearMotorReal;
    const almacen = d.almacen || { guardar: () => {}, leer: () => [], confirmar: () => false };
    const nuevoId = d.nuevoId || nuevoIdReal;
    const ahora = d.ahora || ahoraReal;
    const temporizar = d.temporizar || setTimeout;

    let motor = SIN_CAMPANIA;
    let campanaId = '';
    let vigente = 0;

    function enviarSeguro(enviar, obj) {
        try {
            enviar(obj);
        } catch (_) { /* cliente desconectado: la campaña sigue */ }
    }

    function errorSeguro(enviar, code, message) {
        enviarSeguro(enviar, { type: 'error', code, message });
    }

    async function manejar(msg, enviar) {
        const pedido = msg || {};
        switch (pedido.type) {
            case 'list_devices': {
                try {
                    const canal = crearCanal();
                    const devices = await canal.listTargets();
                    enviarSeguro(enviar, { type: 'devices', devices: Array.isArray(devices) ? devices : [] });
                } catch (err) {
                    errorSeguro(enviar, Codigo.ADB_NOT_FOUND, err && err.message ? err.message : 'adb no disponible');
                }
                return;
            }
            case 'start': {
                if (motor.enCurso) {
                    errorSeguro(enviar, Codigo.CAMPAIGN_RUNNING, 'Ya hay una campaña en curso');
                    return;
                }
                const contactos = Array.isArray(pedido.contacts) ? pedido.contacts : [];
                if (contactos.length === 0) {
                    errorSeguro(enviar, Codigo.EMPTY_CONTACTS, 'Sin contactos para enviar: carga al menos un contacto');
                    return;
                }
                let canal;
                try {
                    canal = crearCanal();
                } catch (err) {
                    errorSeguro(enviar, Codigo.ADB_NOT_FOUND, err && err.message ? err.message : 'adb no disponible');
                    return;
                }
                let conectados;
                try {
                    conectados = await canal.listTargets();
                } catch (err) {
                    errorSeguro(enviar, Codigo.ADB_NOT_FOUND, err && err.message ? err.message : 'adb no disponible');
                    return;
                }
                const validacion = validarInicio(conectados, pedido);
                if (!validacion.ok) {
                    errorSeguro(enviar, validacion.code, validacion.message);
                    return;
                }
                const id = nuevoId();
                const targets = validacion.targets;
                const engine = crearMotor({
                    contacts: contactos,
                    template: pedido.template || '',
                    messageVariants: Array.isArray(pedido.messageVariants) ? pedido.messageVariants : [],
                    channels: [withEnabledTargets(canal, pedido.enabledDevices)],
                    config: pedido.config && typeof pedido.config === 'object' ? pedido.config : {},
                    imageDataUrl: pedido.imageDataUrl || ''
                });
                motor = engine;
                motor.enCurso = true;
                campanaId = id;
                vigente += 1;
                const turno = vigente;
                enviarSeguro(enviar, { type: 'started', campaignId: id, devices: targets, total: contactos.length });
                const alProgresar = (progreso) => {
                    enviarSeguro(enviar, {
                        type: 'progress',
                        campaignId: id,
                        index: progreso.index,
                        phone: progreso.phone,
                        status: progreso.status,
                        target: progreso.target
                    });
                };
                let salida;
                try {
                    salida = await engine.run(alProgresar);
                } catch (err) {
                    if (turno !== vigente) return; // done ya forzado por stop
                    const abortado = (engine && engine.aborted) || (err && err.message && err.message.includes('ABORTED'));
                    const resultados = (engine && Array.isArray(engine.results) && engine.results) || [];
                    if (abortado) {
                        almacen.guardar({ campaignId: id, results: resultados, stopped: true, terminadaEn: ahora() });
                        motor = SIN_CAMPANIA;
                        campanaId = '';
                        enviarSeguro(enviar, { type: 'done', campaignId: id, results: resultados, stopped: true });
                    } else {
                        almacen.guardar({ campaignId: id, results: resultados, stopped: true, terminadaEn: ahora() });
                        motor = SIN_CAMPANIA;
                        campanaId = '';
                        errorSeguro(enviar, Codigo.CAMPANIA_FALLIDA, err && err.message ? err.message : 'Error en la campaña');
                        enviarSeguro(enviar, { type: 'done', campaignId: id, results: resultados, stopped: true });
                    }
                    return;
                }
                if (turno !== vigente) return; // done ya forzado por stop
                const resultados = (salida && Array.isArray(salida.results) && salida.results)
                    || (engine && Array.isArray(engine.results) && engine.results) || [];
                const detenido = !!engine.aborted;
                almacen.guardar({ campaignId: id, results: resultados, stopped: detenido, terminadaEn: ahora() });
                motor = SIN_CAMPANIA;
                campanaId = '';
                enviarSeguro(enviar, { type: 'done', campaignId: id, results: resultados, stopped: detenido });
                return;
            }
            case 'stop': {
                if (motor.enCurso) {
                    try {
                        motor.abort();
                    } catch (_) { /* abortar nunca rompe el stop */ }
                    const turno = vigente;
                    const motorParado = motor;
                    const idParado = campanaId;
                    temporizar(() => {
                        if (turno !== vigente || !motor.enCurso) return;
                        const resultados = (motorParado && Array.isArray(motorParado.results) && motorParado.results) || [];
                        almacen.guardar({ campaignId: idParado, results: resultados, stopped: true, terminadaEn: ahora() });
                        motor = SIN_CAMPANIA;
                        campanaId = '';
                        vigente += 1;
                        enviarSeguro(enviar, { type: 'done', campaignId: idParado, results: resultados, stopped: true });
                    }, STOP_FORZADO_MS);
                }
                enviarSeguro(enviar, { type: 'stopping' });
                return;
            }
            case 'status': {
                enviarSeguro(enviar, {
                    type: 'status',
                    isRunning: motor.enCurso,
                    campaignId: motor.enCurso ? campanaId : '',
                    total: Array.isArray(motor.contacts) ? motor.contacts.length : 0,
                    progressIndex: Array.isArray(motor.results) ? motor.results.length : 0,
                    results: Array.isArray(motor.results) ? motor.results.slice() : [],
                    sinConfirmar: almacen.leer()
                });
                return;
            }
            case 'ack': {
                const ok = almacen.confirmar(pedido.campaignId);
                enviarSeguro(enviar, { type: 'acked', campaignId: pedido.campaignId, ok });
                return;
            }
            default: {
                errorSeguro(enviar, Codigo.TIPO_DESCONOCIDO, 'Tipo desconocido: ' + pedido.type);
            }
        }
    }

    return { manejar };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { crearSesion, SIN_CAMPANIA };
}
