/**
 * resultadoDurable — guarda el último resultado de campaña en un JSON hasta
 * recibir su `ack`. Permite que un cliente reiniciado (service worker
 * dormido) recupere el resultado con `status`. `fs` inyectable para tests.
 */

const fsReal = require('fs');

function crearAlmacen(opts) {
    const o = opts || {};
    const ruta = o.ruta || '';
    const fs = o.fs || fsReal;

    function guardar(datos) {
        const d = datos || {};
        const registro = {
            campaignId: d.campaignId || '',
            results: Array.isArray(d.results) ? d.results : [],
            stopped: d.stopped === true,
            terminadaEn: d.terminadaEn || ''
        };
        // Escritura atómica: primero al .tmp y luego rename sobre la ruta,
        // para que un corte a mitad de escritura no deje el JSON corrupto.
        const temporal = ruta + '.tmp';
        fs.writeFileSync(temporal, JSON.stringify(registro));
        fs.renameSync(temporal, ruta);
    }

    function leer() {
        try {
            const crudo = fs.readFileSync(ruta, 'utf-8');
            const obj = JSON.parse(String(crudo));
            if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return [];
            return [{
                campaignId: obj.campaignId || '',
                results: Array.isArray(obj.results) ? obj.results : [],
                stopped: obj.stopped === true,
                terminadaEn: obj.terminadaEn || ''
            }];
        } catch (_) {
            return [];
        }
    }

    function confirmar(campaignId) {
        const actual = leer();
        if (actual.length === 0) return false;
        if (actual[0].campaignId !== campaignId) return false;
        try {
            fs.unlinkSync(ruta);
        } catch (_) {
            return false;
        }
        return true;
    }

    return { guardar, leer, confirmar };
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { crearAlmacen };
}
