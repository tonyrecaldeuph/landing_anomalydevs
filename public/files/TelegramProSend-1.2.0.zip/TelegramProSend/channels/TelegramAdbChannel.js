/**
 * TelegramAdbChannel — interfaz Channel sobre la app nativa de Telegram
 * manejada por adb + uiautomator dump. Solo Node (child_process): no entra
 * al zip de la extensión.
 *
 * Cada acción se decide sobre el dump actual: se confirma la pantalla con
 * screenOf() antes de tocar, y cada tap sale de los bounds reales. Evidencia:
 * channels/fixtures/ (HONOR ALI-NX3, Android 15, Telegram 12.10.5, es).
 *
 * Regla fail-closed: antes de cada toque se comprueba que ningún otro nodo
 * clicable tape el punto; si está tapado se reintenta con un dump nuevo.
 *
 * Interfaz Channel:
 *   listTargets() -> Promise<string[]>              // seriales autorizados
 *   openConversation(target, phone, contact) -> Promise<void>  // lanza TELEGRAM_NOT_FOUND si no hay cuenta
 *   send(target, text) -> Promise<void>
 *   verifySent(target) -> Promise<boolean>
 *   detectProtocol(target) -> Promise<'telegram'>
 *   isBlocked(target) -> Promise<boolean>
 *   attachImage(target, dataUrl) -> Promise<void>   // no soportado en v1: lanza
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const P = require('./telegramAdbPantallas.js');

const execFileAsync = promisify(execFile);
const PAQUETE = 'org.telegram.messenger';
const RUTA_DUMP = '/sdcard/window_dump.xml';

class TelegramAdbChannel {
    /**
     * @param {Object} [opts]
     * @param {string} [opts.adbPath='adb']
     * @param {Function} [opts.execFn] - (args) => Promise<{stdout, stderr}>
     * @param {number} [opts.launchWaitMs=2000] - espera tras relanzar Telegram en frío
     * @param {number} [opts.stepWaitMs=900] - espera entre dumps de un mismo sondeo
     * @param {number} [opts.pollAttempts=6] - dumps por pantalla esperada
     * @param {number} [opts.dumpAttempts=5] - reintentos de uiautomator dump
     * @param {number} [opts.dumpRetryDelayMs=600]
     * @param {number} [opts.existingContactPolls=2] - dumps para detectar "already in your contacts"
     */
    constructor(opts = {}) {
        this.adbPath = opts.adbPath || 'adb';
        // windowsHide evita una ventana de consola por cada llamada a adb.exe
        this.execFn = opts.execFn || ((args) => execFileAsync(this.adbPath, args, { windowsHide: true }));
        this.launchWaitMs = valorO(opts.launchWaitMs, 2000);
        this.stepWaitMs = valorO(opts.stepWaitMs, 900);
        this.pollAttempts = valorO(opts.pollAttempts, 6);
        this.dumpAttempts = valorO(opts.dumpAttempts, 5);
        this.dumpRetryDelayMs = valorO(opts.dumpRetryDelayMs, 600);
        this.existingContactPolls = valorO(opts.existingContactPolls, 2);
        this.ultimoTextoPorTarget = new Map();
    }

    // ── API Channel ────────────────────────────────────────────────

    async listTargets() {
        const { stdout } = await this.execFn(['devices']);
        return P.parseDevices(stdout);
    }

    async openConversation(target, phone, contact) {
        // Validar antes de tocar el teléfono
        const nacional = P.nationalNumber(phone);
        const nombre = P.contactNameFor(contact, phone);

        const inicio = await this.resetToChatList(target);
        let menu;
        if (inicio.pantalla === P.PANTALLAS.permisoContactos) {
            menu = inicio;
        } else {
            await this.tapNodo(target, inicio.nodos, n => P.findByDesc(n, 'Nuevo mensaje'), 'Nuevo mensaje');
            menu = await this.esperarPantalla(target, [P.PANTALLAS.permisoContactos, P.PANTALLAS.nuevoMensaje]);
        }
        if (menu.pantalla === P.PANTALLAS.permisoContactos) {
            await this.tapNodo(target, menu.nodos, n => P.findByText(n, 'Continuar'), 'Continuar');
            menu = await this.esperarPantalla(target, [P.PANTALLAS.nuevoMensaje]);
        }
        await this.tapNodo(target, menu.nodos, n => P.findByDesc(n, 'Crear nuevo contacto'), 'Crear nuevo contacto');

        const formulario = await this.llenarFormulario(target, nombre, nacional);
        const aviso = P.findByTextIncludes(formulario.nodos, 'already in your contacts');
        if (aviso.encontrado) {
            await this.tapNodo(target, formulario.nodos, n => P.findByTextIncludes(n, 'already in your contacts'), 'aviso de contacto existente', P.linkTapPoint);
            const perfil = await this.esperarPantalla(target, [P.PANTALLAS.perfil]);
            return this.entrarDesdePerfil(target, perfil.nodos, nacional);
        }

        await this.tapNodo(target, formulario.nodos, n => P.findByText(n, 'Crear contacto'), 'Crear contacto');
        const resultado = await this.esperarPantalla(target, [P.PANTALLAS.noEncontrado, P.PANTALLAS.chat, P.PANTALLAS.perfil]);
        if (resultado.pantalla === P.PANTALLAS.noEncontrado) {
            // Nunca "Invitar": manda un SMS desde el teléfono
            await this.tapNodo(target, resultado.nodos, n => P.findByText(n, 'Cancelar'), 'Cancelar');
            throw new Error('TELEGRAM_NOT_FOUND: sin cuenta de Telegram para ' + phone);
        }
        if (resultado.pantalla === P.PANTALLAS.perfil) {
            return this.entrarDesdePerfil(target, resultado.nodos, nacional);
        }
        if (P.chatHeaderName(resultado.nodos) !== nombre) {
            throw new Error('TELEGRAM_ADB_CHAT_EQUIVOCADO: se abrió "' + P.chatHeaderName(resultado.nodos) + '", se esperaba "' + nombre + '"');
        }
    }

    async send(target, text) {
        // Re-dump: una notificación pudo robar el foco desde openConversation()
        const chat = await this.esperarPantalla(target, [P.PANTALLAS.chat]);
        await this.tapNodo(target, chat.nodos, n => P.editTexts(n)[0] || P.NODO_AUSENTE, 'compositor');
        await this.vaciarCompositorSiHayBorrador(target, chat.nodos);
        this.ultimoTextoPorTarget.set(target, P.sanitizeTypedText(text));
        await this.escribir(target, text);
        // Enviar se ubica después de escribir: con texto el compositor cambia de tamaño.
        // El centro del nodo cae sobre el EditText y no envía: se toca el extremo derecho.
        const escrito = await this.esperarPantalla(target, [P.PANTALLAS.chat]);
        await this.tapNodo(target, escrito.nodos, n => P.findByDesc(n, 'Enviar'), 'Enviar', P.sendTapPoint);
    }

    /**
     * Enviado = chat con el compositor en "Mensaje" Y la última burbuja
     * enviada trae el texto que se escribió (compara con espacios
     * colapsados). Sin texto guardado para el target se exige burbuja
     * vacía, nunca null.
     */
    async verifySent(target) {
        const nodos = P.parseNodes(await this.dump(target));
        if (P.screenOf(nodos) !== P.PANTALLAS.chat || P.composerText(nodos) !== 'Mensaje') return false;
        return espaciosColapsados(P.ultimaBurbujaEnviada(nodos).texto) === espaciosColapsados(this.ultimoTextoPorTarget.get(target));
    }

    async detectProtocol(target) {
        return 'telegram';
    }

    async isBlocked(target) {
        return false;
    }

    /**
     * v1 no adjunta imágenes: la evidencia llega hasta el selector de galería
     * pero no cubre elegir la foto ni el envío con pie. Se lanza en vez de
     * ignorarla para que la campaña no marque "Enviado" sin la imagen.
     */
    async attachImage(target, dataUrl) {
        throw new Error('TELEGRAM_ADB_IMAGEN_NO_SOPORTADA: el canal ADB aún no envía imágenes');
    }

    // ── Pasos del flujo ────────────────────────────────────────────

    /**
     * Relanza Telegram en frío y confirma la lista de chats antes de actuar.
     * Primero espera la carga con el sondeo normal (pollAttempts, como
     * esperarPantalla): así un splash sin nodos alcanza la lista sin BACK.
     * Solo si se agota el sondeo y el último dump es de Telegram se vuelve
     * con BACK (máx. 5). Fuera de Telegram no se aprieta BACK: se aborta
     * para no cerrar la app ni tocar el launcher.
     */
    async resetToChatList(target) {
        await this.execFn(['-s', target, 'shell', 'am', 'force-stop', PAQUETE]);
        await this.execFn(['-s', target, 'shell', 'input', 'keyevent', '224']);
        await this.execFn(['-s', target, 'shell', 'wm', 'dismiss-keyguard']);
        await this.execFn(['-s', target, 'shell', 'monkey', '-p', PAQUETE, '-c', 'android.intent.category.LAUNCHER', '1']);
        await sleep(this.launchWaitMs);
        let nodos = [];
        for (let backs = 0; backs <= 5; backs++) {
            const sondeo = await this.sondear(target, this.pollAttempts,
                n => [P.PANTALLAS.listaChats, P.PANTALLAS.permisoContactos].includes(P.screenOf(n)));
            nodos = sondeo.nodos;
            if (sondeo.cumple) {
                return { pantalla: P.screenOf(nodos), nodos };
            }
            if (!P.esDeTelegram(sondeo.ultimoXml)) break;
            if (backs < 5) {
                await this.execFn(['-s', target, 'shell', 'input', 'keyevent', 'KEYCODE_BACK']);
                await sleep(this.stepWaitMs);
            }
        }
        throw new Error('TELEGRAM_ADB_PANTALLA_INESPERADA: se esperaba listaChats/permisoContactos, se vio ' + P.screenOf(nodos));
    }

    /** Llena nombre y teléfono; devuelve el último dump del formulario. */
    async llenarFormulario(target, nombre, nacional) {
        const vacio = await this.esperarPantalla(target, [P.PANTALLAS.nuevoContacto]);
        await this.tapNodo(target, vacio.nodos, n => P.editTexts(n)[0] || P.NODO_AUSENTE, 'campo Nombre');
        await this.escribir(target, nombre);

        // Re-dump: el teclado desplaza el formulario y los bounds cambian
        const conNombre = await this.esperarPantalla(target, [P.PANTALLAS.nuevoContacto]);
        const codigo = P.findByDesc(conNombre.nodos, 'Código de país');
        if (codigo.text !== '593') {
            throw new Error('TELEGRAM_ADB_PAIS_NO_SOPORTADO: el formulario tiene código ' + codigo.text);
        }
        await this.tapNodo(target, conNombre.nodos, n => P.findByDesc(n, 'Número de teléfono'), 'Número de teléfono');
        await this.escribir(target, nacional);

        // El aviso "already in your contacts" puede tardar en aparecer
        const { nodos } = await this.sondear(target, this.existingContactPolls,
            n => P.findByTextIncludes(n, 'already in your contacts').encontrado);
        return { nodos };
    }

    /**
     * Telegram guarda borradores por chat: si el compositor trae texto se
     * selecciona todo (Ctrl+A) y se borra; si no queda vacío se aborta sin
     * escribir para no concatenar el mensaje con el borrador.
     */
    async vaciarCompositorSiHayBorrador(target, nodos) {
        if (P.composerText(nodos) === 'Mensaje') return;
        await this.execFn(['-s', target, 'shell', 'input', 'keycombination', '113', '29']);
        await this.execFn(['-s', target, 'shell', 'input', 'keyevent', 'KEYCODE_DEL']);
        const limpio = await this.esperarPantalla(target, [P.PANTALLAS.chat]);
        if (P.composerText(limpio.nodos) !== 'Mensaje') {
            throw new Error('TELEGRAM_ADB_COMPOSITOR_NO_VACIO: el compositor conserva texto tras vaciarlo');
        }
    }

    async entrarDesdePerfil(target, nodos, nacional) {
        if (!P.profilePhoneMatches(nodos, nacional)) {
            throw new Error('TELEGRAM_ADB_CHAT_EQUIVOCADO: el perfil abierto no es de ' + nacional);
        }
        await this.tapNodo(target, nodos, n => P.findByText(n, 'Mensaje', 'android.widget.Button'), 'Mensaje');
        await this.esperarPantalla(target, [P.PANTALLAS.chat]);
    }

    // ── Primitivas adb ─────────────────────────────────────────────

    async esperarPantalla(target, esperadas) {
        const { nodos, cumple } = await this.sondear(target, this.pollAttempts,
            n => esperadas.includes(P.screenOf(n)));
        if (!cumple) {
            throw new Error('TELEGRAM_ADB_PANTALLA_INESPERADA: se esperaba ' + esperadas.join('/') + ', se vio ' + P.screenOf(nodos));
        }
        return { pantalla: P.screenOf(nodos), nodos };
    }

    /** Hace hasta `intentos` dumps hasta que `condicion(nodos)` se cumpla. */
    async sondear(target, intentos, condicion) {
        let nodos = [];
        let ultimoXml = '';
        for (let i = 0; i < intentos; i++) {
            if (i > 0) await sleep(this.stepWaitMs);
            try {
                const xml = await this.dump(target);
                ultimoXml = xml;
                nodos = P.parseNodes(xml);
            } catch (_) {
                continue; // dump() ya agotó sus reintentos: cuenta como un intento fallido
            }
            if (condicion(nodos)) return { nodos, cumple: true, ultimoXml };
        }
        return { nodos, cumple: false, ultimoXml };
    }

    /** uiautomator dump falla de forma intermitente en algunos ROM: se reintenta. */
    async dump(target) {
        let ultimoError = new Error('uiautomator dump sin intentos');
        for (let i = 0; i < this.dumpAttempts; i++) {
            try {
                await this.execFn(['-s', target, 'shell', 'uiautomator', 'dump', RUTA_DUMP]);
                const { stdout } = await this.execFn(['-s', target, 'shell', 'cat', RUTA_DUMP]);
                return stdout;
            } catch (err) {
                ultimoError = err;
                if (i < this.dumpAttempts - 1) await sleep(this.dumpRetryDelayMs);
            }
        }
        throw ultimoError;
    }

    /**
     * Toca un nodo solo si ningún otro nodo clicable tapa su punto: si está
     * tapado reintenta con un dump nuevo hasta pollAttempts y si sigue tapado
     * lanza TELEGRAM_ADB_NODO_TAPADO sin tocar nada.
     */
    async tapNodo(target, nodos, buscar, descripcion, puntoDe = b => b) {
        let actuales = nodos;
        for (let i = 0; i < this.pollAttempts; i++) {
            if (i > 0) {
                await sleep(this.stepWaitMs);
                actuales = P.parseNodes(await this.dump(target));
            }
            const nodo = buscar(actuales);
            if (!nodo || !nodo.encontrado) {
                throw new Error('TELEGRAM_ADB_NODO_AUSENTE: no se encontró "' + descripcion + '" en pantalla');
            }
            const punto = puntoDe(nodo.bounds);
            if (!P.nodoQueTapa(actuales, nodo, punto).encontrado) {
                await this.tap(target, punto);
                return;
            }
        }
        throw new Error('TELEGRAM_ADB_NODO_TAPADO: ' + descripcion + ' está tapado por otro elemento en pantalla');
    }

    async tap(target, punto) {
        await this.execFn(['-s', target, 'shell', 'input', 'tap', String(punto.cx), String(punto.cy)]);
    }

    async escribir(target, texto) {
        const seguro = P.sanitizeTypedText(texto).replace(/\s/g, '%s');
        await this.execFn(['-s', target, 'shell', 'input', 'text', seguro]);
    }
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

function valorO(valor, porDefecto) {
    return valor !== undefined ? valor : porDefecto;
}

function espaciosColapsados(valor) {
    return String(valor || '').replace(/\s+/g, ' ').trim();
}

module.exports = { TelegramAdbChannel };
