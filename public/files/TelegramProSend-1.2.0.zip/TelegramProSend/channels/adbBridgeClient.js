/**
 * adbBridgeClient — cliente del puente ADB para el service worker.
 *
 * Vive en background.js y no en el popup porque el service worker sobrevive
 * al cierre del dashboard y ya traduce el progreso (`UPDATE_STATUS`), el
 * historial y el `campaignFinished` del canal Web: la campaña ADB corre en el
 * puente (Node, proceso propio) y aquí solo se controla su ciclo de vida por
 * WebSocket (ver spec §5.3). Lógica pura con socket inyectable para probar
 * sin puente ni Chrome reales.
 */

var _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

var URL_PUENTE = 'ws://127.0.0.1:8767';

var SIN_CAMPANIA_ADB = Object.freeze({ campaignId: '', campania: Object.freeze({ contacts: [] }), resultados: Object.freeze([]) });

/**
 * Casos Especiales sin `null`: el cliente nunca guarda ni compara `null`.
 * SOCKET_CERRADO finge la API mínima del WebSocket y su `send` informa
 * PUENTE_APAGADO; HOLA_AUSENTE equivale a "puente no contactado".
 */
var SOCKET_CERRADO = Object.freeze({
    send: function () { throw new Error('PUENTE_APAGADO'); },
    close: function () {}
});

var HOLA_AUSENTE = Object.freeze({ isolation: false, bridgeVersion: '' });

/**
 * Alinea los `results` del puente (orden de llegada) por índice de `contacts`.
 * Índices fuera de rango se ignoran. Huecos intermedios → `Error: no alcanzado`;
 * tras el último índice alcanzado no se rellena. Sin resultados → `[]`.
 */
function alinearResultados(contacts, results) {
    var lista = Array.isArray(contacts) ? contacts : [];
    var res = Array.isArray(results) ? results : [];
    if (res.length === 0) return [];
    var porIndice = {};
    var max = -1;
    res.forEach(function (r) {
        if (!r || typeof r.index !== 'number') return;
        if (r.index < 0 || r.index >= lista.length) return;
        porIndice[r.index] = r;
        if (r.index > max) max = r.index;
    });
    if (max < 0) return [];
    var salida = [];
    for (var i = 0; i <= max; i++) {
        if (porIndice[i]) {
            salida.push({ phone: porIndice[i].phone || '', status: porIndice[i].status, contactData: porIndice[i].contactData });
        } else {
            salida.push({ phone: '', status: 'Error: no alcanzado', contactData: lista[i] });
        }
    }
    return salida;
}

/**
 * Arma el item de historial de una campaña ADB terminada.
 */
function armarItemHistorial(campania, results, stopped, fecha) {
    var c = campania || {};
    var contactos = Array.isArray(c.contacts) ? c.contacts : [];
    return {
        date: fecha,
        contactCount: contactos.length,
        status: stopped ? 'Detenida' : 'Completada',
        contactResults: alinearResultados(contactos, results),
        channel: 'adb',
        contacts: contactos,
        messageTemplate: c.messageTemplate || '',
        messageVariants: c.messageVariants || [],
        imageDataUrl: '',
        config: c.config || {},
        enabledDevices: c.enabledDevices || []
    };
}

/**
 * Crea un cliente del puente con sus dependencias inyectadas.
 * Una sola conexión viva: se reutiliza el socket si ya recibió `connected`.
 */
function crearClientePuente(deps) {
    var d = deps || {};
    var crearSocket = d.crearSocket;
    var almacen = d.almacen;
    var avisar = typeof d.avisar === 'function' ? d.avisar : function () {};
    var guardarHistorial = typeof d.guardarHistorial === 'function' ? d.guardarHistorial : async function () {};
    var ahora = typeof d.ahora === 'function' ? d.ahora : function () { return Date.now(); };
    var esperaMs = d.esperaMs || 5000;

    var socket = SOCKET_CERRADO;
    var hola = HOLA_AUSENTE;
    var hayConexion = false;
    var promesaConexion;
    var conectando = false;
    var enEspera = [];

    /**
     * Cola de promesas que encadena el procesamiento de `progress`/`done`
     * y el cierre de `recuperar`, uno tras otro. Cada uno hace
     * leer→guardar sobre el almacén: en paralelo dos `progress` seguidos
     * se pisan y un `progress` tardío puede guardar la campaña DESPUÉS
     * de que `done` la borró. Las respuestas a `pedir()` no pasan por
     * aquí: se despachan en `manejarMensaje` antes de encolar.
     */
    var colaMensajes = Promise.resolve();

    function encolar(trabajo) {
        var hecho = colaMensajes.then(trabajo, trabajo);
        colaMensajes = hecho.catch(function () {});
        return hecho;
    }

    function quitarEnEspera(entrada) {
        var i = enEspera.indexOf(entrada);
        if (i !== -1) enEspera.splice(i, 1);
    }

    function fallarEnEspera(err) {
        var pendientes = enEspera.slice();
        enEspera = [];
        pendientes.forEach(function (e) { clearTimeout(e.timer); e.rechazar(err); });
    }

    function esperarTipos(tipos, ms) {
        return new Promise(function (resolver, rechazar) {
            var entrada = { tipos: tipos, resolver: resolver, rechazar: rechazar, timer: undefined };
            entrada.timer = setTimeout(function () {
                quitarEnEspera(entrada);
                rechazar(new Error('TIMEOUT'));
            }, typeof ms === 'number' ? ms : esperaMs);
            enEspera.push(entrada);
        });
    }

    function manejarCrudo(ev) {
        var msg;
        try {
            msg = JSON.parse(ev && ev.data);
        } catch (_) {
            return;
        }
        manejarMensaje(msg);
    }

    function conectar() {
        if (hayConexion) return Promise.resolve(socket);
        if (conectando) return promesaConexion;
        var s;
        try {
            s = crearSocket(URL_PUENTE);
        } catch (_) {
            return Promise.reject(new Error('PUENTE_APAGADO'));
        }
        socket = s;
        conectando = true;
        s.onopen = function () {};
        s.onerror = function () {};
        s.onclose = function () {
            if (s !== socket) return;
            socket = SOCKET_CERRADO;
            hola = HOLA_AUSENTE;
            hayConexion = false;
            fallarEnEspera(new Error('PUENTE_APAGADO'));
        };
        s.onmessage = function (ev) { manejarCrudo(ev); };
        promesaConexion = esperarTipos(['connected'], esperaMs).then(function (msg) {
            hola = msg;
            hayConexion = true;
            conectando = false;
            promesaConexion = undefined;
            return socket;
        }, function (err) {
            conectando = false;
            promesaConexion = undefined;
            try { s.close(); } catch (_) {}
            if (s === socket) {
                socket = SOCKET_CERRADO;
                hola = HOLA_AUSENTE;
                hayConexion = false;
            }
            throw err;
        });
        return promesaConexion;
    }

    function pedir(obj, tipos) {
        return conectar().then(function () {
            socket.send(JSON.stringify(obj));
            return esperarTipos(tipos, esperaMs);
        });
    }

    async function consultarEstado() {
        var apagado = { conectado: false, bridgeVersion: '', isolation: false, devices: [], error: 'PUENTE_APAGADO' };
        try {
            await conectar();
        } catch (_) {
            return apagado;
        }
        var resp;
        try {
            resp = await pedir({ type: 'list_devices' }, ['devices', 'error']);
        } catch (_) {
            return apagado;
        }
        if (resp.type === 'error') {
            return { conectado: true, bridgeVersion: hola.bridgeVersion || '', isolation: hola.isolation === true, devices: [], error: resp.message || resp.code || '' };
        }
        return {
            conectado: true,
            bridgeVersion: resp.bridgeVersion || hola.bridgeVersion || '',
            isolation: hola.isolation === true,
            devices: Array.isArray(resp.devices) ? resp.devices : [],
            error: ''
        };
    }

    async function iniciar(campania) {
        var c = campania || {};
        try {
            await conectar();
        } catch (_) {
            return { ok: false, code: 'PUENTE_APAGADO', message: 'El puente de celulares no está iniciado' };
        }
        if (hola.isolation !== true) {
            return { ok: false, code: 'BRIDGE_OUTDATED', message: 'Puente desactualizado: pulsa Reiniciar puente' };
        }
        var resp;
        try {
            resp = await pedir({
                type: 'start',
                contacts: c.contacts,
                template: c.messageTemplate,
                messageVariants: c.messageVariants,
                config: c.config,
                imageDataUrl: c.imageDataUrl,
                enabledDevices: Array.isArray(c.enabledDevices) ? c.enabledDevices : []
            }, ['started', 'error']);
        } catch (err) {
            if (err && err.message === 'PUENTE_APAGADO') {
                return { ok: false, code: 'PUENTE_APAGADO', message: 'El puente de celulares no está iniciado' };
            }
            return { ok: false, code: 'PUENTE_ERROR', message: (err && err.message) || String(err) };
        }
        if (resp.type === 'error') return { ok: false, code: resp.code, message: resp.message };
        await almacen.guardar({ campaignId: resp.campaignId, campania: c, resultados: [] });
        return { ok: true, campaignId: resp.campaignId, total: resp.total };
    }

    async function detener() {
        try {
            await conectar();
        } catch (_) {
            return { ok: false, code: 'PUENTE_APAGADO' };
        }
        socket.send(JSON.stringify({ type: 'stop' }));
        return { ok: true };
    }

    /**
     * Etiquetas visibles del resultado crudo del puente. En el service worker
     * son globales (`campaignEngine.js` va antes en `importScripts`); en Node
     * se cargan del motor.
     */
    function etiquetasResultado() {
        if (typeof displayResultLabel === 'function' && typeof resultColor === 'function') {
            return { etiqueta: displayResultLabel, color: resultColor };
        }
        var motor = require('../campaignEngine.js');
        return { etiqueta: motor.displayResultLabel, color: motor.resultColor };
    }

    /**
     * Cierra una campaña conocida como terminada: historial + borrar + ack.
     * El `ack` reutiliza o abre la conexión; si no hay puente se omite
     * (el puente reanuncia el resultado en `sinConfirmar` al reconectar).
     */
    async function finalizarAdb(estado, results, stopped) {
        await guardarHistorial(armarItemHistorial(estado.campania, results, stopped, ahora()));
        await almacen.borrar();
        try {
            await conectar();
            socket.send(JSON.stringify({ type: 'ack', campaignId: estado.campaignId }));
        } catch (_) {}
    }

    async function manejarMensaje(msg) {
        if (!msg || msg.type === 'ping') return;
        for (var i = 0; i < enEspera.length; i++) {
            if (enEspera[i].tipos.indexOf(msg.type) !== -1) {
                var entrada = enEspera[i];
                enEspera.splice(i, 1);
                clearTimeout(entrada.timer);
                entrada.resolver(msg);
                return;
            }
        }
        if (msg.type === 'progress') {
            return encolar(function () { return aplicarProgress(msg); });
        }
        if (msg.type === 'done') {
            return encolar(function () { return aplicarDone(msg); });
        }
    }

    async function aplicarProgress(msg) {
        var estado = await almacen.leer();
        if (!estado || estado.campaignId === '' || msg.campaignId !== estado.campaignId) return;
        var resultados = Array.isArray(estado.resultados) ? estado.resultados.slice() : [];
        for (var k = 0; k < msg.index; k++) {
            if (resultados[k] === undefined) resultados[k] = '';
        }
        resultados[msg.index] = msg.status;
        await almacen.guardar({ campaignId: estado.campaignId, campania: estado.campania, resultados: resultados });
        var etiquetas = etiquetasResultado();
        avisar({ action: 'UPDATE_STATUS', index: msg.index, status: etiquetas.etiqueta(msg.status), color: etiquetas.color(msg.status) });
    }

    async function aplicarDone(msg) {
        var est = await almacen.leer();
        if (!est || est.campaignId === '' || msg.campaignId !== est.campaignId) return;
        await finalizarAdb(est, msg.results, msg.stopped);
    }

    /**
     * Recupera la campaña guardada tras la muerte del SW: pregunta `status`
     * al puente y cierra o sigue según lo que el puente aún sepa.
     */
    async function recuperar() {
        var estado = await almacen.leer();
        if (!estado || estado.campaignId === '') return;
        try {
            await conectar();
        } catch (_) {
            return;
        }
        var resp;
        try {
            resp = await pedir({ type: 'status' }, ['status', 'error']);
        } catch (_) {
            return;
        }
        if (!resp || resp.type === 'error') return;
        await encolar(function () { return cierreRecuperar(estado.campaignId, resp); });
    }

    /**
     * Cierra la campaña guardada según lo que el puente aún sepa.
     * Corre dentro de la cola para no entrelazarse con un `progress`
     * o `done` en vuelo: relee el almacén en su turno.
     */
    async function cierreRecuperar(campaignId, resp) {
        var estado = await almacen.leer();
        if (!estado || estado.campaignId === '' || estado.campaignId !== campaignId) return;
        var sinConfirmar = Array.isArray(resp.sinConfirmar) ? resp.sinConfirmar : [];
        var pendiente;
        for (var i = 0; i < sinConfirmar.length; i++) {
            if (sinConfirmar[i] && sinConfirmar[i].campaignId === estado.campaignId) pendiente = sinConfirmar[i];
        }
        if (pendiente) {
            await finalizarAdb(estado, pendiente.results, pendiente.stopped);
            return;
        }
        if (resp.isRunning && resp.campaignId === estado.campaignId) return;
        var conocidos = Array.isArray(estado.resultados) ? estado.resultados : [];
        var contactos = estado.campania && Array.isArray(estado.campania.contacts) ? estado.campania.contacts : [];
        var conv = [];
        for (var j = 0; j < conocidos.length; j++) {
            if (conocidos[j] === undefined || conocidos[j] === '') continue;
            conv.push({ index: j, phone: '', status: conocidos[j], contactData: contactos[j] });
        }
        await guardarHistorial(armarItemHistorial(estado.campania, conv, true, ahora()));
        await almacen.borrar();
    }

    async function estadoCampania() {
        var estado = await almacen.leer();
        if (!estado || estado.campaignId === '') {
            return { isRunning: false, isPaused: false, progressIndex: 0, total: 0, results: [], channel: 'adb' };
        }
        var resultados = Array.isArray(estado.resultados) ? estado.resultados.slice() : [];
        for (var i = 0; i < resultados.length; i++) {
            if (resultados[i] === undefined) resultados[i] = '';
        }
        var hechos = 0;
        resultados.forEach(function (r) { if (r !== '') hechos++; });
        var contactos = estado.campania && Array.isArray(estado.campania.contacts) ? estado.campania.contacts : [];
        return { isRunning: true, isPaused: false, progressIndex: hechos, total: contactos.length, results: resultados, channel: 'adb' };
    }

    return { consultarEstado: consultarEstado, iniciar: iniciar, detener: detener, recuperar: recuperar, estadoCampania: estadoCampania, manejarMensaje: manejarMensaje };
}

_root.AdbBridgeClient = _root.AdbBridgeClient || {
    crearClientePuente: crearClientePuente,
    SIN_CAMPANIA_ADB: SIN_CAMPANIA_ADB,
    URL_PUENTE: URL_PUENTE,
    alinearResultados: alinearResultados,
    armarItemHistorial: armarItemHistorial
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        crearClientePuente: crearClientePuente,
        SIN_CAMPANIA_ADB: SIN_CAMPANIA_ADB,
        URL_PUENTE: URL_PUENTE,
        alinearResultados: alinearResultados,
        armarItemHistorial: armarItemHistorial
    };
}
