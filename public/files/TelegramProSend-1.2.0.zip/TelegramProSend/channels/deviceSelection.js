/**
 * deviceSelection — celulares habilitados para el puente ADB de Telegram.
 *
 * Portado de docs/referencia-sms-pro/channels/deviceSelection.js (solo las
 * funciones que usa Telegram: lista de habilitados, no de aislados).
 * Funciones puras, sin chrome.* ni adb — compartidas por dashboard y puente.
 */

var _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

_root.DeviceSelection = _root.DeviceSelection || {};

/**
 * Seriales conectados que además están habilitados.
 * Entradas no-array -> [] (nunca null).
 */
function selectEnabledTargets(connected, enabled) {
    var connectedList = Array.isArray(connected) ? connected : [];
    var enabledSet = new Set(Array.isArray(enabled) ? enabled : []);
    return connectedList.filter(function (serial) { return enabledSet.has(serial); });
}

/**
 * Canal que expone solo los targets habilitados. El resto de métodos se
 * hereda por prototipo del canal real, así campaignEngine no cambia.
 */
function withEnabledTargets(channel, enabled) {
    var filtered = Object.create(channel);
    filtered.listTargets = async function () {
        return selectEnabledTargets(await channel.listTargets(), enabled);
    };
    return filtered;
}

/**
 * Estado del puente según su mensaje `connected`. UNKNOWN mientras no hay
 * conexión o hello: no es lo mismo un puente apagado que uno viejo.
 */
var BridgeIsolation = Object.freeze({
    UNKNOWN: 'unknown',
    SUPPORTED: 'supported',
    UNSUPPORTED: 'unsupported'
});

/**
 * Un puente anterior al handshake no trae `isolation:true`: arrancar contra
 * él enviaría por todos los teléfonos.
 */
function bridgeIsolationFromHello(hello) {
    return !!hello && hello.isolation === true ? BridgeIsolation.SUPPORTED : BridgeIsolation.UNSUPPORTED;
}

function canStartAdbCampaign(state) {
    return state === BridgeIsolation.SUPPORTED;
}

/**
 * Aviso solo ante un puente que respondió sin aislamiento. Reiniciar relanza
 * el server.js de la carpeta registrada en el host: si el aviso persiste hay
 * que ejecutar install.exe de la versión nueva.
 */
function bridgeIsolationWarning(state) {
    if (state !== BridgeIsolation.UNSUPPORTED) return '';
    return 'Puente ADB desactualizado (no respeta los celulares habilitados). ' +
        'Pulsa "Reiniciar puente"; si el aviso persiste, ejecuta native-launcher\\install.exe de la versión nueva.';
}

_root.DeviceSelection.selectEnabledTargets = selectEnabledTargets;
_root.DeviceSelection.withEnabledTargets = withEnabledTargets;
_root.DeviceSelection.BridgeIsolation = BridgeIsolation;
_root.DeviceSelection.bridgeIsolationFromHello = bridgeIsolationFromHello;
_root.DeviceSelection.canStartAdbCampaign = canStartAdbCampaign;
_root.DeviceSelection.bridgeIsolationWarning = bridgeIsolationWarning;

// Export dual como ui/utils.js: Node (puente/tests) + globalThis (dashboard/plan 3)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        selectEnabledTargets: selectEnabledTargets,
        withEnabledTargets: withEnabledTargets,
        BridgeIsolation: BridgeIsolation,
        bridgeIsolationFromHello: bridgeIsolationFromHello,
        canStartAdbCampaign: canStartAdbCampaign,
        bridgeIsolationWarning: bridgeIsolationWarning
    };
}
