/**
 * telegramAdbPantallas.js — Parsers puros de dumps de uiautomator de la app
 * nativa de Telegram. Sin adb ni chrome.*: todo se prueba con fixtures reales
 * de channels/fixtures/.
 *
 * Telegram casi no expone resource-id: se ubican nodos por content-desc y
 * text. Las búsquedas sin resultado devuelven NODO_AUSENTE (Caso Especial).
 */

const Utils = require('../ui/utils.js');

const NODO_AUSENTE = Object.freeze({
    encontrado: false,
    text: '',
    contentDesc: '',
    className: '',
    clickable: false,
    bounds: Object.freeze({ x1: 0, y1: 0, x2: 0, y2: 0, cx: 0, cy: 0 })
});

function parseNodes(xml) {
    const nodos = [];
    const re = /<node\s([^>]*?)\/?>/g;
    let m;
    while ((m = re.exec(String(xml || '')))) {
        const attrs = leerAtributos(m[1]);
        const b = /\[(\d+),(\d+)\]\[(\d+),(\d+)\]/.exec(attrs.bounds || '');
        if (!b) continue;
        nodos.push({
            encontrado: true,
            text: attrs.text || '',
            contentDesc: attrs['content-desc'] || '',
            className: attrs.class || '',
            clickable: attrs.clickable === 'true',
            bounds: boundsDesde(b.slice(1).map(Number))
        });
    }
    return nodos;
}

function findByDesc(nodos, desc) {
    return nodos.find(n => n.contentDesc === desc) || NODO_AUSENTE;
}

function findByText(nodos, text, className = '') {
    return nodos.find(n => n.text === text && (!className || n.className === className)) || NODO_AUSENTE;
}

function findByTextIncludes(nodos, fragmento) {
    return nodos.find(n => n.text.includes(fragmento)) || NODO_AUSENTE;
}

function editTexts(nodos) {
    return nodos.filter(n => n.className === 'android.widget.EditText');
}

const PANTALLAS = Object.freeze({
    listaChats: 'listaChats',
    permisoContactos: 'permisoContactos',
    nuevoMensaje: 'nuevoMensaje',
    nuevoContacto: 'nuevoContacto',
    perfil: 'perfil',
    chat: 'chat',
    noEncontrado: 'noEncontrado',
    desconocida: 'desconocida'
});

/**
 * Decide en qué pantalla está Telegram. El orden importa: los diálogos se
 * evalúan antes que la pantalla que tienen detrás.
 */
function screenOf(nodos) {
    const hay = nodo => nodo.encontrado;
    if (hay(findByText(nodos, 'Invitar a Telegram'))) return PANTALLAS.noEncontrado;
    if (hay(findByTextIncludes(nodos, 'necesita acceso a tus contactos'))) return PANTALLAS.permisoContactos;
    if (hay(findByText(nodos, 'Nuevo contacto')) && hay(findByDesc(nodos, 'Número de teléfono'))) return PANTALLAS.nuevoContacto;
    if (hay(findByText(nodos, 'Mensaje', 'android.widget.Button')) && hay(findByTextIncludes(nodos, 'Móvil:'))) return PANTALLAS.perfil;
    if (editTexts(nodos).length > 0 && (hay(findByDesc(nodos, 'Adjuntar multimedia')) || hay(findByDesc(nodos, 'Enviar')))) return PANTALLAS.chat;
    if (hay(findByDesc(nodos, 'Crear nuevo contacto'))) return PANTALLAS.nuevoMensaje;
    if (hay(findByDesc(nodos, 'Nuevo mensaje')) && hay(findByDesc(nodos, 'Buscar chats'))) return PANTALLAS.listaChats;
    return PANTALLAS.desconocida;
}

const PAIS_POR_DEFECTO = '593';
const CLAVE_CEDULA = /^(cedula|identificacion)$/;

function nationalNumber(phone, countryCode = PAIS_POR_DEFECTO) {
    const intl = Utils.toInternationalDigits(phone, countryCode);
    if (!intl) throw new Error('TELEGRAM_NOT_FOUND: número inválido ' + phone);
    if (!intl.startsWith(countryCode)) {
        throw new Error('TELEGRAM_ADB_PAIS_NO_SOPORTADO: el canal ADB solo envía a +' + countryCode + ', recibido ' + phone);
    }
    return intl.slice(countryCode.length);
}

function contactNameFor(contact, phone) {
    const datos = contact || {};
    const clave = Object.keys(datos).find(k => CLAVE_CEDULA.test(sinTildes(k).toLowerCase()));
    const cedula = clave ? String(datos[clave]).replace(/\D/g, '') : '';
    return cedula || Utils.toInternationalDigits(phone, PAIS_POR_DEFECTO);
}

/**
 * `adb shell input text` corre bajo `sh -c` (riesgo de inyección) y aborta
 * ante cualquier no-ASCII: se transcriben tildes y se quitan metacaracteres.
 * Los saltos de línea se vuelven un espacio (colapsando repetidos) para no
 * pegar palabras al escribir.
 */
function sanitizeTypedText(value) {
    if (value === null || value === undefined) return '';
    const ascii = sinTildes(String(value)).replace(/[^\x00-\x7F]/g, '');
    const conEspacios = ascii.replace(/\r\n|\n|\r/g, ' ');
    const sinMetacaracteres = conEspacios.replace(/['";&|$`<>(){}\\]/g, '');
    return sinMetacaracteres.replace(/ {2,}/g, ' ');
}

function parseDevices(salida) {
    return String(salida || '')
        .split('\n')
        .slice(1)
        .map(l => l.trim().split(/\s+/))
        .filter(partes => partes.length >= 2 && partes[1] === 'device')
        .map(partes => partes[0]);
}

/** El enlace "View >" es el final del texto: se toca a 1,5 alturas del borde derecho. */
function linkTapPoint(bounds) {
    const alto = bounds.y2 - bounds.y1;
    return { cx: bounds.x2 - Math.round(alto * 1.5), cy: bounds.cy };
}

/** El icono Enviar es el cuadrado derecho del nodo: el centro cae sobre el EditText y no envía. */
function sendTapPoint(bounds) {
    const alto = bounds.y2 - bounds.y1;
    return { cx: bounds.x2 - Math.round(alto / 2), cy: bounds.cy };
}

/**
 * Nodo clicable dibujado encima del punto de un toque: el primero tras
 * `objetivo` (orden del XML = orden de dibujo) que contiene el punto sin
 * ser hijo suyo (no contenido en sus bounds). Sin tapa, Caso Especial.
 */
function nodoQueTapa(nodos, objetivo, punto) {
    const lista = nodos || [];
    const desde = lista.indexOf(objetivo);
    if (desde < 0) return NODO_AUSENTE;
    const cx = punto ? punto.cx : undefined;
    const cy = punto ? punto.cy : undefined;
    for (let i = desde + 1; i < lista.length; i++) {
        const n = lista[i];
        if (!n.clickable) continue;
        const b = n.bounds;
        if (!(b.x1 <= cx && cx < b.x2 && b.y1 <= cy && cy < b.y2)) continue;
        const o = objetivo.bounds;
        if (b.x1 >= o.x1 && b.y1 >= o.y1 && b.x2 <= o.x2 && b.y2 <= o.y2) continue;
        return n;
    }
    return NODO_AUSENTE;
}

function profilePhoneMatches(nodos, nacional) {
    const movil = findByTextIncludes(nodos, 'Móvil:');
    return movil.encontrado && movil.text.replace(/\D/g, '').endsWith(nacional);
}

function chatHeaderName(nodos) {
    const cabecera = nodos.find(n => n.className === 'android.widget.FrameLayout' && n.contentDesc.includes('\n'));
    return cabecera ? cabecera.contentDesc.split('\n')[0] : '';
}

function composerText(nodos) {
    const campo = editTexts(nodos)[0];
    return campo ? campo.text : '';
}

/** El dump pertenece a Telegram si declara su paquete (splash/launcher son de otro paquete). */
function esDeTelegram(xml) {
    return String(xml || '').includes('package="org.telegram.messenger"');
}

const BURBUJA_ENVIADA_AUSENTE = Object.freeze({ encontrada: false, texto: '' });

/**
 * Burbuja enviada más reciente: nodos con "\nEnviado a las", el de mayor
 * bounds.y2. `texto` es el primer renglón (el resto es la hora de envío).
 * Sin burbuja devuelve el Caso Especial, nunca null.
 */
function ultimaBurbujaEnviada(nodos) {
    const enviadas = (nodos || []).filter(n => n.text.includes('\nEnviado a las'));
    if (enviadas.length === 0) return BURBUJA_ENVIADA_AUSENTE;
    const ultima = enviadas.reduce((anterior, actual) => (actual.bounds.y2 > anterior.bounds.y2 ? actual : anterior));
    return { encontrada: true, texto: ultima.text.split('\n')[0] };
}

// ── Detalles ────────────────────────────────────────────────────────

function leerAtributos(fuente) {
    const attrs = {};
    const re = /([\w-]+)="([^"]*)"/g;
    let m;
    while ((m = re.exec(fuente))) {
        attrs[m[1]] = decodificarEntidades(m[2]);
    }
    return attrs;
}

function decodificarEntidades(valor) {
    return valor
        .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&apos;/g, "'")
        .replace(/&amp;/g, '&');
}

function boundsDesde([x1, y1, x2, y2]) {
    return { x1, y1, x2, y2, cx: Math.round((x1 + x2) / 2), cy: Math.round((y1 + y2) / 2) };
}

function sinTildes(texto) {
    return texto.normalize('NFD').replace(/[̀-ͯ]/g, '');
}

module.exports = {
    NODO_AUSENTE,
    PANTALLAS,
    parseNodes,
    findByDesc,
    findByText,
    findByTextIncludes,
    editTexts,
    screenOf,
    nationalNumber,
    contactNameFor,
    sanitizeTypedText,
    parseDevices,
    linkTapPoint,
    sendTapPoint,
    nodoQueTapa,
    profilePhoneMatches,
    chatHeaderName,
    composerText,
    esDeTelegram,
    ultimaBurbujaEnviada
};
