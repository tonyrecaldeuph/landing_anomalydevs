/**
 * Respaldo exportable del dashboard (historial, promociones y dispositivo).
 * Existe porque la migración de ID de la 1.2.0 borra el `chrome.storage`
 * de la extensión actual: el cliente descarga este `.json` antes y lo
 * reimporta en la nueva versión. Módulo puro (sin `chrome`, sin DOM).
 */

var _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

_root.Respaldo = _root.Respaldo || {
    CLAVES: ['history', 'promotions', 'licenseDeviceId'],

    /**
     * Arma el objeto de respaldo con el formato exacto de la 1.1.4.
     * Solo lee `history`, `promotions` y `licenseDeviceId`; la clave
     * y el estado de licencia nunca se exportan. Faltantes o tipos
     * inválidos se reemplazan por `[]` o `''` (sin null).
     * @param {Object} datos - Lo devuelto por `chrome.storage.local.get(CLAVES)`.
     * @param {string} exportadoEn - Fecha ISO de exportación.
     * @param {string} versionExtension - Versión del manifest.
     * @returns {Object} - Respaldo listo para `JSON.stringify`.
     */
    armar(datos, exportadoEn, versionExtension) {
        const fuente = datos || {};
        return {
            formato: 1,
            producto: 'TelegramProSend',
            versionExtension: versionExtension,
            exportadoEn: exportadoEn,
            history: Array.isArray(fuente.history) ? fuente.history : [],
            promotions: Array.isArray(fuente.promotions) ? fuente.promotions : [],
            licenseDeviceId: typeof fuente.licenseDeviceId === 'string' ? fuente.licenseDeviceId : ''
        };
    },

    /**
     * Nombre del archivo a descargar a partir de la fecha de exportación (UTC).
     * @param {string} exportadoEn - Fecha ISO de exportación.
     * @returns {string} - `TelegramProSend-respaldo-AAAA-MM-DD.json`.
     */
    nombreArchivo(exportadoEn) {
        return 'TelegramProSend-respaldo-' + String(exportadoEn).slice(0, 10) + '.json';
    },

    /**
     * Valida un objeto leído de un `.json` como respaldo de la 1.1.4.
     * Normaliza tipos igual que `armar` (no arreglos → `[]`, no string → `''`).
     * @param {Object} objeto - Lo devuelto por `JSON.parse` del archivo.
     * @returns {Object} - `{ ok, motivo, datos: { history, promotions, licenseDeviceId } }`.
     */
    validar(objeto) {
        const fuente = (objeto && typeof objeto === 'object') ? objeto : {};
        const datos = {
            history: Array.isArray(fuente.history) ? fuente.history : [],
            promotions: Array.isArray(fuente.promotions) ? fuente.promotions : [],
            licenseDeviceId: typeof fuente.licenseDeviceId === 'string' ? fuente.licenseDeviceId : ''
        };
        if (fuente.formato !== 1 || fuente.producto !== 'TelegramProSend') {
            return {
                ok: false,
                motivo: 'El archivo no es un respaldo de TelegramProSend',
                datos: { history: [], promotions: [], licenseDeviceId: '' }
            };
        }
        return { ok: true, motivo: '', datos };
    },

    /**
     * Fusiona un respaldo validado con lo que ya hay en el storage.
     * @param {Object} actual - `{ history, promotions, licenseDeviceId, licenseKey }` del storage.
     * @param {Object} datos - `datos` de `validar`.
     * @returns {Object} - `{ cambios, avisos }` (`cambios` listo para `storage.set`).
     */
    fusionar(actual, datos) {
        const base = actual || {};
        const nuevos = datos || {};
        const historiaActual = Array.isArray(base.history) ? base.history : [];
        const historiaNueva = Array.isArray(nuevos.history) ? nuevos.history : [];
        const fechas = new Set(historiaActual.map((item) => (item && item.date) || ''));
        const sumadas = historiaNueva.filter((item) => !fechas.has((item && item.date) || ''));
        const historia = historiaActual.concat(sumadas).sort((a, b) => {
            const fa = (a && a.date) || '';
            const fb = (b && b.date) || '';
            if (fb < fa) return -1;
            if (fb > fa) return 1;
            return 0;
        });
        const promosActuales = Array.isArray(base.promotions) ? base.promotions : [];
        const promosNuevas = Array.isArray(nuevos.promotions) ? nuevos.promotions : [];
        const ids = new Set(promosActuales.map((promo) => (promo && promo.id) || ''));
        const agregadas = promosNuevas.filter((promo) => !ids.has((promo && promo.id) || ''));
        const cambios = { history: historia, promotions: promosActuales.concat(agregadas) };
        const avisos = [];
        const conLicencia = typeof base.licenseKey === 'string' && base.licenseKey !== '';
        const dispositivo = typeof nuevos.licenseDeviceId === 'string' ? nuevos.licenseDeviceId : '';
        if (!conLicencia && dispositivo !== '') {
            cambios.licenseDeviceId = dispositivo;
        } else if (conLicencia) {
            avisos.push('La licencia ya está activada en esta versión: se conservó el dispositivo actual');
        }
        avisos.push('Campañas importadas: ' + sumadas.length + '. Promociones importadas: ' + agregadas.length + '.');
        return { cambios, avisos };
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = _root.Respaldo;
}
