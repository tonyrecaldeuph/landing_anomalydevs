/**
 * canalEnvio — reglas puras del canal de envío (Telegram Web / Celular ADB).
 *
 * Existe porque el dashboard y el service worker deben decidir lo mismo sin
 * duplicar condiciones: qué canal está activo, si el botón Enviar se habilita
 * y con qué motivo se bloquea, y qué textos muestran el puente y el lanzador
 * nativo. Módulo puro (sin `chrome`, sin DOM, sin red).
 */

var _root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

function _selectEnabledTargets(conectados, habilitados) {
    if (_root.DeviceSelection && typeof _root.DeviceSelection.selectEnabledTargets === 'function') {
        return _root.DeviceSelection.selectEnabledTargets(conectados, habilitados);
    }
    if (typeof require === 'function') {
        return require('../channels/deviceSelection.js').selectEnabledTargets(conectados, habilitados);
    }
    return [];
}

_root.CanalEnvio = _root.CanalEnvio || {
    CANALES: { WEB: 'web', ADB: 'adb' },

    HOST_NATIVO: 'com.anomalydevs.telegrampro.adblauncher',

    PUENTE_APAGADO: Object.freeze({ conectado: false, bridgeVersion: '', isolation: false, devices: [], error: '' }),

    normalizarCanal(valor) {
        return valor === 'adb' ? 'adb' : 'web';
    },

    /**
     * Canal con el que se lanza una campaña: el pedido explícito (Retomar
     * usa el canal del item del historial) gana sobre el de la pantalla.
     */
    canalDeLanzamiento(pedido, actual) {
        if (pedido === 'adb' || pedido === 'web') return pedido;
        return this.normalizarCanal(actual);
    },

    decidirEnvio(e) {
        const entrada = e || {};
        const canal = this.normalizarCanal(entrada.canal);
        const contactos = entrada.contactos;
        const puente = entrada.puente || this.PUENTE_APAGADO;
        const habilitados = Array.isArray(entrada.habilitados) ? entrada.habilitados : [];
        if (!(contactos > 0)) return { permitido: false, motivo: 'Carga una lista de contactos' };
        if (!entrada.licenciaOk) return { permitido: false, motivo: 'Licencia no válida' };
        if (canal === 'web') {
            if (!entrada.webOnline) return { permitido: false, motivo: 'Abre Telegram Web e inicia sesión' };
            return { permitido: true, motivo: '' };
        }
        if (!puente.conectado) return { permitido: false, motivo: 'Inicia el puente de celulares' };
        if (puente.isolation !== true) return { permitido: false, motivo: 'Puente desactualizado: pulsa Reiniciar puente' };
        if (entrada.conImagen) return { permitido: false, motivo: 'Las campañas con imagen aún no se envían por celular: quita la imagen o usa Telegram Web' };
        if (_selectEnabledTargets(puente.devices, habilitados).length === 0) {
            return { permitido: false, motivo: 'Habilita al menos un celular conectado' };
        }
        return { permitido: true, motivo: '' };
    },

    textoPuente(puente) {
        const p = puente || this.PUENTE_APAGADO;
        if (!p.conectado) return 'Detenido';
        if (p.isolation !== true) return 'Desactualizado';
        return 'Conectado v' + p.bridgeVersion;
    },

    /**
     * Decide qué mostrar en `#puente-aviso` al refrescar el estado sin
     * borrar el aviso que dejó `accionPuente` (Iniciar/Detener…).
     * Solo pisa con el aviso de aislamiento nuevo; solo limpia si lo que
     * se muestra todavía es el aislamiento anterior. Nunca devuelve null.
     */
    avisoPuente(avisoActual, avisoAislamientoAnterior, avisoAislamientoNuevo) {
        const actual = typeof avisoActual === 'string' ? avisoActual : '';
        const anterior = typeof avisoAislamientoAnterior === 'string' ? avisoAislamientoAnterior : '';
        const nuevo = typeof avisoAislamientoNuevo === 'string' ? avisoAislamientoNuevo : '';
        if (nuevo !== '') return nuevo;
        if (actual === anterior) return '';
        return actual;
    },

    textoLauncher(respuesta, errorChrome) {
        const resp = respuesta || {};
        if (typeof errorChrome === 'string' && errorChrome !== '') {
            if (errorChrome.indexOf('not found') !== -1) {
                return { ok: false, texto: 'Falta instalar el puente: ejecuta native-launcher\\install.exe' };
            }
            return { ok: false, texto: errorChrome };
        }
        if (resp.error) return { ok: false, texto: resp.error };
        if (resp.alreadyRunning) return { ok: true, texto: 'El puente ya estaba iniciado' };
        if (resp.started) return { ok: true, texto: 'Puente iniciado' };
        if (resp.stopped === false) return { ok: false, texto: 'No se pudo detener el puente: reinicia el PC o ciérralo desde el Administrador de tareas (node.exe)' };
        if (resp.stopped) return { ok: true, texto: 'Puente detenido' };
        if (resp.restarted) return { ok: true, texto: 'Puente reiniciado' };
        return { ok: true, texto: '' };
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = _root.CanalEnvio;
}
