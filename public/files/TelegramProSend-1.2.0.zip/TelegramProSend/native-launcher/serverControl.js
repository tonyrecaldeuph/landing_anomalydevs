/**
 * serverControl — arranca/detiene/reinicia el puente de Telegram
 * (bridge/server.js) como proceso independiente, y reporta si está corriendo.
 * Vive detrás del Native Messaging Host (launcher.js) para que el botón del
 * dashboard pueda controlarlo sin que el usuario abra una terminal.
 *
 * Testeable sin procesos reales vía inyección de dependencias (spawn/kill/
 * isPortOpen), mismo patrón que TelegramAdbChannel.execFn.
 */

const { spawn } = require('child_process');
const net = require('net');
const fs = require('fs');
const path = require('path');

const SERVER_DIR = path.join(__dirname, '..', 'bridge');
const SERVER_ENTRY = path.join(SERVER_DIR, 'server.js');
const PIDFILE = path.join(SERVER_DIR, '.server.pid');
const LOGFILE = path.join(SERVER_DIR, 'server.log');
const REGISTER_PS1 = path.join(__dirname, 'register.ps1');
const PORT = 8767;

function isPortOpen(port, host, timeoutMs) {
    const h = host || '127.0.0.1';
    const espera = timeoutMs !== undefined ? timeoutMs : 800;
    return new Promise((resolve) => {
        const socket = new net.Socket();
        let done = false;
        const finish = (result) => {
            if (done) return;
            done = true;
            socket.destroy();
            resolve(result);
        };
        socket.setTimeout(espera);
        socket.once('connect', () => finish(true));
        socket.once('timeout', () => finish(false));
        socket.once('error', () => finish(false));
        socket.connect(port, h);
    });
}

function readPid(readFileFn) {
    const leer = readFileFn || fs.readFileSync;
    try {
        const raw = leer(PIDFILE, 'utf-8').trim();
        const pid = parseInt(raw, 10);
        return Number.isInteger(pid) ? pid : 0;
    } catch (_) {
        return 0;
    }
}

function writePid(pid, writeFileFn) {
    (writeFileFn || fs.writeFileSync)(PIDFILE, String(pid));
}

function clearPidfile(unlinkFn) {
    try { (unlinkFn || fs.unlinkSync)(PIDFILE); } catch (_) { /* ya no existía */ }
}

async function statusCheck(deps) {
    const d = deps || {};
    const portOpen = await (d.isPortOpen || isPortOpen)(PORT);
    return { running: portOpen, pid: readPid(d.readFile) };
}

/** @returns {number} pid del proceso arrancado (sin tocar el pidfile: el puente lo escribe al escuchar) */
function startServer(deps) {
    const d = deps || {};
    const spawnFn = d.spawn || spawn;
    const openLogFn = d.openLog || ((file) => fs.openSync(file, 'a'));
    const logFd = openLogFn(LOGFILE);
    const child = spawnFn(process.execPath, [SERVER_ENTRY], {
        cwd: SERVER_DIR,
        detached: true,
        stdio: ['ignore', logFd, logFd],
        windowsHide: true
    });
    child.unref();
    return child.pid;
}

/**
 * Extrae de una salida de `netstat -ano` el pid de la línea
 * `TCP 127.0.0.1:<puerto> ... LISTENING <pid>`. Devuelve 0 si no hay.
 */
function extraerPidDeNetstat(salida, puerto) {
    const texto = typeof salida === 'string' ? salida : '';
    const lineas = texto.split(/\r?\n/);
    const buscado = '127.0.0.1:' + puerto;
    for (const linea of lineas) {
        const partes = linea.trim().split(/\s+/);
        if (partes.length < 4) continue;
        if (partes[0].toUpperCase() !== 'TCP') continue;
        if (partes[1] !== buscado) continue;
        if (partes[partes.length - 2].toUpperCase() !== 'LISTENING') continue;
        const pid = parseInt(partes[partes.length - 1], 10);
        if (Number.isInteger(pid) && pid > 0) return pid;
    }
    return 0;
}

/** Pid que escucha en 127.0.0.1:<puerto> según `netstat -ano`; 0 si ninguno. Nunca lanza. */
async function pidEnPuerto(puerto, deps) {
    const d = deps || {};
    try {
        const ejecutar = d.execNetstat || (() => require('child_process').execSync('netstat -ano', { encoding: 'utf-8', windowsHide: true }));
        return extraerPidDeNetstat(await ejecutar(), puerto);
    } catch (_) {
        return 0;
    }
}

/**
 * Detiene el puente matando SOLO al proceso que escucha en el puerto
 * (según `netstat -ano`): en Windows `kill(pid, 'SIGTERM')` es
 * TerminateProcess y el puente muere sin limpiar, así que matar el pid
 * del pidfile a ciegas deja un pidfile con un pid muerto que Windows
 * puede reasignar a otro programa. Por eso: si el puerto está cerrado
 * no se mata nada (se borra el pidfile y listo); si está abierto se
 * mata únicamente al que lo escucha, y solo si `netstat` falló (pid 0)
 * se usa el pid del pidfile como respaldo. Espera hasta 3 s a que el
 * puerto 8767 se libere.
 * @returns {Promise<{stopped: boolean}>} true solo si el puerto quedó cerrado.
 */
async function stopServer(deps) {
    const d = deps || {};
    const killFn = d.kill || process.kill;
    const puertoAbierto = d.isPortOpen || isPortOpen;
    const buscarPid = d.pidEnPuerto || pidEnPuerto;
    const esperar = d.sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
    const borrar = () => clearPidfile(d.unlink);
    if (!(await puertoAbierto(PORT))) {
        borrar();
        return { stopped: true };
    }
    let escuchando = 0;
    try {
        escuchando = await buscarPid(PORT);
    } catch (_) {
        escuchando = 0;
    }
    const objetivo = escuchando || readPid(d.readFile);
    if (objetivo) {
        try { killFn(objetivo, 'SIGTERM'); } catch (_) { /* ya había muerto */ }
    }
    borrar();
    for (let i = 0; i < 15; i++) {
        if (!(await puertoAbierto(PORT))) return { stopped: true };
        await esperar(200);
    }
    return { stopped: !(await puertoAbierto(PORT)) };
}

async function restartServer(deps) {
    const d = deps || {};
    await stopServer(d);
    return startServer(d);
}

/**
 * Re-corre register.ps1 (resuelve adb.exe/node.exe otra vez y regenera
 * launcher.generated.bat) para cuando el usuario reinstala/mueve adb en
 * una máquina donde el Native Messaging Host ya estaba registrado antes.
 *
 * NO sirve para el registro inicial: sendNativeMessage exige que el
 * manifest ya exista en HKCU\...\NativeMessagingHosts para poder lanzar
 * este mismo launcher — ese primer registro sigue siendo manual
 * (ejecutar register.ps1 a mano), documentado en README.md.
 */
function registerHost(deps) {
    const d = deps || {};
    const spawnFn = d.spawn || spawn;
    return new Promise((resolve) => {
        const child = spawnFn('powershell.exe', [
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', REGISTER_PS1
        ], { windowsHide: true });
        let stdout = '';
        let stderr = '';
        child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
        child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
        child.on('error', (err) => resolve({ ok: false, code: null, stdout, stderr: err.message }));
        child.on('close', (code) => resolve({ ok: code === 0, code, stdout: stdout.trim(), stderr: stderr.trim() }));
    });
}

module.exports = {
    isPortOpen,
    statusCheck,
    startServer,
    stopServer,
    restartServer,
    registerHost,
    readPid,
    pidEnPuerto,
    extraerPidDeNetstat,
    PIDFILE,
    LOGFILE,
    SERVER_ENTRY,
    SERVER_DIR,
    REGISTER_PS1,
    PORT
};
